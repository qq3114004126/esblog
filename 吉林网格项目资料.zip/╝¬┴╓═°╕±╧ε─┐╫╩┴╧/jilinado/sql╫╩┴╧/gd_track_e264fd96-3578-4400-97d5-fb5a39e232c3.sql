/*
Navicat MySQL Data Transfer

Source Server         : ai4a_10.161.124.150_22035_ucadmin
Source Server Version : 50723
Source Host           : 10.161.124.150:22035
Source Database       : gd_track_e264fd96-3578-4400-97d5-fb5a39e232c3

Target Server Type    : MYSQL
Target Server Version : 50723
File Encoding         : 65001

Date: 2020-04-26 11:12:17
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for sign_in_t
-- ----------------------------
DROP TABLE IF EXISTS `sign_in_t`;
CREATE TABLE `sign_in_t` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `tenant_code` varchar(50) DEFAULT NULL COMMENT '租户编码',
  `uid` varchar(50) NOT NULL COMMENT '用户账号',
  `user_id` varchar(50) DEFAULT NULL COMMENT '用户Id',
  `date` date NOT NULL COMMENT '签到日期',
  `time` time NOT NULL COMMENT '签到时间',
  `address` varchar(200) DEFAULT NULL COMMENT '地址',
  `coordinate` point DEFAULT NULL COMMENT '坐标',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `index_user_date` (`user_id`,`date`) USING BTREE,
  KEY `index_user_id` (`user_id`) USING BTREE,
  KEY `index_date` (`date`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2253 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='签到记录表';

-- ----------------------------
-- Table structure for t_user_critical_incidents
-- ----------------------------
DROP TABLE IF EXISTS `t_user_critical_incidents`;
CREATE TABLE `t_user_critical_incidents` (
  `id` int(12) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `user_id` varchar(50) DEFAULT NULL COMMENT '统一用户ID',
  `user_account` varchar(50) DEFAULT NULL COMMENT '用户主账号',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `addr` varchar(300) DEFAULT NULL COMMENT '地址全称',
  `type_code` varchar(50) NOT NULL COMMENT '关键事件类型编码',
  `phone_type` int(4) DEFAULT NULL COMMENT '手机类型：1=安卓，2=苹果',
  `phone_model` varchar(200) DEFAULT NULL COMMENT '手机型号',
  `remark` varchar(600) DEFAULT NULL COMMENT '备注',
  `create_date` datetime DEFAULT NULL COMMENT '登记时间',
  `res_name` varchar(600) DEFAULT NULL COMMENT '资源名称',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `index_user_id` (`user_id`) USING BTREE,
  KEY `index_create_date` (`create_date`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=18129 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='用户关键事件表';

-- ----------------------------
-- Table structure for t_user_critical_incidents_type
-- ----------------------------
DROP TABLE IF EXISTS `t_user_critical_incidents_type`;
CREATE TABLE `t_user_critical_incidents_type` (
  `type_code` varchar(50) NOT NULL COMMENT '类型编码',
  `type_name` varchar(50) NOT NULL COMMENT '类型名称',
  `remark` varchar(600) DEFAULT NULL COMMENT '备注',
  `create_user` varchar(50) DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`type_code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='用户关键事件类型定义表';

-- ----------------------------
-- Table structure for t_user_sign_in_report
-- ----------------------------
DROP TABLE IF EXISTS `t_user_sign_in_report`;
CREATE TABLE `t_user_sign_in_report` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `date` date NOT NULL COMMENT '签到日期',
  `city` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '城市编码',
  `district` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '区域编码',
  `net_grid` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '网格编码',
  `field` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '责任田编码',
  `grid_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '区域编码',
  `province_name` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '省份名称',
  `city_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '城市名称',
  `district_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '区域名称',
  `net_grid_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '网格名称',
  `field_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '责任田名称',
  `level` int(11) DEFAULT NULL COMMENT '区域层级',
  `user_id` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户登录主账号',
  `user_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户姓名',
  `user_type` int(10) DEFAULT NULL COMMENT '职责类型，21=合作商店面经理,20=自有渠道店面经理,19=装维人员,18=加盟店面经理,17=地市财务管理人员,16=地市服务入格角色,15=省公司财务管理人员,14=省公司服务入格角色,13=省级指标管理员,12=省级号管理员,11=省级用户,,10=市级指标管理员,9=市工号管理员,8=市级用户,7=社区经理,,6=分公司指标管理员,5=分公司工号管理员,4=分公司用户,0=网格总监,3=网格副总监,2=商企经理,1=销售经理',
  `user_type_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户角色名称',
  `user_account` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户全部账号',
  `first_datetime` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '首次打卡时间',
  `first_address` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '首次打卡地址',
  `middle_count` int(11) DEFAULT NULL COMMENT '中间打卡次数',
  `middle_datetime` mediumtext COLLATE utf8mb4_unicode_ci COMMENT '中间打卡时间',
  `middle_address` mediumtext COLLATE utf8mb4_unicode_ci COMMENT '中间打卡地址',
  `last_datetime` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '末次打卡时间',
  `last_address` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '末次打卡地址',
  `create_user` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `unique_user_date_type` (`date`,`user_id`,`user_type`,`grid_code`) USING BTREE,
  KEY `index_date` (`date`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2683 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='用户考勤统计';

-- ----------------------------
-- Table structure for t_user_track
-- ----------------------------
DROP TABLE IF EXISTS `t_user_track`;
CREATE TABLE `t_user_track` (
  `id` int(12) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `user_id` varchar(50) DEFAULT NULL COMMENT '统一用户ID',
  `user_account` varchar(50) DEFAULT NULL COMMENT '用户主账号',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `addr` varchar(300) DEFAULT NULL COMMENT '地址全称',
  `track_type` int(4) DEFAULT NULL COMMENT '轨迹类型：1=工作足迹',
  `phone_type` int(4) DEFAULT NULL COMMENT '手机类型：1=安卓，2=苹果',
  `phone_model` varchar(200) DEFAULT NULL COMMENT '手机型号',
  `remark` varchar(600) DEFAULT NULL COMMENT '备注',
  `create_date` datetime DEFAULT NULL COMMENT '登记时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `index_user_id` (`user_id`) USING BTREE,
  KEY `index_create_date` (`create_date`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5290 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='用户轨迹表';

-- ----------------------------
-- Table structure for t_user_track_setting
-- ----------------------------
DROP TABLE IF EXISTS `t_user_track_setting`;
CREATE TABLE `t_user_track_setting` (
  `id` int(12) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `user_id` varchar(50) DEFAULT NULL COMMENT '统一用户ID',
  `time_setting` varchar(300) DEFAULT NULL COMMENT '时间段设置，格式8-12,14-18,只允许整点从小到大，不允许交叉',
  `weekday_setting` varchar(300) DEFAULT NULL COMMENT '记录周期，选择星期1-5前台表达为每个工作日，星期1-7表达为每天，其余表达为周一，周三..格式',
  `cron_expressions` varchar(300) DEFAULT NULL COMMENT 'cron表达式',
  `state` int(4) DEFAULT NULL COMMENT '开启状态:0=关闭，1=已开启',
  `create_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `unique_index_user_id` (`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='用户轨迹配置';

-- ----------------------------
-- Procedure structure for p_insert_sign_in
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_sign_in`;
DELIMITER ;;
CREATE DEFINER=`app_admin`@`%` PROCEDURE `p_insert_sign_in`()
BEGIN

	INSERT INTO `gd_track_e264fd96-3578-4400-97d5-fb5a39e232c3`.t_user_critical_incidents
	(user_id,user_account,longitude,latitude,type_code,addr,create_date)
	SELECT user_id,uid,x(coordinate),y(coordinate),'2',address, 
		CONVERT_TZ(str_to_date(concat(DATE_FORMAT(date,'%Y-%m-%d'),' ',DATE_FORMAT(time,'%H:%i:%s')),'%Y-%m-%d %H:%i:%s'),"+00:00","-08:00")
	FROM `app_base_business`.sign_in_t
	WHERE id not in(SELECT id FROM sign_in_t);

	INSERT INTO `gd_track_e264fd96-3578-4400-97d5-fb5a39e232c3`.sign_in_t
	(id,tenant_code,uid,user_id,date,time,address,coordinate)
	SELECT id,tenant_code,uid,user_id,date,time,address,coordinate 
	FROM `app_base_business`.sign_in_t
	WHERE id not in(SELECT id FROM `gd_track_e264fd96-3578-4400-97d5-fb5a39e232c3`.sign_in_t);


END
;;
DELIMITER ;
