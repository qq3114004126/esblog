/*
Navicat MySQL Data Transfer

Source Server         : ai4a_10.161.124.150_22035_ucadmin
Source Server Version : 50723
Source Host           : 10.161.124.150:22035
Source Database       : iam_public

Target Server Type    : MYSQL
Target Server Version : 50723
File Encoding         : 65001

Date: 2020-04-26 11:15:58
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for cmp_app_info
-- ----------------------------
DROP TABLE IF EXISTS `cmp_app_info`;
CREATE TABLE `cmp_app_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(4000) DEFAULT NULL,
  `tenant_id` varchar(255) NOT NULL,
  `client_detail_id` int(11) NOT NULL,
  `times` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_company_info
-- ----------------------------
DROP TABLE IF EXISTS `cmp_company_info`;
CREATE TABLE `cmp_company_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `address` varchar(2000) NOT NULL,
  `industry` varchar(2000) NOT NULL,
  `description` varchar(4000) DEFAULT NULL,
  `principal` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `idcard` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_access_module_cfg_t
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_access_module_cfg_t`;
CREATE TABLE `cmp_iam_access_module_cfg_t` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `access_module_chn` varchar(128) NOT NULL,
  `access_module_eng` varchar(128) NOT NULL,
  `reserved` varchar(100) DEFAULT NULL,
  `uri` varchar(256) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_action_t
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_action_t`;
CREATE TABLE `cmp_iam_action_t` (
  `actionid` varchar(100) NOT NULL,
  `actionname` varchar(1000) DEFAULT NULL,
  `servicetype` varchar(100) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `lastupdatedate` datetime DEFAULT NULL,
  `lastupdateby` varchar(100) DEFAULT NULL,
  `enabled` decimal(1,0) DEFAULT '1',
  PRIMARY KEY (`actionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_action_url_t
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_action_url_t`;
CREATE TABLE `cmp_iam_action_url_t` (
  `id` varchar(100) NOT NULL,
  `actionid` varchar(100) DEFAULT NULL,
  `api_urn` varchar(1000) DEFAULT NULL,
  `actiontype` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_affiche_user_receive
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_affiche_user_receive`;
CREATE TABLE `cmp_iam_affiche_user_receive` (
  `user_receive_id` int(10) NOT NULL AUTO_INCREMENT COMMENT '用户关联自增ID主键',
  `user_id` varchar(100) NOT NULL COMMENT '用户ID',
  `affiche_id` decimal(10,0) NOT NULL COMMENT '公告主键ID',
  `read_flag` varchar(500) DEFAULT NULL COMMENT '读取标识 0=未读,1=已读',
  `delete_flag` char(1) DEFAULT NULL COMMENT '删除标识 0=已删除,1=未删除',
  PRIMARY KEY (`user_receive_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统公告用户关联';

-- ----------------------------
-- Table structure for cmp_iam_ak_t
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_ak_t`;
CREATE TABLE `cmp_iam_ak_t` (
  `ak_id` varchar(100) NOT NULL,
  `ak_name` varchar(100) NOT NULL,
  `ak_value` varchar(100) NOT NULL,
  `ak_type` varchar(100) NOT NULL,
  `userid` varchar(100) DEFAULT NULL,
  `disable` varchar(10) DEFAULT NULL,
  `secretaccesskey` varchar(500) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `lastupdatedate` datetime DEFAULT NULL,
  `lastupdateby` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ak_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_apigatewat_log
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_apigatewat_log`;
CREATE TABLE `cmp_iam_apigatewat_log` (
  `id` varchar(100) NOT NULL,
  `userid` varchar(100) DEFAULT NULL,
  `apialias` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `operaetime` datetime DEFAULT NULL,
  `apiversion` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_az
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_az`;
CREATE TABLE `cmp_iam_az` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `region_id` varchar(100) NOT NULL,
  `region_name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_domain
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_domain`;
CREATE TABLE `cmp_iam_domain` (
  `id` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_icp_t
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_icp_t`;
CREATE TABLE `cmp_iam_icp_t` (
  `id` varchar(100) NOT NULL,
  `icp_number` varchar(100) DEFAULT NULL,
  `icp_number_en` varchar(100) DEFAULT NULL,
  `icp_url` varchar(255) DEFAULT NULL,
  `public_security_number` varchar(100) DEFAULT NULL,
  `public_security_number_en` varchar(100) DEFAULT NULL,
  `public_security_url` varchar(255) DEFAULT NULL,
  `enable` varchar(10) DEFAULT NULL,
  `valid` varchar(10) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_mapping_t
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_mapping_t`;
CREATE TABLE `cmp_iam_mapping_t` (
  `iam_id` varchar(100) NOT NULL,
  `keystone_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`iam_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_module_access_log_t
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_module_access_log_t`;
CREATE TABLE `cmp_iam_module_access_log_t` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tenant_id` varchar(100) DEFAULT NULL,
  `userid` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `account_id` varchar(100) DEFAULT NULL,
  `access_time` datetime NOT NULL,
  `appid` varchar(50) DEFAULT NULL,
  `hostip` varchar(32) DEFAULT NULL,
  `serverip` varchar(32) DEFAULT NULL,
  `access_module` varchar(128) NOT NULL,
  `reserved` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=217 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_permission_gateway_t
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_permission_gateway_t`;
CREATE TABLE `cmp_iam_permission_gateway_t` (
  `permissionid` varchar(100) NOT NULL,
  `permissionname` varchar(500) DEFAULT NULL,
  `permissioncode` varchar(1000) DEFAULT NULL,
  `permissiontype` varchar(100) DEFAULT NULL,
  `url` varchar(4000) DEFAULT NULL,
  `fid` varchar(100) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `lastupdatedate` datetime DEFAULT NULL,
  `lastupdateby` varchar(100) DEFAULT NULL,
  `enabled` decimal(1,0) DEFAULT '1',
  `is_important` decimal(2,0) DEFAULT '0' COMMENT '标识字段，值为0表示只进行一次校验，值为1表示需要进行二次校验，值为2表示不进行校验',
  `permission_enname` varchar(100) DEFAULT NULL COMMENT '权限英文名',
  PRIMARY KEY (`permissionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_permission_t
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_permission_t`;
CREATE TABLE `cmp_iam_permission_t` (
  `permissionid` varchar(100) NOT NULL,
  `permissionname` varchar(500) DEFAULT NULL,
  `permissioncode` varchar(1000) DEFAULT NULL,
  `permissiontype` varchar(100) DEFAULT NULL,
  `url` varchar(4000) DEFAULT NULL,
  `fid` varchar(100) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `lastupdatedate` datetime DEFAULT NULL,
  `lastupdateby` varchar(100) DEFAULT NULL,
  `enabled` decimal(1,0) DEFAULT '1',
  `is_important` decimal(2,0) DEFAULT '0' COMMENT '标识字段，值为0表示只进行一次校验，值为1表示需要进行二次校验，值为2表示不进行校验',
  `permission_enname` varchar(100) DEFAULT NULL COMMENT '权限英文名',
  PRIMARY KEY (`permissionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_policy_t
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_policy_t`;
CREATE TABLE `cmp_iam_policy_t` (
  `policyid` varchar(100) NOT NULL,
  `actionid` varchar(100) NOT NULL,
  `tenantid` varchar(100) NOT NULL,
  `roleid` varchar(100) NOT NULL,
  PRIMARY KEY (`policyid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_register_t
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_register_t`;
CREATE TABLE `cmp_iam_register_t` (
  `id` varchar(100) NOT NULL,
  `url` varchar(3000) DEFAULT NULL,
  `api_alians` varchar(100) DEFAULT NULL,
  `requesttype` varchar(100) DEFAULT NULL,
  `apiversion` varchar(10) DEFAULT NULL,
  `modeltype` varchar(100) DEFAULT NULL,
  `modelname` varchar(100) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `lastupdatedate` datetime DEFAULT NULL,
  `lastupdateby` varchar(100) DEFAULT NULL,
  `enabled` decimal(1,0) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_resource_tree
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_resource_tree`;
CREATE TABLE `cmp_iam_resource_tree` (
  `node_id` bigint(20) NOT NULL,
  `node_text` varchar(255) NOT NULL,
  `node_type` int(11) NOT NULL,
  `parent_node_id` bigint(20) DEFAULT NULL,
  `node_level` int(11) NOT NULL,
  `parent_node_id_level0` bigint(20) DEFAULT NULL,
  `parent_node_id_level1` bigint(20) DEFAULT NULL,
  `parent_node_id_level2` bigint(20) DEFAULT NULL,
  `parent_node_id_level3` bigint(20) DEFAULT NULL,
  `parent_node_id_level4` bigint(20) DEFAULT NULL,
  `parent_node_id_level5` bigint(20) DEFAULT NULL,
  `parent_node_id_level6` bigint(20) DEFAULT NULL,
  `parent_node_id_level7` bigint(20) DEFAULT NULL,
  `parent_node_id_level8` bigint(20) DEFAULT NULL,
  `parent_node_id_level9` bigint(20) DEFAULT NULL,
  `parent_node_id_level10` bigint(20) DEFAULT NULL,
  `parent_node_id_level11` bigint(20) DEFAULT NULL,
  `parent_node_id_level12` bigint(20) DEFAULT NULL,
  `parent_node_id_level13` bigint(20) DEFAULT NULL,
  `parent_node_id_level14` bigint(20) DEFAULT NULL,
  `obj_id` varchar(255) DEFAULT NULL,
  `node_text_en` varchar(255) DEFAULT NULL,
  `sequence` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`node_id`),
  KEY `cmp_iam_resource_tree_obj_id_IDX` (`obj_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_role_permission_t
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_role_permission_t`;
CREATE TABLE `cmp_iam_role_permission_t` (
  `roleid` varchar(100) NOT NULL,
  `permissionid` varchar(100) NOT NULL,
  PRIMARY KEY (`roleid`,`permissionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_role_t
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_role_t`;
CREATE TABLE `cmp_iam_role_t` (
  `roleid` varchar(100) NOT NULL,
  `rolename` varchar(100) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `roletype` varchar(10) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `lastupdatedate` datetime DEFAULT NULL,
  `lastupdateby` varchar(100) DEFAULT NULL,
  `enabled` decimal(1,0) DEFAULT '1',
  PRIMARY KEY (`roleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_security_strategy
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_security_strategy`;
CREATE TABLE `cmp_iam_security_strategy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accountlocktriggererrornums` decimal(8,0) DEFAULT '5',
  `accountlockmintime` decimal(8,0) DEFAULT '5',
  `accountlockdeltatime` decimal(8,0) DEFAULT '5',
  `iplocktriggererrornums` decimal(8,0) DEFAULT '10',
  `iplockmintime` decimal(8,0) DEFAULT '5',
  `iplockdeltatime` decimal(8,0) DEFAULT '5',
  `passwordlifedays` decimal(8,0) DEFAULT '50',
  `passwordexpiredpromptdays` decimal(8,0) DEFAULT '10',
  `unusedaccountlockdays` decimal(8,0) DEFAULT '50',
  `lockedaccountdeldays` decimal(8,0) DEFAULT '50',
  `defaultlogouttime` decimal(8,0) DEFAULT '30',
  `adminlockdefaulttime` decimal(8,0) DEFAULT '60',
  `sessiondatakeepingdays` decimal(8,0) DEFAULT '10',
  `enablebanner` decimal(8,0) DEFAULT '1',
  `banner` varchar(100) DEFAULT NULL,
  `accountlockcancel` decimal(1,0) DEFAULT '0',
  `iplockcancel` decimal(1,0) DEFAULT '0',
  `enablenumoferrorattempts` decimal(1,0) DEFAULT '0',
  `enablelastloginsuccessinfo` decimal(1,0) DEFAULT '0',
  `enablelastloginfailureinfo` decimal(1,0) DEFAULT '0',
  `adminconsolemaxsessions` int(11) DEFAULT '100',
  `userconsolemaxsessions` int(11) DEFAULT '100',
  `passworddiffchars` decimal(8,0) DEFAULT '3' COMMENT '密码最少不相同字符',
  `passwordhistimes` decimal(8,0) DEFAULT '3' COMMENT '密码历史记录数',
  `passwordperformdays` decimal(8,0) DEFAULT '7' COMMENT '密码过期提前提醒天数',
  `passwordshortestlifetime` decimal(8,0) DEFAULT '5' COMMENT '口令最短有效期',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1002 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_session_active
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_session_active`;
CREATE TABLE `cmp_iam_session_active` (
  `userid` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `tenantid` varchar(100) DEFAULT NULL,
  `tenantname` varchar(100) DEFAULT NULL,
  `client_url` varchar(100) DEFAULT NULL,
  `logintime` datetime NOT NULL,
  `logouttime` datetime DEFAULT NULL,
  `sessionid` varchar(100) DEFAULT NULL,
  `clientipaddr` varchar(100) DEFAULT NULL,
  `endtag` decimal(8,0) DEFAULT NULL,
  `isfail` decimal(8,0) DEFAULT NULL,
  `id` varchar(100) NOT NULL,
  `roletype` varchar(30) DEFAULT NULL,
  `loginway` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_sync_log
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_sync_log`;
CREATE TABLE `cmp_iam_sync_log` (
  `logid` varchar(100) NOT NULL,
  `synccount` decimal(8,0) DEFAULT NULL,
  `logtime` datetime DEFAULT NULL,
  `consumetime` decimal(8,0) DEFAULT NULL,
  PRIMARY KEY (`logid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_sys_affiche
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_sys_affiche`;
CREATE TABLE `cmp_iam_sys_affiche` (
  `affiche_id` int(10) NOT NULL AUTO_INCREMENT COMMENT '系统公告自增ID主键',
  `affiche_subject` varchar(100) DEFAULT NULL COMMENT '公告主题',
  `affiche_content` varchar(1000) DEFAULT NULL COMMENT '公告内容',
  `affiche_type` char(1) NOT NULL COMMENT '公告类型: 0=系统公告,1=申请流程[订单],2=故障通知[云监控],3=变更升级通知[应用部署],4=产品信息[框架]',
  `affiche_importance` char(1) NOT NULL COMMENT '公告重要程度: 0=高,1=中,2=低',
  `affiche_status` char(1) NOT NULL COMMENT '公告状态,是否失效 0=失效,1=正常',
  `create_time` datetime DEFAULT NULL COMMENT '创建日期',
  `create_by` varchar(200) DEFAULT NULL COMMENT '公告发布人',
  `last_update_time` datetime DEFAULT NULL COMMENT '公告更新人',
  `last_update_by` varchar(200) DEFAULT NULL COMMENT '最后更新日期',
  PRIMARY KEY (`affiche_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统公告消息';

-- ----------------------------
-- Table structure for cmp_iam_sys_affiche_receive
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_sys_affiche_receive`;
CREATE TABLE `cmp_iam_sys_affiche_receive` (
  `receive_id` int(10) NOT NULL AUTO_INCREMENT COMMENT '系统公告受众自增ID主键',
  `affiche_id` decimal(10,0) NOT NULL COMMENT '公告主键ID',
  `receive_type` char(1) NOT NULL COMMENT '公告受众类型:0=All(系统所有用户均能收到),1=租户,2=角色,3=组织,4=第三方用户',
  `type_group` varchar(500) DEFAULT NULL COMMENT '根据受众类型,ALL=(向受众类型下的所有二级子项用户发送公告),二级子项可多选,以 ; 分割',
  PRIMARY KEY (`receive_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统公告受众';

-- ----------------------------
-- Table structure for cmp_iam_tenant_quato_t
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_tenant_quato_t`;
CREATE TABLE `cmp_iam_tenant_quato_t` (
  `id` varchar(100) NOT NULL,
  `tenantid` varchar(100) DEFAULT NULL,
  `regionid` varchar(100) DEFAULT NULL,
  `quatotype` varchar(100) DEFAULT NULL,
  `quatovalue` varchar(100) DEFAULT NULL,
  `quatoused` varchar(100) DEFAULT NULL,
  `groupid` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_tenant_role_t
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_tenant_role_t`;
CREATE TABLE `cmp_iam_tenant_role_t` (
  `tenantid` varchar(100) NOT NULL,
  `roleid` varchar(100) NOT NULL,
  PRIMARY KEY (`tenantid`,`roleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_tenant_t
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_tenant_t`;
CREATE TABLE `cmp_iam_tenant_t` (
  `tenantid` varchar(100) NOT NULL,
  `tenantname` varchar(100) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `tenanttype` varchar(100) DEFAULT NULL,
  `owner` varchar(100) DEFAULT NULL,
  `apiswitch` varchar(100) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `lastupdatedate` datetime DEFAULT NULL,
  `lastupdateby` varchar(100) DEFAULT NULL,
  `enabled` decimal(1,0) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL COMMENT '电话',
  `email` varchar(100) DEFAULT NULL COMMENT '邮箱',
  `tenantmanagers` varchar(4000) DEFAULT NULL,
  `projectid` varchar(100) DEFAULT NULL,
  `homepage` varchar(200) DEFAULT NULL,
  `home_page_url` varchar(500) DEFAULT NULL COMMENT '租户首页地址',
  `is_permission` varchar(2) DEFAULT NULL COMMENT 'SAAS普通用户安装UC',
  `isavailable` varchar(2) DEFAULT NULL COMMENT '租户是否失效',
  `active_endTimeStamp` datetime DEFAULT NULL,
  `active_startTimeStamp` datetime DEFAULT NULL,
  PRIMARY KEY (`tenantid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_thirdsource_t
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_thirdsource_t`;
CREATE TABLE `cmp_iam_thirdsource_t` (
  `id` varchar(100) NOT NULL,
  `sourcename` varchar(100) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `url` varchar(100) DEFAULT NULL,
  `domain` varchar(100) DEFAULT NULL,
  `domainalias` varchar(100) DEFAULT NULL,
  `loginname` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `secretpwd` varchar(500) DEFAULT NULL,
  `groupbase` varchar(100) DEFAULT NULL,
  `userbase` varchar(100) DEFAULT NULL,
  `lastsync` datetime DEFAULT NULL,
  `loginfield` varchar(20) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `lastupdatedate` datetime DEFAULT NULL,
  `lastupdateby` varchar(100) DEFAULT NULL,
  `enabled` decimal(1,0) DEFAULT '1',
  `tenantid` varchar(100) DEFAULT NULL,
  `fuzzyname` varchar(100) DEFAULT NULL,
  `cmpdomain` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_thirduser_t
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_thirduser_t`;
CREATE TABLE `cmp_iam_thirduser_t` (
  `id` varchar(200) NOT NULL,
  `fullname` varchar(200) DEFAULT NULL,
  `lastname` varchar(200) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `samaccountname` varchar(200) DEFAULT NULL,
  `mail` varchar(200) DEFAULT NULL,
  `displayname` varchar(200) DEFAULT NULL,
  `thirdsrcid` varchar(200) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `lastupdatedate` datetime DEFAULT NULL,
  `lastupdateby` varchar(100) DEFAULT NULL,
  `enabled` decimal(1,0) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_token_t
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_token_t`;
CREATE TABLE `cmp_iam_token_t` (
  `tokenid` varchar(100) NOT NULL,
  `expires` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `userid` varchar(100) DEFAULT NULL,
  `tokentype` varchar(100) DEFAULT NULL,
  `isvalid` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`tokenid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_user_role_t
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_user_role_t`;
CREATE TABLE `cmp_iam_user_role_t` (
  `userid` varchar(100) NOT NULL,
  `roleid` varchar(100) NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_user_t
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_user_t`;
CREATE TABLE `cmp_iam_user_t` (
  `userid` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(500) DEFAULT NULL,
  `usernamecn` varchar(100) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `secretemail` varchar(200) DEFAULT NULL,
  `md5_email` varchar(255) DEFAULT NULL COMMENT '邮箱摘要',
  `secretphone` varchar(200) DEFAULT NULL,
  `md5_phone` varchar(255) DEFAULT NULL COMMENT '手机号码摘要',
  `usertype` decimal(1,0) DEFAULT NULL,
  `usersrc` varchar(100) DEFAULT NULL,
  `orgid` varchar(50) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `lastupdatedate` datetime DEFAULT NULL,
  `lastupdateby` varchar(100) DEFAULT NULL,
  `enabled` decimal(1,0) DEFAULT '1',
  `usericon` varchar(200) DEFAULT NULL,
  `sessiontime` decimal(8,0) DEFAULT NULL,
  `updatepwddate` datetime DEFAULT NULL,
  `updatepwduser` varchar(100) DEFAULT NULL,
  `managerlocktag` varchar(10) DEFAULT NULL,
  `logoutlast` datetime DEFAULT NULL,
  `unlocklast` datetime DEFAULT NULL,
  `locklast` datetime DEFAULT NULL,
  `landline` varchar(100) DEFAULT NULL,
  `lan_set` varchar(100) DEFAULT NULL,
  `tenantid` varchar(100) DEFAULT NULL,
  `operator_id` varchar(100) DEFAULT NULL,
  `active_endTimeStamp` datetime DEFAULT NULL,
  `active_startTimeStamp` datetime DEFAULT NULL,
  `identity_no` varchar(255) DEFAULT NULL COMMENT '身份证号码',
  `number` varchar(255) DEFAULT NULL COMMENT '用户工号',
  `party` varchar(2) DEFAULT NULL COMMENT '政党',
  PRIMARY KEY (`userid`),
  KEY `UQ_cmp_iam_user_t` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_user_t_delete
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_user_t_delete`;
CREATE TABLE `cmp_iam_user_t_delete` (
  `userid` varchar(100) NOT NULL,
  `username` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `password` varchar(500) DEFAULT NULL,
  `usernamecn` varchar(100) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `secretemail` varchar(200) DEFAULT NULL,
  `md5_email` varchar(255) DEFAULT NULL COMMENT '邮箱摘要',
  `secretphone` varchar(200) DEFAULT NULL,
  `md5_phone` varchar(255) DEFAULT NULL COMMENT '手机号码摘要',
  `usertype` decimal(1,0) DEFAULT NULL,
  `usersrc` varchar(100) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `lastupdatedate` datetime DEFAULT NULL,
  `lastupdateby` varchar(100) DEFAULT NULL,
  `identity_no` varchar(32) DEFAULT NULL COMMENT '身份证号码',
  `number` varchar(255) DEFAULT NULL COMMENT '用户工号',
  `party` varchar(2) DEFAULT NULL COMMENT '政党',
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_user_tenant_t
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_user_tenant_t`;
CREATE TABLE `cmp_iam_user_tenant_t` (
  `userid` varchar(100) NOT NULL,
  `tenantid` varchar(100) NOT NULL,
  PRIMARY KEY (`userid`,`tenantid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_user_usergroup_t
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_user_usergroup_t`;
CREATE TABLE `cmp_iam_user_usergroup_t` (
  `userid` varchar(100) NOT NULL,
  `groupid` varchar(100) NOT NULL,
  PRIMARY KEY (`userid`,`groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_usergroup_role_t
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_usergroup_role_t`;
CREATE TABLE `cmp_iam_usergroup_role_t` (
  `groupid` varchar(100) NOT NULL,
  `roleid` varchar(100) NOT NULL,
  PRIMARY KEY (`groupid`,`roleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_iam_usergroup_t
-- ----------------------------
DROP TABLE IF EXISTS `cmp_iam_usergroup_t`;
CREATE TABLE `cmp_iam_usergroup_t` (
  `groupid` varchar(100) NOT NULL,
  `groupname` varchar(100) DEFAULT NULL,
  `fid` varchar(100) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `lastupdatedate` datetime DEFAULT NULL,
  `lastupdateby` varchar(100) DEFAULT NULL,
  `enabled` decimal(1,0) DEFAULT NULL,
  `tenantid` varchar(100) NOT NULL,
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_mapping_company_apps
-- ----------------------------
DROP TABLE IF EXISTS `cmp_mapping_company_apps`;
CREATE TABLE `cmp_mapping_company_apps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `app_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_oauth_access_token
-- ----------------------------
DROP TABLE IF EXISTS `cmp_oauth_access_token`;
CREATE TABLE `cmp_oauth_access_token` (
  `authentication_id` varchar(255) NOT NULL,
  `token_id` varchar(255) DEFAULT NULL,
  `token` blob,
  `user_name` varchar(255) DEFAULT NULL,
  `client_id` varchar(255) DEFAULT NULL,
  `authentication` blob,
  `refresh_token` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL COMMENT '用户id',
  PRIMARY KEY (`authentication_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_oauth_approvals
-- ----------------------------
DROP TABLE IF EXISTS `cmp_oauth_approvals`;
CREATE TABLE `cmp_oauth_approvals` (
  `userId` varchar(255) DEFAULT NULL,
  `clientId` varchar(255) DEFAULT NULL,
  `scope` varchar(255) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `expiresAt` datetime DEFAULT NULL,
  `lastModifiedAt` datetime DEFAULT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_oauth_client_details
-- ----------------------------
DROP TABLE IF EXISTS `cmp_oauth_client_details`;
CREATE TABLE `cmp_oauth_client_details` (
  `id` varchar(100) NOT NULL,
  `client_id` varchar(255) DEFAULT NULL,
  `client_name` varchar(255) DEFAULT NULL,
  `resource_ids` varchar(255) DEFAULT NULL,
  `client_secret` varchar(255) DEFAULT NULL,
  `scope` varchar(255) DEFAULT NULL,
  `authorized_grant_types` varchar(255) DEFAULT NULL,
  `web_server_redirect_uri` varchar(255) DEFAULT NULL,
  `authorities` varchar(255) DEFAULT NULL,
  `access_token_validity` int(11) DEFAULT NULL,
  `refresh_token_validity` int(11) DEFAULT NULL,
  `additional_information` varchar(4096) DEFAULT NULL,
  `autoapprove` varchar(255) DEFAULT NULL,
  `enable` varchar(2) DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL,
  `tenant_id` varchar(255) DEFAULT NULL,
  `logo_url` varchar(255) DEFAULT NULL,
  `ban_url` varchar(255) DEFAULT NULL,
  `web_server_url` varchar(255) DEFAULT NULL,
  `province_node` bigint(20) DEFAULT NULL,
  `city_node` bigint(20) DEFAULT NULL,
  `web_proxy_url` varchar(500) DEFAULT NULL COMMENT '终端代理地址',
  `is_private` varchar(2) DEFAULT NULL COMMENT '终端是否私有',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_oauth_client_token
-- ----------------------------
DROP TABLE IF EXISTS `cmp_oauth_client_token`;
CREATE TABLE `cmp_oauth_client_token` (
  `authentication_id` varchar(255) NOT NULL,
  `token_id` varchar(255) DEFAULT NULL,
  `token` blob,
  `user_name` varchar(255) DEFAULT NULL,
  `client_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`authentication_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_oauth_code
-- ----------------------------
DROP TABLE IF EXISTS `cmp_oauth_code`;
CREATE TABLE `cmp_oauth_code` (
  `code` varchar(255) DEFAULT NULL,
  `authentication` blob,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cmp_oauth_refresh_token
-- ----------------------------
DROP TABLE IF EXISTS `cmp_oauth_refresh_token`;
CREATE TABLE `cmp_oauth_refresh_token` (
  `token_id` varchar(255) NOT NULL,
  `token` blob,
  `authentication` blob,
  PRIMARY KEY (`token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for flyway_schema_history
-- ----------------------------
DROP TABLE IF EXISTS `flyway_schema_history`;
CREATE TABLE `flyway_schema_history` (
  `installed_rank` int(11) NOT NULL,
  `version` varchar(50) DEFAULT NULL,
  `description` varchar(200) NOT NULL,
  `type` varchar(20) NOT NULL,
  `script` varchar(1000) NOT NULL,
  `checksum` int(11) DEFAULT NULL,
  `installed_by` varchar(100) NOT NULL,
  `installed_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `execution_time` int(11) NOT NULL,
  `success` tinyint(1) NOT NULL,
  PRIMARY KEY (`installed_rank`),
  KEY `flyway_schema_history_s_idx` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for pub_file_t
-- ----------------------------
DROP TABLE IF EXISTS `pub_file_t`;
CREATE TABLE `pub_file_t` (
  `uuid` varchar(100) NOT NULL COMMENT '文件UUID',
  `name` varchar(100) DEFAULT NULL COMMENT '文件名称',
  `path` varchar(250) DEFAULT NULL COMMENT '文件保存路径',
  `size` bigint(20) DEFAULT NULL COMMENT '文件大小',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `create_user_id` varchar(100) DEFAULT NULL COMMENT '创建用户ID',
  `create_user_name` varchar(100) DEFAULT NULL COMMENT '创建用户名称',
  `extension_name` varchar(50) DEFAULT NULL COMMENT '扩展名',
  `download_url` varchar(250) DEFAULT NULL COMMENT '下载路径',
  `content_type` varchar(100) DEFAULT NULL COMMENT '文件类型',
  `state` int(1) DEFAULT NULL COMMENT '文件状态，0初始化，1文件存在，2正在写文件，3已删除该文件',
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='文件存储表';

-- ----------------------------
-- Table structure for uc_access_code_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_access_code_t`;
CREATE TABLE `uc_access_code_t` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `code` varchar(100) NOT NULL COMMENT '注册码',
  `tenant_id` varchar(64) DEFAULT NULL COMMENT '租户id',
  `invite_id` varchar(64) NOT NULL COMMENT '根邀请码Id',
  `user_id` varchar(64) DEFAULT NULL COMMENT '创建用户Id',
  `user_name` varchar(500) DEFAULT NULL COMMENT '创建用户名',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `content` text COMMENT 'Json邀请码内容，角色，区域，部门',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_access_code_user_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_access_code_user_t`;
CREATE TABLE `uc_access_code_user_t` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `code` varchar(100) NOT NULL COMMENT '注册码',
  `tenant_id` varchar(64) DEFAULT NULL COMMENT '租户id',
  `user_id` varchar(64) DEFAULT NULL COMMENT '创建用户Id',
  `create_user` varchar(64) DEFAULT NULL COMMENT '创建用户Id',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_announcement_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_announcement_t`;
CREATE TABLE `uc_announcement_t` (
  `id` varchar(100) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `title` varchar(2000) DEFAULT NULL,
  `content` longtext COMMENT '内容',
  `publish_time` datetime DEFAULT NULL,
  `edit_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_announcement_terminal_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_announcement_terminal_t`;
CREATE TABLE `uc_announcement_terminal_t` (
  `id` varchar(100) NOT NULL,
  `terminal_id` varchar(5000) DEFAULT '0',
  `announcement_id` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_announcement_user_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_announcement_user_t`;
CREATE TABLE `uc_announcement_user_t` (
  `id` varchar(100) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `announcement_id` varchar(100) NOT NULL,
  `readStatus` varchar(10) DEFAULT '已读',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_app_login_log_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_app_login_log_t`;
CREATE TABLE `uc_app_login_log_t` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(250) DEFAULT NULL,
  `user_name` varchar(250) DEFAULT NULL,
  `token_key` varchar(250) DEFAULT NULL,
  `ip_addr` varchar(250) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `login_type` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_app_public_key
-- ----------------------------
DROP TABLE IF EXISTS `uc_app_public_key`;
CREATE TABLE `uc_app_public_key` (
  `keyid` int(10) NOT NULL AUTO_INCREMENT COMMENT '公钥Id',
  `appid` varchar(32) NOT NULL COMMENT '公钥对应的app',
  `public_key` text NOT NULL COMMENT '公钥',
  PRIMARY KEY (`keyid`) USING BTREE,
  KEY `IDX_APP_ID` (`appid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Table structure for uc_app_refresh_token_log_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_app_refresh_token_log_t`;
CREATE TABLE `uc_app_refresh_token_log_t` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token_key` varchar(1000) DEFAULT NULL COMMENT '刷新tokenkey值',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3064 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_app_refresh_token_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_app_refresh_token_t`;
CREATE TABLE `uc_app_refresh_token_t` (
  `id` varchar(1000) NOT NULL,
  `user_id` varchar(100) DEFAULT NULL,
  `expire` datetime DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `access_token` varchar(3000) DEFAULT NULL COMMENT '访问token',
  `uc_code` varchar(255) DEFAULT NULL COMMENT 'uc_code',
  `phone_id` varchar(255) DEFAULT NULL COMMENT '手机标识',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_assignment_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_assignment_t`;
CREATE TABLE `uc_assignment_t` (
  `id` varchar(100) NOT NULL,
  `user_id` varchar(100) NOT NULL COMMENT '用户id',
  `target_id` varchar(100) NOT NULL,
  `role_id` varchar(100) NOT NULL COMMENT '角色id',
  `target_type` varchar(50) DEFAULT NULL COMMENT '类型',
  PRIMARY KEY (`id`),
  KEY `uc_assignment_t_target_id_IDX` (`target_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_async_import_log
-- ----------------------------
DROP TABLE IF EXISTS `uc_async_import_log`;
CREATE TABLE `uc_async_import_log` (
  `id` varchar(100) NOT NULL,
  `type` int(11) NOT NULL,
  `file_size` bigint(20) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `cost_time_millis` bigint(20) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `create_user_Id` varchar(100) DEFAULT NULL,
  `create_user_name` varchar(100) DEFAULT NULL,
  `message` text,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Table structure for uc_client_src_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_client_src_t`;
CREATE TABLE `uc_client_src_t` (
  `id` varchar(100) NOT NULL,
  `client_id` varchar(100) DEFAULT NULL,
  `user_src` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_common_auth_url_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_common_auth_url_t`;
CREATE TABLE `uc_common_auth_url_t` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `model` varchar(50) DEFAULT NULL COMMENT '接口模块',
  `url` varchar(500) DEFAULT NULL COMMENT '请求地址,方法',
  `description` varchar(500) DEFAULT NULL COMMENT '请求白名单描述',
  `abled` tinyint(4) DEFAULT '0' COMMENT '0-无效；1-有效',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_data_area_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_data_area_t`;
CREATE TABLE `uc_data_area_t` (
  `id` varchar(100) NOT NULL COMMENT '自增ID',
  `code` varchar(50) DEFAULT NULL COMMENT '网格编码',
  `data_id` bigint(20) DEFAULT NULL COMMENT '数据服务id',
  `parent_code` varchar(50) DEFAULT NULL COMMENT '父级网格编码',
  `all_parent_code` varchar(10000) DEFAULT NULL COMMENT '全部父节点网格编码',
  `NAME` varchar(300) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL COMMENT '网格类型：营销网格、规划网格等',
  `client_id` varchar(100) DEFAULT NULL COMMENT '终端Id',
  `tenant_id` varchar(100) DEFAULT NULL COMMENT '租户Id',
  `bundary` text COMMENT '边界',
  `bundary_coordinate` geometry DEFAULT NULL COMMENT '边界坐标',
  `level` int(11) DEFAULT NULL COMMENT '层级',
  `headperson` varchar(50) DEFAULT NULL COMMENT '网格负责人名称',
  `headperson_code` varchar(50) DEFAULT NULL COMMENT '网格负责人工号',
  `headperson_tel` varchar(50) DEFAULT NULL COMMENT '网格负责人电话',
  `center_longitude` decimal(18,8) DEFAULT NULL COMMENT '网格中心点经度',
  `center_latitude` decimal(18,8) DEFAULT NULL COMMENT '网格中心点纬度',
  `area` decimal(10,2) DEFAULT NULL COMMENT '面积',
  `create_user` varchar(50) DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `full_name` varchar(5000) DEFAULT '',
  `grid_status` int(8) DEFAULT '1' COMMENT '区域状态，有效,0 无效,2 已删除',
  `old_code` text COMMENT '区域code更改轨迹',
  `original_grid_code` varchar(50) DEFAULT NULL COMMENT '外部系统(原始)区域编码',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uc_data_area_t_UN` (`code`,`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='网格基础信息';

-- ----------------------------
-- Table structure for uc_district_data_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_district_data_t`;
CREATE TABLE `uc_district_data_t` (
  `id` varchar(128) CHARACTER SET utf8 NOT NULL,
  `parent_id` varchar(128) CHARACTER SET utf8 NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '城市名称',
  `group_name` varchar(255) DEFAULT NULL COMMENT '组名',
  `item_name` varchar(255) DEFAULT NULL,
  `center_point` varchar(255) DEFAULT NULL COMMENT '中心点',
  `city_id` int(16) NOT NULL DEFAULT '-1' COMMENT '编号',
  `level_type` int(8) NOT NULL COMMENT '1国家，2省份(直辖市)，3市级，4区县级',
  `longitude` varchar(128) NOT NULL DEFAULT '0' COMMENT '经度',
  `latitude` varchar(128) CHARACTER SET utf8 NOT NULL DEFAULT '0' COMMENT '纬度',
  `area` varchar(255) NOT NULL DEFAULT '0' COMMENT '面积',
  `boundary` geometry NOT NULL COMMENT '边界',
  `remark` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '标记'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for uc_district_site
-- ----------------------------
DROP TABLE IF EXISTS `uc_district_site`;
CREATE TABLE `uc_district_site` (
  `id` varchar(128) NOT NULL,
  `district_id` varchar(128) NOT NULL COMMENT '区域id',
  `parent_id` varchar(128) NOT NULL DEFAULT '-1',
  `city_name` varchar(255) NOT NULL COMMENT '城市名',
  `group_name` varchar(255) NOT NULL,
  `item_name` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `config_id` varchar(32) DEFAULT NULL COMMENT 'config_id'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_district_tenant
-- ----------------------------
DROP TABLE IF EXISTS `uc_district_tenant`;
CREATE TABLE `uc_district_tenant` (
  `id` varchar(128) NOT NULL COMMENT '主键',
  `district_id` varchar(128) NOT NULL COMMENT '区域ID',
  `tenant_id` varchar(128) NOT NULL COMMENT '租户ID'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_domain_name_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_domain_name_t`;
CREATE TABLE `uc_domain_name_t` (
  `id` varchar(100) NOT NULL,
  `domain_name` varchar(100) NOT NULL COMMENT '域名',
  `used` varchar(2) DEFAULT NULL COMMENT '是否已使用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_email
-- ----------------------------
DROP TABLE IF EXISTS `uc_email`;
CREATE TABLE `uc_email` (
  `id` varchar(100) NOT NULL,
  `address` longtext,
  `user_id` varchar(1000) DEFAULT NULL,
  `active_code` varchar(1000) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `lastupdate_date` datetime DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `is_valid` varchar(2) DEFAULT NULL,
  `message` longtext COMMENT '邮件发送结果',
  `subject` varchar(255) DEFAULT NULL COMMENT '邮件主题',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_email_template_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_email_template_t`;
CREATE TABLE `uc_email_template_t` (
  `id` varchar(36) NOT NULL,
  `name` varchar(100) DEFAULT NULL COMMENT '邮件名',
  `TYPE` varchar(10) DEFAULT NULL,
  `sms_content` text,
  `mail_title` varchar(1000) DEFAULT NULL,
  `mail_content` text COMMENT '邮件内容',
  `service` varchar(20) DEFAULT NULL COMMENT '服务',
  `create_by` decimal(22,0) DEFAULT NULL COMMENT '创建人id',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `last_update_by` decimal(22,0) DEFAULT NULL COMMENT '更新人id',
  `last_update_date` datetime DEFAULT NULL COMMENT '更新时间',
  `language_type` varchar(10) DEFAULT NULL COMMENT '语言',
  `relation` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_grid_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_grid_t`;
CREATE TABLE `uc_grid_t` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `code` varchar(50) DEFAULT NULL COMMENT '网格编码',
  `parent_code` varchar(50) DEFAULT NULL COMMENT '父级网格编码',
  `all_parent_code` varchar(10000) DEFAULT NULL COMMENT '全部父节点网格编码',
  `name` varchar(50) DEFAULT NULL COMMENT '网格名称',
  `type` varchar(50) DEFAULT NULL COMMENT '网格类型：营销网格、规划网格等',
  `bundary` text COMMENT '边界',
  `bundary_coordinate` geometry DEFAULT NULL COMMENT '边界坐标',
  `level` int(11) DEFAULT NULL COMMENT '层级',
  `headperson` varchar(50) DEFAULT NULL COMMENT '网格负责人名称',
  `headperson_code` varchar(50) DEFAULT NULL COMMENT '网格负责人工号',
  `headperson_tel` varchar(50) DEFAULT NULL COMMENT '网格负责人电话',
  `center_longitude` decimal(18,8) DEFAULT NULL COMMENT '网格中心点经度',
  `center_latitude` decimal(18,8) DEFAULT NULL COMMENT '网格中心点纬度',
  `area` decimal(10,2) DEFAULT NULL COMMENT '面积',
  `create_user` varchar(50) DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `full_name` varchar(5000) DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_grid_code` (`code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11579 DEFAULT CHARSET=utf8 COMMENT='网格基础信息';

-- ----------------------------
-- Table structure for uc_iam_apply_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_iam_apply_t`;
CREATE TABLE `uc_iam_apply_t` (
  `id` varchar(100) NOT NULL,
  `target_id` varchar(4000) DEFAULT NULL,
  `apply_type` tinyint(4) NOT NULL COMMENT '申请类型(1租户，2UC)',
  `approve_result` varchar(4000) DEFAULT NULL COMMENT '最后审批结果',
  `apply_reason` varchar(255) DEFAULT NULL COMMENT '申请原因',
  `applicant_id` varchar(100) DEFAULT NULL COMMENT '申请人',
  `status` tinyint(4) DEFAULT NULL COMMENT '审批结果(1通过，2驳回，3审核中)',
  `apply_date` datetime DEFAULT NULL,
  `approve_date` datetime DEFAULT NULL,
  `approver_id` varchar(100) DEFAULT NULL COMMENT '审批人',
  `approve_descrption` varchar(255) DEFAULT NULL COMMENT '审批描述',
  `instance_id` varchar(100) DEFAULT NULL COMMENT '实例id',
  `instance_name` varchar(255) DEFAULT NULL COMMENT '实例名称',
  `tenant_id` varchar(255) DEFAULT NULL COMMENT '租户id',
  `apply_content` text COMMENT 's申请内容',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_iam_operator_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_iam_operator_t`;
CREATE TABLE `uc_iam_operator_t` (
  `id` varchar(100) NOT NULL,
  `logo_url` varchar(255) DEFAULT NULL COMMENT 'logo存放地址',
  `name_cn` varchar(250) DEFAULT NULL COMMENT '中文名',
  `name` varchar(250) NOT NULL COMMENT '英文名',
  `description` varchar(250) DEFAULT NULL COMMENT '描述',
  `create_by` varchar(100) DEFAULT NULL COMMENT '创建人',
  `create_date` date DEFAULT NULL COMMENT '创建时间',
  `last_update_by` varchar(100) DEFAULT NULL COMMENT '最后修改人',
  `last_update_date` date DEFAULT NULL COMMENT '最后修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_instance_info_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_instance_info_t`;
CREATE TABLE `uc_instance_info_t` (
  `id` varchar(100) NOT NULL,
  `instance_id` varchar(100) NOT NULL COMMENT '实例id',
  `tenant_id` varchar(100) NOT NULL COMMENT '租户id',
  `client_id` varchar(100) DEFAULT NULL COMMENT '终端id',
  `region_type` int(4) NOT NULL COMMENT '区域管理开关，配置0（开）或者1（关），默认为0.',
  `instance_name` varchar(255) DEFAULT NULL,
  `instance_name_en` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_instance_permission_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_instance_permission_t`;
CREATE TABLE `uc_instance_permission_t` (
  `id` varchar(100) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `code` varchar(100) DEFAULT NULL,
  `instance_id` varchar(100) DEFAULT NULL,
  `permission_id` varchar(100) DEFAULT NULL,
  `permission_name` varchar(500) DEFAULT NULL,
  `permission_name_en` varchar(100) DEFAULT NULL,
  `uc_id` varchar(100) DEFAULT NULL,
  `expression` text,
  `description` varchar(2000) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `create_by` varchar(100) DEFAULT NULL,
  `last_update_by` varchar(100) DEFAULT NULL,
  `last_update_date` datetime DEFAULT NULL,
  `microservice` varchar(255) DEFAULT NULL,
  `microservice_en` varchar(255) DEFAULT NULL,
  `obj_id` varchar(255) DEFAULT NULL,
  `version` varchar(100) DEFAULT NULL,
  `ismust` varchar(1) DEFAULT NULL,
  `columnlocation` int(2) DEFAULT NULL,
  `tenant_id` varchar(100) DEFAULT NULL,
  `is_instance_tag` int(11) DEFAULT '0' COMMENT '是否应用标签',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_instance_permission_t_history
-- ----------------------------
DROP TABLE IF EXISTS `uc_instance_permission_t_history`;
CREATE TABLE `uc_instance_permission_t_history` (
  `id` varchar(100) NOT NULL,
  `instance_id` varchar(100) DEFAULT NULL,
  `permission_id` varchar(100) DEFAULT NULL,
  `permission_name` varchar(500) DEFAULT NULL,
  `permission_name_en` varchar(100) DEFAULT NULL,
  `uc_id` varchar(100) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `create_by` varchar(100) DEFAULT NULL,
  `last_update_by` varchar(100) DEFAULT NULL,
  `last_update_date` datetime DEFAULT NULL,
  `microservice` varchar(255) DEFAULT NULL,
  `microservice_en` varchar(255) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `code` varchar(100) DEFAULT NULL,
  `expression` text,
  `description` varchar(2000) DEFAULT NULL,
  `obj_id` varchar(255) DEFAULT NULL,
  `version` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_instance_resource_tree_history
-- ----------------------------
DROP TABLE IF EXISTS `uc_instance_resource_tree_history`;
CREATE TABLE `uc_instance_resource_tree_history` (
  `node_id` bigint(20) NOT NULL,
  `node_text` varchar(255) NOT NULL,
  `node_type` int(11) NOT NULL,
  `parent_node_id` bigint(20) DEFAULT NULL,
  `node_level` int(11) NOT NULL,
  `parent_node_id_level0` bigint(20) DEFAULT NULL,
  `parent_node_id_level1` bigint(20) DEFAULT NULL,
  `parent_node_id_level2` bigint(20) DEFAULT NULL,
  `parent_node_id_level3` bigint(20) DEFAULT NULL,
  `parent_node_id_level4` bigint(20) DEFAULT NULL,
  `parent_node_id_level5` bigint(20) DEFAULT NULL,
  `parent_node_id_level6` bigint(20) DEFAULT NULL,
  `parent_node_id_level7` bigint(20) DEFAULT NULL,
  `parent_node_id_level8` bigint(20) DEFAULT NULL,
  `parent_node_id_level9` bigint(20) DEFAULT NULL,
  `parent_node_id_level10` bigint(20) DEFAULT NULL,
  `parent_node_id_level11` bigint(20) DEFAULT NULL,
  `parent_node_id_level12` bigint(20) DEFAULT NULL,
  `parent_node_id_level13` bigint(20) DEFAULT NULL,
  `parent_node_id_level14` bigint(20) DEFAULT NULL,
  `obj_id` varchar(255) DEFAULT NULL,
  `node_text_en` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_instance_role_permission_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_instance_role_permission_t`;
CREATE TABLE `uc_instance_role_permission_t` (
  `id` varchar(100) NOT NULL,
  `instance_role_id` varchar(100) DEFAULT NULL,
  `instance_permission_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_instance_role_permission_t_history
-- ----------------------------
DROP TABLE IF EXISTS `uc_instance_role_permission_t_history`;
CREATE TABLE `uc_instance_role_permission_t_history` (
  `id` varchar(100) NOT NULL,
  `instance_role_id` varchar(100) DEFAULT NULL,
  `instance_permission_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_instance_role_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_instance_role_t`;
CREATE TABLE `uc_instance_role_t` (
  `id` varchar(100) NOT NULL,
  `role_id` varchar(100) DEFAULT NULL,
  `role_name` varchar(500) DEFAULT NULL,
  `role_name_en` varchar(100) DEFAULT NULL,
  `code` varchar(100) DEFAULT NULL,
  `instance_id` varchar(100) DEFAULT NULL,
  `is_new` int(11) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `create_by` varchar(100) DEFAULT NULL,
  `last_update_by` varchar(100) DEFAULT NULL,
  `last_update_date` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `uc_id` varchar(255) DEFAULT NULL COMMENT 'ucid',
  `instance_user_mgm` varchar(100) DEFAULT NULL COMMENT '实例用户管理',
  `microservice` varchar(200) DEFAULT NULL COMMENT '角色微服务',
  `microservice_en` varchar(200) DEFAULT NULL COMMENT '角色微服务En',
  `version` varchar(100) DEFAULT NULL,
  `area_level` varchar(100) DEFAULT NULL,
  `role_level` varchar(50) DEFAULT NULL COMMENT '角色层级',
  `tenant_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_instance_role_t_history
-- ----------------------------
DROP TABLE IF EXISTS `uc_instance_role_t_history`;
CREATE TABLE `uc_instance_role_t_history` (
  `id` varchar(100) NOT NULL,
  `role_id` varchar(100) DEFAULT NULL,
  `role_name` varchar(500) DEFAULT NULL,
  `role_name_en` varchar(100) DEFAULT NULL,
  `code` varchar(100) DEFAULT NULL,
  `instance_id` varchar(100) DEFAULT NULL,
  `is_new` int(11) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `create_by` varchar(100) DEFAULT NULL,
  `last_update_by` varchar(100) DEFAULT NULL,
  `last_update_date` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `uc_id` varchar(255) DEFAULT NULL COMMENT 'ucid',
  `instance_user_mgm` varchar(100) DEFAULT NULL COMMENT '实例用户管理',
  `microservice` varchar(200) DEFAULT NULL COMMENT '角色微服务',
  `microservice_en` varchar(200) DEFAULT NULL COMMENT '角色微服务En',
  `version` varchar(100) DEFAULT NULL,
  `area_level` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_instance_user_oaid_map
-- ----------------------------
DROP TABLE IF EXISTS `uc_instance_user_oaid_map`;
CREATE TABLE `uc_instance_user_oaid_map` (
  `login_id` varchar(255) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `user_mobile` varchar(255) DEFAULT NULL,
  `user_oaid` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_invitation_code_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_invitation_code_t`;
CREATE TABLE `uc_invitation_code_t` (
  `id` varchar(128) NOT NULL COMMENT '自增ID',
  `invitation_code` varchar(64) NOT NULL COMMENT '邀请码',
  `register_id` varchar(64) NOT NULL COMMENT '注册码',
  `register_date` datetime DEFAULT NULL COMMENT '申请时间',
  `expiratoin_date` datetime DEFAULT NULL COMMENT '失效时间',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  `validity_type` int(8) NOT NULL COMMENT '邀请码状态 1激活,0未激活',
  `user_the_number` int(8) DEFAULT NULL COMMENT '已使用次数',
  `total_the_number` int(8) DEFAULT NULL COMMENT '总次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_ip_pool_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_ip_pool_t`;
CREATE TABLE `uc_ip_pool_t` (
  `id` varchar(100) NOT NULL,
  `ip` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL COMMENT '国家',
  `region` varchar(100) DEFAULT NULL COMMENT '省份',
  `city` varchar(100) DEFAULT NULL COMMENT '市区',
  `isp` varchar(100) DEFAULT NULL COMMENT '运营商',
  `create_date` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_job_task_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_job_task_t`;
CREATE TABLE `uc_job_task_t` (
  `id` varchar(100) NOT NULL,
  `job_id` varchar(255) DEFAULT NULL,
  `job_name` varchar(500) DEFAULT NULL,
  `job_summary` varchar(2000) DEFAULT NULL,
  `job_detail` text,
  `job_type` varchar(100) DEFAULT NULL,
  `job_level` tinyint(4) DEFAULT NULL,
  `commit_user` varchar(100) DEFAULT NULL,
  `assign_to` varchar(255) DEFAULT NULL,
  `assign_type` varchar(100) DEFAULT NULL,
  `assign_date` datetime DEFAULT NULL,
  `expire_date` datetime DEFAULT NULL,
  `premise_id` varchar(200) DEFAULT NULL,
  `instance_id` varchar(100) DEFAULT NULL,
  `instance_name` varchar(500) DEFAULT NULL,
  `tenant_id` varchar(100) DEFAULT NULL,
  `tenant_name` varchar(500) DEFAULT NULL,
  `link_url` varchar(500) DEFAULT NULL,
  `job_status` tinyint(4) DEFAULT NULL,
  `finish_user` varchar(100) DEFAULT NULL,
  `finish_type` varchar(100) DEFAULT NULL,
  `finish_date` datetime DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_lisense_illegal_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_lisense_illegal_t`;
CREATE TABLE `uc_lisense_illegal_t` (
  `path_prefix` varchar(100) NOT NULL COMMENT '服务地址前缀',
  `path_full` varchar(500) DEFAULT NULL COMMENT '抓取服务访问地址',
  PRIMARY KEY (`path_prefix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_lisense_manage_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_lisense_manage_t`;
CREATE TABLE `uc_lisense_manage_t` (
  `id` varchar(50) NOT NULL COMMENT '主键Id',
  `name` varchar(50) NOT NULL COMMENT '名称',
  `customer_public_key` varchar(2000) NOT NULL COMMENT '客户公钥',
  `system_config` longtext NOT NULL COMMENT '系统配置',
  `expir_date` datetime DEFAULT NULL COMMENT '0-无效；1-有效',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `create_by` varchar(100) DEFAULT NULL COMMENT '创建人',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  `update_by` varchar(255) DEFAULT NULL COMMENT '更新人',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_lisense_system_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_lisense_system_t`;
CREATE TABLE `uc_lisense_system_t` (
  `id` varchar(50) NOT NULL COMMENT '主键Id',
  `lisense` longtext NOT NULL COMMENT '证书内容',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  `abled` tinyint(4) NOT NULL DEFAULT '1' COMMENT '0:无效;1有效',
  `message` varchar(500) DEFAULT NULL COMMENT '证书锁定原因',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_lisense_vapp_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_lisense_vapp_t`;
CREATE TABLE `uc_lisense_vapp_t` (
  `id` varchar(50) NOT NULL COMMENT '主键Id',
  `lisense` text NOT NULL COMMENT '证书内容',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `abled` tinyint(4) NOT NULL DEFAULT '1' COMMENT '0:无效;1有效',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  `uuid` varchar(50) DEFAULT NULL COMMENT 'VAPP id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_locale_alphabet
-- ----------------------------
DROP TABLE IF EXISTS `uc_locale_alphabet`;
CREATE TABLE `uc_locale_alphabet` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `code` varchar(50) NOT NULL COMMENT '语言code',
  `name` varchar(50) DEFAULT NULL COMMENT '语言名称',
  `modify_time` datetime DEFAULT NULL COMMENT '更新时间',
  `alphabet` tinytext NOT NULL COMMENT '字母表(必须排好顺序，英文逗号分隔)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uc_locale_alphabet_index` (`code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8 COMMENT='语种及字母表';

-- ----------------------------
-- Table structure for uc_mail_config_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_mail_config_t`;
CREATE TABLE `uc_mail_config_t` (
  `mail_id` varchar(100) NOT NULL,
  `mail_server` varchar(256) DEFAULT NULL,
  `mail_port` decimal(6,0) DEFAULT NULL,
  `mail_user` varchar(256) DEFAULT NULL,
  `mail_pass` varchar(256) DEFAULT NULL,
  `mail_address` varchar(300) DEFAULT NULL,
  `mail_test_address` varchar(300) DEFAULT NULL,
  `mail_status` varchar(1) DEFAULT NULL,
  `mail_ssl` varchar(1) DEFAULT NULL,
  `create_by` decimal(22,0) DEFAULT NULL,
  `create_by_name` varchar(1000) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `last_update_by` decimal(22,0) DEFAULT NULL,
  `last_update_by_name` varchar(1000) DEFAULT NULL,
  `last_update_date` datetime DEFAULT NULL,
  PRIMARY KEY (`mail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_menu_node_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_menu_node_t`;
CREATE TABLE `uc_menu_node_t` (
  `id` varchar(100) NOT NULL,
  `parent_id` varchar(200) DEFAULT NULL,
  `group_name` varchar(200) DEFAULT NULL,
  `icon` varchar(100) DEFAULT NULL,
  `node_name` varchar(200) DEFAULT NULL,
  `menu_type` varchar(200) DEFAULT NULL,
  `permiss_code` varchar(200) DEFAULT NULL,
  `has_child` tinyint(4) DEFAULT NULL,
  `node_level` int(11) DEFAULT NULL,
  `menu_sys` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_message_role
-- ----------------------------
DROP TABLE IF EXISTS `uc_message_role`;
CREATE TABLE `uc_message_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `roleid` varchar(100) DEFAULT NULL COMMENT '角色ID ',
  `message_type` varchar(10) DEFAULT NULL COMMENT '消息类型',
  `message_role` text COMMENT '消息接收的角色对象',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_meta_data_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_meta_data_t`;
CREATE TABLE `uc_meta_data_t` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `type` varchar(50) DEFAULT NULL COMMENT '类型',
  `key` varchar(100) DEFAULT NULL COMMENT '配置关键字',
  `value` varchar(500) DEFAULT NULL COMMENT '配置值',
  `tenant_id` varchar(255) DEFAULT NULL COMMENT '租户id',
  `meta_name` varchar(500) DEFAULT NULL COMMENT '中文名',
  `meta_name_en` varchar(500) DEFAULT NULL COMMENT '英文名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_meta_permission_tag_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_meta_permission_tag_t`;
CREATE TABLE `uc_meta_permission_tag_t` (
  `id` varchar(100) NOT NULL COMMENT 'id',
  `name` varchar(100) DEFAULT NULL COMMENT '名称',
  `tag_name_en` varchar(100) DEFAULT NULL COMMENT '英文名称',
  `code` varchar(100) DEFAULT NULL COMMENT '权限标签',
  `description` text COMMENT '描述',
  `create_by` varchar(100) DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  `microservice` varchar(255) DEFAULT NULL COMMENT '微服务名',
  `microservice_en` varchar(255) DEFAULT NULL COMMENT '微服务英文名',
  `type` varchar(100) DEFAULT NULL COMMENT '元数据类别',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_org_area_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_org_area_t`;
CREATE TABLE `uc_org_area_t` (
  `orga_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `orga_name` varchar(255) DEFAULT NULL,
  `area_level` int(11) NOT NULL,
  `area_id` varchar(255) DEFAULT NULL,
  `area_name` varchar(255) DEFAULT NULL,
  `relation_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`orga_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_organize_user_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_organize_user_t`;
CREATE TABLE `uc_organize_user_t` (
  `id` varchar(100) NOT NULL,
  `user_id` varchar(200) DEFAULT NULL,
  `tenant_id` varchar(200) DEFAULT NULL,
  `is_leader` tinyint(4) DEFAULT NULL,
  `position` varchar(100) DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `last_update_by` varchar(100) DEFAULT NULL,
  `last_update_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_password_history
-- ----------------------------
DROP TABLE IF EXISTS `uc_password_history`;
CREATE TABLE `uc_password_history` (
  `id` varchar(100) NOT NULL,
  `userid` varchar(100) NOT NULL,
  `password` varchar(500) NOT NULL,
  `creatdate` datetime NOT NULL,
  `parentid` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_permission_tag_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_permission_tag_t`;
CREATE TABLE `uc_permission_tag_t` (
  `id` varchar(100) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `tag_name_en` varchar(100) DEFAULT NULL,
  `code` varchar(100) DEFAULT NULL,
  `uc_id` varchar(100) DEFAULT NULL,
  `expression` text,
  `description` varchar(2000) DEFAULT NULL,
  `create_by` varchar(100) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `last_update_by` varchar(100) DEFAULT NULL,
  `last_update_date` datetime DEFAULT NULL,
  `microservice` varchar(255) DEFAULT NULL,
  `microservice_en` varchar(255) DEFAULT NULL,
  `version` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_portable_hall_relastion_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_portable_hall_relastion_t`;
CREATE TABLE `uc_portable_hall_relastion_t` (
  `id` varchar(100) NOT NULL,
  `user_id` varchar(100) DEFAULT NULL COMMENT '平台用户id',
  `ph_user_id` varchar(100) DEFAULT NULL COMMENT '随身厅用户id',
  `ph_token` varchar(255) DEFAULT NULL COMMENT '随身厅token',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_problem_collection
-- ----------------------------
DROP TABLE IF EXISTS `uc_problem_collection`;
CREATE TABLE `uc_problem_collection` (
  `id` varchar(100) NOT NULL,
  `problem_type` tinyint(4) DEFAULT NULL COMMENT '问题类型（0无）',
  `user_id` varchar(100) DEFAULT NULL,
  `code` varchar(100) DEFAULT NULL,
  `descrption` varchar(4000) DEFAULT NULL COMMENT '意见反馈内容和需求描述',
  `md5_phone` varchar(255) NOT NULL COMMENT '手机号码',
  `client_id` varchar(100) DEFAULT NULL COMMENT '终端Id'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_products_trial_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_products_trial_t`;
CREATE TABLE `uc_products_trial_t` (
  `id` varchar(100) NOT NULL,
  `task_name` varchar(100) DEFAULT NULL,
  `task_service` varchar(100) DEFAULT NULL COMMENT 'uc名称',
  `trade` varchar(100) DEFAULT NULL COMMENT '行业',
  `corporation` varchar(100) DEFAULT NULL COMMENT '公司名称',
  `province` varchar(100) DEFAULT NULL COMMENT '公司所在省',
  `city` varchar(100) DEFAULT NULL COMMENT '公司所在市',
  `user_id` varchar(100) DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL COMMENT '申请使用用户',
  `duties` varchar(100) DEFAULT NULL COMMENT '职务',
  `we_chat` varchar(1000) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL COMMENT '电话号码',
  `code` varchar(100) DEFAULT NULL COMMENT '短信验证码',
  `create_date` datetime DEFAULT NULL,
  `package_type` tinyint(4) DEFAULT NULL COMMENT '套餐类型（1、体验版，2、初级版，3、高级版，4、企业版，5、超级版）',
  `invitation_code_number` int(4) DEFAULT NULL COMMENT '注册码个数',
  `status` tinyint(4) DEFAULT NULL COMMENT '审批结果(1通过，2驳回，3审核中)',
  `approver_id` varchar(100) DEFAULT NULL COMMENT '审批人',
  `approve_date` datetime DEFAULT NULL COMMENT '审批时间',
  `approve_descrption` varchar(255) DEFAULT NULL COMMENT '审批描述',
  `enabled` decimal(1,0) DEFAULT '0' COMMENT '是否显示数据（0、显示，1不显示 默认是0）',
  `approve_register_version` int(128) DEFAULT NULL COMMENT '审核通过版本',
  `approve_total_number` int(8) DEFAULT NULL COMMENT '审核通过邀请码使用次数',
  `premise_id` varchar(255) DEFAULT NULL COMMENT 'premise_id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_register_invitation_user_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_register_invitation_user_t`;
CREATE TABLE `uc_register_invitation_user_t` (
  `id` varchar(128) NOT NULL COMMENT '主键id',
  `register_id` varchar(128) NOT NULL COMMENT '注册码',
  `invitation_id` varchar(128) NOT NULL COMMENT '邀请码',
  `user_id` varchar(128) DEFAULT NULL COMMENT '用户id',
  `modify_date` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_registered_code_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_registered_code_t`;
CREATE TABLE `uc_registered_code_t` (
  `id` varchar(128) NOT NULL COMMENT '自增ID',
  `register_code` varchar(64) NOT NULL COMMENT '注册码',
  `tenant_id` varchar(128) DEFAULT NULL COMMENT '租户id',
  `register_company` varchar(1024) DEFAULT NULL COMMENT '注册公司',
  `register_version` int(8) NOT NULL COMMENT '1:体验版   2:初级版  3:高级版  4:企业版',
  `register_date` datetime DEFAULT NULL COMMENT '注册时间',
  `expiratoin_date` datetime DEFAULT NULL COMMENT '失效时间',
  `modify_date` datetime DEFAULT NULL,
  `validity_type` int(8) NOT NULL COMMENT '注册码状态 1未使用,0已使用',
  `contact_name` varchar(255) DEFAULT NULL COMMENT '联系人姓名',
  `contact_email` varchar(255) DEFAULT NULL COMMENT '联系人邮箱',
  `contact_phone` varchar(255) DEFAULT NULL COMMENT '联系人电话',
  `number` int(8) DEFAULT NULL COMMENT '注册码下邀请码可使用次数',
  `total_the_number` int(8) DEFAULT NULL COMMENT '注册码下可加入最大人数',
  `user_number` int(8) DEFAULT NULL COMMENT '注册码已加入人数',
  `premise_id` varchar(255) DEFAULT NULL COMMENT 'premise_id',
  `packages` varchar(255) DEFAULT NULL,
  `premise_name` varchar(255) DEFAULT NULL,
  `app` int(5) DEFAULT NULL,
  `QRCode` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_role_permission_tag_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_role_permission_tag_t`;
CREATE TABLE `uc_role_permission_tag_t` (
  `id` varchar(100) NOT NULL,
  `role_id` varchar(100) DEFAULT NULL,
  `permission_id` varchar(100) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `create_by` varchar(100) DEFAULT NULL,
  `last_update_by` varchar(100) DEFAULT NULL,
  `last_update_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_role_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_role_t`;
CREATE TABLE `uc_role_t` (
  `id` varchar(100) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `role_name_en` varchar(100) DEFAULT NULL,
  `code` varchar(100) DEFAULT NULL,
  `uc_id` varchar(50) DEFAULT NULL,
  `role_type` varchar(10) DEFAULT NULL,
  `create_by` varchar(100) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `last_update_date` datetime DEFAULT NULL,
  `last_update_by` varchar(100) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `description_en` varchar(2000) DEFAULT NULL,
  `instance_user_mgm` varchar(100) DEFAULT NULL COMMENT '实例用户管理',
  `microservice` varchar(200) DEFAULT NULL COMMENT '角色微服务',
  `microservice_en` varchar(200) DEFAULT NULL COMMENT '角色微服务En',
  `version` varchar(100) DEFAULT NULL,
  `area_level` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_role_user_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_role_user_t`;
CREATE TABLE `uc_role_user_t` (
  `id` varchar(100) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `instance_new_role_id` varchar(100) NOT NULL,
  `instance_id` varchar(100) DEFAULT NULL,
  `target_id` varchar(100) DEFAULT NULL,
  `target_type` varchar(200) DEFAULT NULL,
  `target_code` varchar(2000) DEFAULT NULL COMMENT '权限code',
  `lastupdatedate` datetime DEFAULT NULL COMMENT '最后更新时间',
  `gridmanager` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_role_user_t_history
-- ----------------------------
DROP TABLE IF EXISTS `uc_role_user_t_history`;
CREATE TABLE `uc_role_user_t_history` (
  `id` varchar(100) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `instance_new_role_id` varchar(100) NOT NULL,
  `instance_id` varchar(100) DEFAULT NULL,
  `target_id` varchar(100) DEFAULT NULL,
  `target_type` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_second_check_url_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_second_check_url_t`;
CREATE TABLE `uc_second_check_url_t` (
  `id` varchar(100) NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `check_url` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_shipment_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_shipment_t`;
CREATE TABLE `uc_shipment_t` (
  `company_name` varchar(100) DEFAULT NULL COMMENT '公司名称',
  `contact` varchar(50) DEFAULT NULL COMMENT '联系人',
  `job_title` varchar(20) DEFAULT NULL COMMENT '职务',
  `email` varchar(255) DEFAULT NULL COMMENT '邮箱地址',
  `phone` varchar(255) DEFAULT NULL COMMENT '电话号码',
  `terminal` varchar(100) DEFAULT NULL COMMENT '部署终端',
  `uat_terminal` varchar(100) DEFAULT NULL COMMENT '测试部署终端',
  `expire_time` datetime DEFAULT NULL COMMENT '到期时间',
  `tenant` varchar(50) DEFAULT NULL COMMENT '租户',
  `uat_tenant` varchar(50) DEFAULT NULL COMMENT '测试租户',
  `sender` varchar(50) DEFAULT NULL COMMENT '发货人',
  `status` varchar(10) DEFAULT NULL COMMENT '当前状态',
  `create_time` datetime DEFAULT NULL COMMENT '调测发货时间',
  `test_end_time` datetime DEFAULT NULL COMMENT '调测结束时间',
  `send_time` datetime DEFAULT NULL COMMENT '发货时间',
  `QRCode` varchar(255) DEFAULT NULL COMMENT '二维码地址',
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `package_type` int(5) DEFAULT NULL COMMENT '(1.基础版 2.营销增强版 3.规划增强版 4.开发版)',
  `product_name` varchar(255) DEFAULT NULL COMMENT '产品名称',
  `app` varchar(50) DEFAULT NULL COMMENT '手机app',
  `total_number` int(20) DEFAULT NULL COMMENT '可激活用户数',
  `uat_total_number` int(20) DEFAULT NULL COMMENT '测试可激活用户数',
  `register_id` varchar(100) DEFAULT NULL COMMENT '注册码',
  `uat_register_id` varchar(100) DEFAULT NULL COMMENT '测试注册码',
  `domain` varchar(100) DEFAULT NULL COMMENT '域名',
  `uat_domain` varchar(100) DEFAULT NULL COMMENT '测试域名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_task_info_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_task_info_t`;
CREATE TABLE `uc_task_info_t` (
  `id` varchar(100) NOT NULL COMMENT '任务ID',
  `name` varchar(250) DEFAULT NULL COMMENT '任务名称',
  `key` varchar(100) DEFAULT NULL COMMENT '任务关键字',
  `service` varchar(250) DEFAULT NULL COMMENT 'UC应用名',
  `callback` text COMMENT '点击任务时，回调UC的回调接口',
  `type` varchar(16) DEFAULT NULL COMMENT '任务类型',
  `status` int(11) DEFAULT '0' COMMENT '任务状态——0: 未开始; 1: 进行中; 2: 已完成',
  `process` int(11) DEFAULT '0' COMMENT '任务进度——[0, 100]',
  `start_type` int(11) DEFAULT '0' COMMENT '任务启动类型——[0: 任务触发; 1: 定时启动;]',
  `info` text COMMENT '任务信息',
  `creater_name` varchar(100) DEFAULT NULL COMMENT '任务创建者；系统创建的任务填写sys',
  `creater_id` varchar(100) DEFAULT NULL COMMENT '任务创建者ID；此ID与用户管理中的用户ID关联查询出用户信息',
  `current_usr_name` varchar(100) DEFAULT NULL COMMENT '当前处理人；系统创建的任务填写sys',
  `current_usr_id` varchar(100) DEFAULT NULL COMMENT '当前处理人ID；此ID与用户管理中的用户ID关联查询出用户信息',
  `create_time` datetime DEFAULT NULL COMMENT '任务创建时间',
  `start_time` datetime DEFAULT NULL COMMENT '任务启动时间',
  `end_time` datetime DEFAULT NULL COMMENT '任务完成时间',
  `expiration_time` int(11) DEFAULT NULL COMMENT '任务老化时间——与任务创建时间的UTC秒数差',
  `client_id` varchar(100) DEFAULT NULL COMMENT '终端Id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_tenant_client_url_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_tenant_client_url_t`;
CREATE TABLE `uc_tenant_client_url_t` (
  `id` varchar(100) NOT NULL,
  `client_id` varchar(255) DEFAULT NULL,
  `url` varchar(500) DEFAULT NULL,
  `tenant_id` varchar(100) DEFAULT NULL,
  `redirect_uri` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_tenant_fixed_instance_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_tenant_fixed_instance_t`;
CREATE TABLE `uc_tenant_fixed_instance_t` (
  `id` varchar(100) NOT NULL,
  `tenant_id` varchar(100) DEFAULT NULL,
  `instance_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_tenant_org_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_tenant_org_t`;
CREATE TABLE `uc_tenant_org_t` (
  `id` varchar(100) NOT NULL,
  `tenant_id` varchar(100) NOT NULL,
  `premise_id` varchar(100) DEFAULT NULL,
  `operator_id` varchar(100) DEFAULT NULL,
  `sso_auto` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_tenant_recordset_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_tenant_recordset_t`;
CREATE TABLE `uc_tenant_recordset_t` (
  `id` varchar(100) NOT NULL COMMENT 'id',
  `recordset_id` varchar(100) DEFAULT NULL COMMENT '记录集Id,产生真实数据前为空 ',
  `tenant_id` varchar(100) NOT NULL COMMENT '租户Id',
  `details` varchar(3000) DEFAULT NULL COMMENT '详情',
  `status` varchar(50) NOT NULL COMMENT '状态： ACTIVE',
  `create_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_trade_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_trade_t`;
CREATE TABLE `uc_trade_t` (
  `id` varchar(100) NOT NULL,
  `trade_name` varchar(100) DEFAULT NULL COMMENT '行业名称',
  `trade_name_en` varchar(100) DEFAULT NULL COMMENT '行业英文名称',
  `seq` int(11) DEFAULT NULL COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_user_meta_config_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_user_meta_config_t`;
CREATE TABLE `uc_user_meta_config_t` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `meta_key` varchar(100) NOT NULL COMMENT '配置关键字',
  `meta_name` varchar(500) DEFAULT NULL COMMENT '配置项名称,默认名称',
  `meta_type` varchar(100) DEFAULT NULL COMMENT '元数据类型，按照Java类型处理:Boolean,String,Integer,Long',
  `edit_able` int(11) NOT NULL DEFAULT '1' COMMENT '0:不可便捷1:可编辑',
  `tenant_id` varchar(255) NOT NULL DEFAULT '0' COMMENT '租户:id;非租户数据填:0',
  `create_date` time DEFAULT NULL COMMENT '创建时间',
  `update_date` time DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `mkey` (`meta_key`,`tenant_id`) USING BTREE COMMENT '唯一索引'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='用户元数据配置';

-- ----------------------------
-- Table structure for uc_user_metadata_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_user_metadata_t`;
CREATE TABLE `uc_user_metadata_t` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_id` varchar(100) NOT NULL COMMENT '用户ID',
  `key` varchar(100) NOT NULL COMMENT '配置关键字',
  `value` varchar(500) DEFAULT NULL COMMENT '配置值',
  `tenant_id` varchar(255) NOT NULL DEFAULT '0' COMMENT '租户id:非租户数据填0',
  `create_date` time DEFAULT NULL COMMENT '创建时间',
  `update_date` time DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mkey` (`user_id`,`key`,`tenant_id`) COMMENT '唯一索引'
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='用户元数据';

-- ----------------------------
-- Table structure for uc_user_premise_tenant
-- ----------------------------
DROP TABLE IF EXISTS `uc_user_premise_tenant`;
CREATE TABLE `uc_user_premise_tenant` (
  `id` varchar(100) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `premise_client_id` varchar(255) NOT NULL,
  `tenant_id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_user_relation_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_user_relation_t`;
CREATE TABLE `uc_user_relation_t` (
  `id` varchar(100) NOT NULL,
  `user_id` varchar(100) DEFAULT NULL,
  `user_name` varchar(200) DEFAULT NULL,
  `user_src` varchar(200) DEFAULT NULL,
  `relation_user_id` varchar(100) DEFAULT NULL,
  `relation_user_name` varchar(200) DEFAULT NULL,
  `relation_user_src` varchar(200) DEFAULT NULL,
  `last_check_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uc_user_relation_t_UN` (`user_id`,`relation_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_user_src_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_user_src_t`;
CREATE TABLE `uc_user_src_t` (
  `user_src` varchar(100) NOT NULL,
  `user_src_name` varchar(200) DEFAULT NULL,
  `user_src_name_en` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`user_src`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_user_status_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_user_status_t`;
CREATE TABLE `uc_user_status_t` (
  `id` varchar(100) NOT NULL,
  `user_id` varchar(100) NOT NULL COMMENT '用户ID',
  `status` varchar(2) DEFAULT NULL COMMENT '是否全屏',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_vapp_configuration_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_vapp_configuration_t`;
CREATE TABLE `uc_vapp_configuration_t` (
  `id` varchar(50) NOT NULL COMMENT '配置ID',
  `target_id` varchar(50) NOT NULL COMMENT 'VAPP关联ID',
  `params` varchar(500) DEFAULT NULL COMMENT 'VAPP配置参数',
  `tenant_id` varchar(50) NOT NULL COMMENT '租户id',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `type` int(11) DEFAULT NULL COMMENT '类型',
  `create_date` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  `last_update_date` timestamp NULL DEFAULT NULL COMMENT '最后更新时间',
  `name` varchar(50) DEFAULT NULL COMMENT '名称',
  `site_id` varchar(50) DEFAULT NULL COMMENT '站点ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_vapp_permission_tag_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_vapp_permission_tag_t`;
CREATE TABLE `uc_vapp_permission_tag_t` (
  `id` varchar(100) NOT NULL,
  `code` varchar(100) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `tag_name` varchar(100) DEFAULT NULL,
  `tag_name_en` varchar(100) DEFAULT NULL,
  `vapp_code` varchar(100) DEFAULT NULL,
  `description` text,
  `expression` text,
  `microservice` varchar(255) DEFAULT NULL,
  `microservice_en` varchar(255) DEFAULT NULL,
  `create_by` varchar(100) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Table structure for uc_white_auth_url_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_white_auth_url_t`;
CREATE TABLE `uc_white_auth_url_t` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `model` varchar(50) DEFAULT NULL COMMENT '接口模块',
  `url` varchar(500) DEFAULT NULL COMMENT '请求地址,方法',
  `description` varchar(500) DEFAULT NULL COMMENT '请求白名单描述',
  `abled` tinyint(4) DEFAULT '0' COMMENT '0-无效；1-有效',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_zone_info_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_zone_info_t`;
CREATE TABLE `uc_zone_info_t` (
  `id` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `create_date` datetime DEFAULT NULL,
  `project_id` varchar(100) DEFAULT NULL,
  `port` varchar(16) DEFAULT NULL COMMENT '端口号',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for uc_zone_recordset_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_zone_recordset_t`;
CREATE TABLE `uc_zone_recordset_t` (
  `id` varchar(100) NOT NULL COMMENT 'id',
  `zone_id` varchar(100) NOT NULL COMMENT '上级域名Id',
  `name` varchar(200) NOT NULL COMMENT '域名',
  `records` text NOT NULL COMMENT '域名',
  `type` varchar(200) NOT NULL COMMENT '类型,暂时使用A',
  `ttl` bigint(20) DEFAULT NULL COMMENT '缓存时间',
  `description` varchar(2000) DEFAULT NULL,
  `status` varchar(50) NOT NULL COMMENT '状态：ACTIVE ',
  `project_id` varchar(100) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for user_application_info
-- ----------------------------
DROP TABLE IF EXISTS `user_application_info`;
CREATE TABLE `user_application_info` (
  `application` varchar(255) DEFAULT NULL,
  `application_id` varchar(200) DEFAULT NULL,
  `register_id` varchar(200) DEFAULT NULL,
  `applicationEN` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- View structure for user_tenant_view
-- ----------------------------
DROP VIEW IF EXISTS `user_tenant_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`ucmarket_iam`@`%` SQL SECURITY DEFINER VIEW `user_tenant_view` AS select `am`.`user_id` AS `user_id`,group_concat(distinct `it`.`tenantname` separator ',') AS `tenant_name`,group_concat(distinct `it`.`tenantid` separator ',') AS `tenant_id` from (`uc_assignment_t` `am` join `cmp_iam_tenant_t` `it` on((`am`.`target_id` = `it`.`tenantid`))) group by `am`.`user_id` ;

-- ----------------------------
-- Procedure structure for add_role_with_code
-- ----------------------------
DROP PROCEDURE IF EXISTS `add_role_with_code`;
DELIMITER ;;
CREATE DEFINER=`ucmarket_iam`@`%` PROCEDURE `add_role_with_code`(IN code_param VARCHAR(50), IN roleName VARCHAR(50))
BEGIN
        SET @permission_code = code_param;
        SET @role_name = roleName;
        SET @role_id_p = null;
        SET @permission_id_p = null;

        SELECT id INTO @permission_id_p FROM `uc_permission_tag_t` WHERE CODE = @permission_code AND uc_id = '0';
        select id INTO @role_id_p FROM uc_role_t WHERE name = @role_name AND uc_id = '0';
    IF 
                -- 查询code是否存在，不存在则退出
            EXISTS ( SELECT @permission_id_p )
                -- 查询角色是否存在，不存在则退出
            AND EXISTS ( SELECT @role_id_p )
                -- 查询角色和code绑定关系是否存在,不存在则添加
            AND NOT EXISTS ( SELECT 1 FROM uc_role_permission_tag_t WHERE role_id = @role_id_p AND permission_id = @permission_id_p )

        THEN
                -- 插入角色-菜单code关系到uc_role_permission_tag_t表
                INSERT INTO `uc_role_permission_tag_t` (`id`, `role_id`, `permission_id`, `create_date`, `create_by`, `last_update_by`, `last_update_date`) 
                VALUES (UUID(), @role_id_p, @permission_id_p, UTC_TIMESTAMP, NULL, NULL, NULL);

    ELSE
        SELECT 'exist';
    END IF;
end
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for create_node_index
-- ----------------------------
DROP PROCEDURE IF EXISTS `create_node_index`;
DELIMITER ;;
CREATE DEFINER=`ucmarket_iam`@`%` PROCEDURE `create_node_index`()
BEGIN
    
	DECLARE  CurrentDatabase VARCHAR(100);
	SELECT DATABASE() INTO CurrentDatabase;
	IF NOT EXISTS (SELECT * FROM information_schema.statistics WHERE table_schema=CurrentDatabase AND table_name = 'cmp_iam_resource_tree' AND index_name = 'cmp_iam_resource_tree_obj_id_IDX') THEN  
	   CREATE INDEX cmp_iam_resource_tree_obj_id_IDX ON cmp_iam_resource_tree (obj_id) ;
	ELSE
        select 'exist';
	END IF;  
end
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for pro_clear_ip_data
-- ----------------------------
DROP PROCEDURE IF EXISTS `pro_clear_ip_data`;
DELIMITER ;;
CREATE DEFINER=`ucmarket_iam`@`%` PROCEDURE `pro_clear_ip_data`()
BEGIN
    
  DELETE FROM uc_ip_pool_t WHERE DATE(create_date)<=DATE(DATE_SUB(NOW(),INTERVAL 90 DAY));
end
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for update_assignment_schema
-- ----------------------------
DROP PROCEDURE IF EXISTS `update_assignment_schema`;
DELIMITER ;;
CREATE DEFINER=`ucmarket_iam`@`%` PROCEDURE `update_assignment_schema`()
BEGIN
    
	DECLARE  CurrentDatabase VARCHAR(100);
	SELECT DATABASE() INTO CurrentDatabase;
	

	
	IF NOT EXISTS (SELECT * FROM information_schema.statistics WHERE table_schema=CurrentDatabase AND table_name = 'uc_assignment_t' AND index_name = 'uc_assignment_t_target_id_IDX') THEN  
	  CREATE INDEX uc_assignment_t_target_id_IDX ON uc_assignment_t (target_id);
	ELSE
        SELECT 'exist';
	END IF;  
	
END
;;
DELIMITER ;

-- ----------------------------
-- Event structure for event_time_clear_ip
-- ----------------------------
DROP EVENT IF EXISTS `event_time_clear_ip`;
DELIMITER ;;
CREATE DEFINER=`ucmarket_iam`@`%` EVENT `event_time_clear_ip` ON SCHEDULE EVERY 1 DAY STARTS '2019-01-15 00:00:00' ON COMPLETION PRESERVE ENABLE DO CALL pro_clear_ip_data()
;;
DELIMITER ;
