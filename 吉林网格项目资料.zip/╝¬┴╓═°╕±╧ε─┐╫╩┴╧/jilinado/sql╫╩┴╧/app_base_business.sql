/*
Navicat MySQL Data Transfer

Source Server         : ai4a_10.161.124.150_22035_ucadmin
Source Server Version : 50723
Source Host           : 10.161.124.150:22035
Source Database       : app_base_business

Target Server Type    : MYSQL
Target Server Version : 50723
File Encoding         : 65001

Date: 2020-04-26 11:11:26
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for advertisement_file_t
-- ----------------------------
DROP TABLE IF EXISTS `advertisement_file_t`;
CREATE TABLE `advertisement_file_t` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `image_id` varchar(50) NOT NULL COMMENT '图片id',
  `type` varchar(50) DEFAULT NULL COMMENT '文件类型(后缀)',
  `image` longblob NOT NULL COMMENT 'byte数组',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='广告附件表';

-- ----------------------------
-- Table structure for advertisement_t
-- ----------------------------
DROP TABLE IF EXISTS `advertisement_t`;
CREATE TABLE `advertisement_t` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `tenant_code` varchar(50) DEFAULT NULL COMMENT '租户编码',
  `name` varchar(200) DEFAULT NULL COMMENT '名称',
  `image_id` varchar(200) NOT NULL COMMENT '图片id',
  `link` varchar(255) DEFAULT NULL COMMENT '链接',
  `content` mediumtext COMMENT '内容',
  `seq` int(11) NOT NULL COMMENT '排序',
  `status` bit(1) NOT NULL COMMENT '状态(是否启用)',
  `create_time` datetime NOT NULL COMMENT '发布时间',
  `publisher` varchar(100) NOT NULL COMMENT '发布人账号',
  `publisher_name` varchar(100) DEFAULT NULL COMMENT '发布人姓名',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='广告表';

-- ----------------------------
-- Table structure for flyway_schema_history
-- ----------------------------
DROP TABLE IF EXISTS `flyway_schema_history`;
CREATE TABLE `flyway_schema_history` (
  `installed_rank` int(11) NOT NULL,
  `version` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `script` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checksum` int(11) DEFAULT NULL,
  `installed_by` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `installed_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `execution_time` int(11) NOT NULL,
  `success` tinyint(1) NOT NULL,
  PRIMARY KEY (`installed_rank`),
  KEY `flyway_schema_history_s_idx` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for form_data_t
-- ----------------------------
DROP TABLE IF EXISTS `form_data_t`;
CREATE TABLE `form_data_t` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `form_id` bigint(20) NOT NULL COMMENT '表单id',
  `page_id` bigint(20) DEFAULT NULL COMMENT '分页id',
  `group_id` bigint(20) DEFAULT NULL COMMENT '分组id',
  `item_id` bigint(20) NOT NULL COMMENT '条目id',
  `value` text COMMENT '条目值',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `form_id_index` (`form_id`) USING BTREE,
  KEY `item_id_index` (`item_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='表单数据';

-- ----------------------------
-- Table structure for form_item_t
-- ----------------------------
DROP TABLE IF EXISTS `form_item_t`;
CREATE TABLE `form_item_t` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `category` int(11) DEFAULT NULL COMMENT '所属分类: 1表单,2分页,3分组',
  `category_id` bigint(20) NOT NULL COMMENT '所属分类id',
  `sort` int(11) NOT NULL COMMENT '排序',
  `direction` int(11) DEFAULT NULL COMMENT '方向: 1纵向,2横向',
  `label` varchar(30) DEFAULT NULL COMMENT '标签',
  `label_width` int(11) DEFAULT NULL COMMENT '标签宽度',
  `required` bit(1) NOT NULL COMMENT '是否必填',
  `control_type` varchar(20) DEFAULT NULL COMMENT '控件类型: radio单选,checkbox多选,textarea文本',
  `default_value` text COMMENT '默认值',
  `prefix` varchar(50) DEFAULT NULL COMMENT '前缀',
  `suffix` varchar(50) DEFAULT NULL COMMENT '后缀',
  `rule` json DEFAULT NULL COMMENT '规则',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `category_id_index` (`category_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='表单条目';

-- ----------------------------
-- Table structure for form_t
-- ----------------------------
DROP TABLE IF EXISTS `form_t`;
CREATE TABLE `form_t` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `code` varchar(36) NOT NULL COMMENT '编码',
  `name` varchar(50) NOT NULL COMMENT '名称',
  `memo` varchar(200) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `code_index` (`code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='表单';

-- ----------------------------
-- Table structure for form_user_t
-- ----------------------------
DROP TABLE IF EXISTS `form_user_t`;
CREATE TABLE `form_user_t` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `tenant_code` varchar(36) DEFAULT NULL COMMENT '租户编码',
  `form_code` varchar(36) NOT NULL COMMENT '表单编码',
  `user_id` varchar(36) NOT NULL COMMENT '用户',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='表单与用户关系表';

-- ----------------------------
-- Table structure for sign_in_t
-- ----------------------------
DROP TABLE IF EXISTS `sign_in_t`;
CREATE TABLE `sign_in_t` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `tenant_code` varchar(50) DEFAULT NULL COMMENT '租户编码',
  `uid` varchar(50) NOT NULL COMMENT '用户账号',
  `user_id` varchar(50) DEFAULT NULL COMMENT '用户Id',
  `date` date NOT NULL COMMENT '签到日期',
  `time` time NOT NULL COMMENT '签到时间',
  `address` varchar(200) DEFAULT NULL COMMENT '地址',
  `coordinate` point NOT NULL COMMENT '坐标',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=213 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='签到记录表';

-- ----------------------------
-- Table structure for task_ccperson_t
-- ----------------------------
DROP TABLE IF EXISTS `task_ccperson_t`;
CREATE TABLE `task_ccperson_t` (
  `code` varchar(36) NOT NULL COMMENT '主键',
  `task_code` varchar(36) NOT NULL COMMENT '任务编码',
  `executor` varchar(36) NOT NULL COMMENT '抄送人',
  `execution_time` datetime DEFAULT NULL COMMENT '操作完成时间',
  `status` int(11) DEFAULT NULL COMMENT '状态:1处理中,2已完成',
  PRIMARY KEY (`code`) USING BTREE,
  KEY `index_taskcode` (`task_code`) USING BTREE COMMENT '任务编码索引',
  KEY `index_executor` (`executor`) USING BTREE COMMENT '抄送人索引'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='任务抄送记录表';

-- ----------------------------
-- Table structure for task_dynamic_t
-- ----------------------------
DROP TABLE IF EXISTS `task_dynamic_t`;
CREATE TABLE `task_dynamic_t` (
  `code` varchar(36) NOT NULL COMMENT '主键',
  `task_code` varchar(36) NOT NULL COMMENT '任务编码',
  `task_handle_code` varchar(36) DEFAULT NULL COMMENT '任务执行编码',
  `operator` varchar(36) NOT NULL COMMENT '操作人',
  `execution_time` datetime NOT NULL COMMENT '操作时间',
  `execution_type` int(11) NOT NULL COMMENT '操作类型 1:发起任务,2:执行任务,3:审核同意,4:审核拒绝,5:留言',
  `content` json DEFAULT NULL COMMENT '操作内容',
  PRIMARY KEY (`code`) USING BTREE,
  KEY `index_taskcode` (`task_code`) USING BTREE COMMENT '任务编码索引'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='任务动态表';

-- ----------------------------
-- Table structure for task_executor_form_t
-- ----------------------------
DROP TABLE IF EXISTS `task_executor_form_t`;
CREATE TABLE `task_executor_form_t` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `task_handle_code` varchar(36) NOT NULL COMMENT '任务执行表编码',
  `form_data_id` bigint(20) NOT NULL COMMENT '表单数据id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='执行记录与表单数据的关系表';

-- ----------------------------
-- Table structure for task_executor_t
-- ----------------------------
DROP TABLE IF EXISTS `task_executor_t`;
CREATE TABLE `task_executor_t` (
  `code` varchar(36) NOT NULL COMMENT '主键',
  `task_code` varchar(36) NOT NULL COMMENT '任务编码',
  `executor` varchar(36) NOT NULL COMMENT '执行人',
  `status` int(11) NOT NULL COMMENT '10: 执行中 11: 已拒绝 20: 审批中 30: 已完成 31: 已终止',
  `execution_time` datetime DEFAULT NULL COMMENT '完成时间',
  `approver` varchar(36) DEFAULT NULL COMMENT '审批人',
  `approver_comment` varchar(200) DEFAULT NULL COMMENT '审批意见',
  `approver_time` datetime DEFAULT NULL COMMENT '审批时间',
  `batch_fields` json DEFAULT NULL COMMENT '批量派发字段',
  PRIMARY KEY (`code`) USING BTREE,
  KEY `index_taskcode` (`task_code`) USING BTREE COMMENT '任务编码索引',
  KEY `index_executor` (`executor`) USING BTREE COMMENT '执行人索引'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='任务执行记录表';

-- ----------------------------
-- Table structure for task_remind_t
-- ----------------------------
DROP TABLE IF EXISTS `task_remind_t`;
CREATE TABLE `task_remind_t` (
  `code` varchar(36) NOT NULL COMMENT '主键',
  `tenant_code` varchar(36) DEFAULT NULL COMMENT '租户编码',
  `task_code` varchar(36) NOT NULL COMMENT '任务编码',
  `type` int(11) NOT NULL COMMENT '提醒类型:1执行任务,2审批任务,3抄送任务',
  `executor` varchar(36) NOT NULL COMMENT '执行人(也即是被提醒人)',
  PRIMARY KEY (`code`) USING BTREE,
  KEY `index_taskcode` (`task_code`) USING BTREE COMMENT '任务编码索引',
  KEY `index_executor` (`executor`) USING BTREE COMMENT '执行人索引'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='任务提醒表';

-- ----------------------------
-- Table structure for task_t
-- ----------------------------
DROP TABLE IF EXISTS `task_t`;
CREATE TABLE `task_t` (
  `code` varchar(36) NOT NULL COMMENT '任务编码',
  `tenant_code` varchar(36) DEFAULT NULL COMMENT '租户编码',
  `template_code` varchar(36) DEFAULT NULL COMMENT '任务模板编码',
  `area_code` varchar(100) DEFAULT NULL COMMENT '区域编码',
  `title` varchar(50) NOT NULL COMMENT '标题',
  `content` mediumtext NOT NULL COMMENT '内容',
  `start_time` datetime NOT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `mode` int(11) NOT NULL COMMENT '派发方式: 1直接派发, 2批量派发',
  `is_approval` int(11) NOT NULL COMMENT '是否需要审批: 1需要, 0不需要',
  `attachments` json DEFAULT NULL COMMENT '附件列表: files文件, images图片',
  `form_id` bigint(11) DEFAULT NULL COMMENT '反馈表单编码',
  `status` int(11) NOT NULL COMMENT '状态: 10草稿, 20进行中, 30已完成, 31已终止',
  `create_user` varchar(36) NOT NULL COMMENT '创建人',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `update_user` varchar(36) DEFAULT NULL COMMENT '最后修改人',
  `update_time` datetime DEFAULT NULL COMMENT '最后修改时间',
  PRIMARY KEY (`code`) USING BTREE,
  KEY `index_create_user` (`create_user`) USING BTREE,
  KEY `index_end_time` (`end_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='任务表';
