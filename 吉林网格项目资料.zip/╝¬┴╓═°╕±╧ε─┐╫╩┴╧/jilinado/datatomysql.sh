#!/bin/bash
HOSTNAME="10.186.249.187"
PORT="3306"
USERNAME="root"
PASSWORD="Huawei@123"
DBNAME=$1
TABLENAME="t_test_temp"
#
#create_tb_sql
tableName=$2
drop_tb_sql="drop table if exists ${tableName}" 
#delete_sql="delete from ${TABLENAME}"
mysql -h${HOSTNAME}  -P${PORT}  -u${USERNAME} -p${PASSWORD} ${DBNAME} -e "${drop_tb_sql}"
