/*
Navicat MySQL Data Transfer

Source Server         : ai4a_10.161.124.31_22021_dcp_admin
Source Server Version : 50723
Source Host           : 10.161.124.31:22021
Source Database       : xindex_management_e264fd96-3578-4400-97d5-fb5a39e232c3

Target Server Type    : MYSQL
Target Server Version : 50723
File Encoding         : 65001

Date: 2020-04-21 15:38:57
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for gbase_t_temp_dim_grid_index_def
-- ----------------------------
DROP TABLE IF EXISTS `gbase_t_temp_dim_grid_index_def`;
CREATE TABLE `gbase_t_temp_dim_grid_index_def` (
  `index_code` varchar(128) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '指标编码',
  `index_name` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指标名称',
  `city` varchar(32) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '分类：ent:集团;wire:家庭;acct:收入;user:用户发展;terminal 终端',
  `index_unit` varchar(32) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指标单位',
  `TARGET_TABLE` varchar(1024) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指标值来源表',
  `APPTYPE` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '应用分类',
  `index_cycle` varchar(10) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指标周期',
  `city_id` bigint(21) DEFAULT NULL COMMENT '城市id',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- ----------------------------
-- Table structure for tci_addition_area
-- ----------------------------
DROP TABLE IF EXISTS `tci_addition_area`;
CREATE TABLE `tci_addition_area` (
  `addition_code` varchar(64) NOT NULL COMMENT '联合主键  pk_addition_area 指标id',
  `area_code` varchar(64) NOT NULL COMMENT '联合主键 pk_addition_area 地域编码',
  `area_name` varchar(64) NOT NULL COMMENT '地域名称',
  `area_level` int(2) NOT NULL COMMENT '地域等级 1 省 2 地区市 3 县级市 4 网格 5 责任田',
  `area_path` varchar(256) NOT NULL COMMENT '地域路径path',
  PRIMARY KEY (`addition_code`,`area_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_addition_info
-- ----------------------------
DROP TABLE IF EXISTS `tci_addition_info`;
CREATE TABLE `tci_addition_info` (
  `addition_code` varchar(64) NOT NULL COMMENT '主键 附加项id',
  `addition_name_en` varchar(128) DEFAULT NULL COMMENT '附加项英文名称',
  `addition_name_cn` varchar(128) NOT NULL COMMENT '附加项中文名称',
  `type_id` int(11) NOT NULL COMMENT '附加项分类id',
  `addition_version` varchar(32) NOT NULL COMMENT ' 附加项版本号',
  `addition_cycle` varchar(64) DEFAULT NULL,
  `interface_person` varchar(64) DEFAULT NULL COMMENT '接口人名称',
  `business_caliber` varchar(1024) DEFAULT NULL COMMENT '业务口径',
  `remarks` varchar(1024) DEFAULT NULL COMMENT '备注 ',
  `addition_status` int(2) NOT NULL COMMENT '附加项状态  0 失效  1 生效',
  `addition_type` int(2) NOT NULL COMMENT '附加项类别 加分项和扣分项',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '创建者用户名',
  `create_opername` varchar(64) DEFAULT NULL COMMENT '创建者别名',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '更新者用户名',
  `update_opername` varchar(64) DEFAULT NULL COMMENT '更新者别名',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '预留字段1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '预留字段2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '预留字段3',
  `interface_tel` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`addition_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_addition_info_his
-- ----------------------------
DROP TABLE IF EXISTS `tci_addition_info_his`;
CREATE TABLE `tci_addition_info_his` (
  `addition_code` varchar(64) NOT NULL COMMENT '主键 附加项id',
  `addition_name_en` varchar(128) DEFAULT NULL COMMENT '附加项英文名称',
  `addition_name_cn` varchar(128) NOT NULL COMMENT '附加项中文名称',
  `type_id` int(11) NOT NULL COMMENT '附加项分类id',
  `addition_version` varchar(32) NOT NULL COMMENT ' 附加项版本号',
  `addition_cycle` varchar(64) DEFAULT NULL,
  `interface_person` varchar(64) DEFAULT NULL COMMENT '接口人名称',
  `business_caliber` varchar(1024) DEFAULT NULL COMMENT '业务口径',
  `remarks` varchar(1024) DEFAULT NULL COMMENT '备注 ',
  `addition_status` int(2) NOT NULL COMMENT '附加项状态  0 失效  1 生效',
  `addition_type` int(2) NOT NULL COMMENT '附加项类别 加分项和扣分项',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '创建者用户名',
  `create_opername` varchar(64) DEFAULT NULL COMMENT '创建者别名',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '更新者用户名',
  `update_opername` varchar(64) DEFAULT NULL COMMENT '更新者别名',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '预留字段1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '预留字段2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '预留字段3',
  `interface_tel` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`addition_code`,`addition_version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_addition_type
-- ----------------------------
DROP TABLE IF EXISTS `tci_addition_type`;
CREATE TABLE `tci_addition_type` (
  `type_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键   自增长附加项类型id',
  `type_name` varchar(64) NOT NULL COMMENT '附加项类型名称',
  `type_catalog` int(3) NOT NULL COMMENT '附加项类型分类  1 省统附加项 2 自定义附加项',
  `type_path` varchar(64) DEFAULT NULL COMMENT '类型路径',
  `parent_id` int(11) NOT NULL COMMENT '父类型id  -1代表根节点',
  `type_level` int(3) NOT NULL COMMENT '附加项类型层级',
  `order_no` int(3) DEFAULT '1' COMMENT '类型在当前层级下顺序',
  `create_areacode` varchar(64) NOT NULL COMMENT '创建者当前地域编码',
  `create_areaname` varchar(64) NOT NULL COMMENT '创建者当前地域名称',
  `create_areapath` varchar(64) NOT NULL COMMENT '创建者当前地域层级',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '创建者用户名',
  `create_opername` varchar(64) DEFAULT NULL COMMENT '创建者别名',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '更新者用户名',
  `update_opername` varchar(64) DEFAULT NULL COMMENT '更新者别名',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '预留字段1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '预留字段2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '预留字段3',
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1852 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_check_apply
-- ----------------------------
DROP TABLE IF EXISTS `tci_check_apply`;
CREATE TABLE `tci_check_apply` (
  `operate_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '操作批次ID',
  `apply_type` int(2) NOT NULL COMMENT '审批类型 1:新增指标目标,2:发布考核任务',
  `task_id` varchar(32) NOT NULL COMMENT '当前任务ID',
  `task_name` varchar(200) NOT NULL DEFAULT '' COMMENT '任务名称',
  `task_type` int(2) NOT NULL DEFAULT '0' COMMENT '任务类型',
  `apply_status` int(2) NOT NULL COMMENT '0:待审批,1:已审批,-1:已驳回,-2:已撤销',
  `apply_desc` varchar(2000) DEFAULT NULL COMMENT '审批意见',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '创建人ID',
  `create_opername` varchar(200) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `audit_operid` varchar(32) DEFAULT NULL COMMENT '审批人ID',
  `audit_opername` varchar(200) DEFAULT NULL COMMENT '审批人',
  `audit_time` datetime DEFAULT NULL COMMENT '审批时间',
  `reserve1` varchar(200) DEFAULT NULL COMMENT '预留字段1',
  `reserve2` varchar(200) DEFAULT NULL COMMENT '预留字段2',
  `reserve3` varchar(200) DEFAULT NULL COMMENT '预留字段3',
  PRIMARY KEY (`operate_id`),
  KEY `taskId_applyType_applyStatus_index` (`task_id`,`apply_type`,`apply_status`) USING BTREE,
  KEY `applyStatus_index` (`apply_status`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_check_auditinfo_his
-- ----------------------------
DROP TABLE IF EXISTS `tci_check_auditinfo_his`;
CREATE TABLE `tci_check_auditinfo_his` (
  `check_id` varchar(64) NOT NULL COMMENT '考核项id',
  `operate_id` int(11) DEFAULT NULL COMMENT '操作批次ID',
  `check_name` varchar(64) NOT NULL COMMENT '考核项目名称 ',
  `index_code` varchar(64) DEFAULT NULL,
  `index_name` varchar(256) NOT NULL COMMENT '指标名称',
  `index_cycle` int(2) NOT NULL COMMENT '1 年 2 季 3 月',
  `check_time` varchar(32) NOT NULL COMMENT '考核时间 年份/季度/月份',
  `obj_type` int(2) NOT NULL COMMENT '对象类型 2 市 3 县 4 网格 5 责任田 6 销售经理 7 最小单元',
  `unit_type` int(2) DEFAULT NULL COMMENT 'obj_type=7时存在，单元类型 1 渠道 2 社区 3 中小微企业',
  `obj_id` varchar(64) NOT NULL COMMENT '考核对象id',
  `obj_name` varchar(256) NOT NULL COMMENT '考核对象名称',
  `obj_path` varchar(64) NOT NULL COMMENT '对象路径',
  `role_id` varchar(64) DEFAULT NULL COMMENT '角色id',
  `role_name` varchar(64) DEFAULT NULL COMMENT '角色name',
  `obj_target_value` decimal(16,4) NOT NULL COMMENT '考核对象拟定目标值',
  `obj_challenge_value` decimal(16,4) DEFAULT NULL COMMENT '考核对象拟定挑战值',
  `base_value` decimal(16,4) DEFAULT NULL COMMENT '考核对象保底值',
  `audit_operid` varchar(32) NOT NULL COMMENT '审批人工号',
  `audit_opername` varchar(64) NOT NULL COMMENT '审批人姓名',
  `audit_status` int(2) NOT NULL COMMENT '审批状态码 1 通过 -1 驳回',
  `audit_type` int(2) NOT NULL COMMENT '审核类型 1 新增考核项 2 删除考核项',
  `audit_content` varchar(256) NOT NULL COMMENT '审批意见',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '创建人id',
  `create_opername` varchar(64) DEFAULT NULL COMMENT '创建者姓名',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '更新者id',
  `update_opername` varchar(64) DEFAULT NULL COMMENT '更新者姓名',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '预留字段1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '预留字段2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '预留字段3',
  `task_id` varchar(64) DEFAULT NULL COMMENT '任务ID',
  `child_taskid` varchar(64) DEFAULT NULL COMMENT '子任务ID',
  `weight` decimal(12,2) DEFAULT NULL COMMENT '权重',
  PRIMARY KEY (`check_id`),
  KEY `idx_check_auditinfo_his_indexcode` (`index_code`) USING BTREE,
  KEY `idx_check_auditinfo_his_indexcycle` (`index_cycle`) USING BTREE,
  KEY `idx_check_auditinfo_his_checktime` (`check_time`) USING BTREE,
  KEY `idx_check_auditinfo_his_auditstatus` (`audit_status`) USING BTREE,
  KEY `idx_check_auditinfo_his_objtype` (`obj_type`) USING BTREE,
  KEY `idx_check_auditinfo_his_obj_id` (`obj_id`) USING BTREE,
  KEY `idx_check_auditinfo_his_audit_operid` (`audit_operid`) USING BTREE,
  KEY `index_operate_id` (`operate_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_check_content
-- ----------------------------
DROP TABLE IF EXISTS `tci_check_content`;
CREATE TABLE `tci_check_content` (
  `check_id` varchar(64) NOT NULL COMMENT '考核ID',
  `operate_id` int(11) DEFAULT NULL COMMENT '操作批次ID',
  `task_id` varchar(64) NOT NULL COMMENT '主任务ID',
  `child_taskid` varchar(64) DEFAULT NULL COMMENT '子任务ID  存在子任务时存在',
  `check_name` varchar(64) NOT NULL COMMENT '考核项目名称 ',
  `index_code` varchar(64) NOT NULL,
  `index_name` varchar(256) NOT NULL COMMENT '指标名称',
  `index_cycle` int(2) NOT NULL COMMENT '1 年 2 季 3 月',
  `check_time` varchar(32) NOT NULL COMMENT '考核时间 年份/季度/月份',
  `obj_path` varchar(256) NOT NULL COMMENT '考核对象路径',
  `role_id` varchar(64) DEFAULT NULL COMMENT '角色id',
  `role_name` varchar(64) DEFAULT NULL COMMENT '角色name',
  `obj_type` int(2) NOT NULL COMMENT '对象类型 2 市 3 县 4 网格 5 责任田 6 销售经理 7 最小单元',
  `unit_type` int(2) DEFAULT NULL COMMENT 'obj_type=7时存在，单元类型 1 渠道 2 社区 3 中小微企业',
  `obj_id` varchar(64) NOT NULL COMMENT '考核对象id',
  `obj_name` varchar(64) NOT NULL COMMENT '考核对象名称',
  `obj_target_value` decimal(16,4) NOT NULL COMMENT '考核对象拟定目标值',
  `obj_challenge_value` decimal(16,4) DEFAULT NULL COMMENT '考核对象拟定挑战值',
  `base_value` decimal(16,4) DEFAULT NULL COMMENT '考核对象保底值',
  `audit_operid` varchar(32) NOT NULL COMMENT '审批人用户名',
  `audit_opername` varchar(64) NOT NULL COMMENT '审批人别名',
  `audit_status` int(2) NOT NULL COMMENT '审批最新状态 1 已审核 0 待审批 -1 被驳回',
  `audit_type` int(2) NOT NULL COMMENT '审核类型 1 新增考核项 2 删除考核项',
  `audit_content` varchar(256) DEFAULT NULL COMMENT '审批意见 待审批 为空',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '创建人id',
  `create_opername` varchar(64) DEFAULT NULL COMMENT '创建者姓名',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '更新者id',
  `update_opername` varchar(64) DEFAULT NULL COMMENT '更新者姓名',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '预留字段1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '预留字段2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '预留字段3',
  `weight` decimal(12,2) DEFAULT NULL,
  PRIMARY KEY (`check_id`),
  UNIQUE KEY `uk_check_content` (`index_code`,`index_cycle`,`check_time`,`obj_id`,`obj_type`,`unit_type`,`task_id`) USING BTREE,
  KEY `idx_check_content_task_id` (`task_id`) USING BTREE,
  KEY `idx_check_content_indexcode` (`index_code`),
  KEY `idx_check_content_indexcycle` (`index_cycle`) USING BTREE,
  KEY `idx_check_content_checktime` (`check_time`) USING BTREE,
  KEY `idx_check_content_createoperid` (`create_operid`) USING BTREE,
  KEY `idx_check_content_auditstatus` (`audit_status`) USING BTREE,
  KEY `idx_check_content_objtype` (`obj_type`,`unit_type`) USING BTREE,
  KEY `idx_check_content_objid` (`obj_id`) USING BTREE,
  KEY `idx_check_content_auditoperid` (`audit_operid`) USING BTREE,
  KEY `index_operate_id` (`operate_id`) USING BTREE,
  KEY `idx_updatetime` (`update_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_check_content_preview
-- ----------------------------
DROP TABLE IF EXISTS `tci_check_content_preview`;
CREATE TABLE `tci_check_content_preview` (
  `preview_id` varchar(64) NOT NULL COMMENT '预览id',
  `task_id` varchar(64) NOT NULL COMMENT '当前下发任务ID',
  `obj_id` varchar(128) DEFAULT NULL,
  `index_code` varchar(64) DEFAULT NULL,
  `index_name` varchar(128) DEFAULT NULL,
  `statistics_type` varchar(128) DEFAULT NULL,
  `target_value` varchar(1000) DEFAULT NULL,
  `weight` varchar(16) DEFAULT NULL,
  `preview_type` int(2) DEFAULT NULL COMMENT '1:指标，2:附加项',
  `index_level` varchar(2) DEFAULT NULL,
  `base_parent_id` varchar(64) NOT NULL,
  PRIMARY KEY (`preview_id`),
  UNIQUE KEY `unique` (`obj_id`,`index_code`,`index_name`,`base_parent_id`),
  KEY `index_taskid` (`task_id`),
  KEY `index_basetaskid` (`base_parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_check_manager
-- ----------------------------
DROP TABLE IF EXISTS `tci_check_manager`;
CREATE TABLE `tci_check_manager` (
  `rel_id` varchar(64) NOT NULL COMMENT '关联ID  考核ID',
  `mgr_operid` varchar(32) NOT NULL COMMENT '责任人用户名',
  `mgr_name` varchar(64) NOT NULL COMMENT '责任人别名',
  `order_no` int(3) DEFAULT '1' COMMENT '责任人顺序',
  `operate_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`rel_id`,`mgr_operid`),
  KEY `index_operate_id` (`operate_id`) USING BTREE,
  KEY `index_mgr_operid` (`mgr_operid`) USING BTREE,
  KEY `rel_id_index` (`rel_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_check_manager_his
-- ----------------------------
DROP TABLE IF EXISTS `tci_check_manager_his`;
CREATE TABLE `tci_check_manager_his` (
  `rel_id` varchar(64) NOT NULL COMMENT '关联ID  历史考核ID',
  `mgr_operid` varchar(32) NOT NULL COMMENT '责任人用户名',
  `mgr_name` varchar(64) NOT NULL COMMENT '责任人别名',
  `order_no` int(3) DEFAULT '1' COMMENT '责任人顺序',
  `operate_id` int(11) NOT NULL COMMENT '操作ID',
  PRIMARY KEY (`rel_id`,`mgr_operid`,`operate_id`),
  KEY `index_operate_id` (`operate_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_check_task
-- ----------------------------
DROP TABLE IF EXISTS `tci_check_task`;
CREATE TABLE `tci_check_task` (
  `task_id` varchar(64) NOT NULL COMMENT '任务ID',
  `task_name` varchar(64) NOT NULL COMMENT '任务名称',
  `frame_type` int(2) DEFAULT NULL COMMENT '框架类型',
  `begin_month` varchar(6) NOT NULL COMMENT '开始月份',
  `end_month` varchar(6) NOT NULL COMMENT '结束月份',
  `task_describe` varchar(1024) DEFAULT NULL COMMENT '任务描述',
  `task_type` int(2) NOT NULL COMMENT '任务类型',
  `parent_id` varchar(64) DEFAULT NULL COMMENT '父任务ID',
  `task_status` int(2) NOT NULL COMMENT '任务状态',
  `task_scope_type` int(2) DEFAULT '1' COMMENT '考核任务范围类型 1:区域 2:角色 3:区域和角色',
  `create_org_code` varchar(64) DEFAULT NULL COMMENT '创建区域',
  `create_org_name` varchar(64) DEFAULT NULL COMMENT '创建名称',
  `create_org_level` int(2) DEFAULT NULL COMMENT '创建级别',
  `create_org_path` varchar(256) DEFAULT NULL COMMENT '创建路径',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '创建人',
  `create_opername` varchar(64) DEFAULT NULL COMMENT '创建人别名',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '更新人',
  `update_opername` varchar(64) DEFAULT NULL COMMENT '更新人别名',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `AUDIT_TIME` varchar(32) DEFAULT NULL,
  `base_parent_id` varchar(64) DEFAULT NULL COMMENT '根任务ID',
  `latest_time` varchar(20) DEFAULT NULL COMMENT '考核报表最新时间',
  PRIMARY KEY (`task_id`),
  KEY `idx_check_task_parentid` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_check_task_addition
-- ----------------------------
DROP TABLE IF EXISTS `tci_check_task_addition`;
CREATE TABLE `tci_check_task_addition` (
  `task_id` varchar(64) NOT NULL COMMENT '任务id',
  `addition_code` varchar(64) NOT NULL COMMENT '附加项编码',
  `addition_name` varchar(64) NOT NULL COMMENT '附加项名称',
  `type_path` varchar(200) DEFAULT NULL COMMENT '类型路径',
  `addition_type` varchar(200) DEFAULT NULL COMMENT '附加项类别',
  `addition_weight` decimal(12,2) DEFAULT NULL COMMENT '附加项权重',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '创建者用户名',
  `create_opername` varchar(64) DEFAULT NULL COMMENT '创建者别名',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '更新者用户名',
  `update_opername` varchar(64) DEFAULT NULL COMMENT '更新者别名',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `order_no` int(11) DEFAULT NULL COMMENT '排序 对外接口使用',
  `first_level_type` varchar(32) DEFAULT NULL,
  `second_level_type` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`task_id`,`addition_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_check_task_addition_his
-- ----------------------------
DROP TABLE IF EXISTS `tci_check_task_addition_his`;
CREATE TABLE `tci_check_task_addition_his` (
  `operate_id` int(11) NOT NULL COMMENT '操作ID',
  `task_id` varchar(64) NOT NULL COMMENT '任务id',
  `task_type` int(2) NOT NULL DEFAULT '0' COMMENT '任务类型:1 主任务;2 子任务',
  `addition_code` varchar(64) NOT NULL COMMENT '附加项编码',
  `addition_name` varchar(64) NOT NULL COMMENT '附加项名称',
  `type_path` varchar(200) DEFAULT NULL COMMENT '附加项类型路径',
  `addition_type` varchar(64) DEFAULT NULL COMMENT '附加项类类别',
  `addition_weight` decimal(12,2) DEFAULT NULL COMMENT '附加项权重',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '创建者用户名',
  `create_opername` varchar(64) DEFAULT NULL COMMENT '创建者别名',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '更新者用户名',
  `update_opername` varchar(64) DEFAULT NULL COMMENT '更新者别名',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `order_no` int(11) DEFAULT NULL COMMENT '排序 对外接口使用',
  `first_level_type` varchar(32) DEFAULT NULL,
  `second_level_type` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`operate_id`,`task_id`,`addition_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_check_task_area
-- ----------------------------
DROP TABLE IF EXISTS `tci_check_task_area`;
CREATE TABLE `tci_check_task_area` (
  `task_id` varchar(64) NOT NULL COMMENT '任务ID',
  `area_code` varchar(64) NOT NULL COMMENT '区域编码',
  `area_name` varchar(64) NOT NULL COMMENT '区域名称',
  `area_level` int(2) NOT NULL COMMENT '区域级别',
  `area_path` varchar(256) NOT NULL COMMENT '区域路径',
  PRIMARY KEY (`task_id`,`area_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_check_task_cfg
-- ----------------------------
DROP TABLE IF EXISTS `tci_check_task_cfg`;
CREATE TABLE `tci_check_task_cfg` (
  `task_cfg_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '任务配置ID',
  `month` int(2) NOT NULL DEFAULT '0' COMMENT '月份',
  `task_begin_time` varchar(32) NOT NULL COMMENT '任务开始时间',
  `task_end_time` varchar(32) NOT NULL COMMENT '任务结束时间',
  `target_value_begin_time` varchar(32) NOT NULL COMMENT '目标值开始时间',
  `target_value_end_time` varchar(32) NOT NULL COMMENT '目标值结束时间',
  PRIMARY KEY (`task_cfg_id`)
) ENGINE=InnoDB AUTO_INCREMENT=273 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_check_task_cfg_info
-- ----------------------------
DROP TABLE IF EXISTS `tci_check_task_cfg_info`;
CREATE TABLE `tci_check_task_cfg_info` (
  `task_begin_time` int(2) NOT NULL COMMENT '任务开始时间',
  `task_end_time` int(2) NOT NULL COMMENT '任务结束时间',
  `target_value_begin_time` int(2) NOT NULL COMMENT '目标值开始时间',
  `target_value_end_time` int(2) NOT NULL COMMENT '目标值结束时间',
  `task_begin_time_index` int(1) NOT NULL COMMENT '任务开始月份 1:上月;2:本月',
  `task_end_time_index` int(1) NOT NULL COMMENT '任务结束月份 1:上月;2:本月',
  `target_value_begin_time_index` int(1) NOT NULL COMMENT '目标值开始月份 1:上月;2:本月',
  `target_value_end_time_index` int(1) NOT NULL COMMENT '目标值结束月份 1:上月;2:本月',
  `months` varchar(64) NOT NULL COMMENT '月份',
  `order_no` int(8) NOT NULL COMMENT '排序'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_check_task_his
-- ----------------------------
DROP TABLE IF EXISTS `tci_check_task_his`;
CREATE TABLE `tci_check_task_his` (
  `operate_id` int(11) NOT NULL COMMENT '操作ID',
  `task_id` varchar(64) NOT NULL COMMENT '任务ID',
  `task_name` varchar(64) NOT NULL COMMENT '任务名称',
  `frame_type` int(2) DEFAULT NULL COMMENT '框架类型',
  `begin_month` varchar(6) NOT NULL COMMENT '开始月份',
  `end_month` varchar(6) NOT NULL COMMENT '结束月份',
  `task_describe` varchar(1024) DEFAULT NULL COMMENT '任务描述',
  `task_type` int(2) NOT NULL COMMENT '任务类型',
  `parent_id` varchar(64) DEFAULT NULL COMMENT '父任务ID',
  `parent_task_name` varchar(64) DEFAULT NULL COMMENT '父任务名称',
  `area_name` varchar(2000) DEFAULT NULL COMMENT '区域路径',
  `task_status` int(2) NOT NULL COMMENT '任务状态',
  `task_scope_type` int(2) DEFAULT '1' COMMENT '考核任务范围类型 1:区域 2:角色 3:区域和角色',
  `create_org_code` varchar(64) DEFAULT NULL COMMENT '创建区域编码',
  `create_org_name` varchar(64) DEFAULT NULL COMMENT '创建区域名称',
  `create_org_level` int(2) DEFAULT NULL COMMENT '创建区域级别',
  `create_org_path` varchar(256) DEFAULT NULL COMMENT '创建区域路径',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '创建人',
  `create_opername` varchar(64) DEFAULT NULL COMMENT '创建人别名',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '更新人',
  `update_opername` varchar(64) DEFAULT NULL COMMENT '更新别名',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`operate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_check_task_index
-- ----------------------------
DROP TABLE IF EXISTS `tci_check_task_index`;
CREATE TABLE `tci_check_task_index` (
  `index_id` int(11) NOT NULL AUTO_INCREMENT COMMENT ' 主键  pk_check_task_index指标id',
  `task_id` varchar(64) NOT NULL COMMENT ' 唯一联合索引  idx_u_check_task_index任务id',
  `index_code` varchar(64) NOT NULL COMMENT ' 唯一联合索引  idx_u_check_task_index指标编码',
  `index_name` varchar(128) NOT NULL COMMENT ' 指标名称',
  `index_feature` int(2) NOT NULL DEFAULT '0',
  `first_level_type` varchar(64) DEFAULT NULL COMMENT '一级类型名称',
  `second_level_type` varchar(64) DEFAULT NULL COMMENT '二级类型名称',
  `index_weight` decimal(12,2) DEFAULT NULL COMMENT '指标权重',
  `default_dimension` int(2) DEFAULT NULL COMMENT '默认维度 4 日  5 月累计',
  `create_operid` varchar(32) DEFAULT NULL COMMENT ' 创建者用户名',
  `create_opername` varchar(64) DEFAULT NULL COMMENT ' 创建者别名',
  `create_time` datetime DEFAULT NULL COMMENT ' 创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT ' 更新者用户名',
  `update_opername` varchar(64) DEFAULT NULL COMMENT ' 更新者别名',
  `update_time` datetime DEFAULT NULL COMMENT ' 更新时间',
  `order_no` int(11) DEFAULT NULL COMMENT '排序 对外接口使用',
  `WARN_COLOR` varchar(2000) DEFAULT NULL,
  `weight_type` int(2) DEFAULT NULL COMMENT '指标权重类型',
  `calc_type` int(2) DEFAULT NULL COMMENT '指标计算类型',
  PRIMARY KEY (`index_id`),
  UNIQUE KEY `idx_u_check_task_index` (`task_id`,`index_code`)
) ENGINE=InnoDB AUTO_INCREMENT=225856 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_check_task_index_his
-- ----------------------------
DROP TABLE IF EXISTS `tci_check_task_index_his`;
CREATE TABLE `tci_check_task_index_his` (
  `operate_id` int(11) NOT NULL COMMENT '操作ID',
  `index_id` int(11) NOT NULL COMMENT '主键  pk_check_task_index 指标id',
  `task_id` varchar(64) NOT NULL COMMENT '任务id',
  `index_code` varchar(64) NOT NULL COMMENT '指标编码',
  `task_type` int(2) NOT NULL DEFAULT '0' COMMENT '任务类型: 1 主任务;2 子任务',
  `index_name` varchar(128) NOT NULL COMMENT '指标名称',
  `first_level_type` varchar(64) DEFAULT NULL COMMENT '一级类型名称',
  `second_level_type` varchar(64) DEFAULT NULL COMMENT '二级类型名称',
  `index_weight` decimal(12,2) DEFAULT NULL COMMENT '指标权重',
  `default_dimension` int(2) DEFAULT NULL COMMENT '默认维度 4 日  5 月累计',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '创建者用户名',
  `create_opername` varchar(64) DEFAULT NULL COMMENT '创建者别名',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '更新者用户名',
  `update_opername` varchar(64) DEFAULT NULL COMMENT '更新者别名',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `order_no` int(11) DEFAULT NULL COMMENT '排序 对外接口使用',
  `weight_type` int(2) DEFAULT NULL COMMENT '指标权重类型',
  `calc_type` int(2) DEFAULT NULL COMMENT '指标计算类型',
  PRIMARY KEY (`operate_id`,`index_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_check_task_operate
-- ----------------------------
DROP TABLE IF EXISTS `tci_check_task_operate`;
CREATE TABLE `tci_check_task_operate` (
  `operate_id` varchar(64) DEFAULT NULL COMMENT '操作批次ID',
  `task_id` varchar(64) DEFAULT NULL COMMENT '任务ID',
  `obj_id` varchar(64) DEFAULT NULL COMMENT '地域ID',
  `obj_name` varchar(128) DEFAULT NULL,
  `obj_type` int(2) DEFAULT NULL,
  `obj_path` varchar(256) DEFAULT NULL,
  `base_parent_id` varchar(64) DEFAULT NULL COMMENT '根任务ID',
  `operate_type` varchar(16) DEFAULT NULL COMMENT '操作类型',
  KEY `index_operate_id` (`operate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_check_task_role
-- ----------------------------
DROP TABLE IF EXISTS `tci_check_task_role`;
CREATE TABLE `tci_check_task_role` (
  `task_id` varchar(64) NOT NULL COMMENT '考核任务id',
  `role_id` varchar(64) NOT NULL COMMENT '角色id',
  `role_name` varchar(64) NOT NULL COMMENT '角色名称',
  PRIMARY KEY (`task_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_check_task_role_area
-- ----------------------------
DROP TABLE IF EXISTS `tci_check_task_role_area`;
CREATE TABLE `tci_check_task_role_area` (
  `task_id` varchar(64) NOT NULL COMMENT '任务ID',
  `area_code` varchar(64) NOT NULL COMMENT '区域编码',
  `area_name` varchar(64) NOT NULL COMMENT '区域名称',
  `area_level` int(2) NOT NULL COMMENT '区域级别',
  `area_path` varchar(256) NOT NULL COMMENT '区域路径',
  PRIMARY KEY (`task_id`,`area_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_data_plan_fee
-- ----------------------------
DROP TABLE IF EXISTS `tci_data_plan_fee`;
CREATE TABLE `tci_data_plan_fee` (
  `index_code` varchar(64) NOT NULL COMMENT '套餐费用编码  唯一关联索引',
  `index_name` varchar(64) NOT NULL COMMENT '套餐费用名称  唯一关联索引',
  `month` varchar(64) NOT NULL COMMENT '套餐费用时间 唯一关联索引',
  `data_plan_value` decimal(12,2) NOT NULL COMMENT '套餐费用',
  `area_code` varchar(64) NOT NULL COMMENT '地域编码 唯一关联索引',
  `area_name` varchar(64) NOT NULL COMMENT '地域名称',
  `parent_code` varchar(32) DEFAULT NULL COMMENT '父编码',
  `task_id` varchar(64) NOT NULL COMMENT '任务ID',
  `area_level` varchar(64) NOT NULL COMMENT '地域等级 唯一关联索引',
  `area_path` varchar(64) NOT NULL COMMENT '地域路径path',
  `reserver1` varchar(64) DEFAULT NULL COMMENT 'reserver1',
  `reserver2` varchar(64) DEFAULT NULL COMMENT 'reserver2',
  `reserver3` varchar(64) DEFAULT NULL COMMENT 'reserver3',
  UNIQUE KEY `idx_plan_unique` (`task_id`,`index_code`,`month`,`area_code`,`area_level`) USING BTREE,
  KEY `idx_plan_month` (`month`) USING BTREE,
  KEY `tci_data_plan_fee_area_code` (`area_code`),
  KEY `tci_data_plan_fee_index_code` (`index_code`),
  KEY `tci_data_plan_fee_month` (`month`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_free_audit_info
-- ----------------------------
DROP TABLE IF EXISTS `tci_free_audit_info`;
CREATE TABLE `tci_free_audit_info` (
  `is_task_audit` int(2) NOT NULL DEFAULT '0' COMMENT '考核任务免审批状态',
  `is_target_audit` int(2) NOT NULL DEFAULT '0' COMMENT '目标值免审批状态'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_index_area
-- ----------------------------
DROP TABLE IF EXISTS `tci_index_area`;
CREATE TABLE `tci_index_area` (
  `index_code` varchar(64) NOT NULL COMMENT ' 联合主键  pk_index_area指标id',
  `area_code` varchar(64) NOT NULL COMMENT '联合主键 pk_index_area 地域编码',
  `area_name` varchar(64) NOT NULL COMMENT ' 地域名称',
  `area_level` int(2) NOT NULL COMMENT ' 地域等级 1 省 2 地区市 3 县级市 4 网格 5 责任田',
  `area_path` varchar(256) NOT NULL COMMENT ' 地域路径path',
  PRIMARY KEY (`index_code`,`area_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_index_area_bak
-- ----------------------------
DROP TABLE IF EXISTS `tci_index_area_bak`;
CREATE TABLE `tci_index_area_bak` (
  `index_code` varchar(64) NOT NULL COMMENT ' 联合主键  pk_index_area指标id',
  `area_code` varchar(64) NOT NULL COMMENT '联合主键 pk_index_area 地域编码',
  `area_name` varchar(64) NOT NULL COMMENT ' 地域名称',
  `area_level` int(2) NOT NULL COMMENT ' 地域等级 1 省 2 地区市 3 县级市 4 网格 5 责任田',
  `area_path` varchar(256) NOT NULL COMMENT ' 地域路径path',
  PRIMARY KEY (`index_code`,`area_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_index_building_value
-- ----------------------------
DROP TABLE IF EXISTS `tci_index_building_value`;
CREATE TABLE `tci_index_building_value` (
  `data_id` varchar(64) NOT NULL COMMENT '主键  pk_index_building_value 自增长        数据id',
  `index_code` varchar(64) NOT NULL COMMENT '唯一联合索引  u_index_building_value_value        指标编码',
  `index_name` varchar(64) NOT NULL COMMENT '指标中文名称',
  `index_cycle` int(2) NOT NULL COMMENT '唯一联合索引  u_index_building_value_value        指标周期 数据字典',
  `index_time` varchar(32) NOT NULL COMMENT '唯一联合索引  u_index_building_value_value        指标时间',
  `obj_id` varchar(64) NOT NULL COMMENT '唯一联合索引  u_idx_index_building_value        对象编码',
  `obj_type` int(2) DEFAULT NULL,
  `obj_name` varchar(64) NOT NULL COMMENT '对象名称',
  `obj_path` varchar(128) DEFAULT NULL,
  `parent_id` varchar(64) NOT NULL COMMENT '渠道父对象编码 责任田',
  `index_value` decimal(16,4) NOT NULL COMMENT '指标值',
  `create_opername` varchar(64) DEFAULT NULL COMMENT '创建人别名',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '更新者用户名',
  `update_opername` varchar(64) DEFAULT NULL COMMENT '更新者别名',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '预留字段1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '预留字段2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '预留字段3',
  PRIMARY KEY (`data_id`),
  UNIQUE KEY `u_idx_index_building_value` (`index_code`,`index_cycle`,`index_time`,`obj_id`),
  KEY `idx_index_building_value_indexcode` (`index_code`) USING BTREE,
  KEY `idx_index_building_value_indexcycle` (`index_cycle`) USING BTREE,
  KEY `idx_index_building_value_indextime` (`index_time`) USING BTREE,
  KEY `idx_index_building_value_objid` (`obj_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='楼宇指标值表';

-- ----------------------------
-- Table structure for tci_index_channel_value
-- ----------------------------
DROP TABLE IF EXISTS `tci_index_channel_value`;
CREATE TABLE `tci_index_channel_value` (
  `data_id` varchar(64) NOT NULL COMMENT '主键  pk_index_channel_value 自增长数据id',
  `index_code` varchar(64) NOT NULL COMMENT '唯一联合索引  u_index_channel_value_value指标编码',
  `index_name` varchar(64) NOT NULL COMMENT '指标中文名称',
  `index_cycle` int(2) NOT NULL COMMENT '唯一联合索引  u_index_channel_value_value指标周期 数据字典',
  `index_time` varchar(32) NOT NULL COMMENT '唯一联合索引  u_index_channel_value_value指标时间',
  `obj_id` varchar(64) NOT NULL COMMENT '唯一联合索引  u_idx_index_value对象编码',
  `obj_type` varchar(128) DEFAULT NULL,
  `obj_name` varchar(64) NOT NULL COMMENT '对象名称',
  `obj_path` varchar(128) DEFAULT NULL,
  `parent_id` varchar(64) NOT NULL COMMENT '渠道父对象编码 责任田',
  `index_value` decimal(16,4) NOT NULL COMMENT '指标值',
  `create_opername` varchar(64) DEFAULT NULL COMMENT '创建人别名',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '更新者用户名',
  `update_opername` varchar(64) DEFAULT NULL COMMENT '更新者别名',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '预留字段1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '预留字段2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '预留字段3',
  PRIMARY KEY (`data_id`),
  UNIQUE KEY `u_idx_index_channel_value` (`index_code`,`index_cycle`,`index_time`,`obj_id`),
  KEY `idx_index_channel_value_indexcode` (`index_code`) USING BTREE,
  KEY `idx_index_channel_value_indexcycle` (`index_cycle`) USING BTREE,
  KEY `idx_index_channel_value_indextime` (`index_time`) USING BTREE,
  KEY `idx_index_channel_value_objid` (`obj_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='渠道指标值表';

-- ----------------------------
-- Table structure for tci_index_cluster_value
-- ----------------------------
DROP TABLE IF EXISTS `tci_index_cluster_value`;
CREATE TABLE `tci_index_cluster_value` (
  `data_id` varchar(64) NOT NULL COMMENT '主键  pk_index_cluster_value 自增长        数据id',
  `index_code` varchar(64) NOT NULL COMMENT '唯一联合索引  u_index_cluster_value_value        指标编码',
  `index_name` varchar(64) NOT NULL COMMENT '指标中文名称',
  `index_cycle` int(2) NOT NULL COMMENT '唯一联合索引  u_index_cluster_value_value        指标周期 数据字典',
  `index_time` varchar(32) NOT NULL COMMENT '唯一联合索引  u_index_cluster_value_value        指标时间',
  `obj_id` varchar(64) NOT NULL COMMENT '唯一联合索引  u_idx_index_cluster_value        对象编码',
  `obj_type` int(2) DEFAULT NULL,
  `obj_name` varchar(64) NOT NULL COMMENT '对象名称',
  `obj_path` varchar(128) DEFAULT NULL,
  `parent_id` varchar(64) NOT NULL COMMENT '渠道父对象编码 责任田',
  `index_value` decimal(16,4) NOT NULL COMMENT '指标值',
  `create_opername` varchar(64) DEFAULT NULL COMMENT '创建人别名',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '更新者用户名',
  `update_opername` varchar(64) DEFAULT NULL COMMENT '更新者别名',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '预留字段1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '预留字段2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '预留字段3',
  PRIMARY KEY (`data_id`),
  UNIQUE KEY `u_idx_index_cluster_value` (`index_code`,`index_cycle`,`index_time`,`obj_id`),
  KEY `idx_index_cluster_value_indexcode` (`index_code`) USING BTREE,
  KEY `idx_index_cluster_value_indexcycle` (`index_cycle`) USING BTREE,
  KEY `idx_index_cluster_value_indextime` (`index_time`) USING BTREE,
  KEY `idx_index_cluster_value_objid` (`obj_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='聚类指标值表';

-- ----------------------------
-- Table structure for tci_index_define
-- ----------------------------
DROP TABLE IF EXISTS `tci_index_define`;
CREATE TABLE `tci_index_define` (
  `index_code` varchar(32) NOT NULL COMMENT '指标编码',
  `index_name` varchar(64) NOT NULL COMMENT '指标名称',
  `index_type` int(2) NOT NULL COMMENT '指标类型 1 比率类  2 销量类',
  `index_unit` varchar(32) DEFAULT NULL COMMENT '指标单位',
  `order_no` int(3) DEFAULT '1' COMMENT '指标顺序',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '预留字段1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '预留字段2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '预留字段3',
  PRIMARY KEY (`index_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_index_enterprise_value
-- ----------------------------
DROP TABLE IF EXISTS `tci_index_enterprise_value`;
CREATE TABLE `tci_index_enterprise_value` (
  `data_id` varchar(64) NOT NULL COMMENT '主键  pk_index_enterprise_value 自增长        数据id',
  `index_code` varchar(64) NOT NULL COMMENT '唯一联合索引  u_index_enterprise_value_value        指标编码',
  `index_name` varchar(64) NOT NULL COMMENT '指标中文名称',
  `index_cycle` int(2) NOT NULL COMMENT '唯一联合索引  u_index_enterprise_value_value        指标周期 数据字典',
  `index_time` varchar(32) NOT NULL COMMENT '唯一联合索引  u_index_enterprise_value_value        指标时间',
  `obj_id` varchar(64) NOT NULL COMMENT '唯一联合索引  u_idx_index_enterprise_value        对象编码',
  `obj_type` int(2) DEFAULT NULL,
  `obj_name` varchar(64) NOT NULL COMMENT '对象名称',
  `obj_path` varchar(128) DEFAULT NULL,
  `parent_id` varchar(64) NOT NULL COMMENT '渠道父对象编码 责任田',
  `index_value` decimal(16,4) NOT NULL COMMENT '指标值',
  `create_opername` varchar(64) DEFAULT NULL COMMENT '创建人别名',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '更新者用户名',
  `update_opername` varchar(64) DEFAULT NULL COMMENT '更新者别名',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '预留字段1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '预留字段2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '预留字段3',
  PRIMARY KEY (`data_id`),
  UNIQUE KEY `u_idx_index_enterprise_value` (`index_code`,`index_cycle`,`index_time`,`obj_id`),
  KEY `idx_index_enterprise_value_indexcode` (`index_code`) USING BTREE,
  KEY `idx_index_enterprise_value_indexcycle` (`index_cycle`) USING BTREE,
  KEY `idx_index_enterprise_value_indextime` (`index_time`) USING BTREE,
  KEY `idx_index_enterprise_value_objid` (`obj_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='集团指标值表';

-- ----------------------------
-- Table structure for tci_index_manage
-- ----------------------------
DROP TABLE IF EXISTS `tci_index_manage`;
CREATE TABLE `tci_index_manage` (
  `index_code` varchar(64) NOT NULL COMMENT '  联合主键  pk_index_manage  指标id',
  `index_name_en` varchar(128) DEFAULT NULL,
  `index_name_cn` varchar(128) NOT NULL COMMENT ' 指标中文名称',
  `index_alias_name` varchar(128) DEFAULT NULL COMMENT ' 指标别名',
  `index_catalog` int(11) NOT NULL COMMENT ' 指标分类id',
  `index_version` varchar(32) NOT NULL COMMENT '  联合主键  pk_index_manage  指标版本号',
  `statistics_obj` varchar(32) NOT NULL COMMENT '    类型对象',
  `statistics_type` int(2) DEFAULT NULL,
  `value_type` varchar(32) NOT NULL COMMENT '    指标值类型',
  `index_unit` varchar(32) NOT NULL COMMENT '    指标单位',
  `index_cycle` varchar(64) DEFAULT NULL COMMENT '指标周期',
  `save_time` int(5) DEFAULT NULL COMMENT '    保留周期，单位月',
  `statistics_time` varchar(32) DEFAULT NULL COMMENT '    统计时间  数据字典',
  `interface_person` varchar(64) DEFAULT NULL COMMENT '    接口人名称',
  `business_caliber` varchar(1024) DEFAULT NULL COMMENT '    业务口径',
  `technology_calber` varchar(1024) DEFAULT NULL COMMENT '    技术口径',
  `data_sources` varchar(128) DEFAULT NULL COMMENT '    数据来源',
  `remarks` varchar(1024) DEFAULT NULL COMMENT '    备注 ',
  `index_status` int(2) NOT NULL COMMENT '    指标状态  0 失效  1 生效',
  `index_type` int(2) NOT NULL COMMENT '    指标类型 1 比率类  2 销量类',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '    创建者用户名',
  `create_opername` varchar(64) DEFAULT NULL COMMENT '    创建者别名',
  `create_time` datetime DEFAULT NULL COMMENT '    创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '    更新者用户名',
  `update_opername` varchar(64) DEFAULT NULL COMMENT '    更新者别名',
  `update_time` datetime DEFAULT NULL COMMENT '    更新时间',
  `is_parent_index` varchar(1) DEFAULT NULL COMMENT ' 是否父指标 1：是，0否',
  `parent_index_code` varchar(64) DEFAULT NULL COMMENT ' 父指标编码',
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '    预留字段1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '    预留字段2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '    预留字段3',
  `is_accumulatie` int(2) DEFAULT '0' COMMENT '累计标识 1 是  0 否  默认0',
  `index_level` varchar(32) DEFAULT NULL COMMENT '指标区域层级',
  `interface_tel` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`index_code`,`index_version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_index_manage_bak
-- ----------------------------
DROP TABLE IF EXISTS `tci_index_manage_bak`;
CREATE TABLE `tci_index_manage_bak` (
  `index_code` varchar(64) NOT NULL COMMENT '  联合主键  pk_index_manage  指标id',
  `index_name_en` varchar(128) DEFAULT NULL,
  `index_name_cn` varchar(128) NOT NULL COMMENT ' 指标中文名称',
  `index_alias_name` varchar(128) DEFAULT NULL COMMENT ' 指标别名',
  `index_catalog` int(11) NOT NULL COMMENT ' 指标分类id',
  `index_version` varchar(32) NOT NULL COMMENT '  联合主键  pk_index_manage  指标版本号',
  `statistics_obj` varchar(32) NOT NULL COMMENT '    类型对象',
  `statistics_type` int(2) DEFAULT NULL,
  `value_type` varchar(32) NOT NULL COMMENT '    指标值类型',
  `index_unit` varchar(32) NOT NULL COMMENT '    指标单位',
  `index_cycle` varchar(64) DEFAULT NULL COMMENT '指标周期',
  `save_time` int(5) DEFAULT NULL COMMENT '    保留周期，单位月',
  `statistics_time` varchar(32) DEFAULT NULL COMMENT '    统计时间  数据字典',
  `interface_person` varchar(64) DEFAULT NULL COMMENT '    接口人名称',
  `business_caliber` varchar(1024) DEFAULT NULL COMMENT '    业务口径',
  `technology_calber` varchar(1024) DEFAULT NULL COMMENT '    技术口径',
  `data_sources` varchar(128) DEFAULT NULL COMMENT '    数据来源',
  `remarks` varchar(1024) DEFAULT NULL COMMENT '    备注 ',
  `index_status` int(2) NOT NULL COMMENT '    指标状态  0 失效  1 生效',
  `index_type` int(2) NOT NULL COMMENT '    指标类型 1 比率类  2 销量类',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '    创建者用户名',
  `create_opername` varchar(64) DEFAULT NULL COMMENT '    创建者别名',
  `create_time` datetime DEFAULT NULL COMMENT '    创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '    更新者用户名',
  `update_opername` varchar(64) DEFAULT NULL COMMENT '    更新者别名',
  `update_time` datetime DEFAULT NULL COMMENT '    更新时间',
  `is_parent_index` varchar(1) DEFAULT NULL COMMENT ' 是否父指标 1：是，0否',
  `parent_index_code` varchar(64) DEFAULT NULL COMMENT ' 父指标编码',
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '    预留字段1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '    预留字段2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '    预留字段3',
  `is_accumulatie` int(2) DEFAULT '0' COMMENT '累计标识 1 是  0 否  默认0',
  `index_level` varchar(32) DEFAULT NULL COMMENT '指标区域层级',
  `interface_tel` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`index_code`,`index_version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_index_manage_his
-- ----------------------------
DROP TABLE IF EXISTS `tci_index_manage_his`;
CREATE TABLE `tci_index_manage_his` (
  `index_code` varchar(64) NOT NULL COMMENT '  联合主键  pk_index_manage  指标id',
  `index_name_en` varchar(128) DEFAULT NULL,
  `index_name_cn` varchar(128) NOT NULL COMMENT '    指标中文名称',
  `index_alias_name` varchar(128) DEFAULT NULL,
  `index_catalog` int(11) NOT NULL COMMENT '    指标分类id',
  `index_version` varchar(32) NOT NULL COMMENT '  联合主键  pk_index_manage  指标版本号',
  `statistics_obj` varchar(32) NOT NULL COMMENT '    类型对象',
  `statistics_type` varchar(32) DEFAULT NULL COMMENT '统计类型',
  `value_type` varchar(32) NOT NULL COMMENT '    指标值类型',
  `index_unit` varchar(32) NOT NULL COMMENT '    指标单位',
  `save_time` int(5) DEFAULT NULL COMMENT '    保留周期，单位月',
  `index_cycle` varchar(32) DEFAULT NULL COMMENT '    统计时间  数据字典',
  `interface_person` varchar(64) DEFAULT NULL COMMENT '    接口人名称',
  `business_caliber` varchar(1024) DEFAULT NULL COMMENT '    业务口径',
  `technology_calber` varchar(1024) DEFAULT NULL COMMENT '    技术口径',
  `data_sources` varchar(128) DEFAULT NULL COMMENT '    数据来源',
  `remarks` varchar(1024) DEFAULT NULL COMMENT '    备注 ',
  `index_status` int(2) NOT NULL COMMENT '    指标状态  0 失效  1 生效',
  `index_type` int(2) NOT NULL COMMENT '    指标类型 1 比率类  2 销量类',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '    创建者用户名',
  `create_opername` varchar(64) DEFAULT NULL COMMENT '    创建者别名',
  `create_time` datetime DEFAULT NULL COMMENT '    创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '    更新者用户名',
  `update_opername` varchar(64) DEFAULT NULL COMMENT '    更新者别名',
  `update_time` datetime DEFAULT NULL COMMENT '    更新时间',
  `is_parent_index` varchar(1) DEFAULT NULL COMMENT ' 是否父指标 1：是，0否',
  `parent_index_code` varchar(64) DEFAULT NULL COMMENT ' 父指标编码',
  `is_accumulatie` int(2) DEFAULT NULL,
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '    预留字段1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '    预留字段2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '    预留字段3',
  `index_level` varchar(32) DEFAULT NULL COMMENT '指标区域层级',
  `interface_tel` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`index_code`,`index_version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_index_minor_enterprise_value
-- ----------------------------
DROP TABLE IF EXISTS `tci_index_minor_enterprise_value`;
CREATE TABLE `tci_index_minor_enterprise_value` (
  `data_id` varchar(64) NOT NULL COMMENT '主键  pk_index_channel_value 自增长  数据id',
  `index_code` varchar(64) NOT NULL COMMENT '唯一联合索引  u_index_channel_value_value  指标编码',
  `index_name` varchar(64) NOT NULL COMMENT '指标中文名称',
  `index_cycle` int(2) NOT NULL COMMENT '唯一联合索引  u_index_channel_value_value  指标周期 数据字典',
  `index_time` varchar(32) NOT NULL COMMENT '唯一联合索引  u_index_channel_value_value  指标时间',
  `obj_id` varchar(64) NOT NULL COMMENT '唯一联合索引  u_idx_index_value  对象编码',
  `obj_name` varchar(64) NOT NULL COMMENT '对象名称',
  `parent_id` varchar(64) NOT NULL COMMENT '小区父对象编码 责任田',
  `index_value` decimal(16,4) NOT NULL COMMENT '指标值',
  `create_opername` varchar(64) DEFAULT NULL COMMENT '创建人别名',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '更新者用户名',
  `update_opername` varchar(64) DEFAULT NULL COMMENT '更新者别名',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '预留字段1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '预留字段2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '预留字段3',
  PRIMARY KEY (`data_id`),
  UNIQUE KEY `u_idx_index_enterprise_value` (`index_code`,`index_cycle`,`index_time`,`obj_id`),
  KEY `idx_index_enterprise_value_indexcode` (`index_code`) USING BTREE,
  KEY `idx_index_enterprise_value_indexcycle` (`index_cycle`) USING BTREE,
  KEY `idx_index_enterprise_value_indextime` (`index_time`) USING BTREE,
  KEY `idx_index_enterprise_value_objid` (`obj_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='中小微企业指标值表';

-- ----------------------------
-- Table structure for tci_index_module_catalog
-- ----------------------------
DROP TABLE IF EXISTS `tci_index_module_catalog`;
CREATE TABLE `tci_index_module_catalog` (
  `catalog_id` varchar(64) NOT NULL,
  `channel_type` int(2) NOT NULL,
  `menu_name` varchar(256) NOT NULL,
  `parent_id` varchar(64) NOT NULL,
  `menu_level` int(2) NOT NULL,
  `order_no` int(3) NOT NULL,
  PRIMARY KEY (`catalog_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_index_module_cfg
-- ----------------------------
DROP TABLE IF EXISTS `tci_index_module_cfg`;
CREATE TABLE `tci_index_module_cfg` (
  `cfg_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键 自动生成',
  `catalog_id` varchar(64) NOT NULL COMMENT '分类菜单ID',
  `module_code` varchar(64) NOT NULL COMMENT '模块编码',
  `index_code` varchar(64) NOT NULL COMMENT '指标编码',
  `index_name` varchar(64) NOT NULL COMMENT '指标名称',
  `default_cycle` int(2) DEFAULT NULL,
  `first_level_type` varchar(256) DEFAULT NULL COMMENT '指标类型',
  `second_level_type` varchar(256) DEFAULT NULL,
  `area_code` varchar(64) DEFAULT NULL COMMENT '地域编码',
  `area_name` varchar(256) NOT NULL COMMENT '地域名称',
  `area_level` int(2) NOT NULL COMMENT '地域等级 1 省 2 地区市 3 县级市 4 网格 5 责任田',
  `area_path` varchar(256) NOT NULL COMMENT '地域路径PATH',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '创建者用户名',
  `create_opername` varchar(64) DEFAULT NULL COMMENT '创建者别名',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '更新者用户名',
  `update_opername` varchar(64) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '更新者别名',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '预留字段1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '预留字段2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '预留字段3',
  `order_no` int(3) DEFAULT NULL COMMENT '序号',
  `is_default` int(2) NOT NULL,
  PRIMARY KEY (`cfg_id`),
  KEY `idx_index_module_cfg_catalog` (`catalog_id`),
  KEY `idx_index_module_cfg_module` (`module_code`),
  KEY `idx_index_module_cfg_area_code` (`area_code`)
) ENGINE=InnoDB AUTO_INCREMENT=217 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_index_module_info
-- ----------------------------
DROP TABLE IF EXISTS `tci_index_module_info`;
CREATE TABLE `tci_index_module_info` (
  `module_code` varchar(64) NOT NULL,
  `catalog_id` varchar(64) NOT NULL,
  `module_name` varchar(64) NOT NULL,
  `area_level` varchar(64) DEFAULT NULL,
  `order_no` int(3) NOT NULL,
  `default_cycle` varchar(64) DEFAULT NULL COMMENT '默认周期，1、年；2、季；3、月；4、日；5、月累计；6、季累计',
  `remark` varchar(1024) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`module_code`),
  KEY `idx_index_module_info_catalog` (`catalog_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_index_module_pre_cfg
-- ----------------------------
DROP TABLE IF EXISTS `tci_index_module_pre_cfg`;
CREATE TABLE `tci_index_module_pre_cfg` (
  `module_code` varchar(64) NOT NULL,
  `catalog_id` varchar(64) NOT NULL,
  `index_code` varchar(32) NOT NULL,
  `order_no` int(3) NOT NULL,
  PRIMARY KEY (`module_code`,`catalog_id`,`index_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_index_person_value
-- ----------------------------
DROP TABLE IF EXISTS `tci_index_person_value`;
CREATE TABLE `tci_index_person_value` (
  `data_id` varchar(64) NOT NULL COMMENT '主键  pk_index_person_value 自增长        数据id',
  `index_code` varchar(64) NOT NULL COMMENT '唯一联合索引  u_index_person_value_value        指标编码',
  `index_name` varchar(64) NOT NULL COMMENT '指标中文名称',
  `index_cycle` int(2) NOT NULL COMMENT '唯一联合索引  u_index_person_value_value        指标周期 数据字典',
  `index_time` varchar(32) NOT NULL COMMENT '唯一联合索引  u_index_person_value_value        指标时间',
  `obj_id` varchar(64) NOT NULL COMMENT '唯一联合索引  u_idx_index_person_value        对象编码',
  `obj_type` int(2) DEFAULT NULL,
  `obj_name` varchar(64) NOT NULL COMMENT '对象名称',
  `obj_path` varchar(128) DEFAULT NULL,
  `role_id` varchar(64) NOT NULL COMMENT '角色id',
  `role_name` varchar(64) NOT NULL COMMENT '角色name',
  `index_value` decimal(16,4) NOT NULL COMMENT '指标值',
  `create_opername` varchar(64) DEFAULT NULL COMMENT '创建人别名',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '更新者用户名',
  `update_opername` varchar(64) DEFAULT NULL COMMENT '更新者别名',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '预留字段1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '预留字段2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '预留字段3',
  PRIMARY KEY (`data_id`),
  UNIQUE KEY `u_idx_index_person_value` (`index_code`,`index_cycle`,`index_time`,`obj_id`),
  KEY `idx_index_person_value_indexcode` (`index_code`) USING BTREE,
  KEY `idx_index_person_value_indexcycle` (`index_cycle`) USING BTREE,
  KEY `idx_index_person_value_indextime` (`index_time`) USING BTREE,
  KEY `idx_index_person_value_roleid` (`role_id`) USING BTREE,
  KEY `idx_index_person_value_objid` (`obj_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='人员指标值表';

-- ----------------------------
-- Table structure for tci_index_station_value
-- ----------------------------
DROP TABLE IF EXISTS `tci_index_station_value`;
CREATE TABLE `tci_index_station_value` (
  `data_id` varchar(64) NOT NULL COMMENT '主键  pk_index_station_value 自增长        数据id',
  `index_code` varchar(64) NOT NULL COMMENT '唯一联合索引  u_index_station_value_value        指标编码',
  `index_name` varchar(64) NOT NULL COMMENT '指标中文名称',
  `index_cycle` int(2) NOT NULL COMMENT '唯一联合索引  u_index_station_value_value        指标周期 数据字典',
  `index_time` varchar(32) NOT NULL COMMENT '唯一联合索引  u_index_station_value_value        指标时间',
  `obj_id` varchar(64) NOT NULL COMMENT '唯一联合索引  u_idx_index_station_value        对象编码',
  `obj_type` int(2) DEFAULT NULL,
  `obj_name` varchar(64) NOT NULL COMMENT '对象名称',
  `obj_path` varchar(128) DEFAULT NULL,
  `parent_id` varchar(64) NOT NULL COMMENT '渠道父对象编码 责任田',
  `index_value` decimal(16,4) NOT NULL COMMENT '指标值',
  `create_opername` varchar(64) DEFAULT NULL COMMENT '创建人别名',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '更新者用户名',
  `update_opername` varchar(64) DEFAULT NULL COMMENT '更新者别名',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '预留字段1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '预留字段2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '预留字段3',
  PRIMARY KEY (`data_id`),
  UNIQUE KEY `u_idx_index_station_value` (`index_code`,`index_cycle`,`index_time`,`obj_id`),
  KEY `idx_index_station_value_indexcode` (`index_code`) USING BTREE,
  KEY `idx_index_station_value_indexcycle` (`index_cycle`) USING BTREE,
  KEY `idx_index_station_value_indextime` (`index_time`) USING BTREE,
  KEY `idx_index_station_value_objid` (`obj_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='基站指标值表';

-- ----------------------------
-- Table structure for tci_index_type
-- ----------------------------
DROP TABLE IF EXISTS `tci_index_type`;
CREATE TABLE `tci_index_type` (
  `type_id` int(11) NOT NULL AUTO_INCREMENT COMMENT ' 主键  pk_warn_rule  自增长  指标类型id',
  `type_name` varchar(64) NOT NULL COMMENT '   指标类型名称',
  `type_catalog` int(3) NOT NULL COMMENT '   指标类型分类  1 省统指标 2 自定义指标',
  `type_path` varchar(64) DEFAULT NULL,
  `parent_id` int(11) NOT NULL COMMENT '   父类型id  -1代表根节点',
  `type_level` int(3) NOT NULL COMMENT '   指标类型层级',
  `order_no` int(3) DEFAULT '1' COMMENT '  1 类型在当前层级下顺序',
  `create_areacode` varchar(64) NOT NULL COMMENT '创建者当前地域编码',
  `create_areaname` varchar(64) NOT NULL COMMENT '创建者当前地域名称',
  `create_areapath` varchar(64) NOT NULL COMMENT '   创建者当前地域层级',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '   创建者用户名',
  `create_opername` varchar(64) DEFAULT NULL COMMENT '   创建者别名',
  `create_time` datetime DEFAULT NULL COMMENT '   创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '   更新者用户名',
  `update_opername` varchar(64) DEFAULT NULL COMMENT '   更新者别名',
  `update_time` datetime DEFAULT NULL COMMENT '   更新时间',
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '   预留字段1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '   预留字段2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '   预留字段3',
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1907 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_index_type_bak
-- ----------------------------
DROP TABLE IF EXISTS `tci_index_type_bak`;
CREATE TABLE `tci_index_type_bak` (
  `type_id` int(11) NOT NULL AUTO_INCREMENT COMMENT ' 主键  pk_warn_rule  自增长  指标类型id',
  `type_name` varchar(64) NOT NULL COMMENT '   指标类型名称',
  `type_catalog` int(3) NOT NULL COMMENT '   指标类型分类  1 省统指标 2 自定义指标',
  `type_path` varchar(64) DEFAULT NULL,
  `parent_id` int(11) NOT NULL COMMENT '   父类型id  -1代表根节点',
  `type_level` int(3) NOT NULL COMMENT '   指标类型层级',
  `order_no` int(3) DEFAULT '1' COMMENT '  1 类型在当前层级下顺序',
  `create_areacode` varchar(64) NOT NULL COMMENT '创建者当前地域编码',
  `create_areaname` varchar(64) NOT NULL COMMENT '创建者当前地域名称',
  `create_areapath` varchar(64) NOT NULL COMMENT '   创建者当前地域层级',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '   创建者用户名',
  `create_opername` varchar(64) DEFAULT NULL COMMENT '   创建者别名',
  `create_time` datetime DEFAULT NULL COMMENT '   创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '   更新者用户名',
  `update_opername` varchar(64) DEFAULT NULL COMMENT '   更新者别名',
  `update_time` datetime DEFAULT NULL COMMENT '   更新时间',
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '   预留字段1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '   预留字段2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '   预留字段3',
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_index_uptown_value
-- ----------------------------
DROP TABLE IF EXISTS `tci_index_uptown_value`;
CREATE TABLE `tci_index_uptown_value` (
  `data_id` varchar(64) NOT NULL COMMENT '主键  pk_index_channel_value 自增长  数据id',
  `index_code` varchar(64) NOT NULL COMMENT '唯一联合索引  u_index_channel_value_value  指标编码',
  `index_name` varchar(64) NOT NULL COMMENT '指标中文名称',
  `index_cycle` int(2) NOT NULL COMMENT '唯一联合索引  u_index_channel_value_value  指标周期 数据字典',
  `index_time` varchar(32) NOT NULL COMMENT '唯一联合索引  u_index_channel_value_value  指标时间',
  `obj_id` varchar(64) NOT NULL COMMENT '唯一联合索引  u_idx_index_value  对象编码',
  `obj_name` varchar(64) NOT NULL COMMENT '对象名称',
  `parent_id` varchar(64) NOT NULL COMMENT '小区父对象编码 责任田',
  `index_value` decimal(16,4) NOT NULL COMMENT '指标值',
  `create_opername` varchar(64) DEFAULT NULL COMMENT '创建人别名',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '更新者用户名',
  `update_opername` varchar(64) DEFAULT NULL COMMENT '更新者别名',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '预留字段1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '预留字段2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '预留字段3',
  PRIMARY KEY (`data_id`),
  UNIQUE KEY `u_idx_index_uptown_value` (`index_code`,`index_cycle`,`index_time`,`obj_id`),
  KEY `idx_index_channel_uptown_indexcode` (`index_code`) USING BTREE,
  KEY `idx_index_channel_uptown_indexcycle` (`index_cycle`) USING BTREE,
  KEY `idx_index_channel_uptown_indextime` (`index_time`) USING BTREE,
  KEY `idx_index_channel_uptown_objid` (`obj_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='小区指标值表';

-- ----------------------------
-- Table structure for tci_index_value
-- ----------------------------
DROP TABLE IF EXISTS `tci_index_value`;
CREATE TABLE `tci_index_value` (
  `data_id` varchar(64) NOT NULL COMMENT ' 主键  pk_index_value 自增长  数据id',
  `index_code` varchar(64) NOT NULL COMMENT ' 唯一联合索引  u_idx_index_value  指标编码',
  `index_name` varchar(64) NOT NULL COMMENT '   指标中文名称',
  `index_cycle` int(2) NOT NULL COMMENT ' 唯一联合索引  u_idx_index_value  指标周期 数据字典',
  `index_time` varchar(32) NOT NULL COMMENT ' 唯一联合索引  u_idx_index_value  指标时间',
  `obj_type` int(2) NOT NULL COMMENT '   对象类型 1 省公司 2 市公司 3 分公司 4 网格  5 责任田 6 销售经理 7 渠道 8 社区 9 中小微企业',
  `obj_id` varchar(64) NOT NULL COMMENT '区域编码',
  `obj_name` varchar(64) NOT NULL COMMENT '   提示阀值',
  `obj_path` varchar(256) NOT NULL COMMENT '   对象路径',
  `index_value` decimal(16,4) DEFAULT NULL COMMENT '  指标值',
  `create_opername` varchar(64) DEFAULT NULL COMMENT '创建人别名',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '   创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '   更新者用户名',
  `update_opername` varchar(64) DEFAULT NULL COMMENT '   更新者别名',
  `update_time` datetime DEFAULT NULL COMMENT '   更新时间',
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '   预留字段1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '   预留字段2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '   预留字段3',
  `index_score` decimal(6,2) DEFAULT NULL COMMENT '指标得分',
  PRIMARY KEY (`data_id`),
  UNIQUE KEY `u_idx_index_value` (`index_code`,`index_cycle`,`index_time`,`obj_id`),
  KEY `idx_index_value_indexcode` (`index_code`) USING BTREE,
  KEY `idx_index_value_indexcycle` (`index_cycle`) USING BTREE,
  KEY `idx_index_value_indextime` (`index_time`) USING BTREE,
  KEY `idx_index_value_objtype` (`obj_type`) USING BTREE,
  KEY `idx_index_value_objid` (`obj_id`) USING BTREE,
  KEY `idx_index_value_createoperid` (`create_operid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_index_value_mid
-- ----------------------------
DROP TABLE IF EXISTS `tci_index_value_mid`;
CREATE TABLE `tci_index_value_mid` (
  `data_id` bigint(20) NOT NULL COMMENT '主键 自增长  数据id',
  `index_code` varchar(64) NOT NULL COMMENT '指标编码',
  `index_name` varchar(64) NOT NULL COMMENT '指标中文名称',
  `index_cycle` int(2) NOT NULL COMMENT '指标周期 数据字典',
  `index_time` varchar(32) NOT NULL COMMENT '指标时间',
  `obj_type` int(2) NOT NULL COMMENT '对象类型 1 省公司 2 市公司 3 分公司 4 网格  5 责任田 6 销售经理 7 渠道 8 社区 9 中小微企业',
  `obj_id` varchar(64) NOT NULL COMMENT '区域编码',
  `obj_name` varchar(64) NOT NULL COMMENT '对象名称',
  `obj_path` varchar(256) NOT NULL COMMENT '对象路径',
  `index_value_type` int(2) NOT NULL COMMENT '指标值类型 1 当前值 2 累计值',
  `index_value` decimal(16,4) NOT NULL COMMENT '指标值',
  `index_ratio` decimal(6,2) DEFAULT NULL COMMENT '指标系数',
  `index_calculate_value` decimal(16,4) DEFAULT NULL COMMENT '指标计算值',
  `index_score` decimal(6,2) DEFAULT NULL COMMENT '指标得分',
  `create_opername` varchar(64) DEFAULT NULL COMMENT '创建人别名',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '创建名称',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '更新者用户名',
  `update_opername` varchar(64) DEFAULT NULL COMMENT '更新者别名',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `city` varchar(32) DEFAULT NULL COMMENT '地区分公司信息',
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '预留字段1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '预留字段2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '预留字段3',
  PRIMARY KEY (`data_id`),
  UNIQUE KEY `u_idx_index_value_mid` (`index_code`,`index_cycle`,`index_time`,`obj_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='完成值导入中间表';

-- ----------------------------
-- Table structure for tci_new_task_cfg
-- ----------------------------
DROP TABLE IF EXISTS `tci_new_task_cfg`;
CREATE TABLE `tci_new_task_cfg` (
  `task_cfg_id` varchar(32) NOT NULL COMMENT '任务配置ID',
  `describes` varchar(1024) DEFAULT NULL COMMENT '参数描述',
  `main_value` varchar(256) DEFAULT NULL COMMENT '参数值1',
  `vice_value` varchar(256) DEFAULT NULL COMMENT '参数值2',
  PRIMARY KEY (`task_cfg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_procedure_log
-- ----------------------------
DROP TABLE IF EXISTS `tci_procedure_log`;
CREATE TABLE `tci_procedure_log` (
  `procedure_name` varchar(64) DEFAULT NULL,
  `log_time` datetime DEFAULT NULL,
  `log_title` varchar(64) DEFAULT NULL,
  `log_info` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_sys_action
-- ----------------------------
DROP TABLE IF EXISTS `tci_sys_action`;
CREATE TABLE `tci_sys_action` (
  `object_id` varchar(255) NOT NULL COMMENT '权限ID',
  `uri` varchar(255) NOT NULL COMMENT '动作ID',
  `describe` varchar(512) DEFAULT NULL COMMENT '备注 ',
  PRIMARY KEY (`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_sys_area
-- ----------------------------
DROP TABLE IF EXISTS `tci_sys_area`;
CREATE TABLE `tci_sys_area` (
  `area_code` varchar(64) NOT NULL,
  `area_name` varchar(64) NOT NULL,
  `parent_code` varchar(32) DEFAULT NULL,
  `area_level` int(2) NOT NULL COMMENT ' 1  2  3  4  5 ',
  `area_path` varchar(256) DEFAULT NULL COMMENT 'path',
  `mgr_operid` varchar(32) DEFAULT NULL,
  `mgr_name` varchar(64) DEFAULT NULL,
  `mgr_tel` varchar(32) DEFAULT NULL,
  `mgr_email` varchar(64) DEFAULT NULL,
  `order_no` int(3) DEFAULT '1',
  `create_operid` varchar(32) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_operid` varchar(32) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '3',
  PRIMARY KEY (`area_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_sys_channel_duty
-- ----------------------------
DROP TABLE IF EXISTS `tci_sys_channel_duty`;
CREATE TABLE `tci_sys_channel_duty` (
  `id` varchar(32) NOT NULL COMMENT '职责ID',
  `name` varchar(256) NOT NULL COMMENT '职责名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='渠道职责表';

-- ----------------------------
-- Table structure for tci_sys_datadict
-- ----------------------------
DROP TABLE IF EXISTS `tci_sys_datadict`;
CREATE TABLE `tci_sys_datadict` (
  `dict_code` varchar(64) NOT NULL COMMENT '数据字典编码',
  `dict_name` varchar(64) NOT NULL COMMENT '数据字典名称',
  `dict_desc` varchar(256) DEFAULT NULL COMMENT '数据字典描述',
  `data_value` varchar(128) NOT NULL COMMENT '数据编码',
  `data_name` varchar(64) NOT NULL COMMENT '数据名称',
  `data_desc` varchar(256) DEFAULT NULL COMMENT '数据描述',
  `dict_status` int(1) NOT NULL DEFAULT '1' COMMENT '状态： 1 激活, 0 草稿',
  `order_no` int(3) DEFAULT '1' COMMENT '字典顺序',
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '预留字段1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '预留字段2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '预留字段3',
  `lang` varchar(32) NOT NULL,
  PRIMARY KEY (`dict_code`,`data_value`,`lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_sys_grid_staff_e
-- ----------------------------
DROP TABLE IF EXISTS `tci_sys_grid_staff_e`;
CREATE TABLE `tci_sys_grid_staff_e` (
  `grid_code` varchar(64) NOT NULL COMMENT '地域编码',
  `user_id` varchar(200) DEFAULT NULL COMMENT '平台用户ID',
  `code` varchar(64) DEFAULT NULL COMMENT '责任人工号',
  `code1` varchar(64) DEFAULT NULL COMMENT '责任人工号1',
  `code2` varchar(64) DEFAULT NULL COMMENT '责任人工号2',
  `name` varchar(32) NOT NULL COMMENT '责任人名称',
  `type` int(10) DEFAULT NULL COMMENT '职责类型',
  `portal` varchar(64) DEFAULT NULL COMMENT '责任人portal账号',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  UNIQUE KEY `IDX_U_SYS_GRID_STAFF_E` (`grid_code`,`code`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统网格员工表';

-- ----------------------------
-- Table structure for tci_sys_menu
-- ----------------------------
DROP TABLE IF EXISTS `tci_sys_menu`;
CREATE TABLE `tci_sys_menu` (
  `menu_id` varchar(32) NOT NULL COMMENT '菜单id',
  `menu_name` varchar(64) NOT NULL COMMENT '菜单名称',
  `menu_uri` varchar(128) DEFAULT NULL COMMENT '菜单对应地址',
  `menu_icon` varchar(128) DEFAULT NULL COMMENT '菜单图标',
  `menu_icon_active` varchar(128) DEFAULT NULL COMMENT '菜单激活图标',
  `parent_id` varchar(32) NOT NULL COMMENT '父菜单id',
  `menu_code` varchar(32) DEFAULT NULL,
  `order_no` int(2) DEFAULT '1' COMMENT '菜单顺序',
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '预留字段1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '预留字段2 ',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '预留字段3',
  `lang` varchar(32) NOT NULL,
  PRIMARY KEY (`menu_id`,`menu_name`,`lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_sys_mini_unit
-- ----------------------------
DROP TABLE IF EXISTS `tci_sys_mini_unit`;
CREATE TABLE `tci_sys_mini_unit` (
  `unit_code` varchar(64) NOT NULL COMMENT '单元编码',
  `unit_name` varchar(128) NOT NULL COMMENT '单元名称',
  `unit_type` int(2) NOT NULL COMMENT '单元类型 1 渠道 2 社区 3 中小微企业',
  `parent_code` varchar(64) DEFAULT NULL COMMENT '父编码',
  `mgr_operid` varchar(32) DEFAULT NULL COMMENT '责任人用户名  社区和中小微企业没有责任人',
  `mgr_name` varchar(64) DEFAULT NULL COMMENT '责任人别名',
  `order_no` int(3) DEFAULT '1' COMMENT '地域顺序',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '预留字段1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '预留字段2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '预留字段3',
  PRIMARY KEY (`unit_code`,`unit_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_sys_privilege
-- ----------------------------
DROP TABLE IF EXISTS `tci_sys_privilege`;
CREATE TABLE `tci_sys_privilege` (
  `privilege_id` varchar(32) NOT NULL COMMENT '权限id',
  `object_type` int(2) NOT NULL COMMENT '权限对象类型,1：菜单,2 : 按钮,3：其他',
  `object_id` varchar(32) NOT NULL COMMENT '权限对象id',
  `privilege_desc` varchar(256) DEFAULT NULL COMMENT '权限描述',
  PRIMARY KEY (`privilege_id`),
  KEY `idx_sys_privilege_objectid` (`object_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_sys_privilege_set
-- ----------------------------
DROP TABLE IF EXISTS `tci_sys_privilege_set`;
CREATE TABLE `tci_sys_privilege_set` (
  `set_id` varchar(32) NOT NULL,
  `privilege_id` varchar(32) NOT NULL,
  PRIMARY KEY (`set_id`,`privilege_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for TCI_SYS_SEQUENCE
-- ----------------------------
DROP TABLE IF EXISTS `TCI_SYS_SEQUENCE`;
CREATE TABLE `TCI_SYS_SEQUENCE` (
  `NAME` varchar(50) NOT NULL,
  `START_VALUE` int(11) NOT NULL,
  `VALUE` int(11) DEFAULT NULL,
  `INCREMENT` int(11) NOT NULL DEFAULT '1',
  `PREFIX` varchar(10) DEFAULT NULL COMMENT '前缀',
  `MAX_VALUE` int(11) DEFAULT '999999999',
  PRIMARY KEY (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_sys_useless_area
-- ----------------------------
DROP TABLE IF EXISTS `tci_sys_useless_area`;
CREATE TABLE `tci_sys_useless_area` (
  `area_code` varchar(32) NOT NULL,
  `area_name` varchar(64) NOT NULL,
  `parent_code` varchar(32) DEFAULT NULL,
  `area_level` int(2) NOT NULL COMMENT ' 1  2  3  4  5 ',
  `area_path` varchar(256) DEFAULT NULL COMMENT 'path',
  `mgr_operid` varchar(32) DEFAULT NULL,
  `mgr_name` varchar(64) DEFAULT NULL,
  `mgr_tel` varchar(32) DEFAULT NULL,
  `mgr_email` varchar(64) DEFAULT NULL,
  `order_no` int(3) DEFAULT '1',
  `create_operid` varchar(32) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_operid` varchar(32) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '3',
  PRIMARY KEY (`area_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_sys_website_staff_e
-- ----------------------------
DROP TABLE IF EXISTS `tci_sys_website_staff_e`;
CREATE TABLE `tci_sys_website_staff_e` (
  `id` bigint(32) NOT NULL,
  `website_code` varchar(200) DEFAULT NULL,
  `website_name` varchar(800) DEFAULT NULL,
  `oper_id` varchar(80) DEFAULT NULL,
  `oper_code` varchar(80) DEFAULT NULL,
  `oper_name` varchar(320) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_website_code` (`website_code`),
  KEY `index_operid` (`oper_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_task_addition_value
-- ----------------------------
DROP TABLE IF EXISTS `tci_task_addition_value`;
CREATE TABLE `tci_task_addition_value` (
  `task_id` varchar(64) NOT NULL COMMENT '考核任务ID',
  `addition_code` int(10) NOT NULL AUTO_INCREMENT COMMENT '附加项编码',
  `addition_name` varchar(128) NOT NULL COMMENT '附加项名称',
  `obj_id` varchar(64) NOT NULL COMMENT '区域编码',
  `obj_name` varchar(64) DEFAULT NULL COMMENT '区域名称',
  `addition_type` int(2) NOT NULL COMMENT '类型',
  `weight` decimal(12,2) NOT NULL COMMENT '权重',
  `addition_content` varchar(1000) DEFAULT NULL COMMENT '口径',
  `create_operid` varchar(64) DEFAULT NULL,
  `create_time` date DEFAULT NULL,
  `create_opername` varchar(64) DEFAULT NULL,
  `base_parent_id` varchar(64) NOT NULL COMMENT '根任务ID',
  `obj_type` int(2) DEFAULT NULL,
  `obj_path` varchar(255) DEFAULT NULL,
  `addition_cycle` int(2) DEFAULT NULL,
  `addition_time` varchar(32) DEFAULT NULL,
  UNIQUE KEY `base_parent_id` (`base_parent_id`,`obj_id`,`addition_name`),
  KEY `addition_code` (`addition_code`),
  KEY `tci_task_addition_value_task_id` (`task_id`),
  KEY `tci_task_addition_value_obj_id` (`obj_id`),
  KEY `tci_task_addition_value_addition_type` (`addition_type`)
) ENGINE=InnoDB AUTO_INCREMENT=645 DEFAULT CHARSET=utf8 MIN_ROWS=1000000;

-- ----------------------------
-- Table structure for tci_task_addition_value_tmp
-- ----------------------------
DROP TABLE IF EXISTS `tci_task_addition_value_tmp`;
CREATE TABLE `tci_task_addition_value_tmp` (
  `batch_id` varchar(64) NOT NULL COMMENT '批次ID',
  `row_index` int(8) DEFAULT NULL,
  `task_id` varchar(64) NOT NULL COMMENT '考核任务ID',
  `addition_name` varchar(128) NOT NULL COMMENT '附加项名称',
  `obj_id` varchar(64) NOT NULL COMMENT '区域编码',
  `obj_name` varchar(64) DEFAULT NULL COMMENT '区域名称',
  `addition_type` int(2) NOT NULL COMMENT '类型',
  `weight` decimal(12,2) NOT NULL COMMENT '权重',
  `addition_content` varchar(1000) DEFAULT NULL COMMENT '口径',
  `create_operid` varchar(64) DEFAULT NULL,
  `create_time` date DEFAULT NULL,
  `create_opername` varchar(64) DEFAULT NULL,
  `base_parent_id` varchar(64) DEFAULT NULL,
  `obj_type` int(2) DEFAULT NULL,
  `obj_path` varchar(255) DEFAULT NULL,
  `addition_cycle` int(2) DEFAULT NULL,
  `addition_time` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_task_score
-- ----------------------------
DROP TABLE IF EXISTS `tci_task_score`;
CREATE TABLE `tci_task_score` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `CHECK_TASK_ID` varchar(64) DEFAULT NULL COMMENT '考核任务ID ',
  `CHILD_CHECK_TASK_ID` varchar(64) DEFAULT NULL COMMENT '子考核任务ID ',
  `INDEX_CODE` varchar(64) DEFAULT NULL COMMENT '指标编码',
  `INDEX_NAME` varchar(128) DEFAULT NULL COMMENT '指标编码',
  `INDEX_CYCLE` int(2) DEFAULT NULL COMMENT '指标周期 1年 2季 3月 4日 5月累计 6季累计',
  `INDEX_TIME` varchar(32) DEFAULT NULL COMMENT '指标时间',
  `OBJ_TYPE` int(2) DEFAULT NULL COMMENT '对象类型 1 省公司 2 市公司 3 分公司 4 网格  5 责任田',
  `obj_id` varchar(64) DEFAULT NULL COMMENT '区域编码',
  `obj_name` varchar(128) DEFAULT NULL,
  `OBJ_PATH` varchar(200) DEFAULT NULL,
  `role_id` varchar(128) DEFAULT NULL,
  `role_name` varchar(128) DEFAULT NULL,
  `IS_ADDITION` int(2) DEFAULT NULL,
  `SCORE` decimal(16,2) DEFAULT NULL COMMENT '指标得分',
  `SUGGEST_SCORE` decimal(10,2) DEFAULT NULL COMMENT '建议得分 BDI计算',
  `CREATE_OPERID` varchar(32) DEFAULT NULL COMMENT '创建者用户名',
  `CREATE_OPERNAME` varchar(64) DEFAULT NULL COMMENT '创建者别名',
  `CREATE_TIME` datetime DEFAULT NULL COMMENT '创建时间',
  `UPDATE_OPERID` varchar(32) DEFAULT NULL COMMENT '更新者用户名',
  `UPDATE_OPERNAME` varchar(64) DEFAULT NULL COMMENT '更新者别名',
  `UPDATE_TIME` datetime DEFAULT NULL COMMENT '更新时间',
  `INDEX_TYPE` int(2) DEFAULT NULL,
  PRIMARY KEY (`DATA_ID`),
  UNIQUE KEY `U_IDX_TASK_SCORE` (`CHECK_TASK_ID`,`INDEX_CODE`,`INDEX_CYCLE`,`INDEX_TIME`,`obj_id`,`IS_ADDITION`),
  KEY `idx_task_score_task_id` (`CHECK_TASK_ID`),
  KEY `idx_task_score_child_task_id` (`CHILD_CHECK_TASK_ID`),
  KEY `idx_task_score_index_code` (`INDEX_CODE`),
  KEY `idx_task_score_index_cycle` (`INDEX_CYCLE`),
  KEY `idx_task_score_index_time` (`INDEX_TIME`),
  KEY `idx_task_score_obj_id` (`obj_id`),
  KEY `idx_task_score_is_add` (`IS_ADDITION`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_temp_index_value_imp
-- ----------------------------
DROP TABLE IF EXISTS `tci_temp_index_value_imp`;
CREATE TABLE `tci_temp_index_value_imp` (
  `batch_id` varchar(64) NOT NULL COMMENT '   联合主键  pk_temp_index_value_imp  导入批次id',
  `row_index` int(10) NOT NULL COMMENT '   联合主键  pk_temp_index_value_imp  excel行号 用于提示用户报错行',
  `index_code` varchar(64) NOT NULL COMMENT '   唯一联合索引  u_idx_temp_index_value_imp  指标编码',
  `index_name` varchar(64) NOT NULL COMMENT '     指标中文名称',
  `index_cycle` int(2) NOT NULL COMMENT '   唯一联合索引  u_idx_temp_index_value_imp  指标周期 数据字典',
  `index_time` varchar(32) NOT NULL COMMENT '   唯一联合索引  u_idx_temp_index_value_imp  指标时间',
  `obj_type` int(2) NOT NULL COMMENT '     对象类型 1 省公司 2 市公司 3 分公司 4 网格  5 责任田 6 销售经理 7 渠道 8 社区 9 中小微企业',
  `obj_id` varchar(64) NOT NULL COMMENT '区域编码',
  `obj_name` varchar(64) NOT NULL COMMENT '     提示阀值',
  `obj_path` varchar(256) DEFAULT NULL COMMENT '对象路径',
  `role_id` varchar(128) DEFAULT NULL,
  `role_name` varchar(128) DEFAULT NULL,
  `index_value` decimal(16,4) DEFAULT NULL COMMENT '指标值',
  `index_score` decimal(6,2) DEFAULT NULL COMMENT '指标得分',
  `create_opername` varchar(64) DEFAULT NULL,
  `create_operid` varchar(32) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL COMMENT '     创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '     更新者用户名',
  `update_opername` varchar(64) DEFAULT NULL COMMENT '     更新者别名',
  `update_time` datetime DEFAULT NULL COMMENT '     更新时间',
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '     预留字段1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '     预留字段2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '     预留字段3',
  `is_addition` int(2) DEFAULT NULL,
  `data_id` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`batch_id`,`row_index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_temp_task_score_imp
-- ----------------------------
DROP TABLE IF EXISTS `tci_temp_task_score_imp`;
CREATE TABLE `tci_temp_task_score_imp` (
  `batch_id` varchar(64) NOT NULL COMMENT '   联合主键  pk_temp_index_value_imp  导入批次id',
  `row_index` int(10) NOT NULL COMMENT '   联合主键  pk_temp_index_value_imp  excel行号 用于提示用户报错行',
  `data_id` varchar(64) DEFAULT NULL,
  `check_task_id` varchar(64) DEFAULT NULL COMMENT '   唯一联合索引  u_idx_temp_task_score_imp   考核任务id',
  `child_check_task_id` varchar(64) DEFAULT NULL COMMENT '   子考核任务id',
  `index_code` varchar(64) DEFAULT NULL COMMENT '   唯一联合索引  u_idx_temp_task_score_imp  指标编码',
  `index_name` varchar(128) DEFAULT NULL COMMENT '     指标中文名称',
  `index_cycle` int(2) DEFAULT NULL COMMENT '   唯一联合索引  u_idx_temp_task_score_imp  指标周期 数据字典',
  `index_time` varchar(32) DEFAULT NULL COMMENT '   唯一联合索引  u_idx_temp_task_score_imp  指标时间',
  `obj_type` int(2) DEFAULT NULL COMMENT '     对象类型 1 省公司 2 市公司 3 分公司 4 网格  5 责任田 6 销售经理 7 渠道 8 社区 9 中小微企业',
  `obj_id` varchar(64) DEFAULT NULL,
  `obj_name` varchar(64) DEFAULT NULL COMMENT '     区域类型',
  `obj_path` varchar(256) DEFAULT NULL COMMENT '对象路径',
  `is_addition` int(2) DEFAULT NULL COMMENT '   唯一联合索引  u_idx_temp_task_score_imp  是否附加项',
  `score` decimal(10,2) DEFAULT NULL COMMENT '指标得分',
  `suggest_score` decimal(10,2) DEFAULT NULL COMMENT '建议得分',
  `create_opername` varchar(64) DEFAULT NULL,
  `create_operid` varchar(32) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL COMMENT '     创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '     更新者用户名',
  `update_opername` varchar(64) DEFAULT NULL COMMENT '     更新者别名',
  `update_time` datetime DEFAULT NULL COMMENT '     更新时间',
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '     预留字段1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '     预留字段2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '     预留字段3',
  `index_type` int(2) DEFAULT NULL,
  PRIMARY KEY (`batch_id`,`row_index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_temp_warn_rule_detail_imp
-- ----------------------------
DROP TABLE IF EXISTS `tci_temp_warn_rule_detail_imp`;
CREATE TABLE `tci_temp_warn_rule_detail_imp` (
  `rel_id` varchar(64) NOT NULL COMMENT ' 联合主键  pk_temp_warn_rule_detail_imp  预警规则id',
  `row_index` int(10) NOT NULL COMMENT ' 联合主键  pk_temp_warn_rule_detail_imp  excel行号 用于提示用户报错行',
  `begin_day` int(2) NOT NULL COMMENT '   开始天数',
  `end_day` int(2) NOT NULL COMMENT '   结束天数',
  `critical_threshold` decimal(16,4) DEFAULT NULL,
  `general_threshold` decimal(16,4) DEFAULT NULL,
  `prompt_threshold` decimal(16,4) DEFAULT NULL,
  `warn_level` int(2) NOT NULL COMMENT '   预警级别',
  `warn_rate` int(2) NOT NULL COMMENT '   预警频率',
  PRIMARY KEY (`rel_id`,`row_index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_temp_warn_rule_imp
-- ----------------------------
DROP TABLE IF EXISTS `tci_temp_warn_rule_imp`;
CREATE TABLE `tci_temp_warn_rule_imp` (
  `batch_id` varchar(64) NOT NULL COMMENT ' 联合主键  pk_temp_warn_rule_imp  导入批次id',
  `row_index` int(10) NOT NULL COMMENT ' 联合主键  pk_temp_warn_rule_imp  excel行号 用于提示用户报错行',
  `rule_name` varchar(64) NOT NULL COMMENT '   预警规则名称',
  `index_code` varchar(32) NOT NULL COMMENT '   指标id',
  `index_name` varchar(256) NOT NULL COMMENT '   指标名称',
  `index_cycle` int(11) DEFAULT NULL,
  `task_id` varchar(64) DEFAULT NULL,
  `task_name` varchar(64) DEFAULT NULL,
  `moni_level` int(2) DEFAULT NULL COMMENT '监控等级 1 省公司 2 市公司 3 分公司 4 网格  5 责任田 7 渠道',
  `moni_project` int(2) NOT NULL COMMENT '   监控项目 1 完成值',
  `moni_derection` int(2) NOT NULL COMMENT '   监控方向 1 大于 0 等于 -1 小于',
  `apply_time` datetime NOT NULL COMMENT '   生效时间',
  `expire_time` datetime NOT NULL COMMENT '   失效时间',
  `header_desc` varchar(1024) DEFAULT NULL,
  `tail_desc` varchar(1024) DEFAULT NULL,
  `create_operid` varchar(32) DEFAULT NULL COMMENT '   创建者用户名',
  `create_opername` varchar(64) DEFAULT NULL COMMENT '   创建者别名',
  `create_time` datetime DEFAULT NULL COMMENT '   创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '   更新者用户名',
  `update_opername` varchar(64) DEFAULT NULL COMMENT '   更新者别名',
  `update_time` datetime DEFAULT NULL COMMENT '   更新时间',
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '   预留字段1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '   预留字段2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '   预留字段3',
  `moni_levels` varchar(255) DEFAULT NULL COMMENT '预警层级   数字用英文逗号隔开',
  PRIMARY KEY (`batch_id`,`row_index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_warn_notice_list
-- ----------------------------
DROP TABLE IF EXISTS `tci_warn_notice_list`;
CREATE TABLE `tci_warn_notice_list` (
  `notice_id` varchar(64) NOT NULL COMMENT ' 主键pk_warn_notice_template  通知id',
  `data_time` varchar(64) DEFAULT NULL COMMENT '   数据时间',
  `task_id` varchar(64) DEFAULT NULL COMMENT ' 索引idx_warn_notice_template_taskid  考核任务id',
  `task_name` varchar(64) DEFAULT NULL COMMENT '   考核任务名称',
  `rule_id` varchar(64) DEFAULT NULL COMMENT ' 索引idx_warn_notice_template_ruleid  考核规则id',
  `rule_name` varchar(64) DEFAULT NULL COMMENT '   考核规则名称',
  `warn_level` int(2) DEFAULT NULL COMMENT '   预警级别  1 提示 2 一般 3 严重',
  `index_code` varchar(32) DEFAULT NULL COMMENT '   指标编码',
  `index_name` varchar(256) DEFAULT NULL COMMENT '   指标名称',
  `moni_level` int(2) DEFAULT NULL COMMENT '   监控等级 1 省公司 2 市公司 3 分公司 4 网格  5 责任田 6 销售经理 7 渠道 8 社区 9 中小微企业',
  `obj_id` varchar(64) DEFAULT NULL COMMENT '区域编码',
  `obj_name` varchar(64) DEFAULT NULL COMMENT '   对象名称',
  `obj_index_value` decimal(16,4) DEFAULT NULL COMMENT '   对象指标值',
  `obj_target_value` decimal(16,4) DEFAULT NULL COMMENT '   对象目标值',
  `notice_channel` int(2) DEFAULT NULL COMMENT '   通知渠道 1 短信 2 邮箱 3 短信+邮箱',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '   创建者用户名 取task创建的用户',
  `create_opername` varchar(64) DEFAULT NULL COMMENT '   创建者别名',
  `create_time` datetime DEFAULT NULL COMMENT '   创建时间',
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '消息发送标识：0未发送，1已发送',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '   预留字段2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '   预留字段3',
  `parent_code` varchar(64) DEFAULT NULL COMMENT '父地域id',
  `obj_path` varchar(256) DEFAULT NULL COMMENT '对象路径',
  `moni_project` int(2) DEFAULT NULL COMMENT '监控项目',
  `index_cycle` varchar(64) DEFAULT NULL COMMENT '指标周期',
  `role_names` varchar(512) DEFAULT NULL COMMENT '角色名称集合',
  `warn_threshold` decimal(16,4) DEFAULT NULL COMMENT '预警阀值',
  PRIMARY KEY (`notice_id`),
  KEY `idx_warn_notice_template_taskid` (`task_id`) USING BTREE,
  KEY `idx_warn_notice_template_ruleid` (`rule_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_warn_notice_list_mgr
-- ----------------------------
DROP TABLE IF EXISTS `tci_warn_notice_list_mgr`;
CREATE TABLE `tci_warn_notice_list_mgr` (
  `rel_id` varchar(64) NOT NULL COMMENT ' 联合主键 pk_warn_notice_list_mgr  关联id  关联tci_warn_notice_list.notice_id',
  `mgr_operid` varchar(64) NOT NULL COMMENT ' 联合主键 pk_warn_notice_list_mgr  责任人用户名',
  `mgr_name` varchar(64) NOT NULL COMMENT '   责任人别名',
  `order_no` int(3) DEFAULT NULL COMMENT '   责任人顺序',
  PRIMARY KEY (`rel_id`,`mgr_operid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_warn_notice_monitor
-- ----------------------------
DROP TABLE IF EXISTS `tci_warn_notice_monitor`;
CREATE TABLE `tci_warn_notice_monitor` (
  `moni_id` varchar(64) NOT NULL COMMENT ' 主键pk_warn_notice_monitor  监控id',
  `data_time` varchar(64) NOT NULL COMMENT '   数据时间',
  `task_id` varchar(64) NOT NULL COMMENT ' 索引idx_warn_notice_monitor_taskid  考核任务id',
  `task_name` varchar(64) NOT NULL COMMENT '   考核任务名称',
  `rule_id` varchar(64) DEFAULT NULL COMMENT ' 索引idx_warn_notice_monitor_ruleid  考核规则id',
  `rule_name` varchar(64) DEFAULT NULL COMMENT '   考核规则名称',
  `template_id` varchar(64) DEFAULT NULL COMMENT ' 索引idx_warn_notice_monitor_templateid  预警模板id',
  `template_name` varchar(64) DEFAULT NULL COMMENT '   预警模板名称',
  `index_code` varchar(32) NOT NULL COMMENT '   指标编码',
  `index_name` varchar(256) NOT NULL COMMENT '   指标名称',
  `moni_level` int(2) DEFAULT NULL COMMENT '   监控等级 1 省公司 2 市公司 3 分公司 4 网格  5 责任田 6 销售经理 7 渠道 8 社区 9 中小微企业',
  `obj_id` varchar(64) NOT NULL COMMENT '区域编码',
  `obj_name` varchar(64) NOT NULL COMMENT '   对象名称',
  `obj_index_value` decimal(16,4) NOT NULL COMMENT '   对象指标值',
  `obj_target_value` decimal(16,4) DEFAULT NULL COMMENT '   对象目标值',
  `notice_operid` varchar(2048) NOT NULL COMMENT '   通知人用户名',
  `notice_opername` varchar(2048) DEFAULT NULL COMMENT '   通知人别名',
  `notice_channel` int(2) NOT NULL COMMENT '   通知渠道 1 短信 2 邮箱 ',
  `notice_result` int(2) NOT NULL COMMENT '   通知结果 1 成功 0 失败',
  `warn_level` int(2) DEFAULT NULL COMMENT '预警等级',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '   创建者用户名',
  `create_opername` varchar(64) DEFAULT NULL COMMENT '   创建者别名',
  `create_time` datetime DEFAULT NULL COMMENT '   创建时间',
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '   备用字段1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '   预留字段2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '   预留字段3',
  `moni_project` int(2) NOT NULL COMMENT '监控对象',
  `notice_id` varchar(64) DEFAULT NULL,
  `moni_derection` int(2) DEFAULT NULL COMMENT '监控方向',
  `warn_threshold` decimal(16,4) DEFAULT NULL COMMENT '预警阈值',
  `head_desc` varchar(1024) DEFAULT NULL COMMENT '消息头描述',
  `tail_desc` varchar(1024) DEFAULT NULL COMMENT '消息尾描述',
  `index_cycle` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`moni_id`,`notice_channel`),
  KEY `idx_warn_notice_monitor_ruleid` (`rule_id`) USING BTREE,
  KEY `idx_warn_notice_monitor_taskid` (`task_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_warn_notice_obj_mgr
-- ----------------------------
DROP TABLE IF EXISTS `tci_warn_notice_obj_mgr`;
CREATE TABLE `tci_warn_notice_obj_mgr` (
  `rel_id` varchar(64) NOT NULL COMMENT ' 联合主键 pk_warn_notice_obj_mgr  关联id  关联tci_warn_notice_obj.(task_id+obj_id)',
  `mgr_operid` varchar(32) NOT NULL COMMENT ' 联合主键 pk_warn_notice_obj_mgr  责任人用户名',
  `mgr_name` varchar(64) NOT NULL COMMENT '   责任人别名',
  `order_no` int(3) DEFAULT NULL COMMENT '   责任人顺序',
  PRIMARY KEY (`rel_id`,`mgr_operid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_warn_notice_task
-- ----------------------------
DROP TABLE IF EXISTS `tci_warn_notice_task`;
CREATE TABLE `tci_warn_notice_task` (
  `task_id` varchar(64) NOT NULL COMMENT ' 主键  pk_warn_rule_detail  任务id',
  `task_name` varchar(64) NOT NULL COMMENT '   任务名称',
  `rule_id` varchar(64) NOT NULL COMMENT ' 索引  idx_warn_rule_detail_ruleid  预警规则id',
  `rule_name` varchar(64) NOT NULL COMMENT '   预警规则名称',
  `moni_level` int(2) DEFAULT NULL COMMENT '   监控等级 1 省公司 2 市公司 3 分公司 4 网格  5 责任田 6 销售经理 7 渠道 8 社区 9 中小微企业',
  `email_flag` int(2) DEFAULT NULL COMMENT '   邮件标记  1 是 0 否',
  `sms_flag` int(2) DEFAULT NULL COMMENT '   短信标记  1 是 0  否',
  `notice_time` varchar(20) NOT NULL COMMENT '   发送时间 格式 hh:mm:ss',
  `task_status` int(2) NOT NULL COMMENT '   job状态 1 停止  2 运行 3 失效',
  `create_operid` varchar(32) DEFAULT NULL COMMENT '   创建者用户名',
  `create_opername` varchar(64) DEFAULT NULL COMMENT '   创建者别名',
  `create_time` datetime DEFAULT NULL COMMENT '   创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '   更新者用户名',
  `update_opername` varchar(64) DEFAULT NULL COMMENT '   更新者别名',
  `update_time` datetime DEFAULT NULL COMMENT '   更新时间',
  `notice_channel` int(2) DEFAULT NULL COMMENT '1 短信 2 邮箱 3 短信,邮箱',
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '   预留字段1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '   预留字段2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '   预留字段3',
  `moni_levels` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`task_id`),
  KEY `idx_warn_rule_detail_ruleid` (`rule_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_warn_notice_task_obj
-- ----------------------------
DROP TABLE IF EXISTS `tci_warn_notice_task_obj`;
CREATE TABLE `tci_warn_notice_task_obj` (
  `task_id` varchar(64) NOT NULL COMMENT ' 联合主键  pk_warn_notice_obj_taskid  任务id  关联tci_warn_notice_task.task_id',
  `obj_id` varchar(64) NOT NULL COMMENT '区域编码',
  `obj_name` varchar(64) NOT NULL COMMENT '   对象名称',
  `obj_type` int(2) NOT NULL COMMENT '   对象类型 1 省公司 2 市公司 3 分公司 4 网格  5 责任田 6 销售经理 7 渠道 8 社区 9 中小微企业',
  `obj_path` varchar(256) NOT NULL COMMENT '   考核对象路径',
  PRIMARY KEY (`task_id`,`obj_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_warn_notice_task_ogr
-- ----------------------------
DROP TABLE IF EXISTS `tci_warn_notice_task_ogr`;
CREATE TABLE `tci_warn_notice_task_ogr` (
  `task_id` varchar(64) NOT NULL COMMENT ' 联合主键  pk_warn_notice_task_ogr  taskid',
  `create_org_code` varchar(64) NOT NULL COMMENT '区域编码',
  `create_org_name` varchar(64) DEFAULT NULL COMMENT '   创建者组织名称',
  `create_org_level` int(2) DEFAULT NULL COMMENT '   组织等级 1 省公司 2 市公司 3 分公司 4 网格  5 责任田 6 销售经理 7 渠道 8 社区 9 中小微企业',
  `create_org_path` varchar(256) DEFAULT NULL COMMENT '   创建者组织路径',
  PRIMARY KEY (`task_id`,`create_org_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_warn_notice_task_role
-- ----------------------------
DROP TABLE IF EXISTS `tci_warn_notice_task_role`;
CREATE TABLE `tci_warn_notice_task_role` (
  `task_id` varchar(64) NOT NULL COMMENT '预警任务ID',
  `role_id` varchar(100) NOT NULL COMMENT '预警角色ID',
  `role_name` varchar(500) DEFAULT NULL COMMENT '预警角色名称',
  PRIMARY KEY (`task_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_warn_rule
-- ----------------------------
DROP TABLE IF EXISTS `tci_warn_rule`;
CREATE TABLE `tci_warn_rule` (
  `rule_id` int(11) NOT NULL AUTO_INCREMENT,
  `rule_name` varchar(64) NOT NULL COMMENT '   预警规则名称',
  `index_code` varchar(64) DEFAULT NULL,
  `index_name` varchar(256) NOT NULL COMMENT '   指标名称',
  `index_cycle` int(11) DEFAULT NULL,
  `task_id` varchar(64) DEFAULT NULL,
  `task_name` varchar(64) DEFAULT NULL,
  `moni_level` int(2) DEFAULT NULL COMMENT '   监控等级 1 省公司 2 市公司 3 分公司 4 网格  5 责任田 6 销售经理 7 渠道 8 社区 9 中小微企业',
  `moni_project` int(2) NOT NULL COMMENT '   监控项目 1 完成值',
  `moni_derection` int(2) NOT NULL COMMENT '   监控方向 1 大于 2小于',
  `apply_time` datetime NOT NULL COMMENT '   生效时间',
  `expire_time` datetime NOT NULL COMMENT '   失效时间',
  `header_desc` varchar(1024) DEFAULT NULL,
  `tail_desc` varchar(1024) DEFAULT NULL,
  `create_operid` varchar(32) DEFAULT NULL COMMENT '   创建者用户名',
  `create_opername` varchar(64) DEFAULT NULL COMMENT '   创建者别名',
  `create_time` datetime DEFAULT NULL COMMENT '   创建时间',
  `update_operid` varchar(32) DEFAULT NULL COMMENT '   更新者用户名',
  `update_opername` varchar(64) DEFAULT NULL COMMENT '   更新者别名',
  `update_time` datetime DEFAULT NULL COMMENT '   更新时间',
  `reserve1` varchar(1024) DEFAULT NULL COMMENT '   预留字段1',
  `reserve2` varchar(1024) DEFAULT NULL COMMENT '   预留字段2',
  `reserve3` varchar(1024) DEFAULT NULL COMMENT '   预留字段3',
  `moni_levels` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`rule_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1000000269 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_warn_rule_detail
-- ----------------------------
DROP TABLE IF EXISTS `tci_warn_rule_detail`;
CREATE TABLE `tci_warn_rule_detail` (
  `detail_id` varchar(64) NOT NULL COMMENT ' 主键  pk_warn_rule_detail  明细id',
  `rule_id` varchar(64) NOT NULL COMMENT ' 索引  idx_warn_rule_detail_ruleid  预警规则id',
  `begin_day` int(2) NOT NULL COMMENT '   开始天数',
  `end_day` int(2) NOT NULL COMMENT '   结束天数',
  `critical_threshold` decimal(16,4) DEFAULT NULL,
  `general_threshold` decimal(16,4) DEFAULT NULL,
  `prompt_threshold` decimal(16,4) DEFAULT NULL,
  `warn_level` int(2) NOT NULL COMMENT '   预警级别  1 提示 2 一般 3 严重',
  `warn_rate` int(2) NOT NULL COMMENT '   预警频率',
  PRIMARY KEY (`detail_id`),
  KEY `index_name` (`rule_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tci_warn_rule_ogr
-- ----------------------------
DROP TABLE IF EXISTS `tci_warn_rule_ogr`;
CREATE TABLE `tci_warn_rule_ogr` (
  `rule_id` varchar(64) NOT NULL COMMENT ' 联合主键  pk_warn_rule_ogr  规则id',
  `create_org_code` varchar(32) NOT NULL COMMENT ' 联合主键  pk_warn_rule_ogr  创建者组织编码',
  `create_org_name` varchar(64) DEFAULT NULL COMMENT '   创建者组织名称',
  `create_org_level` int(2) DEFAULT NULL COMMENT '   组织等级 1 省公司 2 市公司 3 分公司 4 网格  5 责任田 6 销售经理 7 渠道 8 社区 9 中小微企业',
  `create_org_path` varchar(256) DEFAULT NULL COMMENT '   创建者组织路径',
  PRIMARY KEY (`rule_id`,`create_org_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for 无标题
-- ----------------------------
DROP TABLE IF EXISTS `无标题`;
CREATE TABLE `无标题` (
  `index_code` varchar(255) DEFAULT NULL,
  `index_name_en` varchar(255) DEFAULT NULL,
  `index_name_cn` varchar(255) DEFAULT NULL,
  `index_catalog` varchar(255) DEFAULT NULL,
  `index_version` varchar(255) DEFAULT NULL,
  `statistics_obj` varchar(255) DEFAULT NULL,
  `statistics_type` varchar(255) DEFAULT NULL,
  `value_type` varchar(255) DEFAULT NULL,
  `index_unit` varchar(255) DEFAULT NULL,
  `save_time` varchar(255) DEFAULT NULL,
  `index_cycle` varchar(255) DEFAULT NULL,
  `interface_person` varchar(255) DEFAULT NULL,
  `interface_tel` varchar(255) DEFAULT NULL,
  `business_caliber` varchar(255) DEFAULT NULL,
  `technology_calber` varchar(255) DEFAULT NULL,
  `data_sources` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `index_status` varchar(255) DEFAULT NULL,
  `index_type` varchar(255) DEFAULT NULL,
  `create_operid` varchar(255) DEFAULT NULL,
  `create_opername` varchar(255) DEFAULT NULL,
  `create_time` varchar(255) DEFAULT NULL,
  `update_operid` varchar(255) DEFAULT NULL,
  `update_opername` varchar(255) DEFAULT NULL,
  `update_time` varchar(255) DEFAULT NULL,
  `is_parent_index` varchar(255) DEFAULT NULL,
  `parent_index_code` varchar(255) DEFAULT NULL,
  `statistics_time` varchar(255) DEFAULT NULL,
  `reserve1` varchar(255) DEFAULT NULL,
  `reserve2` varchar(255) DEFAULT NULL,
  `reserve3` varchar(255) DEFAULT NULL,
  `is_accumulatie` varchar(255) DEFAULT NULL,
  `index_alias_name` varchar(255) DEFAULT NULL,
  `index_level` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Procedure structure for index_define_to_xindex
-- ----------------------------
DROP PROCEDURE IF EXISTS `index_define_to_xindex`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `index_define_to_xindex`()
BEGIN
-- 创建xindex 指标定义涉及的临时表
drop table if exists tci_index_area_bak;
drop table if exists tci_index_manage_bak;
drop table if exists tci_index_type_bak;
create table tci_index_area_bak like tci_index_area;
create table tci_index_manage_bak like tci_index_manage;
create table tci_index_type_bak like tci_index_type;

-- 创建临时表gbase_t_temp_dim_grid_index_def
drop table if exists gbase_t_temp_dim_grid_index_def;
CREATE TABLE `gbase_t_temp_dim_grid_index_def` (
  `index_code` varchar(128) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '指标编码',
  `index_name` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指标名称',
  `city` varchar(32) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '分类：ent:集团;wire:家庭;acct:收入;user:用户发展;terminal 终端',
  `index_unit` varchar(32) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指标单位',
  `TARGET_TABLE` varchar(1024) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指标值来源表',
  `APPTYPE` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '应用分类',
  `index_cycle` varchar(10) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指标周期',
  `city_id` bigint(21) DEFAULT NULL COMMENT '城市id',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


-- 现网数据插入临时表 gbase_t_temp_dim_grid_index_def
truncate gbase_t_temp_dim_grid_index_def;
insert into gbase_t_temp_dim_grid_index_def
(
index_code,index_name,city,index_unit,APPTYPE,index_cycle,city_id,create_time
)
select 
index_code,index_name,'',index_unit,'','日','999',create_time
from `xindex_management_e264fd96-3578-4400-97d5-fb5a39e232c3`.tci_index_define;

--  清空临时表 tci_index_type_bak
TRUNCATE .tci_index_type_bak;
-- 插入临时表 tci_index_type_bak
INSERT into .tci_index_type_bak(
type_name,create_areacode,type_catalog,parent_id,type_level,
create_areaname,create_areapath,create_operid,
create_opername,create_time,update_operid,update_opername,update_time
)  
select
distinct city as 'type_name',
if(city_id=999, 'JL', city_id) as 'create_areacode',
if(city_id=999, 1, 2)  as 'type_catalog',
'-1' as 'parent_id','1' as 'type_level',
case city_id 
when '01' then '长春' 
when '02' then '吉林'
when '03' then '延边' 
when '04' then '四平'
when '05' then '通化' 
when '06' then '白城'
when '07' then '辽源' 
when '08' then '松原'
when '09' then '白山' 
else '吉林' end as 'create_areaname',
if(city_id=999, 'JL', concat('JL,',city_id)) as 'create_areapath',
'system' as 'create_operid',
'system' as 'create_opername',
now() as 'create_time',
'system' as 'update_operid',
'system' as 'update_opername',
now() as 'update_time'
from gbase_t_temp_dim_grid_index_def ;

-- 更新 type_id ;
update tci_index_type_bak  t, tci_index_type w
set t.type_id = t.type_id+(select max(type_id) from .tci_index_type);

update .tci_index_type_bak  t, .tci_index_type w
set t.type_id = w.type_id
where t.type_name = w.type_name and t.create_areacode = w.create_areacode;

-- 设置type_path=type_id
update .tci_index_type_bak set type_path = type_id;

-- 导入tci_index_manage_bak
--  清空临时表 tci_index_manage_bak
TRUNCATE tci_index_manage_bak;

-- 插入临时表 tci_index_manage_bak
insert into  .tci_index_manage_bak(
index_code,index_name_cn,index_name_en,index_catalog,index_version,statistics_obj,
statistics_type,value_type,index_unit,index_cycle,business_caliber,index_status,
index_type,create_operid,create_opername,create_time,update_operid,update_opername,
update_time,is_parent_index,is_accumulatie
)
select 
DISTINCT def.index_code as 'index_code',def.index_name as 'index_name_cn','' as 'index_name_en',
tp.type_id as 'index_catalog','V1' as 'index_version',
if(def.apptype='channel', '2', '1') as 'statistics_obj',  -- 2:渠道  1:客户
'1' as 'statistics_type',if(def.index_unit='%', 2, 8) as 'value_type',
ifnull((select data_value from tci_sys_datadict where dict_code = 'DICT_INDEX_UNIT'
and lang='zh_CN' and data_name=def.index_unit), '-1') as 'index_unit',
ifnull((select data_value from tci_sys_datadict where dict_code = 'DICT_INDEX_CYCLE' 
and lang='zh_CN' and data_name=def.index_cycle), '-1') as 'index_cycle',
'暂无' as 'business_caliber',
'1' as 'index_status',
if(def.index_unit='%','1', '2') as 'index_type',
'system' as 'create_operid',
'system' as 'create_opername',
NOW() as 'create_time',
'system' as 'update_operid',
'system' as 'update_opername',
NOW() as 'update_time',
'1' as 'is_parent_index',
'0' as 'is_accumulatie'
from (select index_code, city_id, city, index_name, apptype, index_unit, index_cycle from gbase_t_temp_dim_grid_index_def group by index_code ) def
left join tci_index_type_bak tp on def.city=tp.type_name and if(def.city_id=999, 'JL', def.city_id) = tp.create_areacode;

-- 导入tci_index_area_bak
--  清空临时表 tci_index_manage_bak
TRUNCATE .tci_index_area_bak;

-- 插入临时表 tci_index_manage_bak
insert into .tci_index_area_bak
(
index_code,area_level,area_code,area_name,area_path
) 
select
DISTINCT index_code as 'index_code',if(city_id=999, 1, 2)  as 'area_level',
if(city_id=999, 'JL', city_id) as 'areacode',
case city_id 
when '01' then '长春' 
when '02' then '吉林'
when '03' then '延边' 
when '04' then '四平'
when '05' then '通化' 
when '06' then '白城'
when '07' then '辽源' 
when '08' then '松原'
when '09' then '白山' 
else '吉林' end as 'create_areaname',
if(city_id=999, 'JL', concat('JL,',city_id)) as 'create_areapath'
from gbase_t_temp_dim_grid_index_def ;

-- 插入tci_index_type
-- 插入业务表
insert into .tci_index_type
(
type_name,type_catalog,type_path,parent_id,type_level,order_no,create_areacode,create_areaname,
create_areapath,create_operid,create_opername,create_time,update_operid,update_opername,
update_time,reserve1,reserve2,reserve3
)
select 
type_name,type_catalog,type_path,parent_id,type_level,order_no,create_areacode,create_areaname,
create_areapath,create_operid,create_opername,create_time,update_operid,update_opername,
update_time,reserve1,reserve2,reserve3
from tci_index_type_bak bak where not EXISTS 
(select * from tci_index_type tp where bak.type_name = tp.type_name 
and bak.create_areacode = tp.create_areacode);

-- 插入tci_index_manage
insert into .tci_index_manage
(
index_code,index_name_en,index_name_cn,index_catalog,index_version,statistics_obj,
statistics_type,value_type,index_unit,index_cycle,save_time,statistics_time,
interface_person,interface_tel,business_caliber,technology_calber,data_sources,
remarks,index_status,index_type,create_operid,create_opername,create_time,
update_operid,update_opername,update_time,is_parent_index,is_accumulatie,
parent_index_code,reserve1,reserve2,reserve3,index_alias_name
)
select 
index_code,index_name_en,index_name_cn,index_catalog,index_version,statistics_obj,
statistics_type,value_type,index_unit,index_cycle,save_time,statistics_time,
interface_person,interface_tel,business_caliber,technology_calber,data_sources,
remarks,index_status,index_type,create_operid,create_opername,create_time,update_operid,
update_opername,update_time,is_parent_index,is_accumulatie,parent_index_code,
reserve1,reserve2,reserve3,index_alias_name
from .tci_index_manage_bak 
on duplicate key update
index_name_cn = values(index_name_cn),
index_catalog = values(index_catalog),
statistics_obj = values(statistics_obj),
statistics_type = values(statistics_type),
value_type = values(value_type),
index_unit = values(index_unit),
index_cycle = values(index_cycle),
index_status = values(index_status),
index_type = values(index_type);

-- 导入tci_index_area
insert into .tci_index_area(
index_code,area_code,area_name,area_level,area_path
)
select 
index_code,area_code,area_name,area_level,area_path
from .tci_index_area_bak 
on duplicate key update
area_name = values(area_name),
area_level = values(area_level),
area_path = values(area_path);

END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for initIndexValueData
-- ----------------------------
DROP PROCEDURE IF EXISTS `initIndexValueData`;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `initIndexValueData`()
BEGIN
DECLARE i INT;
DECLARE done INT DEFAULT 0;
DECLARE area_code varchar(255);
DECLARE area_level INT;
DECLARE area_name varchar(255);
DECLARE area_path varchar(255);

DECLARE t_area CURSOR FOR select t.area_code,t.area_level,t.area_name,ifnull(t.area_path ,'xxx') from tci_sys_area t  order by area_level , order_no;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

prepare ins from 'INSERT INTO `tci_index_value` VALUES (UUID(), ''GD02'', ''省-广东01'', 4, ?, ?, ?, ?, ?, 5.001 , ''yangwei'', ''yangwei'', ''2019-4-15 17:10:22'', ''yangwei'', ''yangwei'', ''2019-4-15 17:10:22'', null, NULL, NULL, 8)';


OPEN t_area;
REPEAT
  FETCH t_area INTO area_code,area_level,area_name,area_path;
  
  IF done != 1 THEN

     set i := 1;
    set @dt = str_to_date('19980101', '%Y%m%d');
    set @area_path = area_path;
    set @area_level = area_level;
    set @area_code = area_code;
    set @area_name = area_name;
     while i < 200 do
     set @dt = date_format(date_add(@dt, interval 1 day),'%Y%m%d');
     execute ins using @dt,@area_level,@area_code,@area_name,@area_path;
       set i := i +1;
     end while;
    commit;
  END IF;
UNTIL DONE END REPEAT;

end
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for initTakScoreData
-- ----------------------------
DROP PROCEDURE IF EXISTS `initTakScoreData`;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `initTakScoreData`()
BEGIN
DECLARE i INT;
DECLARE done INT DEFAULT 0;
DECLARE area_code varchar(255);
DECLARE area_level INT;
DECLARE area_name varchar(255);
DECLARE area_path varchar(255);

DECLARE t_area CURSOR FOR select t.area_code,t.area_level,t.area_name,t.area_path from tci_sys_area t  order by area_level , order_no;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

prepare ins from 'INSERT INTO `tci_task_score` VALUES (UUID(), ''GD_33'', NULL, ''GD01'', ''省-广东01'', 4, ?, ?, ?,?,?, null, null, 0, 66, 68,  ''yangwei'', ''yangwei'', ''2019-4-15 17:10:22'', ''yangwei'', ''yangwei'', ''2019-4-15 17:10:22'', NULL)';
select t.area_code,t.area_level,t.area_name,t.area_path from tci_sys_area t  where area_path is not null order by area_level , order_no;

OPEN t_area;
REPEAT
  FETCH t_area INTO area_code,area_level,area_name,area_path;
  
  IF done != 1 THEN

     set i := 1;
    set @dt = str_to_date('19460101', '%Y%m%d');
    set @area_path = area_path;
    set @area_level = area_level;
    set @area_code = area_code;
    set @area_name = area_name;
     while i < 2000 do
     set @dt = date_format(date_add(@dt, interval 1 day),'%Y%m%d');
     execute ins using @dt,@area_level,@area_code,@area_name,@area_path;
       set i := i +1;
     end while;
    commit;
  END IF;
UNTIL DONE END REPEAT;

end
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for initTargetValueData
-- ----------------------------
DROP PROCEDURE IF EXISTS `initTargetValueData`;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `initTargetValueData`()
BEGIN
DECLARE i INT;
DECLARE done INT DEFAULT 0;
DECLARE area_code varchar(255);
DECLARE area_level INT;
DECLARE area_name varchar(255);
DECLARE area_path varchar(255);

DECLARE t_area CURSOR FOR select t.area_code,t.area_level,t.area_name,t.area_path from tci_sys_area t where t.area_level = 2 and t.area_path like 'GD,%' order by area_level , order_no;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

prepare ins from 'INSERT INTO `tci_check_content` VALUES (UUID(),0, ''GD_35'', NULL, ''测试主任务'', ''GD01'', ''省-广东01'', 4, ?, ?,null,null,?, -1, ?, ?, 1.0000, 1.0000, null,''yangwei'', ''yangwei'', 1, 1, NULL, ''yangwei'', ''yangwei'', ''2019-4-15 17:10:22'', ''yangwei'', ''yangwei'', ''2019-4-15 17:10:22'', ''5f507f2df8d49eb895201e4a55708f5-1'', NULL, NULL, 1)';


OPEN t_area;
REPEAT
  FETCH t_area INTO area_code,area_level,area_name,area_path;
  
  IF done != 1 THEN

     set i := 1;
    set @dt = str_to_date('20010101', '%Y%m%d');
    set @area_path = area_path;
    set @area_level = area_level;
    set @area_code = area_code;
    set @area_name = area_name;
     while i < 20000 do
     set @dt = date_format(date_add(@dt, interval 1 day),'%Y%m%d');
     execute ins using @dt,@area_path,@area_level,@area_code,@area_name;
       set i := i +1;
     end while;
    commit;
  END IF;
UNTIL DONE END REPEAT;

end
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for pro_calc_taskscore
-- ----------------------------
DROP PROCEDURE IF EXISTS `pro_calc_taskscore`;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `pro_calc_taskscore`(IN taskMonth VARCHAR(64),IN indexDate VARCHAR(64),OUT retCode INT(2))
    COMMENT '考核得分计算'
BEGIN
 DECLARE taskId VARCHAR(64);
 DECLARE done1 INT;
 DECLARE done2 INT;
 DECLARE result_code INTEGER DEFAULT 0;
 
 DECLARE task_cur CURSOR FOR SELECT task_id FROM tci_check_task WHERE begin_month <= taskMonth AND end_month >= taskMonth AND task_type = 1 AND task_status = 1;
 DECLARE CONTINUE HANDLER FOR NOT FOUND SET done1 = 1;
 DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET result_code=-1;
 DELETE FROM tci_procedure_log; 
 OPEN task_cur;
 taskLoop:LOOP
  FETCH task_cur INTO taskId;
  IF done1=1 THEN
   LEAVE taskLoop;
  END IF;
  
  INSERT INTO tci_procedure_log VALUES('pro_calc_taskscore',NOW(),'calc taskId',taskId);
  
  BEGIN
   DECLARE childTaskid VARCHAR(64);
   DECLARE indexCode VARCHAR(64);
   DECLARE indexName VARCHAR(64);
   DECLARE objId VARCHAR(64);
   DECLARE objName VARCHAR(64);
   DECLARE objType INT(2);
   DECLARE indexCycle INT(2);
   DECLARE objPath VARCHAR(64);
   DECLARE targetValue DECIMAL(16,4);
   DECLARE baseValue DECIMAL(16,4);
   DECLARE indexTime VARCHAR(64);
   DECLARE indexValue DECIMAL(16,4);
   DECLARE score DECIMAL(16,4);
   DECLARE indexType INT(2);
   DECLARE calcType INT(2); 
   DECLARE tmpTaskId VARCHAR(64);  
   DECLARE content_cur CURSOR FOR 
   SELECT i.calc_type,m.index_type,c.* FROM (
    SELECT CASE WHEN child_taskid IS NULL THEN task_id ELSE child_taskid END curTaskId,child_taskid,
      index_code,index_name,obj_id,obj_name,obj_type,obj_path,obj_target_value,base_value 
    FROM tci_check_content 
    WHERE check_time = taskMonth AND index_cycle=3 AND task_id = taskId AND base_value IS NOT NULL 
   ) c,tci_check_task_index i,tci_index_manage m 
   WHERE i.task_id=c.curTaskId AND c.index_code=i.index_code AND c.index_code=m.index_code;
   
   DECLARE CONTINUE HANDLER FOR NOT FOUND SET done2 = 1;
   OPEN content_cur;
   contentLoop:LOOP
    FETCH content_cur INTO calcType,indexType,tmpTaskId,childTaskid,indexCode,indexName,objId,objName,objType,objPath,targetValue,baseValue;
    IF done2=1 THEN
     LEAVE contentLoop;
    END IF;
    
    INSERT INTO tci_procedure_log VALUES('pro_calc_taskscore',NOW(),'calc content info',
    CONCAT(calcType,'|',indexType,'|',tmpTaskId,'|',childTaskid,'|',indexCode,'|',indexName,'|',objId,'|',objName,'|',objType,'|',objPath,'|',targetValue,'|',baseValue));
 
    
    IF calcType IS NOT NULL THEN
         
     SET indexValue = (SELECT index_value FROM tci_index_value 
     WHERE index_cycle=5 AND index_code=indexCode AND obj_id=objId AND index_time=indexDate LIMIT 1);
     IF indexValue IS NULL THEN
      SET indexValue = (SELECT index_value FROM tci_index_value 
      WHERE index_cycle=4 AND index_code=indexCode AND obj_id=objId AND index_time=indexDate LIMIT 1);
     END IF;
     
       
     IF indexValue IS NOT NULL THEN
      IF calcType=1 OR calcType=2 THEN
       IF indexValue < baseValue THEN
        SET score = 0;
       ELSEIF indexValue > targetValue THEN
        SET score = 100;
       ELSE        
        SET score = 100*(indexValue-baseValue)/(targetValue-baseValue);
       END IF;
      END IF;
      IF calcType=3 THEN
       IF indexValue > baseValue THEN
        SET score = 0;
       ELSEIF indexValue < targetValue THEN
        SET score = 100;
       ELSE
        SET score = 100*(indexValue-baseValue)/(targetValue-baseValue);
       END IF;
      END IF;
      
      
      INSERT INTO tci_task_score(DATA_ID,CHECK_TASK_ID,CHILD_CHECK_TASK_ID,INDEX_TYPE,INDEX_CODE,INDEX_NAME,INDEX_CYCLE,INDEX_TIME,
       OBJ_TYPE,OBJ_ID,OBJ_NAME,OBJ_PATH,IS_ADDITION,SUGGEST_SCORE,
       CREATE_OPERID,CREATE_OPERNAME,CREATE_TIME,UPDATE_OPERID,UPDATE_OPERNAME,UPDATE_TIME)
      SELECT UUID(),taskId,childTaskid,indexType,indexCode,indexName,3,taskMonth,
             objType,objId,objName,objPath,0,score,'JOB','JOB',NOW(),'JOB','JOB',NOW()       
      ON DUPLICATE KEY UPDATE SUGGEST_SCORE = score,UPDATE_TIME=NOW();
     END IF;    
    END IF; 
   END LOOP contentLoop;
   CLOSE content_cur;
   SET done2 = 0;
  END;
   
 END LOOP taskLoop;
 CLOSE task_cur;   
 
 SET retCode=result_code;
END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for pro_task_delivery
-- ----------------------------
DROP PROCEDURE IF EXISTS `pro_task_delivery`;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `pro_task_delivery`(IN taskId VARCHAR(64),OUT retMsg VARCHAR(4000),OUT retCode INT(2))
    DETERMINISTIC
    COMMENT '任务发布逻辑'
BEGIN
    DECLARE baseParentId VARCHAR(64);
    DECLARE taskName VARCHAR(128);
    DECLARE beginMonth VARCHAR(64);
    DECLARE createOrgCode VARCHAR(64);
    DECLARE taskType INT(2);
    DECLARE createOrgLevel INT(2);
    DECLARE batchId VARCHAR(64);
    DECLARE addRows INT(8);
    DECLARE updateRows INT(8);
    DECLARE deleteRows INT(8);
    DECLARE contentNum INT(8);
    DECLARE deliveryRows INTEGER DEFAULT 0;
    DECLARE result_code INTEGER DEFAULT 0;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET result_code=-1;

    SELECT base_parent_id,task_name,task_type,begin_month,create_org_code,create_org_level
     INTO baseParentId,taskName,taskType,beginMonth,createOrgCode,createOrgLevel 
    FROM tci_check_task WHERE task_id = taskId; 
    
    IF baseParentId IS NULL THEN
        SET baseParentId = taskId;
    END IF;
    

    SELECT UUID() INTO batchId;    
    
    SELECT COUNT(1) INTO contentNum FROM tci_check_content WHERE task_id=baseParentId 
        AND CASE WHEN taskType=1 THEN child_taskid IS NULL ELSE child_taskid=taskId END 
        AND obj_type>createOrgLevel AND obj_type <=5 AND check_time=beginMonth;
        
    IF contentNum > 0 THEN        
        SET retMsg = NOW();    

        INSERT INTO tci_check_task_operate(operate_id,base_parent_id,task_id,obj_id,obj_name,obj_type,obj_path,operate_type)
        SELECT     batchId, baseParentId, IFNULL(b.task_id,CONCAT(a.obj_id,nextval(a.obj_id))) AS task_id,
            a.obj_id,a.obj_name,a.obj_type,a.obj_path,CASE WHEN b.task_id IS NULL THEN 'add' ELSE 'update' END AS operate
        FROM
        (
            SELECT DISTINCT obj_id,obj_name,obj_type,obj_path FROM tci_check_content WHERE task_id=baseParentId 
            AND CASE WHEN taskType=1 THEN child_taskid IS NULL ELSE child_taskid=taskId END 
            AND obj_type>createOrgLevel AND obj_type <=5 AND check_time=beginMonth
        ) a
        LEFT JOIN (SELECT task_id,create_org_code FROM tci_check_task WHERE parent_id=taskId) b ON a.obj_id=b.create_org_code;
                
        INSERT INTO tci_check_task_operate(operate_id,base_parent_id,task_id,obj_id,operate_type)
        SELECT batchId,b.base_parent_id,b.task_id,b.create_org_code AS obj_id,'delete' FROM
        (
            SELECT DISTINCT obj_id FROM tci_check_content WHERE task_id=baseParentId 
            AND CASE WHEN taskType=1 THEN child_taskid IS NULL ELSE child_taskid=taskId END  
            AND obj_type > createOrgLevel AND obj_type <=5 AND check_time=beginMonth
        ) a
        RIGHT JOIN (SELECT task_id,base_parent_id,create_org_code FROM tci_check_task WHERE parent_id=taskId) b 
        ON a.obj_id=b.create_org_code WHERE a.obj_id IS NULL;
        
        SELECT  SUM(CASE WHEN operate_type='add' THEN 1 ELSE 0 END),
            SUM(CASE WHEN operate_type='update' THEN 1 ELSE 0 END),
            SUM(CASE WHEN operate_type='delete' THEN 1 ELSE 0 END) 
        INTO addRows,updateRows,deleteRows FROM tci_check_task_operate WHERE operate_id=batchId;
        
        SET retMsg = CONCAT(retMsg,",operate_id:",batchId,",add:",addRows,',update:',updateRows,',delete:',deleteRows,'>>',NOW());    
        

        START TRANSACTION;
        IF addRows > 0 THEN

            INSERT INTO tci_check_task (task_id,task_name,frame_type,begin_month,end_month,task_describe,task_type,parent_id,task_status,
              create_org_code,create_org_name,create_org_level,create_org_path,
              create_operid,create_opername,create_time,update_operid,update_opername,update_time,AUDIT_TIME,base_parent_id) 
            SELECT p.task_id,CONCAT(task_name,'_',p.obj_name),frame_type,begin_month,end_month,task_describe,'2',t.task_id,0,p.obj_id,p.obj_name,
              p.obj_type,p.obj_path,create_operid,create_opername,create_time,update_operid,update_opername,update_time,AUDIT_TIME,baseParentId 
            FROM tci_check_task_operate p,tci_check_task t WHERE operate_type='add' AND operate_id=batchId    AND t.task_id=taskId;
            
            SET retMsg = CONCAT(retMsg,';',"新增任务入库tci_check_task条数:",ROW_COUNT(),'>>',NOW());    
            

            INSERT INTO tci_check_task_area(task_id,area_code,area_name,area_level,area_path)
            SELECT task_id,obj_id,obj_name,obj_type,obj_path FROM tci_check_task_operate 
            WHERE operate_type='add' AND operate_id=batchId;
            
            SET retMsg = CONCAT(retMsg,';',"新增任务入库tci_check_task_area条数:",ROW_COUNT(),'>>',NOW());    
        END IF;    
        
        IF addRows > 0 THEN

            INSERT INTO tci_check_task_index (task_id,index_code,index_name,first_level_type,second_level_type,index_weight,default_dimension,
                create_operid,create_opername,create_time,update_operid,update_opername,update_time,order_no,WARN_COLOR,weight_type) 
            SELECT m.task_id,m.index_code,index_name,first_level_type,second_level_type,index_weight,default_dimension,create_operid,create_opername,
            create_time,update_operid,update_opername,update_time,order_no,WARN_COLOR,weight_type FROM tci_check_task_index t,
            (
                SELECT task_id,index_code FROM (
                    SELECT DISTINCT obj_id,index_code FROM tci_check_content WHERE task_id=baseParentId 
                    AND CASE WHEN taskType=1 THEN child_taskid IS NULL ELSE child_taskid=taskId END  
                    AND obj_type > createOrgLevel AND obj_type<=5 AND check_time=beginMonth
                ) t2,tci_check_task_operate t3 
                WHERE t2.obj_id=t3.obj_id 
                AND NOT EXISTS (
                    SELECT 1 FROM tci_check_task_index t1 WHERE t1.task_id=t3.task_id AND t1.index_code=t2.index_code
                )
                AND t3.operate_id=batchId AND t3.operate_type='add'
            ) m WHERE t.index_code=m.index_code AND t.task_id=taskId;
            
            SET retMsg = CONCAT(retMsg,';',"插入tci_check_task_index条数:",ROW_COUNT(),'>>',NOW());    
        END IF;    
        
        IF updateRows > 0 THEN

            DELETE t FROM tci_check_task_index t INNER JOIN tci_check_task_operate t3 
            ON t.task_id=t3.task_id AND t3.operate_id=batchId AND t3.operate_type='update';
            SET retMsg = CONCAT(retMsg,';',"删除tci_check_task_index条数:",ROW_COUNT(),'>>',NOW());    
            

            INSERT INTO tci_check_task_index (task_id,index_code,index_name,first_level_type,second_level_type,index_weight,default_dimension,
                create_operid,create_opername,create_time,update_operid,update_opername,update_time,order_no,WARN_COLOR,weight_type)
            SELECT m.task_id,m.index_code,index_name,first_level_type,second_level_type,index_weight,default_dimension,create_operid,create_opername,
            create_time,update_operid,update_opername,update_time,order_no,WARN_COLOR,weight_type FROM tci_check_task_index t,
            (
                SELECT task_id,index_code FROM (
                    SELECT DISTINCT obj_id,index_code FROM tci_check_content WHERE task_id=baseParentId 
                    AND CASE WHEN taskType=1 THEN child_taskid IS NULL ELSE child_taskid=taskId END  
                    AND obj_type > createOrgLevel AND obj_type <=5 AND check_time=beginMonth
                ) t2,tci_check_task_operate t3 
                WHERE t2.obj_id=t3.obj_id AND t3.operate_id=batchId AND t3.operate_type='update'
            ) m WHERE t.index_code=m.index_code AND t.task_id=taskId;    
            
            SET retMsg = CONCAT(retMsg,';',"重新插入tci_check_task_index条数:",ROW_COUNT(),'>>',NOW());                
        END IF;
        
        IF deleteRows > 0 THEN

            UPDATE tci_check_task t INNER JOIN tci_check_task_operate p ON p.task_id=t.task_id
            SET t.task_status = -3
            WHERE p.operate_id=batchId AND operate_type='delete';
            
            SET retMsg = CONCAT(retMsg,';',"删除部分的任务置为已失效条数:",ROW_COUNT(),'>>',NOW());    
        END IF;
        

        DELETE FROM tci_check_content_preview WHERE task_id=taskId;
        
        INSERT INTO tci_check_content_preview(preview_id,task_id,obj_id,index_code,index_name,statistics_type,target_value,weight,preview_type,index_level,base_parent_id)
            SELECT UUID(),n.taskId,n.obj_id,n.index_code,n.index_name_cn,n.statistics_type,n.obj_target_value,n.weight,n.ctype,n.index_level,n.baseParentId FROM (
            SELECT taskId,t1.obj_id,t2.index_code,t2.index_name_cn,t2.statistics_type,t1.obj_target_value,t1.weight,1 AS ctype,t2.index_level,baseParentId
            FROM tci_check_content t1,tci_index_manage t2
            WHERE t1.index_code = t2.index_code AND t1.check_time=beginMonth AND t1.task_id=baseParentId 
            AND CASE WHEN taskType=1 THEN child_taskid IS NULL ELSE child_taskid=taskId END
            UNION ALL
            SELECT taskId,v.obj_id,v.addition_code,v.addition_name,v.addition_type,v.addition_content,v.weight,2,'',baseParentId
            FROM tci_task_addition_value v WHERE v.task_id=taskId
        ) n ON DUPLICATE KEY UPDATE task_id = n.taskId,target_value=n.obj_target_value;
        SET retMsg = CONCAT(retMsg,';',"下发预览信息重置条数:",ROW_COUNT(),'>>',NOW());            
    

        IF result_code = 0 THEN 
            UPDATE tci_check_task SET task_status = 1 WHERE task_id = taskId;
            SET deliveryRows = ROW_COUNT();
            SET retMsg = CONCAT(retMsg,';',"修改任务状态为已发布条数:",deliveryRows,'>>',NOW());    
            IF deliveryRows = 0 THEN
                SET result_code = -1;
            END IF;            
        END IF;
    ELSE
        UPDATE tci_check_task SET task_status = 1 WHERE task_id = taskId;
        SET retCode = 0;
        SET retMsg = '没有下发的目标值';        
    END IF;
    
    IF result_code = -1 THEN 
        ROLLBACK; 
    ELSE     
        COMMIT; 
    END IF;
    DELETE FROM tci_check_task_operate WHERE operate_id = batchId;
    SET retCode=result_code;
END
;;
DELIMITER ;

-- ----------------------------
-- Function structure for f_ordebyareainfo
-- ----------------------------
DROP FUNCTION IF EXISTS `f_ordebyareainfo`;
DELIMITER ;;
CREATE DEFINER=`root`@`%` FUNCTION `f_ordebyareainfo`(`area_level` int,`area_code` varchar(32),`default_order` int) RETURNS int(11)
BEGIN
    DECLARE rs int;
    set rs = 0;
    
  
    if area_level != 2 then
       return default_order;
    end if;

    SET rs = CASE area_code
    WHEN 'GZ' THEN
        1
    WHEN 'SZ' THEN
        2
    WHEN 'DG' THEN
        3
    WHEN 'FS' THEN
        4
    WHEN 'ST' THEN
        5
    WHEN 'ZH' THEN
        6
    WHEN 'HZ' THEN
        7
    WHEN 'ZS' THEN
        8
    WHEN 'JM' THEN
        9
    WHEN 'ZJ' THEN
        10
    WHEN 'MM' THEN
        11
    WHEN 'JY' THEN
        12
    WHEN 'SG' THEN
        13
    WHEN 'HY' THEN
        14
    WHEN 'MZ' THEN
        15
    WHEN 'SW' THEN
        16
    WHEN 'YJ' THEN
        17
    WHEN 'ZQ' THEN
        18
    WHEN 'QY' THEN
        19
    WHEN 'CZ' THEN
        20
    WHEN 'YF' THEN
        21
    ELSE
        default_order
    END;
  
    RETURN rs;
END
;;
DELIMITER ;

-- ----------------------------
-- Function structure for getAdditionPath
-- ----------------------------
DROP FUNCTION IF EXISTS `getAdditionPath`;
DELIMITER ;;
CREATE DEFINER=`root`@`%` FUNCTION `getAdditionPath`(typeId INT) RETURNS varchar(1000) CHARSET utf8
BEGIN
        DECLARE namePath VARCHAR(2000);
    DECLARE curTypeId INT(11);    
    DECLARE curTypePath VARCHAR(2000);  
    SELECT t2.parent_id ,t2.type_path, t2.type_name INTO curTypeId,curTypePath,namePath FROM tci_addition_type t2 WHERE t2.type_id = typeId; 
        
    IF curTypeId <> -1 THEN
            SELECT GROUP_CONCAT(t1.type_name order by type_level SEPARATOR '/') into  namePath FROM tci_addition_type t1 WHERE LOCATE(CONCAT(type_id,','),CONCAT(curTypePath,',')) > 0 ;
    END IF;  
      RETURN namePath; 
END
;;
DELIMITER ;

-- ----------------------------
-- Function structure for getChildTaskIdList
-- ----------------------------
DROP FUNCTION IF EXISTS `getChildTaskIdList`;
DELIMITER ;;
CREATE DEFINER=`root`@`%` FUNCTION `getChildTaskIdList`(parentId VARCHAR(64)) RETURNS varchar(4000) CHARSET utf8
BEGIN
 DECLARE oTemp VARCHAR(4000);
 DECLARE oTempChild VARCHAR(4000);
  
 SET oTemp = '';
 SET oTempChild = parentId;
  
 WHILE oTempChild IS NOT NULL
 DO
 IF oTempChild = parentId THEN 
  SET oTemp=''; 
 ELSE 
  SET oTemp = CONCAT(oTemp,',',oTempChild);
 END IF;
 
 SELECT GROUP_CONCAT(task_id) INTO oTempChild FROM tci_check_task WHERE FIND_IN_SET(parent_id,oTempChild) > 0;
 
 END WHILE;
 RETURN oTemp;
END
;;
DELIMITER ;

-- ----------------------------
-- Function structure for getModulePath
-- ----------------------------
DROP FUNCTION IF EXISTS `getModulePath`;
DELIMITER ;;
CREATE DEFINER=`root`@`%` FUNCTION `getModulePath`(catalogId VARCHAR(64)) RETURNS varchar(4000) CHARSET utf8
BEGIN
 DECLARE catalogName VARCHAR(4000);
 DECLARE catalogParentId VARCHAR(4000);
 DECLARE returnName VARCHAR(4000);
  
 SET catalogName = '';
 SET catalogParentId = '';
 SET returnName = '';
 
 SELECT t.menu_name,t.parent_id INTO catalogName,catalogParentId FROM tci_index_module_catalog t WHERE t.catalog_id =  catalogId;
 
 SET returnName = catalogName;
 WHILE catalogId IS NOT NULL 
 DO 
 IF ISNULL(catalogParentId) || LENGTH(TRIM(catalogParentId))<1 THEN 
  SET catalogId = NULL;
 ELSE 
  SET catalogId = catalogParentId;
  SELECT t.menu_name,t.parent_id INTO catalogName,catalogParentId FROM tci_index_module_catalog t WHERE t.catalog_id =  catalogId;
  SET returnName = CONCAT(catalogName,',',returnName);
 END IF;
 END WHILE;
 RETURN returnName;
    END
;;
DELIMITER ;

-- ----------------------------
-- Function structure for getTypeNamePath
-- ----------------------------
DROP FUNCTION IF EXISTS `getTypeNamePath`;
DELIMITER ;;
CREATE DEFINER=`root`@`%` FUNCTION `getTypeNamePath`(typeId INT) RETURNS varchar(1000) CHARSET utf8
BEGIN
        DECLARE namePath VARCHAR(2000);
    DECLARE curTypeId INT(11);    
    DECLARE curTypePath VARCHAR(2000);  
    SELECT t2.parent_id ,t2.type_path, t2.type_name INTO curTypeId,curTypePath,namePath FROM tci_index_type t2 WHERE t2.type_id = typeId; 
        
    IF curTypeId <> -1 THEN
            SELECT GROUP_CONCAT(t1.type_name order by type_level SEPARATOR '/') into  namePath FROM tci_index_type t1 WHERE LOCATE(CONCAT(type_id,','),CONCAT(curTypePath,',')) > 0;
    END IF;  
      RETURN namePath; 
END
;;
DELIMITER ;

-- ----------------------------
-- Function structure for nextval
-- ----------------------------
DROP FUNCTION IF EXISTS `nextval`;
DELIMITER ;;
CREATE DEFINER=`root`@`%` FUNCTION `nextval`(`seqName` VARCHAR(50)) RETURNS varchar(32) CHARSET utf8
BEGIN
    DECLARE i INT; 
    DECLARE j INT; 
    DECLARE pre VARCHAR(10); 
    DECLARE step INT;
    DECLARE c INT;
    SELECT COUNT(1) INTO c FROM T_SYS_SEQUENCE WHERE NAME=seqName;  
    IF c = 0 THEN
        INSERT INTO T_SYS_SEQUENCE(NAME,START_VALUE,INCREMENT,PREFIX,MAX_VALUE) VALUES (seqName,0,1,'_',999999999);
    END IF;
    
    SELECT IFNULL(VALUE,start_value),MAX_VALUE,IFNULL(prefix,''),INCREMENT INTO i,j,pre,step FROM T_SYS_SEQUENCE WHERE NAME=seqName;  
    IF i >= j THEN
        UPDATE T_SYS_SEQUENCE SET VALUE=start_value WHERE NAME=seqName;
    ELSE
        UPDATE T_SYS_SEQUENCE SET VALUE=i+INCREMENT WHERE NAME=seqName;
        SET i = i + step;
    END IF;    
RETURN CONCAT(pre,i);
END
;;
DELIMITER ;
