/*
Navicat MySQL Data Transfer

Source Server         : ai4a_10.161.124.31_22021_dcp_admin
Source Server Version : 50723
Source Host           : 10.161.124.31:22021
Source Database       : vapp_intelligence_marketing_e264fd96-3578-4400-97d5-fb5a39e232c3

Target Server Type    : MYSQL
Target Server Version : 50723
File Encoding         : 65001

Date: 2020-04-21 15:38:33
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for uc_campaign_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_campaign_t`;
CREATE TABLE `uc_campaign_t` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `code` varchar(100) NOT NULL COMMENT '营销活动主键',
  `campaign_code` varchar(255) NOT NULL COMMENT '活动编码',
  `campaign_name` varchar(255) DEFAULT NULL COMMENT '活动名称',
  `campaign_status` varchar(255) DEFAULT NULL COMMENT '营销活动状态',
  `priority` int(11) NOT NULL COMMENT '优先级',
  `start_time` datetime NOT NULL COMMENT '活动开始时间',
  `end_time` datetime NOT NULL COMMENT '活动截止时间',
  `details` varchar(3000) DEFAULT NULL COMMENT '活动详情',
  `generate_task` int(11) NOT NULL COMMENT '是否生成任务',
  `terminology` varchar(3000) DEFAULT NULL COMMENT '话术',
  `campaign_type` varchar(100) NOT NULL COMMENT '业务类型编码',
  `campaign_type_name` varchar(255) DEFAULT NULL COMMENT '活动类型名字',
  `scope_code` varchar(255) DEFAULT NULL COMMENT '0:个人，1：家庭',
  `create_time` datetime DEFAULT NULL,
  `status` int(11) DEFAULT NULL COMMENT '活动状态1,：正常，2：下线',
  `business_type` varchar(100) DEFAULT NULL COMMENT '活动类型',
  `update_number` varchar(100) DEFAULT NULL COMMENT '更新编码，用来标志更新任务是否完成结束',
  `first_product_code` varchar(255) DEFAULT NULL COMMENT '首推产品编码',
  `offercode` varchar(255) DEFAULT NULL COMMENT '产品编号',
  `offername` varchar(255) DEFAULT NULL COMMENT '产品名称',
  `treatment_id` varchar(255) NOT NULL DEFAULT '' COMMENT '分支编码',
  `offerId` varchar(255) NOT NULL DEFAULT '' COMMENT 'offerId编号',
  `access_channel` varchar(200) DEFAULT NULL COMMENT '接入渠道',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uc_campaign_t_UN` (`campaign_code`) USING BTREE,
  KEY `uc_campaign_t_end_time_INDEX` (`end_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Table structure for uc_marketing_callinfo_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_marketing_callinfo_t`;
CREATE TABLE `uc_marketing_callinfo_t` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `code` varchar(100) NOT NULL COMMENT 'callid',
  `appid` varchar(100) DEFAULT NULL COMMENT '通知结果应用id',
  `callidentifier` varchar(255) DEFAULT NULL COMMENT 'outbound_number会话标识',
  `caller` varchar(32) DEFAULT NULL COMMENT '双向外呼主叫号码',
  `callee` varchar(32) DEFAULT NULL COMMENT '双向外呼被叫号码',
  `status` varchar(32) DEFAULT NULL COMMENT '外呼状态 值范围详见能开接口文档',
  `reason` varchar(32) DEFAULT NULL COMMENT '外呼结果 值范围祥见能开文档',
  `ivr_url` varchar(100) DEFAULT NULL COMMENT '下发ivr文件地址',
  `ivr_result` varchar(32) DEFAULT NULL COMMENT 'ivr通知结果',
  `oper_result` int(3) DEFAULT '0' COMMENT '操作结果 0,正常 1调用ivr接口失败 2其它异常',
  `oper_msg` varchar(500) DEFAULT NULL COMMENT '操作异常信息',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `owner` varchar(255) DEFAULT NULL COMMENT '主叫工号',
  `markteing_type` varchar(50) DEFAULT NULL COMMENT '营销类型，1：智能营销，2：家庭商机，3：小区商机，4：关键时刻，5：回家驿站',
  `connected_time` datetime DEFAULT NULL COMMENT '双方接通时间',
  `disconnected_time` datetime DEFAULT NULL COMMENT '双方挂断时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段列',
  `create_user` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=287 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Table structure for uc_marketing_object_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_marketing_object_t`;
CREATE TABLE `uc_marketing_object_t` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `campaign_code` varchar(255) NOT NULL COMMENT '活动编码',
  `marketing_object` varchar(255) NOT NULL COMMENT '手机号/宽带号',
  `batch_number` varchar(100) DEFAULT NULL COMMENT '营销批次',
  `campaign_time` datetime DEFAULT NULL COMMENT '活动时间',
  `status` varchar(100) NOT NULL COMMENT '状态(1,已生成任务，0：未处理)',
  `employee_id` varchar(255) DEFAULT NULL COMMENT '任务直接责任人',
  `channel_id` varchar(255) DEFAULT NULL COMMENT '任务渠道数据',
  `other_number` varchar(2000) DEFAULT NULL COMMENT '异网手机加密版',
  `customer_uptown_code` varchar(255) DEFAULT NULL COMMENT '客户小区编码',
  `customer_uptown_name` varchar(255) DEFAULT NULL COMMENT '客户小区编码',
  `customer_commercial_building_code` varchar(255) DEFAULT NULL COMMENT '客户商业楼栋编码',
  `customer_commercial_building_name` varchar(255) DEFAULT NULL COMMENT '客户商业楼宇名',
  `customer_grid_code` varchar(255) DEFAULT NULL COMMENT '客户区域编码',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uc_marketing_object_UNI_IDX` (`campaign_code`,`marketing_object`),
  KEY `uc_marketing_object_t_id_IDX` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=32768 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for uc_marketing_object_t_temp
-- ----------------------------
DROP TABLE IF EXISTS `uc_marketing_object_t_temp`;
CREATE TABLE `uc_marketing_object_t_temp` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `campaign_code` varchar(255) NOT NULL COMMENT '活动编码',
  `marketing_object` varchar(255) NOT NULL COMMENT '手机号/宽带号',
  `batch_number` varchar(100) DEFAULT NULL COMMENT '营销批次',
  `campaign_time` datetime DEFAULT NULL COMMENT '活动时间',
  `status` varchar(100) NOT NULL COMMENT '状态(1,已生成任务，0：未处理)',
  `employee_id` varchar(255) DEFAULT NULL COMMENT '任务直接责任人',
  `channel_id` varchar(255) DEFAULT NULL COMMENT '任务渠道数据',
  `other_number` varchar(2000) DEFAULT NULL COMMENT '异网手机加密版',
  `customer_uptown_code` varchar(255) DEFAULT NULL COMMENT '客户小区编码',
  `customer_uptown_name` varchar(255) DEFAULT NULL COMMENT '客户小区编码',
  `customer_commercial_building_code` varchar(255) DEFAULT NULL COMMENT '客户商业楼栋编码',
  `customer_commercial_building_name` varchar(255) DEFAULT NULL COMMENT '客户商业楼宇名',
  `customer_grid_code` varchar(255) DEFAULT NULL COMMENT '客户区域编码',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uc_marketing_object_UNI_IDX` (`campaign_code`,`marketing_object`),
  KEY `uc_marketing_object_t_id_IDX` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=32768 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for uc_marketing_order_intelligence_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_marketing_order_intelligence_t`;
CREATE TABLE `uc_marketing_order_intelligence_t` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `code` varchar(100) NOT NULL COMMENT 'orderid  uuid去掉下划线',
  `action_batchno` varchar(100) DEFAULT NULL COMMENT 'action批次号',
  `order_status` int(3) DEFAULT NULL COMMENT '订单状态 0订单未提交 1订单执行中 2订单已领单  3 办理成功(订单执行完毕) 4其它情况 5办理失败,6订单提交失败 ',
  `remark` text COMMENT '备注',
  `out_order_id` varchar(255) DEFAULT NULL COMMENT '能开订单号',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `modfiy_time` datetime DEFAULT NULL COMMENT '修改时间',
  `city_name` varchar(255) NOT NULL DEFAULT '' COMMENT '归属地名称',
  `order_channel` int(3) DEFAULT '0' COMMENT '订单受理渠道:1-CRM,2-随身厅',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段列',
  `create_user` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='智能营销营销订单表';

-- ----------------------------
-- Table structure for uc_outbond_area_setting_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_outbond_area_setting_t`;
CREATE TABLE `uc_outbond_area_setting_t` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `code` varchar(100) NOT NULL COMMENT '业务主键',
  `display_number` varchar(50) NOT NULL COMMENT '显示号码',
  `area_level` int(11) DEFAULT NULL COMMENT '区域层级',
  `area_code` varchar(255) NOT NULL COMMENT '区域编码',
  `parent_code` varchar(255) DEFAULT NULL COMMENT '区域父级编码',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段列',
  `create_user` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Table structure for uc_task_action_intelligence_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_task_action_intelligence_t`;
CREATE TABLE `uc_task_action_intelligence_t` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `customer_code` varchar(255) NOT NULL DEFAULT '' COMMENT '用户编码',
  `task_id` varchar(255) NOT NULL COMMENT '任务id',
  `marketing_result` int(11) NOT NULL COMMENT '营销结果：101-推荐成功，102-推荐失败，103-客户考虑中，104-未接通',
  `action_time` datetime NOT NULL COMMENT '接触时间',
  `action_mode` varchar(255) NOT NULL DEFAULT '' COMMENT '接触方式：callphone-电话外呼,sendsms-发送短信,datevisit-预约拜访，face2face-面对面营销',
  `owner` varchar(255) NOT NULL DEFAULT '' COMMENT '任务执行人工号',
  `user_name_cn` varchar(255) NOT NULL DEFAULT '' COMMENT '任务执行人姓名',
  `action_phone` varchar(255) NOT NULL DEFAULT '' COMMENT '接触号码',
  `city_name` varchar(255) NOT NULL DEFAULT '' COMMENT '归属地名称',
  `maintain_result` varchar(255) NOT NULL DEFAULT '' COMMENT '维系结果',
  `promote_product` varchar(255) NOT NULL DEFAULT '' COMMENT '推荐产品',
  `maintenance` varchar(255) NOT NULL DEFAULT '' COMMENT '维系维项',
  `outbound_time` datetime NOT NULL COMMENT '外呼时间',
  `outbound_no` varchar(100) NOT NULL DEFAULT '' COMMENT '内部外呼流水号',
  `remarks` varchar(3000) NOT NULL DEFAULT '' COMMENT '备注',
  `task_result` int(11) NOT NULL DEFAULT '0',
  `last_update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `sync_result` int(11) DEFAULT NULL COMMENT '同步结果',
  `meet_date` datetime DEFAULT NULL COMMENT '预约拜访时间',
  `action_batchno` varchar(100) NOT NULL DEFAULT '' COMMENT '提交批次号',
  `operation` varchar(255) DEFAULT NULL COMMENT '用户操作',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段列',
  `create_user` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `task_id` (`task_id`) USING BTREE COMMENT '任务id索引',
  KEY `owner_index` (`owner`) USING BTREE COMMENT '工号索引',
  KEY `customer_code_index` (`customer_code`) USING BTREE COMMENT '手机号索引',
  KEY `marketing_result_index` (`marketing_result`) USING BTREE COMMENT '营销结果索引',
  KEY `outbound_no_index` (`outbound_no`) USING BTREE COMMENT '内部外呼流水号索引',
  KEY `last_update_time` (`last_update_time`) USING BTREE COMMENT '更新时间索引'
) ENGINE=InnoDB AUTO_INCREMENT=241 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='智能营销营销结果表';

-- ----------------------------
-- Table structure for uc_task_intelligence_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_task_intelligence_t`;
CREATE TABLE `uc_task_intelligence_t` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `code` varchar(255) NOT NULL COMMENT '任务id',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '任务状态：0-开启，1-关闭',
  `marketing_result` varchar(255) NOT NULL DEFAULT '' COMMENT '营销结果：101-推荐成功，102-推荐失败，103-客户考虑中，104-未接通',
  `business_type` varchar(255) NOT NULL COMMENT '业务类型：40-智能营销',
  `employee_id` varchar(255) NOT NULL DEFAULT '' COMMENT '执行人工号',
  `campaign_code` varchar(255) NOT NULL DEFAULT '' COMMENT '活动编码',
  `campaign_name` varchar(255) NOT NULL DEFAULT '' COMMENT '活动名称',
  `campaign_type` varchar(100) NOT NULL COMMENT '活动业务类型',
  `campaign_scope_code` varchar(255) DEFAULT NULL COMMENT '活动业务范围',
  `grid_code` varchar(255) NOT NULL DEFAULT '' COMMENT '任务区域编码（微网格层级）',
  `all_parent_code` varchar(255) NOT NULL DEFAULT '' COMMENT '所有父节点编码（含自身）',
  `customer_code` varchar(255) NOT NULL DEFAULT '' COMMENT '用户编码（手机号）',
  `customer_uptown_code` varchar(255) DEFAULT NULL COMMENT '客户小区编码',
  `customer_uptown_name` varchar(255) DEFAULT NULL COMMENT '客户小区名',
  `customer_commercial_building_code` varchar(255) DEFAULT NULL COMMENT '客户商业楼栋编码',
  `customer_commercial_building_name` varchar(255) DEFAULT NULL COMMENT '客户商业楼宇名',
  `start_time` datetime DEFAULT NULL COMMENT '活动开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '活动截止时间',
  `city_name` varchar(255) NOT NULL DEFAULT '' COMMENT '归属地名称',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '其他备注',
  `last_update_time` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '最后更新时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段列',
  `create_user` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `all_parent_code_index` (`all_parent_code`) USING BTREE COMMENT '所有父区域编码索引',
  KEY `business_type_index` (`business_type`) USING BTREE COMMENT '业务类型索引',
  KEY `customer_code_index` (`customer_code`) USING BTREE COMMENT '手机号索引',
  KEY `status_index` (`status`) USING BTREE COMMENT '任务状态索引',
  KEY `employee_id_index` (`employee_id`) USING BTREE COMMENT '工号索引',
  KEY `start_time_index` (`start_time`) USING BTREE COMMENT '任务开始时间索引',
  KEY `end_time_index` (`end_time`) USING BTREE COMMENT '任务结束时间索引',
  KEY `code_index` (`code`) USING BTREE COMMENT '任务id索引',
  KEY `campaign_code_index` (`campaign_code`) USING BTREE,
  KEY `index_all_parent_campaign` (`status`,`employee_id`,`campaign_code`,`all_parent_code`,`end_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=32768 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='智能营销营销任务表';

-- ----------------------------
-- Table structure for uc_task_intelligence_t_yst
-- ----------------------------
DROP TABLE IF EXISTS `uc_task_intelligence_t_yst`;
CREATE TABLE `uc_task_intelligence_t_yst` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `code` varchar(255) NOT NULL COMMENT '任务id',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '任务状态：0-开启，1-关闭',
  `marketing_result` varchar(255) NOT NULL DEFAULT '' COMMENT '营销结果：101-推荐成功，102-推荐失败，103-客户考虑中，104-未接通',
  `business_type` varchar(255) NOT NULL COMMENT '业务类型：40-智能营销',
  `employee_id` varchar(255) NOT NULL DEFAULT '' COMMENT '执行人工号',
  `campaign_code` varchar(255) NOT NULL DEFAULT '' COMMENT '活动编码',
  `campaign_name` varchar(255) NOT NULL DEFAULT '' COMMENT '活动名称',
  `campaign_type` varchar(100) NOT NULL COMMENT '活动业务类型',
  `campaign_scope_code` varchar(255) DEFAULT NULL COMMENT '活动业务范围',
  `grid_code` varchar(255) NOT NULL DEFAULT '' COMMENT '任务区域编码（微网格层级）',
  `all_parent_code` varchar(255) NOT NULL DEFAULT '' COMMENT '所有父节点编码（含自身）',
  `customer_code` varchar(255) NOT NULL DEFAULT '' COMMENT '用户编码（手机号）',
  `customer_uptown_code` varchar(255) DEFAULT NULL COMMENT '客户小区编码',
  `customer_uptown_name` varchar(255) DEFAULT NULL COMMENT '客户小区名',
  `customer_commercial_building_code` varchar(255) DEFAULT NULL COMMENT '客户商业楼栋编码',
  `customer_commercial_building_name` varchar(255) DEFAULT NULL COMMENT '客户商业楼宇名',
  `start_time` datetime DEFAULT NULL COMMENT '活动开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '活动截止时间',
  `city_name` varchar(255) NOT NULL DEFAULT '' COMMENT '归属地名称',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '其他备注',
  `last_update_time` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '最后更新时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段列',
  `create_user` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `all_parent_code_index` (`all_parent_code`) USING BTREE COMMENT '所有父区域编码索引',
  KEY `business_type_index` (`business_type`) USING BTREE COMMENT '业务类型索引',
  KEY `customer_code_index` (`customer_code`) USING BTREE COMMENT '手机号索引',
  KEY `status_index` (`status`) USING BTREE COMMENT '任务状态索引',
  KEY `employee_id_index` (`employee_id`) USING BTREE COMMENT '工号索引',
  KEY `start_time_index` (`start_time`) USING BTREE COMMENT '任务开始时间索引',
  KEY `end_time_index` (`end_time`) USING BTREE COMMENT '任务结束时间索引',
  KEY `code_index` (`code`) USING BTREE COMMENT '任务id索引',
  KEY `campaign_code_index` (`campaign_code`) USING BTREE,
  KEY `index_all_parent_campaign` (`status`,`employee_id`,`campaign_code`,`all_parent_code`,`end_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=32769 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='智能营销营销任务表';

-- ----------------------------
-- Table structure for uc_task_outbound_settings_t
-- ----------------------------
DROP TABLE IF EXISTS `uc_task_outbound_settings_t`;
CREATE TABLE `uc_task_outbound_settings_t` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `employee_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '任务执行人工号',
  `new_outbound_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '新外呼显示号码',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段列',
  `create_user` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
