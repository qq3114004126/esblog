/*
Navicat MySQL Data Transfer

Source Server         : lvqu
Source Server Version : 50723
Source Host           : 10.186.249.187:3306
Source Database       : dcp_business_6ce215b1-ef6e-4aaf-80a5-110a7aacc46c

Target Server Type    : MYSQL
Target Server Version : 50723
File Encoding         : 65001

Date: 2020-03-29 14:49:08
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for dim_pub_city
-- ----------------------------
DROP TABLE IF EXISTS `dim_pub_city`;
CREATE TABLE `dim_pub_city` (
  `CITY_ID` int(6) NOT NULL,
  `PROVINCE_ID` int(6) DEFAULT NULL,
  `BEGIN_TIME` date DEFAULT NULL,
  `END_TIME` date DEFAULT NULL,
  `ACTIVE_FLAG` int(6) DEFAULT NULL,
  `CITY_NAME` varchar(20) DEFAULT NULL,
  `DESCinfo` varchar(64) DEFAULT NULL,
  `AREA_CODE` int(6) DEFAULT NULL,
  `GRID_CODE` varchar(32) DEFAULT NULL,
  `CITY_CODE` int(8) DEFAULT NULL,
  UNIQUE KEY `index_city_unique` (`CITY_ID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Table structure for schema_version
-- ----------------------------
DROP TABLE IF EXISTS `schema_version`;
CREATE TABLE `schema_version` (
  `installed_rank` int(11) NOT NULL,
  `version` varchar(50) DEFAULT NULL,
  `description` varchar(200) NOT NULL,
  `type` varchar(20) NOT NULL,
  `script` varchar(1000) NOT NULL,
  `checksum` int(11) DEFAULT NULL,
  `installed_by` varchar(100) NOT NULL,
  `installed_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `execution_time` int(11) NOT NULL,
  `success` tinyint(1) NOT NULL,
  PRIMARY KEY (`installed_rank`),
  KEY `schema_version_s_idx` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for t_async_task
-- ----------------------------
DROP TABLE IF EXISTS `t_async_task`;
CREATE TABLE `t_async_task` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `client_code` varchar(50) DEFAULT NULL COMMENT '终端编码',
  `tenant_code` varchar(50) DEFAULT NULL COMMENT '租户编码',
  `name` varchar(50) DEFAULT NULL COMMENT '任务名称',
  `source` varchar(50) DEFAULT NULL COMMENT '来源应用',
  `type` varchar(50) DEFAULT NULL COMMENT '任务类型：1:导入 2：导出 3：快速建表 4: 全量同步数据到Gis',
  `progress` varchar(50) DEFAULT NULL COMMENT '进度',
  `status` int(50) DEFAULT NULL COMMENT '状态：\r\n1、已创建\r\n2、执行中\r\n3、失败\r\n4、已完成',
  `cost_time` varchar(50) DEFAULT NULL COMMENT '耗时',
  `exec_log` mediumtext COMMENT '任务日志',
  `create_user_id` varchar(50) DEFAULT NULL COMMENT '创建id',
  `create_user_name` varchar(255) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `finish_time` datetime DEFAULT NULL COMMENT '完成时间',
  `param` json DEFAULT NULL COMMENT '任务参数',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='异步任务表';

-- ----------------------------
-- Table structure for t_biz_bigfamily_portrait_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_bigfamily_portrait_m`;
CREATE TABLE `t_biz_bigfamily_portrait_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `code` varchar(50) NOT NULL COMMENT '家庭画像编码',
  `family_network_status` varchar(50) DEFAULT NULL COMMENT '亲情网',
  `family_network_num` int(10) DEFAULT NULL COMMENT '亲情网可办理人数',
  `family_network_recommend` varchar(500) DEFAULT NULL COMMENT '亲情网推荐话术',
  `lovefamily_package_status` varchar(50) DEFAULT NULL COMMENT '爱家套餐',
  `lovefamily_package_level` varchar(200) DEFAULT NULL COMMENT '爱家套餐档次',
  `lovefamily_package_recommend` varchar(500) DEFAULT NULL COMMENT '爱家套餐推荐话术',
  `rearview_mirror_status` varchar(50) DEFAULT NULL COMMENT '后视镜',
  `rearview_mirror_recommend` varchar(500) DEFAULT NULL COMMENT '后视镜推荐话术',
  `vehicleowner_service_status` varchar(50) DEFAULT NULL COMMENT '车主服务',
  `vehicleowner_service_recommend` varchar(500) DEFAULT NULL COMMENT '车主服务推荐话术',
  `family_num` int(10) DEFAULT NULL COMMENT '家庭成员数',
  `self_net_num` int(10) DEFAULT NULL COMMENT '我网成员',
  `diffnet_net_num` int(10) DEFAULT NULL COMMENT '异网成员',
  `main_phone` varchar(50) DEFAULT NULL COMMENT '家庭主号',
  `family_members_remark` varchar(200) DEFAULT NULL COMMENT '家庭成员备注',
  `remark` varchar(500) DEFAULT NULL COMMENT '其他',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_biz_bigfamily_protrait_unique_key_code` (`code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COMMENT='大家庭画像表';

-- ----------------------------
-- Table structure for t_biz_building_enterprise
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_building_enterprise`;
CREATE TABLE `t_biz_building_enterprise` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `building_code` varchar(50) NOT NULL COMMENT '楼宇编码',
  `enterpirse_code` varchar(50) NOT NULL COMMENT '集团编码',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_building_enterprise_unique_key_building_enterpirse_code` (`building_code`,`enterpirse_code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='楼宇与集团关系表';

-- ----------------------------
-- Table structure for t_biz_building_index_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_building_index_m`;
CREATE TABLE `t_biz_building_index_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `building_code` varchar(50) NOT NULL COMMENT '楼宇编码',
  `self_user_num` int(10) DEFAULT NULL COMMENT '我网用户数',
  `other_user_num` int(10) DEFAULT NULL COMMENT '异网用户数',
  `statistics_time` date NOT NULL COMMENT '统计时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_biz_building_index_m_unique_key_building_code_stat_time` (`building_code`,`statistics_time`) USING BTREE,
  KEY `index_biz_building_index_m_building_code` (`building_code`),
  KEY `index_biz_building_index_m_statistics_time` (`statistics_time`)
) ENGINE=InnoDB AUTO_INCREMENT=11277 DEFAULT CHARSET=utf8mb4 COMMENT='楼宇指标表';

-- ----------------------------
-- Table structure for t_biz_building_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_building_m`;
CREATE TABLE `t_biz_building_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `grid_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '区域编码',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `bundary_coordinates` geometry NOT NULL COMMENT '边界坐标',
  `code` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '楼宇编码',
  `name` varchar(200) CHARACTER SET utf8 DEFAULT NULL COMMENT '楼宇名称',
  `floornum` int(10) DEFAULT NULL COMMENT '楼层数',
  `cusyomer_name` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '客户名称',
  `cusyomer_phone` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '客户联系电话',
  `cover_total` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '覆盖总数',
  `cover_way` int(10) DEFAULT NULL COMMENT '覆盖方式',
  `open_account_num` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '已开户数',
  `production_date` date DEFAULT NULL COMMENT '投产日期',
  `broadband_type` int(10) DEFAULT NULL COMMENT '宽带类型',
  `building_value` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '楼宇价值',
  `route_type` int(10) DEFAULT NULL COMMENT '路由类型',
  `cusyomer_total` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '客户总数',
  `sign_cusyomer_total` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '已注册用户数',
  `is_agree_insert` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '物业是否同意接入',
  `dedic_line_num` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '专线数',
  `dedic_line_mon_income` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '专线月收入',
  `remarks` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '备注',
  `lytype` int(10) DEFAULT NULL COMMENT '楼宇性质',
  `addr` varchar(500) CHARACTER SET utf8 DEFAULT NULL COMMENT '详细地址',
  `xqid` int(10) DEFAULT NULL COMMENT '小区id',
  `street` varchar(200) CHARACTER SET utf8 DEFAULT NULL COMMENT '道路',
  `housenumber` varchar(500) DEFAULT NULL COMMENT '门牌',
  `area` decimal(10,2) DEFAULT NULL COMMENT '面积',
  `inblock` varchar(200) CHARACTER SET utf8 DEFAULT NULL COMMENT '乡镇街道办',
  `ratecoverage` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '资源到达情况',
  `district_code` varchar(50) DEFAULT NULL COMMENT '区县编码',
  `district_name` varchar(200) DEFAULT NULL COMMENT '区县名称',
  `xqname` varchar(200) CHARACTER SET utf8 DEFAULT NULL COMMENT '小区名称',
  `esoptype` int(10) DEFAULT NULL COMMENT 'esop类型',
  `livefirerate` decimal(5,2) DEFAULT NULL COMMENT '实装率',
  `rescontentment` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '(保留字段)资源到达情况取值：1/2/3/4/5/6/7\r\n1.设备已达\r\n2.光缆入户\r\n3.光缆到楼层\r\n4.光缆到红线内\r\n5.50米范围内有光缆\r\n6.管道到红线内\r\n7.50米范围内有管道\r\n8.未覆盖',
  `actualinvestment` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '实际投资额(每栋楼宇实际建设投入的资金数)',
  `sourcetype` int(10) DEFAULT NULL COMMENT '楼宇数据来源 1：网格系统录入，2：大数据，3：地市收集，4：省公司收集，5：CRM，6：互联网',
  `covermode` int(10) DEFAULT NULL COMMENT '覆盖场景类型 1 高价值写字楼 2 普通写字楼 3 专业市场 4 机关单位、大企业、星级酒店 5 学校、厂区、医院、政府办公区 6 工业园厂区',
  `update_date` date DEFAULT NULL COMMENT '楼宇更新时间',
  `order_source` int(10) DEFAULT NULL COMMENT '楼宇来源 1手工录入',
  `build_way` int(10) DEFAULT NULL COMMENT '建设方式',
  `build_type` int(10) DEFAULT NULL COMMENT '楼宇分类',
  `first_finish_date` date DEFAULT NULL COMMENT '初次完工时间',
  `last_finish_date` date DEFAULT NULL COMMENT '最后完工时间',
  `first_open_way` int(10) DEFAULT NULL COMMENT '初次开通方式',
  `last_open_way` int(10) DEFAULT NULL COMMENT '最后开通方式',
  `first_open_date` date DEFAULT NULL COMMENT '初次开通时间',
  `last_open_date` date DEFAULT NULL COMMENT '最后开通时间',
  `isfinish` int(10) DEFAULT NULL COMMENT '是否已完工 1已完工 2未完工',
  `real_ratecoverage` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '实际资源到达情况',
  `serviceorderno` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '服开工单流水号',
  `productname` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '产品名称',
  `openingtype` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '传输接入方式',
  `isconstruction` int(10) DEFAULT NULL COMMENT '是否需要工程建设 1是 2否',
  `businessopen_sync_date` date DEFAULT NULL COMMENT '业务开通同步时间',
  `specialcheck` int(10) DEFAULT NULL COMMENT '专项检查 1是 2否',
  `belongtype` int(10) DEFAULT NULL COMMENT '楼宇归属 1、城镇 2、农村',
  `building` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '楼栋',
  `subscode` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '服开crm编号',
  `is_cover_ims` bit(1) DEFAULT NULL COMMENT '是否覆盖移动ims',
  `is_cover_mobile` bit(1) DEFAULT NULL COMMENT '是否覆盖移动宽带网线',
  `is_cover_mobilecell` bit(1) DEFAULT NULL COMMENT '是否覆盖移动室分基站',
  `mobile_num` int(10) DEFAULT NULL COMMENT '移动宽带数',
  `broadband_share` decimal(10,4) DEFAULT NULL COMMENT '宽带份额',
  `manager` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '网格经理',
  `manager_phone` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '网格经理电话',
  `lt_num` int(10) DEFAULT NULL COMMENT 'LT宽带数',
  `telecommunication_num` int(10) DEFAULT NULL COMMENT '电信宽带数',
  `bundary` mediumtext CHARACTER SET utf8 COMMENT '边界坐标文本',
  `enterprise_num` int(10) DEFAULT NULL COMMENT '企业数量',
  `cover_scene` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '覆盖场景:家庭场景\\校园场景\\聚类覆盖\n',
  `addr_type` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '地址类型',
  `device_type` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '覆盖设备类型',
  `free_port_count` int(10) DEFAULT NULL COMMENT '空闲端口数',
  `dw_portion` decimal(10,4) DEFAULT NULL COMMENT '宽带占比',
  `property_name` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '物业信息',
  `property_tel` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '物业联系电话',
  `property_keyperson` varchar(300) CHARACTER SET utf8 DEFAULT NULL COMMENT '物业关键人信息',
  `property_keyperson_tel` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '物业关键人联系电话',
  `city_code` varchar(50) DEFAULT NULL COMMENT '城市编码',
  `city_name` varchar(200) CHARACTER SET utf8 DEFAULT NULL COMMENT '城市名称',
  `status` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '状态:1 有效, 0 无效, 2 已删除, 3 待审批',
  `is_confirmed` bit(1) DEFAULT NULL COMMENT '是否已确认 1、已确认 0、未确认',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  `building_manager` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '楼宇管理人',
  `building_linkman` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '联系人',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_biz_building_unique_key_code` (`code`) USING BTREE,
  KEY `index_biz_building_city_code` (`city_code`) USING BTREE,
  KEY `index_biz_building_regioncode` (`district_code`) USING BTREE,
  SPATIAL KEY `spatIdx` (`bundary_coordinates`),
  FULLTEXT KEY `ftindex_biz_building_m_name` (`name`) /*!50100 WITH PARSER `ngram` */ 
) ENGINE=InnoDB AUTO_INCREMENT=95283 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='楼宇表';

-- ----------------------------
-- Table structure for t_biz_building_marketing
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_building_marketing`;
CREATE TABLE `t_biz_building_marketing` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `building_code` varchar(50) NOT NULL COMMENT '楼宇编码',
  `marketing_code` varchar(50) NOT NULL COMMENT '活动编码',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_biz_building_marketing_unique_building_marketing_code` (`building_code`,`marketing_code`),
  KEY `index_biz_building_marketing_building_code` (`building_code`),
  KEY `index_biz_building_marketing_marketing_code` (`marketing_code`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COMMENT='楼宇营销活动关系表';

-- ----------------------------
-- Table structure for t_biz_building_marketing_record
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_building_marketing_record`;
CREATE TABLE `t_biz_building_marketing_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `building_code` varchar(50) NOT NULL COMMENT '楼宇编码',
  `marketing_code` varchar(50) NOT NULL COMMENT '活动编码',
  `template_code` varchar(50) NOT NULL COMMENT '短信模板编码',
  `quantity` int(10) DEFAULT NULL COMMENT '营销数量',
  `success_num` int(11) DEFAULT NULL COMMENT '成功发送数量',
  `send_time` datetime NOT NULL COMMENT '发送时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_biz_building_marketing_record_unique_build_mark_templ_send` (`building_code`,`marketing_code`,`template_code`,`send_time`) USING BTREE,
  KEY `index_biz_building_marketing_record_building_code` (`building_code`),
  KEY `index_biz_building_marketing_record_marketing_code` (`marketing_code`),
  KEY `index_biz_building_marketing_record_template_code` (`template_code`),
  KEY `index_biz_building_marketing_record_send_time` (`send_time`)
) ENGINE=InnoDB AUTO_INCREMENT=108031 DEFAULT CHARSET=utf8mb4 COMMENT='楼宇营销活动信息';

-- ----------------------------
-- Table structure for t_biz_building_sector_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_building_sector_m`;
CREATE TABLE `t_biz_building_sector_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `grid_code` varchar(50) NOT NULL COMMENT '区域编码',
  `building_code` varchar(50) NOT NULL COMMENT '楼宇编码',
  `building_name` varchar(200) DEFAULT NULL COMMENT '楼宇名称',
  `cgi` varchar(50) NOT NULL COMMENT 'cgi',
  `station_code` varchar(50) DEFAULT NULL COMMENT '基站编码',
  `station_name` varchar(200) DEFAULT NULL COMMENT '基站名称',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_biz_building_sector_unique_key_building_code_cgi` (`building_code`,`cgi`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='t_biz_building_sector_m';

-- ----------------------------
-- Table structure for t_biz_bw_account_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_bw_account_m`;
CREATE TABLE `t_biz_bw_account_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `bw_account` varchar(50) NOT NULL COMMENT '宽带账户',
  `bw_account_encrypt` varchar(50) DEFAULT NULL COMMENT '宽带账户加密',
  `bw_flag` varchar(50) DEFAULT NULL COMMENT '宽带标识',
  `phone` varchar(50) DEFAULT NULL COMMENT '手机号',
  `uptown_code` varchar(50) DEFAULT NULL COMMENT '小区编码',
  `uptown` varchar(200) DEFAULT NULL COMMENT '小区名称',
  `open_date` datetime DEFAULT NULL COMMENT '开户时间',
  `user_name` varchar(200) DEFAULT NULL COMMENT '姓名',
  `age` varchar(50) DEFAULT NULL COMMENT '年龄',
  `sex` varchar(50) DEFAULT NULL COMMENT '性别',
  `district` varchar(50) DEFAULT NULL COMMENT '区县市',
  `shopping_hall` varchar(50) DEFAULT NULL COMMENT '归属营业部',
  `access_type` varchar(50) DEFAULT NULL COMMENT '接入方式',
  `mix_price` varchar(50) DEFAULT NULL COMMENT '融合资费',
  `broadband_price` varchar(50) DEFAULT NULL COMMENT '宽带资费',
  `bw` int(11) DEFAULT NULL COMMENT '宽带带宽',
  `operator` varchar(50) DEFAULT NULL COMMENT '运营商',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '关联网格',
  `avg_duration` decimal(10,4) DEFAULT NULL COMMENT '平均宽带时长',
  `avg_traffic` decimal(20,4) DEFAULT NULL COMMENT '平均宽带流量',
  `is_handhall_activeuser` bit(1) DEFAULT NULL COMMENT '是否掌厅活跃用户',
  `is_differentbw` bit(1) DEFAULT NULL COMMENT '是否异网宽带',
  `is_publicno_activeuser` bit(1) DEFAULT NULL COMMENT '是否公众号活跃用户',
  `collect_date` datetime DEFAULT NULL COMMENT '数据日期',
  `churn_reason` varchar(200) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '离网原因',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_biz_bw_account_unique_key_bw_account` (`bw_account`) USING BTREE,
  KEY `index_biz_bw_account_bw_account_encrypt` (`bw_account_encrypt`) USING BTREE,
  KEY `index_biz_bw_account_uptown_code` (`uptown_code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='宽带账号基本信息表';

-- ----------------------------
-- Table structure for t_biz_bw_churnaccount_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_bw_churnaccount_m`;
CREATE TABLE `t_biz_bw_churnaccount_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `grid_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '区域编码',
  `account` varchar(50) NOT NULL COMMENT '宽带账户',
  `churn_month` varchar(50) DEFAULT NULL COMMENT '离网月份',
  `churn_reason` varchar(200) DEFAULT NULL COMMENT '离网原因',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_biz_bw_churnaccount_unique_key_account` (`account`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='宽带离网用户表';

-- ----------------------------
-- Table structure for t_biz_bw_usage_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_bw_usage_m`;
CREATE TABLE `t_biz_bw_usage_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增主键ID',
  `grid_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '区域编码',
  `account` varchar(50) NOT NULL COMMENT '宽带账户',
  `month_online_times` int(11) DEFAULT NULL COMMENT '月在线时长',
  `month_inflow` decimal(22,2) DEFAULT NULL COMMENT '月入流量',
  `month_outflow` decimal(22,2) DEFAULT NULL COMMENT '月出流量',
  `account_balance` decimal(10,2) DEFAULT NULL COMMENT '账单余额',
  `caton_count` int(11) DEFAULT NULL COMMENT '卡顿次数',
  `onu_opticalpower` decimal(22,2) DEFAULT NULL,
  `package_bandwidth` decimal(22,2) DEFAULT NULL COMMENT '套餐带宽',
  `package_due` date DEFAULT NULL COMMENT '套餐到期时间',
  `router_abnormal_days` int(11) DEFAULT NULL COMMENT '路由器异常天数',
  `statistical_month` varchar(50) NOT NULL COMMENT '统计月份',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_biz_bw_usage_unique_key_account_sdtatistical_month` (`account`,`statistical_month`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='宽带账户使用情况表';

-- ----------------------------
-- Table structure for t_biz_call_record_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_call_record_m`;
CREATE TABLE `t_biz_call_record_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `grid_code` varchar(50) NOT NULL COMMENT '区域编码',
  `grid_name` varchar(200) DEFAULT NULL COMMENT '区域名称',
  `business_type` varchar(50) NOT NULL COMMENT '商机类型',
  `activity_classify` varchar(50) NOT NULL COMMENT '活动分类',
  `activity_name` varchar(200) DEFAULT NULL COMMENT '活动名称',
  `phone` varchar(50) NOT NULL COMMENT '主叫用户电话号码',
  `work_number` varchar(50) DEFAULT NULL COMMENT '主叫用户工号',
  `work_name` varchar(200) DEFAULT NULL COMMENT '主叫用户姓名',
  `call_time` datetime NOT NULL COMMENT '外呼时间',
  `call_uuid` varchar(50) NOT NULL COMMENT '外呼唯一流水',
  `passive_phone` varchar(50) NOT NULL COMMENT '被叫电话号码',
  `uptwon_code` varchar(50) DEFAULT NULL COMMENT '被叫号码小区编码',
  `uptwon_name` varchar(200) DEFAULT NULL COMMENT '被叫号码小区名称',
  `marketing_result` varchar(50) NOT NULL COMMENT '营销结果',
  `order_number` varchar(255) DEFAULT NULL COMMENT '营销结果',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_biz_call_record_unique_key_phone_call_time_passive_phone` (`phone`,`call_time`,`passive_phone`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='外呼日志记录表';

-- ----------------------------
-- Table structure for t_biz_complaint_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_complaint_m`;
CREATE TABLE `t_biz_complaint_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `grid_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '区域编码',
  `account` varchar(50) NOT NULL COMMENT '宽带账号',
  `account_encrypt` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '宽带账户加密',
  `type` varchar(50) DEFAULT NULL COMMENT '投诉类型',
  `reason` varchar(200) DEFAULT NULL COMMENT '投诉原因',
  `time` datetime NOT NULL COMMENT '投诉时间',
  `statistical_month` varchar(50) DEFAULT NULL COMMENT '统计月份',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_complaint_unique_key_account_statistical_month` (`account`,`time`) USING BTREE,
  KEY `index_complaint_statistical_month` (`statistical_month`) USING BTREE,
  KEY `index_complaint_account_encrypt` (`account_encrypt`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='宽带投诉工单月份统计表';

-- ----------------------------
-- Table structure for t_biz_data_role_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_data_role_m`;
CREATE TABLE `t_biz_data_role_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `role_id` varchar(50) NOT NULL COMMENT '角色ID，关联iam_public.uc_instance_role_t.id',
  `role_name` varchar(200) NOT NULL COMMENT '角色名称，关联iam_public.uc_instance_role_t.role_name',
  `role_type` varchar(4) NOT NULL COMMENT '角色分类，a-被审批、审批类型，b-被审批类型',
  `status` varchar(4) DEFAULT NULL COMMENT '状态：0-无效,1-有效',
  `remark` varchar(200) DEFAULT NULL COMMENT '备注',
  `create_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  `func_code` varchar(255) DEFAULT NULL COMMENT '功能编码',
  `func_name` varchar(255) DEFAULT NULL COMMENT '功能名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COMMENT='数据角色控制表';

-- ----------------------------
-- Table structure for t_biz_enterprise_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_enterprise_m`;
CREATE TABLE `t_biz_enterprise_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '区域编码',
  `code` varchar(50) NOT NULL COMMENT '集团编码',
  `name` varchar(200) DEFAULT NULL COMMENT '集团名称',
  `type` varchar(50) DEFAULT NULL COMMENT '集团类型',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `bundary_coordinates` geometry NOT NULL COMMENT '边界坐标',
  `level` varchar(50) DEFAULT NULL COMMENT '集团等级',
  `customer_manager` varchar(50) DEFAULT NULL COMMENT '客户经理',
  `building_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '楼宇编码',
  `building_name` varchar(200) CHARACTER SET utf8 DEFAULT NULL COMMENT '楼宇名称',
  `address` varchar(200) DEFAULT NULL COMMENT '集团地址',
  `city_code` varchar(50) DEFAULT NULL COMMENT '城市编码',
  `city_name` varchar(200) DEFAULT NULL COMMENT '城市名称',
  `district_code` varchar(50) DEFAULT NULL COMMENT '市县编码',
  `district_name` varchar(200) DEFAULT NULL COMMENT '区县名称',
  `firstlevel_address` varchar(50) DEFAULT NULL COMMENT '一级地址',
  `twolevel_address` varchar(50) DEFAULT NULL COMMENT '二级地址',
  `threelevel_address` varchar(50) DEFAULT NULL COMMENT '三级地址',
  `fourlevel_address` varchar(50) DEFAULT NULL COMMENT '四级地址',
  `fivelevel_address` varchar(50) DEFAULT NULL COMMENT '五级地址',
  `sixlevel_address` varchar(50) DEFAULT NULL COMMENT '六级地址',
  `sevenlevel_address` varchar(50) DEFAULT NULL COMMENT '七级地址',
  `sourcetype` int(10) DEFAULT NULL COMMENT '数据来源 1：网格系统录入，2：大数据，3：地市收集，4：省公司收集，5：CRM，6：互联网',
  `status` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '状态:有效1/无效0/已删除2/待审批3/离网4/潜在5/集团预销户6',
  `is_confirmed` bit(1) DEFAULT NULL COMMENT '是否已确认 1、已确认 0、未确认',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  `building_manager` varchar(50) DEFAULT NULL COMMENT '楼宇管理人',
  `building_linkman` varchar(50) DEFAULT NULL COMMENT '联系人',
  `customer_manager_code` varchar(50) DEFAULT NULL COMMENT '客户经理工号',
  `customer_manager_tel` varchar(50) DEFAULT NULL COMMENT '客户经理电话',
  `building_type` varchar(50) DEFAULT NULL COMMENT '楼宇类型:uptown 家宽小区/building 楼宇',
  `floor` varchar(1000) DEFAULT NULL COMMENT '楼层',
  `room_no` varchar(1000) DEFAULT NULL COMMENT '房号',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_unique_t_biz_enterprise_m` (`code`) USING BTREE,
  KEY `index_biz_enterprise_m_grid_code` (`grid_code`) USING BTREE,
  SPATIAL KEY `spatIdx` (`bundary_coordinates`),
  KEY `index_biz_enterprise_m_area_code` (`city_code`) USING BTREE,
  KEY `index_biz_enterprise_m_cnty_code` (`district_code`) USING BTREE,
  FULLTEXT KEY `ftindex_enterprise_name` (`name`) /*!50100 WITH PARSER `ngram` */ 
) ENGINE=InnoDB AUTO_INCREMENT=798135 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='集团表';

-- ----------------------------
-- Table structure for t_biz_enterprise_m_1022
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_enterprise_m_1022`;
CREATE TABLE `t_biz_enterprise_m_1022` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '区域编码',
  `code` varchar(50) NOT NULL COMMENT '集团编码',
  `name` varchar(200) DEFAULT NULL COMMENT '集团名称',
  `type` varchar(50) DEFAULT NULL COMMENT '集团类型',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `bundary_coordinates` geometry NOT NULL COMMENT '边界坐标',
  `level` varchar(50) DEFAULT NULL COMMENT '集团等级',
  `customer_manager` varchar(50) DEFAULT NULL COMMENT '客户经理',
  `building_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '楼宇编码',
  `building_name` varchar(200) CHARACTER SET utf8 DEFAULT NULL COMMENT '楼宇名称',
  `address` varchar(200) DEFAULT NULL COMMENT '集团地址',
  `city_code` varchar(50) DEFAULT NULL COMMENT '城市编码',
  `city_name` varchar(200) DEFAULT NULL COMMENT '城市名称',
  `district_code` varchar(50) DEFAULT NULL COMMENT '区县编码',
  `district_name` varchar(200) DEFAULT NULL COMMENT '区县名称',
  `firstlevel_address` varchar(50) DEFAULT NULL COMMENT '一级地址',
  `twolevel_address` varchar(50) DEFAULT NULL COMMENT '二级地址',
  `threelevel_address` varchar(50) DEFAULT NULL COMMENT '三级地址',
  `fourlevel_address` varchar(50) DEFAULT NULL COMMENT '四级地址',
  `fivelevel_address` varchar(50) DEFAULT NULL COMMENT '五级地址',
  `sixlevel_address` varchar(50) DEFAULT NULL COMMENT '六级地址',
  `sevenlevel_address` varchar(50) DEFAULT NULL COMMENT '七级地址',
  `sourcetype` int(10) DEFAULT NULL COMMENT '数据来源 1：网格系统录入，2：大数据，3：地市收集，4：省公司收集，5：CRM，6：互联网',
  `status` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '状态:有效1/无效0/已删除2/待审批3/离网4/潜在5/集团预销户6',
  `is_confirmed` bit(1) DEFAULT NULL COMMENT '是否已确认 1、已确认 0、未确认',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_biz_enterprise_m_unique_key_code` (`code`) USING BTREE,
  KEY `index_biz_enterprise_m_grid_code` (`grid_code`) USING BTREE,
  SPATIAL KEY `spatIdx` (`bundary_coordinates`),
  KEY `index_biz_enterprise_m_area_code` (`city_code`) USING BTREE,
  KEY `index_biz_enterprise_m_cnty_code` (`district_code`) USING BTREE,
  FULLTEXT KEY `ftindex_enterprise_name` (`name`) /*!50100 WITH PARSER `ngram` */ 
) ENGINE=InnoDB AUTO_INCREMENT=798135 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='集团表';

-- ----------------------------
-- Table structure for t_biz_flow_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_flow_m`;
CREATE TABLE `t_biz_flow_m` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编码',
  `flow_name` varchar(200) DEFAULT NULL COMMENT '流量名称',
  `flow_type` varchar(50) DEFAULT NULL COMMENT '流量类型',
  `a_ne_id` int(11) DEFAULT NULL COMMENT '源网元编号',
  `a_ne_port_id` int(11) DEFAULT NULL COMMENT '源网元端口编号',
  `z_ne_id` int(11) DEFAULT NULL COMMENT '宿网元编号',
  `z_ne_port_id` int(11) DEFAULT NULL COMMENT '宿网元端口编号',
  `avg_bw` decimal(10,2) DEFAULT NULL COMMENT '均值带宽',
  `peak_bw` decimal(10,2) DEFAULT NULL COMMENT '峰值带宽',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='流量表';

-- ----------------------------
-- Table structure for t_biz_grid_staff_e
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_grid_staff_e`;
CREATE TABLE `t_biz_grid_staff_e` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `grid_code` varchar(50) NOT NULL COMMENT '微网格编码',
  `code` varchar(50) DEFAULT NULL COMMENT '责任人工号',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '责任人姓名',
  `type` int(10) DEFAULT NULL COMMENT '职责类型，1=销售经理,2=商企经理',
  `portal` varchar(50) DEFAULT NULL COMMENT '责任人portal账号',
  `telephone` varchar(50) DEFAULT NULL COMMENT '电话号码',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_biz_grid_staff_unique_key_grid_code_code_name` (`grid_code`,`name`,`portal`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=31090 DEFAULT CHARSET=utf8mb4 COMMENT='网格工作人员表';

-- ----------------------------
-- Table structure for t_biz_handle_record_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_handle_record_m`;
CREATE TABLE `t_biz_handle_record_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '区域编码',
  `phone` varchar(50) NOT NULL COMMENT '手机号',
  `order_number` varchar(50) NOT NULL COMMENT '订单流水号(能开系统受理记录唯一编码)',
  `city_code` varchar(50) DEFAULT NULL COMMENT '归属地市',
  `business_type` varchar(50) DEFAULT NULL COMMENT '商机类型',
  `uptown_code` varchar(50) DEFAULT NULL COMMENT '归属小区编码',
  `install_address` varchar(200) DEFAULT NULL COMMENT '安装地址',
  `handle_package` varchar(200) DEFAULT NULL COMMENT '受理套餐信息',
  `status` varchar(50) NOT NULL COMMENT '订单状态 0订单未提交 1订单执行中 2订单已领单  3 办理成功(订单执行完毕) 4其它情况 5办理失败,6订单提交失败 ',
  `handle_time` datetime NOT NULL COMMENT '受理时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  `business_id` varchar(255) DEFAULT NULL COMMENT '网格侧业务流水号',
  `order_channel` int(3) DEFAULT '0' COMMENT '订单受理渠道 1 crm  2随身厅',
  `market_result_id` bigint(20) DEFAULT NULL COMMENT '对应营销结果表id',
  `mobile_hall_status` varchar(100) DEFAULT NULL COMMENT '随身厅返回标识',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_biz_handle_record_unique_key_phone_handle_time` (`phone`,`handle_time`) USING BTREE,
  KEY `index_biz_handle_record_handle_time` (`handle_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COMMENT='商机受理记录表';

-- ----------------------------
-- Table structure for t_biz_install_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_install_m`;
CREATE TABLE `t_biz_install_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id主键',
  `grid_code` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '网格编码',
  `joborder_flow` varchar(200) NOT NULL COMMENT '工单流水',
  `joborder_number` varchar(200) DEFAULT NULL COMMENT '工单号',
  `callin_number` varchar(200) DEFAULT NULL COMMENT '呼入号码',
  `accept_time` date DEFAULT NULL COMMENT '受理时间',
  `uptown_code` varchar(50) DEFAULT NULL COMMENT '小区编码',
  `branch_office` varchar(200) DEFAULT NULL COMMENT '分公司',
  `order_status` varchar(50) DEFAULT NULL COMMENT '工单状态',
  `phone_price` varchar(200) DEFAULT NULL COMMENT '套餐类型',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_install_unique_key_joborder_flow` (`joborder_flow`) USING BTREE,
  KEY `t_install_callin_number` (`callin_number`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='报装数据表';

-- ----------------------------
-- Table structure for t_biz_interview_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_interview_m`;
CREATE TABLE `t_biz_interview_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `type` varchar(50) DEFAULT NULL COMMENT '类型（企业:enterprise,小区:uptown）',
  `uptown_code` varchar(50) DEFAULT NULL COMMENT '家客小区编码',
  `building_code` varchar(50) DEFAULT NULL COMMENT '楼宇编码',
  `minor_enterprise_code` varchar(50) DEFAULT NULL COMMENT '中小企业或者集客编码',
  `title` varchar(200) DEFAULT NULL COMMENT '走访标题',
  `uptown_buildings_code` varchar(50) DEFAULT NULL COMMENT '楼栋编号',
  `uptown_buildings_unit_code` varchar(50) DEFAULT NULL COMMENT '单元编号',
  `room_number` varchar(1000) DEFAULT NULL COMMENT '房间号',
  `code` varchar(50) DEFAULT NULL COMMENT '走访工号',
  `name` varchar(50) DEFAULT NULL COMMENT '走访人',
  `interview_time` datetime DEFAULT NULL COMMENT '走访时间',
  `record` varchar(500) DEFAULT NULL COMMENT '走访记录',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_t_biz_interview_unique_code_interview_time` (`code`,`interview_time`) USING BTREE COMMENT '走访工号,走访时间',
  KEY `index_biz_interview_uptown_code` (`uptown_code`),
  KEY `index_biz_interview_building_code` (`building_code`),
  KEY `index_biz_interview_minor_enterprise_code` (`minor_enterprise_code`),
  KEY `index_biz_interview_interview_time` (`interview_time`)
) ENGINE=InnoDB AUTO_INCREMENT=221 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='走访记录表';

-- ----------------------------
-- Table structure for t_biz_marketing_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_marketing_m`;
CREATE TABLE `t_biz_marketing_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `code` varchar(50) NOT NULL COMMENT '营销活动编码',
  `name` varchar(200) DEFAULT NULL COMMENT '营销活动名称',
  `begin_time` datetime DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_biz_marketing_m_unique_key_code` (`code`),
  KEY `index_biz_marketing_m_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COMMENT='营销活动表';

-- ----------------------------
-- Table structure for t_biz_marketing_result_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_marketing_result_m`;
CREATE TABLE `t_biz_marketing_result_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '区域编码',
  `phone` varchar(50) NOT NULL COMMENT '手机号',
  `result` varchar(50) DEFAULT NULL COMMENT '处理结果',
  `is_bw` bit(1) DEFAULT NULL COMMENT '我网宽带',
  `is_magicbai` bit(1) DEFAULT NULL COMMENT '魔百和',
  `is_voice_rc` bit(1) DEFAULT NULL COMMENT '语音遥控器',
  `is_family_network` bit(1) DEFAULT NULL COMMENT '亲情网',
  `is_share_flow` bit(1) DEFAULT NULL COMMENT '流量共享',
  `is_lovefamily_package` bit(1) DEFAULT NULL COMMENT '爱家套餐',
  `is_family_fixedline` bit(1) DEFAULT NULL COMMENT '家庭固话',
  `is_rearview_mirror` bit(1) DEFAULT NULL COMMENT '后视镜',
  `is_vehicleowner_service` bit(1) DEFAULT NULL COMMENT '车主服务',
  `is_hemu` bit(1) DEFAULT NULL COMMENT '和目',
  `marketing_time` datetime NOT NULL COMMENT '营销时间',
  `marketing_number` varchar(100) DEFAULT NULL COMMENT '营销人员工号',
  `marketing_name` varchar(100) DEFAULT NULL COMMENT '营销人员姓名',
  `call_uuid` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '内部外呼流水号',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  `operation` varchar(255) DEFAULT NULL COMMENT '用户操作',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `index_biz_marketing_result_phone` (`phone`),
  KEY `index_biz_marketing_result_marketing_time` (`marketing_time`),
  KEY `index_biz_marketing_result_phone_marketing_time` (`phone`,`marketing_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=153 DEFAULT CHARSET=utf8mb4 COMMENT='营销结果表';

-- ----------------------------
-- Table structure for t_biz_mobile_effectiveuser_statistics
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_mobile_effectiveuser_statistics`;
CREATE TABLE `t_biz_mobile_effectiveuser_statistics` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `gird_code` varchar(50) DEFAULT NULL COMMENT '网格编码',
  `field` varchar(50) DEFAULT NULL COMMENT '责任田编码',
  `effectiveuser_statistics` int(11) DEFAULT NULL COMMENT '移动有效个人用户统计数',
  `create_user` varchar(50) NOT NULL DEFAULT '' COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_mobile_effectiveuser_statistics_unique_key_field` (`field`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='移动有效个人客户统计表';

-- ----------------------------
-- Table structure for t_biz_other_broadband_install_info_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_other_broadband_install_info_m`;
CREATE TABLE `t_biz_other_broadband_install_info_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `grid_code` varchar(50) NOT NULL COMMENT '区域编码',
  `city_code` varchar(50) NOT NULL COMMENT '归属地市编码，如：SD.LA',
  `county_code` varchar(50) DEFAULT NULL COMMENT '归属区县编码, 如：SD.LA.001',
  `county_name` varchar(200) DEFAULT NULL COMMENT '区县名称',
  `depart_name` varchar(200) DEFAULT NULL COMMENT '经营部名称',
  `micro_name` varchar(200) DEFAULT NULL COMMENT '网格名称',
  `is_over` varchar(50) DEFAULT NULL COMMENT '是否我网资源覆盖',
  `community_name` varchar(200) DEFAULT NULL COMMENT '社区名称',
  `community_code` varchar(100) NOT NULL COMMENT '社区编码（九级编码）',
  `build` varchar(100) NOT NULL COMMENT '楼号',
  `unit` varchar(100) NOT NULL COMMENT '单元号',
  `doorplate` varchar(50) NOT NULL COMMENT '门牌号',
  `broadband_type` varchar(50) DEFAULT NULL COMMENT '家宽类型',
  `efficacy_time` datetime DEFAULT NULL COMMENT '失效时间',
  `phone1` varchar(20) DEFAULT NULL COMMENT '手机号1',
  `phone2` varchar(20) DEFAULT NULL COMMENT '手机号2',
  `phone3` varchar(20) DEFAULT NULL COMMENT '手机号3',
  `is_decorate` varchar(50) DEFAULT NULL COMMENT '是否装修',
  `is_hire` varchar(50) DEFAULT NULL COMMENT '是否出租',
  `householder_name` varchar(100) DEFAULT NULL COMMENT '户主姓名',
  `family_members` varchar(50) DEFAULT NULL COMMENT '家庭成员数',
  `is_older` varchar(50) DEFAULT NULL COMMENT '是否有老人',
  `is_child` varchar(50) DEFAULT NULL COMMENT '是否有儿童',
  `child_age` varchar(50) DEFAULT NULL COMMENT '儿童年龄段',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `all_parent_code` varchar(255) NOT NULL COMMENT '完整区域地址，如：SD,SD.LA',
  `oper_user` varchar(50) NOT NULL COMMENT '导入人工号',
  `oper_date` datetime DEFAULT NULL COMMENT '导入时间',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `patch_no` varchar(10) NOT NULL COMMENT '导入批次号',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='异网宽带安装信息表';

-- ----------------------------
-- Table structure for t_biz_other_broadband_install_match
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_other_broadband_install_match`;
CREATE TABLE `t_biz_other_broadband_install_match` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `grid_code` varchar(50) NOT NULL COMMENT '区域编码',
  `city_code` varchar(50) NOT NULL COMMENT '归属地市编码，如：SD.LA',
  `county_code` varchar(50) DEFAULT NULL COMMENT '归属区县编码, 如：SD.LA.001',
  `depart_code` varchar(50) DEFAULT NULL COMMENT '经营部编码',
  `micro_code` varchar(50) DEFAULT NULL COMMENT '网格编码',
  `is_over` varchar(50) DEFAULT NULL COMMENT '是否我网资源覆盖',
  `uptown_name` varchar(200) DEFAULT NULL COMMENT '社区名称',
  `uptown_code` varchar(100) NOT NULL COMMENT '社区编码（九级编码）',
  `build_code` varchar(50) NOT NULL COMMENT '楼栋编号',
  `build_name` varchar(50) NOT NULL COMMENT '楼栋名称',
  `unit_code` varchar(100) NOT NULL COMMENT '单元编号',
  `household` varchar(50) NOT NULL COMMENT '房间号',
  `broadband_type` varchar(50) DEFAULT NULL COMMENT '家宽类型',
  `efficacy_time` datetime DEFAULT NULL COMMENT '失效时间',
  `phone1` varchar(20) DEFAULT NULL COMMENT '手机号1',
  `phone2` varchar(20) DEFAULT NULL COMMENT '手机号2',
  `phone3` varchar(20) DEFAULT NULL COMMENT '手机号3',
  `is_decorate` varchar(50) DEFAULT NULL COMMENT '是否装修',
  `is_hire` varchar(50) DEFAULT NULL COMMENT '是否出租',
  `householder_name` varchar(100) DEFAULT NULL COMMENT '户主姓名',
  `family_members` varchar(50) DEFAULT NULL COMMENT '家庭成员数',
  `is_older` varchar(50) DEFAULT NULL COMMENT '是否有老人',
  `is_child` varchar(50) DEFAULT NULL COMMENT '是否有儿童',
  `child_age` varchar(50) DEFAULT NULL COMMENT '儿童年龄段',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `all_parent_code` varchar(255) NOT NULL COMMENT '完整区域地址，如：SD,SD.LA',
  `match_user` varchar(50) NOT NULL COMMENT '匹配人工号',
  `match_date` datetime DEFAULT NULL COMMENT '匹配时间',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `patch_no` varchar(10) NOT NULL COMMENT '导入批次号',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='小区异网宽带安装信息匹配结果表';

-- ----------------------------
-- Table structure for t_biz_other_broadband_install_nomatch
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_other_broadband_install_nomatch`;
CREATE TABLE `t_biz_other_broadband_install_nomatch` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `info_id` bigint(20) NOT NULL COMMENT '导入记录Id',
  `grid_code` varchar(50) NOT NULL COMMENT '区域编码',
  `city_code` varchar(50) NOT NULL COMMENT '归属地市编码，如：SD.LA',
  `county_code` varchar(50) DEFAULT NULL COMMENT '归属区县编码, 如：SD.LA.001',
  `county_name` varchar(200) DEFAULT NULL COMMENT '区县名称',
  `depart_name` varchar(200) DEFAULT NULL COMMENT '经营部名称',
  `micro_name` varchar(200) DEFAULT NULL COMMENT '网格名称',
  `is_over` varchar(50) DEFAULT NULL COMMENT '是否我网资源覆盖',
  `community_name` varchar(200) DEFAULT NULL COMMENT '社区名称',
  `community_code` varchar(100) NOT NULL COMMENT '社区编码（九级编码）',
  `build` varchar(100) NOT NULL COMMENT '楼号',
  `unit` varchar(100) NOT NULL COMMENT '单元号',
  `doorplate` varchar(50) NOT NULL COMMENT '门牌号',
  `broadband_type` varchar(50) DEFAULT NULL COMMENT '家宽类型',
  `efficacy_time` datetime DEFAULT NULL COMMENT '失效时间',
  `phone1` varchar(20) DEFAULT NULL COMMENT '手机号1',
  `phone2` varchar(20) DEFAULT NULL COMMENT '手机号2',
  `phone3` varchar(20) DEFAULT NULL COMMENT '手机号3',
  `is_decorate` varchar(50) DEFAULT NULL COMMENT '是否装修',
  `is_hire` varchar(50) DEFAULT NULL COMMENT '是否出租',
  `householder_name` varchar(100) DEFAULT NULL COMMENT '户主姓名',
  `family_members` varchar(50) DEFAULT NULL COMMENT '家庭成员数',
  `is_older` varchar(50) DEFAULT NULL COMMENT '是否有老人',
  `is_child` varchar(50) DEFAULT NULL COMMENT '是否有儿童',
  `child_age` varchar(50) DEFAULT NULL COMMENT '儿童年龄段',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `all_parent_code` varchar(255) NOT NULL COMMENT '完整区域地址，如：SD,SD.LA',
  `oper_user` varchar(50) NOT NULL COMMENT '导入人工号',
  `oper_date` datetime DEFAULT NULL COMMENT '导入时间',
  `noMatch_reason` varchar(2000) DEFAULT NULL COMMENT '匹配失败原因',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `patch_no` varchar(10) NOT NULL COMMENT '导入批次号',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='小区异网宽带安装信息不匹配结果表';

-- ----------------------------
-- Table structure for t_biz_phone_building
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_phone_building`;
CREATE TABLE `t_biz_phone_building` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `phone` varchar(50) NOT NULL COMMENT '手机号码',
  `building_code` varchar(50) NOT NULL COMMENT '楼宇编码',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_biz_phone_building_unique_phone_building_code` (`phone`,`building_code`) USING BTREE,
  KEY `index_biz_phone_building_phone` (`phone`) USING BTREE,
  KEY `index_biz_phone_building_building_code` (`building_code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COMMENT='手机楼宇关系表';

-- ----------------------------
-- Table structure for t_biz_phone_index_info
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_phone_index_info`;
CREATE TABLE `t_biz_phone_index_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `phone` varchar(50) NOT NULL COMMENT '手机号',
  `name` varchar(50) DEFAULT NULL COMMENT '手机号姓名',
  `city_name` varchar(200) DEFAULT NULL COMMENT '归属地市',
  `package_grade` varchar(50) DEFAULT NULL COMMENT '统一套餐档次',
  `main_products` varchar(100) DEFAULT NULL COMMENT '主体产品',
  `wait_upgrade_grade` varchar(50) DEFAULT NULL COMMENT '待升级流量模组档次',
  `user_grade` varchar(50) DEFAULT NULL COMMENT '全球通用户级别',
  `regionname` varchar(50) DEFAULT NULL COMMENT '区县名称',
  `online_times` int(10) DEFAULT NULL COMMENT '在网时长',
  `customer_star` varchar(50) DEFAULT NULL COMMENT '客户星级',
  `integral` int(10) DEFAULT NULL COMMENT '积分',
  `package_date` date DEFAULT NULL COMMENT '套餐账期日',
  `last_month_arpu` decimal(10,4) DEFAULT NULL COMMENT '上月ARPU值',
  `beforelast_month_arpu` decimal(10,4) DEFAULT NULL COMMENT '上上月ARPU值',
  `three_month_arpu` decimal(10,4) DEFAULT NULL COMMENT '近三个月ARPU值',
  `high_user` varchar(50) DEFAULT NULL COMMENT '中高端用户',
  `handhall_user` varchar(50) DEFAULT NULL COMMENT '掌厅用户',
  `currentmonth_handhall_user` varchar(50) DEFAULT NULL COMMENT '本月掌厅活用用户',
  `school_user` varchar(50) DEFAULT NULL COMMENT '校园用户',
  `non_fourg` varchar(50) DEFAULT NULL COMMENT '2/3G高流量非4G终端',
  `customer_fourg` varchar(50) DEFAULT NULL COMMENT '4G终端非4G资费客户',
  `prestorage_agreement` varchar(50) DEFAULT NULL COMMENT '预存协议款',
  `prestorage_due_time` date DEFAULT NULL COMMENT '协议款到期时间',
  `give_agreement` varchar(50) DEFAULT NULL COMMENT '赠送协议款',
  `give_due_time` date DEFAULT NULL COMMENT '赠送协议款到期时间',
  `last_month_mou` decimal(10,4) DEFAULT NULL COMMENT '上月MOU',
  `beforelast_month_mou` decimal(10,4) DEFAULT NULL COMMENT '上上月MOU',
  `is_happyfamily_user` bit(1) DEFAULT NULL COMMENT '是否欢乐家庭用户',
  `potential_netfamily_customer` varchar(50) DEFAULT NULL COMMENT '家庭网潜在客户',
  `is_use_fourgflow` bit(1) DEFAULT NULL COMMENT '是否产生4G流量',
  `is_order_fourg_flowpackage` bit(1) DEFAULT NULL COMMENT '是否订购4G流量包',
  `overlay_package_grade` decimal(10,4) DEFAULT NULL COMMENT '订购叠加包档次',
  `currentmonth_flow` decimal(10,4) DEFAULT NULL COMMENT '本月产生的流量(MB)',
  `currentmonth_saturation` decimal(10,4) DEFAULT NULL COMMENT '本月流量饱和度',
  `last_month_dou` decimal(10,4) DEFAULT NULL COMMENT '上月DOU',
  `beforelast_month_dou` decimal(10,4) DEFAULT NULL,
  `is_exceedpackage_user` bit(1) DEFAULT NULL COMMENT '是否超套餐用户',
  `migu_music_member` varchar(50) DEFAULT NULL COMMENT '咪咕音乐会员',
  `kind_comic_user` varchar(50) DEFAULT NULL COMMENT '和动漫用户',
  `is_read` bit(1) DEFAULT NULL COMMENT '阅读偏好',
  `crbt` varchar(50) DEFAULT NULL COMMENT '彩铃',
  `kind_read_user` varchar(50) DEFAULT NULL COMMENT '和阅读用户',
  `is_music` bit(1) DEFAULT NULL COMMENT '音乐偏好',
  `email` varchar(50) DEFAULT NULL COMMENT '139邮箱',
  `bw_status` varchar(50) DEFAULT NULL COMMENT '宽带当前状态',
  `bw_customer_type` varchar(50) DEFAULT NULL COMMENT '宽带客户类型',
  `bw_bandwidth` int(10) DEFAULT NULL COMMENT '宽带带宽',
  `bw_due_days` int(10) DEFAULT NULL COMMENT '宽带到期天数',
  `is_install_magicbai` bit(1) DEFAULT NULL COMMENT '历史上是否安装过魔百和',
  `magicbai_install_time` datetime DEFAULT NULL COMMENT '魔百和安装时间',
  `magicbai_due_time` datetime DEFAULT NULL COMMENT '魔百和到期时间',
  `terminal_model` varchar(50) DEFAULT NULL COMMENT '终端型号',
  `terminal_type` varchar(50) DEFAULT NULL COMMENT '终端类型',
  `terminal_use_times` int(10) DEFAULT NULL COMMENT '合约机使用时长(月)',
  `contractphone_due_days` int(10) DEFAULT NULL COMMENT '合约机到期天数',
  `min_consumption` decimal(10,4) DEFAULT NULL COMMENT '保底消费额度',
  `consumption_due_time` datetime DEFAULT NULL COMMENT '保底消费到期时间',
  `statistics_time` date NOT NULL COMMENT '统计时间',
  `bw_busi_num` int(10) DEFAULT NULL COMMENT '宽带商机',
  `value_added_num` int(10) DEFAULT NULL COMMENT '增值业务',
  `family_busi_num` int(10) DEFAULT NULL COMMENT '家庭商机',
  `connect_num_15days` int(10) DEFAULT NULL COMMENT '10085接通次数(15天)',
  `connect_num_30days` int(10) DEFAULT NULL COMMENT '10085接通次数(30天)',
  `connect_num_60days` int(10) DEFAULT NULL COMMENT '10085接通次数(60天)',
  `complaint_num_last_month` int(10) DEFAULT NULL COMMENT '最近1个月投诉次数',
  `complaint_num_last_three_months` int(10) DEFAULT NULL COMMENT '最近3个月投诉次数',
  `complaint_num_last_six_months` int(10) DEFAULT NULL COMMENT '最近6个月投诉次数',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_biz_phone_index_info_unique_key_phone_statistics_time` (`phone`,`statistics_time`),
  KEY `index_biz_phone_index_info_phone` (`phone`),
  KEY `index_biz_phone_index_info_statistics_time` (`statistics_time`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COMMENT='手机个人指标信息表';

-- ----------------------------
-- Table structure for t_biz_phone_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_phone_m`;
CREATE TABLE `t_biz_phone_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `phone` varchar(50) DEFAULT NULL COMMENT '手机号',
  `bw_account` varchar(50) DEFAULT NULL COMMENT '宽带账户',
  `user_name` varchar(200) DEFAULT NULL COMMENT '姓名',
  `age` varchar(50) DEFAULT NULL COMMENT '年龄',
  `sex` varchar(50) DEFAULT NULL COMMENT '性别',
  `role` varchar(50) DEFAULT NULL COMMENT '角色（是否是主值号）：主号码，成员',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '网格编码',
  `uptown_code` varchar(50) DEFAULT NULL COMMENT '小区编码',
  `bw` int(11) DEFAULT NULL COMMENT '宽带带宽',
  `phone_price` varchar(50) DEFAULT NULL COMMENT '手机套餐资费',
  `imsi` varchar(50) DEFAULT NULL COMMENT 'IMSI码',
  `collect_date` datetime DEFAULT NULL COMMENT '数据日期',
  `avg_dou` decimal(10,4) DEFAULT NULL COMMENT '平均DOU',
  `avg_arpu` decimal(10,4) DEFAULT NULL COMMENT '平均ARPU',
  `brand` varchar(50) DEFAULT NULL COMMENT '品牌',
  `city_code` varchar(50) DEFAULT NULL COMMENT '所属城市编码',
  `sector_coordinates` geometry DEFAULT NULL COMMENT '所属基站经纬度',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_biz_phone_unique_key_phone` (`phone`) USING BTREE,
  KEY `index_biz_phone_phone` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='手机基本信息表';

-- ----------------------------
-- Table structure for t_biz_phone_marketing
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_phone_marketing`;
CREATE TABLE `t_biz_phone_marketing` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `phone` varchar(50) NOT NULL COMMENT '手机号码',
  `marketing_code` varchar(50) NOT NULL COMMENT '营销活动编码',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_biz_phone_marketing_unique_phone_marketing_code` (`phone`,`marketing_code`) USING BTREE,
  KEY `index_biz_phone_marketing_phone` (`phone`) USING BTREE,
  KEY `index_biz_phone_marketing_marketing_code` (`marketing_code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='手机营销活动关系表';

-- ----------------------------
-- Table structure for t_biz_phone_marketing_record
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_phone_marketing_record`;
CREATE TABLE `t_biz_phone_marketing_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `phone` varchar(50) NOT NULL COMMENT '模板编码',
  `marketing_code` varchar(50) DEFAULT NULL COMMENT '营销活动编码',
  `template_code` varchar(50) DEFAULT NULL COMMENT '短信模板编码',
  `send_time` datetime DEFAULT NULL COMMENT '发送时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_biz_phone_marketing_record_unique_phone_market_templ_send` (`phone`,`marketing_code`,`template_code`,`send_time`) USING BTREE,
  KEY `index_biz_phone_marketing_record_phone` (`phone`),
  KEY `index_biz_phone_marketing_record_marketing_code` (`marketing_code`),
  KEY `index_biz_phone_marketing_record_template_code` (`template_code`),
  KEY `index_biz_phone_marketing_record_send_time` (`send_time`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COMMENT='手机营销记录表';

-- ----------------------------
-- Table structure for t_biz_port_currentflow_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_port_currentflow_m`;
CREATE TABLE `t_biz_port_currentflow_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `code` varchar(50) DEFAULT NULL COMMENT '端口编码',
  `name` varchar(200) DEFAULT NULL COMMENT '端口名称',
  `type` varchar(50) DEFAULT NULL COMMENT '端口类型',
  `ne_name` varchar(200) NOT NULL COMMENT '网元名称',
  `seq` varchar(50) DEFAULT NULL COMMENT '端口序号',
  `max_rate` decimal(10,4) DEFAULT NULL COMMENT '端口峰值带宽利用率',
  `exceed_times_count` int(11) DEFAULT NULL COMMENT '超越次数',
  `statistical_month` varchar(50) NOT NULL COMMENT '统计月份',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_biz_port_currentflow_ne_name_sdtatistical_month` (`ne_name`,`statistical_month`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='端口现网流量表';

-- ----------------------------
-- Table structure for t_biz_resource_statistics
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_resource_statistics`;
CREATE TABLE `t_biz_resource_statistics` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `grid_code` varchar(50) NOT NULL COMMENT '区域编码',
  `resource_code` varchar(50) NOT NULL COMMENT '资源编码',
  `resource_type` varchar(50) NOT NULL COMMENT '资源类型：village/uptown/enterpirse/website/building/qrcodesite/sector/station/minorenterprise',
  `key` varchar(100) NOT NULL COMMENT '键',
  `value` varchar(200) NOT NULL COMMENT '值',
  `group` varchar(200) DEFAULT NULL COMMENT '组别',
  `statistics_time` date NOT NULL COMMENT '统计时间',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `index_village_statistics_village_code` (`resource_code`) USING BTREE,
  KEY `index_village_statistics_unique_key_grid_code` (`resource_code`,`key`,`statistics_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='资源统计扩展键值表';

-- ----------------------------
-- Table structure for t_biz_resource_statistics_displayconfig
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_resource_statistics_displayconfig`;
CREATE TABLE `t_biz_resource_statistics_displayconfig` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `resource_type` varchar(50) DEFAULT NULL COMMENT '资源类型：village/uptown/enterpirse/website/building/qrcodesite/sector/station/minorenterprise',
  `resource_statistics_key` varchar(100) NOT NULL COMMENT '键',
  `seq` int(10) DEFAULT NULL COMMENT '序号,用于配置显示顺序',
  `name` varchar(200) NOT NULL COMMENT '名称',
  `group` varchar(200) DEFAULT NULL COMMENT '组别:用于多页签显示',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_resource_statistics_displayconfig_unique_resource_type` (`resource_type`,`resource_statistics_key`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='资源统计扩展键值显示配置表';

-- ----------------------------
-- Table structure for t_biz_sector
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_sector`;
CREATE TABLE `t_biz_sector` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '区域编码',
  `station_code` varchar(100) DEFAULT NULL COMMENT '基站编码或者ID',
  `station_name` varchar(200) DEFAULT NULL COMMENT '基站名称',
  `cgi` varchar(200) NOT NULL COMMENT 'CGI',
  `bs_code` varchar(200) DEFAULT NULL COMMENT '基站名称',
  `bs_name` varchar(200) DEFAULT NULL COMMENT '位置代码LOCAL_CD（十六进制）',
  `bs_full_name` varchar(200) DEFAULT NULL COMMENT '镇名称',
  `city_code` varchar(50) DEFAULT NULL COMMENT '城市编码',
  `city_name` varchar(200) DEFAULT NULL COMMENT '城市名称',
  `district_code` varchar(50) DEFAULT NULL COMMENT '区县编码',
  `district_name` varchar(200) DEFAULT NULL COMMENT '区县名称',
  `county_name` varchar(200) DEFAULT NULL COMMENT '覆盖类型',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `bundary_coordinates` geometry NOT NULL,
  `cover_type` varchar(50) DEFAULT NULL COMMENT '覆盖类型',
  `net_type` varchar(50) DEFAULT NULL COMMENT '网络类型',
  `loc_code` varchar(100) DEFAULT NULL COMMENT '位置代码',
  `cell_code` varchar(100) DEFAULT NULL COMMENT '扇区代码',
  `cell_name` varchar(200) DEFAULT NULL COMMENT '扇区名称',
  `cell_ci` varchar(100) DEFAULT NULL,
  `status` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '状态:有效1/无效0/已删除2/待审批3/离网4/潜在5/集团预销户6',
  `is_confirmed` bit(1) DEFAULT NULL COMMENT '是否已确认 1、已确认 0、未确认',
  `sourcetype` int(10) DEFAULT NULL COMMENT '数据来源 1：网格系统录入，2：大数据，3：地市收集，4：省公司收集，5：CRM，6：互联网',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_biz_sector_station_unique_key_cgi` (`cgi`) USING BTREE,
  KEY `index_biz_sector_station_grid_code` (`grid_code`) USING BTREE,
  KEY `index_grid_code` (`grid_code`) USING BTREE,
  KEY `index_biz_sector_station_code` (`station_code`) USING BTREE,
  KEY `index_biz_sector_cnty_code` (`district_code`) USING BTREE,
  SPATIAL KEY `spatIdx` (`bundary_coordinates`),
  KEY `index_biz_sector_area_code` (`city_code`) USING BTREE,
  KEY `index_biz_sector_status` (`status`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=987398 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='扇区表';

-- ----------------------------
-- Table structure for t_biz_sector_copy
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_sector_copy`;
CREATE TABLE `t_biz_sector_copy` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '区域编码',
  `station_code` varchar(100) DEFAULT NULL COMMENT '基站编码或者ID',
  `station_name` varchar(200) DEFAULT NULL COMMENT '基站名称',
  `cgi` varchar(200) NOT NULL COMMENT 'CGI',
  `bs_code` varchar(200) DEFAULT NULL COMMENT '基站名称',
  `bs_name` varchar(200) DEFAULT NULL COMMENT '位置代码LOCAL_CD（十六进制）',
  `bs_full_name` varchar(200) DEFAULT NULL COMMENT '镇名称',
  `city_name` varchar(200) DEFAULT NULL COMMENT '镇代码',
  `area_code` varchar(50) DEFAULT NULL COMMENT '城市编码',
  `area_name` varchar(200) DEFAULT NULL COMMENT '城市名称',
  `cnty_code` varchar(50) DEFAULT NULL COMMENT '区县编码',
  `cnty_name` varchar(200) DEFAULT NULL COMMENT '区县名称',
  `county_name` varchar(200) DEFAULT NULL COMMENT '覆盖类型',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `bundary_coordinates` geometry NOT NULL COMMENT '边界坐标',
  `cover_type` varchar(50) DEFAULT NULL COMMENT '覆盖类型',
  `net_type` varchar(50) DEFAULT NULL COMMENT '网络类型',
  `loc_code` varchar(100) DEFAULT NULL COMMENT '位置代码',
  `cell_code` varchar(100) DEFAULT NULL COMMENT '扇区代码',
  `cell_name` varchar(200) DEFAULT NULL COMMENT '扇区名称',
  `cell_ci` varchar(100) DEFAULT NULL,
  `status` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '状态:有效1/无效0/已删除2/待审批3/离网4/潜在5/集团预销户6',
  `is_confirmed` bit(1) DEFAULT NULL COMMENT '是否已确认 1、已确认 0、未确认',
  `sourcetype` int(10) DEFAULT NULL COMMENT '数据来源 1：网格系统录入，2：大数据，3：地市收集，4：省公司收集，5：CRM，6：互联网',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_biz_sector_station_unique_key_cgi` (`cgi`) USING BTREE,
  SPATIAL KEY `spatIdx` (`bundary_coordinates`),
  KEY `index_biz_sector_station_grid_code` (`grid_code`) USING BTREE,
  KEY `index_grid_code` (`grid_code`) USING BTREE,
  KEY `index_biz_sector_station_code` (`station_code`) USING BTREE,
  KEY `index_biz_sector_area_code` (`area_code`) USING BTREE,
  KEY `index_biz_sector_cnty_code` (`cnty_code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1816665 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='扇区表';

-- ----------------------------
-- Table structure for t_biz_sector_resource
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_sector_resource`;
CREATE TABLE `t_biz_sector_resource` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `cgi` varchar(200) DEFAULT NULL COMMENT 'CGI',
  `resource_type` varchar(50) DEFAULT NULL COMMENT '资源点类型(building/uptown/website/minorenterprise等)',
  `resource_code` varchar(50) DEFAULT NULL COMMENT '资源点编码(楼宇、家宽小区、渠道、中小企业等)',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_biz_sector_resource_unique_station_cell_restype_rescode` (`resource_type`,`resource_code`,`cgi`) USING BTREE,
  KEY `index_biz_sector_resource_resource_code` (`resource_code`),
  KEY `index_biz_sector_resource_cgi` (`cgi`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='基站资源点表';

-- ----------------------------
-- Table structure for t_biz_sector_test
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_sector_test`;
CREATE TABLE `t_biz_sector_test` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '区域编码',
  `station_code` varchar(100) DEFAULT NULL COMMENT '基站编码或者ID',
  `station_name` varchar(200) DEFAULT NULL COMMENT '基站名称',
  `cgi` varchar(200) NOT NULL COMMENT 'CGI',
  `bs_code` varchar(200) DEFAULT NULL COMMENT '基站名称',
  `bs_name` varchar(200) DEFAULT NULL COMMENT '位置代码LOCAL_CD（十六进制）',
  `bs_full_name` varchar(200) DEFAULT NULL COMMENT '镇名称',
  `city_name` varchar(200) DEFAULT NULL COMMENT '镇代码',
  `county_name` varchar(200) DEFAULT NULL COMMENT '覆盖类型',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `bundary_coordinates` geometry NOT NULL COMMENT '边界坐标',
  `cover_type` varchar(50) DEFAULT NULL COMMENT '覆盖类型',
  `net_type` varchar(50) DEFAULT NULL COMMENT '网络类型',
  `loc_code` varchar(100) DEFAULT NULL COMMENT '位置代码',
  `cell_code` varchar(100) DEFAULT NULL COMMENT '扇区代码',
  `cell_name` varchar(200) DEFAULT NULL COMMENT '扇区名称',
  `cell_ci` varchar(100) DEFAULT NULL,
  `status` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '状态:有效1/无效0/已删除2/待审批3/离网4/潜在5/集团预销户6',
  `is_confirmed` bit(1) DEFAULT NULL COMMENT '是否已确认 1、已确认 0、未确认',
  `sourcetype` int(10) DEFAULT NULL COMMENT '数据来源 1：网格系统录入，2：大数据，3：地市收集，4：省公司收集，5：CRM，6：互联网',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_biz_sector_station_unique_key_cgi` (`cgi`) USING BTREE,
  KEY `spatIdx` (`bundary_coordinates`(32))
) ENGINE=InnoDB AUTO_INCREMENT=1745752 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for t_biz_sector_users
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_sector_users`;
CREATE TABLE `t_biz_sector_users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '区域编码',
  `cgi` varchar(200) DEFAULT NULL COMMENT 'CGI',
  `bts_type` varchar(50) DEFAULT NULL COMMENT '类型:1 工作时间,2 休息时间',
  `user_nums` int(10) DEFAULT NULL COMMENT '用户数',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_biz_sector_users_unique_key_cgi` (`cgi`,`bts_type`) USING BTREE,
  KEY `index_biz_sector_users_grid_code` (`grid_code`) USING BTREE,
  KEY `index_biz_sector_users_cgi` (`cgi`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1127221 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='基站用户数';

-- ----------------------------
-- Table structure for t_biz_sig_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_sig_m`;
CREATE TABLE `t_biz_sig_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '网格编码',
  `bw_account` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '宽带账户',
  `bw_account_encrypt` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '宽带账户加密',
  `bw_usagedays` int(10) NOT NULL COMMENT '宽带使用天数',
  `differentbw_number_count` int(10) DEFAULT NULL COMMENT '宽带账号下异网号码数量',
  `differentbw_number` varchar(50) DEFAULT NULL COMMENT '异网号码',
  `differentbw_operator` varchar(50) DEFAULT NULL COMMENT '异网号码运营商',
  `differentbw_location` varchar(200) DEFAULT NULL COMMENT '异网号码归属地',
  `differentbw_usagedays` int(10) DEFAULT NULL COMMENT '异网号码出现天数',
  `differentbw_households` int(10) DEFAULT NULL COMMENT '异网号码出现家庭数',
  `bras` varchar(50) DEFAULT NULL COMMENT 'BRAS',
  `statistical_month` varchar(50) DEFAULT NULL COMMENT '统计月份',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `test` (`bw_account`,`bw_usagedays`) USING BTREE,
  KEY `index_sig_bw_account` (`bw_account`) USING BTREE,
  KEY `index_sig_bw_account_encrypt` (`bw_account_encrypt`) USING BTREE,
  KEY `index_sig_bw_account_unique_key_differentbw_number_statistical_` (`differentbw_number`,`statistical_month`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='SIG数据表';

-- ----------------------------
-- Table structure for t_biz_smallfamily_phone_detail_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_smallfamily_phone_detail_m`;
CREATE TABLE `t_biz_smallfamily_phone_detail_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `phone` varchar(50) NOT NULL COMMENT '手机号',
  `smallfamily_code` varchar(50) NOT NULL COMMENT '小家庭编码',
  `avg_dou` decimal(10,1) DEFAULT NULL COMMENT '平均DOU',
  `avg_arpu` decimal(10,1) DEFAULT NULL COMMENT '平均ARPU',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  `sex` varchar(50) DEFAULT NULL COMMENT '性别',
  `city_name` varchar(200) DEFAULT NULL COMMENT '归属地市',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_smallfamily_phone_detail_unique_key_phone_smallfamily_code` (`phone`,`smallfamily_code`) USING BTREE,
  KEY `index_smallfamily_phone_detail_smallfamily_code` (`smallfamily_code`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='家庭商机小家庭手机明细表';

-- ----------------------------
-- Table structure for t_biz_smallfamily_phone_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_smallfamily_phone_m`;
CREATE TABLE `t_biz_smallfamily_phone_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `grid_code` varchar(50) NOT NULL COMMENT '微网格编码',
  `phone` varchar(50) NOT NULL COMMENT '手机号',
  `city_name` varchar(200) DEFAULT NULL COMMENT '归属地市',
  `is_local` bit(1) DEFAULT NULL COMMENT '是否本地市 1是 0否',
  `name` varchar(50) DEFAULT NULL COMMENT '家庭主号姓名',
  `uptown_code` varchar(50) DEFAULT NULL COMMENT '小区编码',
  `uptown_name` varchar(200) DEFAULT NULL COMMENT '小区名称',
  `uptown_level` varchar(50) DEFAULT NULL COMMENT '小区等级类型:高价值小区、低占小区、空白小区',
  `phone_coordinates` geometry DEFAULT NULL COMMENT '用户位置经纬度',
  `bigfamily_code` varchar(50) DEFAULT NULL COMMENT '大家庭编码',
  `smallfamily_code` varchar(50) DEFAULT NULL COMMENT '小家庭编码',
  `bw_busi_num` int(10) DEFAULT NULL COMMENT '宽带商机',
  `value_added_num` int(10) DEFAULT NULL COMMENT '增值业务',
  `family_busi_num` int(10) DEFAULT NULL COMMENT '家庭商机',
  `is_bw` bit(1) DEFAULT NULL COMMENT '我网宽带',
  `is_diffnet_bw` bit(1) DEFAULT NULL COMMENT '异网宽带',
  `is_potential_bw` bit(1) DEFAULT NULL COMMENT '潜在宽带',
  `is_magicbai` bit(1) DEFAULT NULL COMMENT '魔百和业务',
  `is_voice_rc` bit(1) DEFAULT NULL COMMENT '语音遥控器',
  `is_family_network` bit(1) DEFAULT NULL COMMENT '亲情网',
  `is_lovefamily_package` bit(1) DEFAULT NULL COMMENT '爱家套餐',
  `is_family_fixedline` bit(1) DEFAULT NULL COMMENT '家庭固话',
  `is_rearview_mirror` bit(1) DEFAULT NULL COMMENT '后视镜',
  `is_vehicleowner_service` bit(1) DEFAULT NULL COMMENT '车主服务',
  `is_hemu` bit(1) DEFAULT NULL COMMENT '和目',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_biz_smallfamily_phone_unique_key_phone` (`phone`),
  KEY `index_biz_smallfamily_phone_uptown_code` (`uptown_code`),
  KEY `index_biz_smallfamily_phone_uptown_name` (`uptown_name`),
  KEY `index_biz_smallfamily_phone_bigfamily_code` (`bigfamily_code`),
  KEY `index_biz_smallfamily_phone_smallfamily_code` (`smallfamily_code`),
  KEY `index_biz_smallfamily_phone_grid_code` (`grid_code`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COMMENT='家庭商机小家庭主号手机表';

-- ----------------------------
-- Table structure for t_biz_smallfamily_portrait_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_smallfamily_portrait_m`;
CREATE TABLE `t_biz_smallfamily_portrait_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `code` varchar(50) NOT NULL COMMENT '家庭画像编码',
  `wifi_status` varchar(50) DEFAULT NULL COMMENT '宽带',
  `wifi_recommend` varchar(500) DEFAULT NULL COMMENT '宽带推荐话术',
  `wifi_type` varchar(50) DEFAULT NULL COMMENT '宽带类型',
  `wifi_due_time` date DEFAULT NULL COMMENT '宽带到期时间',
  `htv_status` varchar(50) DEFAULT NULL COMMENT '魔百和',
  `htv_recommend` varchar(500) DEFAULT NULL COMMENT '魔百和推荐话术',
  `ykq_status` varchar(50) DEFAULT NULL COMMENT '语音遥控器',
  `ykq_recommend` varchar(500) DEFAULT NULL COMMENT '语音遥控器推荐话术',
  `hemu_status` varchar(50) DEFAULT NULL COMMENT '和目',
  `hemu_recommend` varchar(500) DEFAULT NULL COMMENT '和目推荐话术',
  `hjxc_status` varchar(50) DEFAULT NULL COMMENT '合家相册',
  `hjxc_recommend` varchar(500) DEFAULT NULL COMMENT '合家相册话术',
  `jstc_status` varchar(50) DEFAULT NULL COMMENT '加速套餐',
  `jstc_recommend` varchar(500) DEFAULT NULL COMMENT '加速套餐话术',
  `dbnb_status` varchar(50) DEFAULT NULL COMMENT '点播年报',
  `dbnb_recommend` varchar(500) DEFAULT NULL COMMENT '点播年报话术',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_biz_smallfamily_protrait_unique_key_code` (`code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COMMENT='小家庭画像表';

-- ----------------------------
-- Table structure for t_biz_sms_record_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_sms_record_m`;
CREATE TABLE `t_biz_sms_record_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `code` varchar(50) DEFAULT NULL COMMENT '实体编码',
  `campaign_type` varchar(50) NOT NULL COMMENT '业务类型编码：uptown-小区商机',
  `business_type` varchar(40) NOT NULL COMMENT '商机类型编码：80-我往到期，82-潜在宽带，81-异网宽带',
  `template_code` varchar(50) NOT NULL COMMENT '短信模板编码 关联id',
  `quantity` int(10) DEFAULT NULL COMMENT '营销数量',
  `success_num` int(11) DEFAULT NULL COMMENT '成功发送数量',
  `send_time` datetime NOT NULL COMMENT '发送时间',
  `cond_str` varchar(1000) DEFAULT NULL COMMENT '查询条件',
  `oper` varchar(100) DEFAULT NULL COMMENT '工号',
  `patch_no` varchar(100) DEFAULT NULL COMMENT '批次号',
  `phone` varchar(50) DEFAULT NULL COMMENT '手机号',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `index_biz_building_marketing_record_building_code` (`code`),
  KEY `index_biz_building_marketing_record_marketing_code` (`business_type`),
  KEY `index_biz_building_marketing_record_template_code` (`template_code`),
  KEY `index_biz_building_marketing_record_send_time` (`send_time`)
) ENGINE=InnoDB AUTO_INCREMENT=108050 DEFAULT CHARSET=utf8mb4 COMMENT='短信下发记录信息';

-- ----------------------------
-- Table structure for t_biz_sms_record_result_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_sms_record_result_m`;
CREATE TABLE `t_biz_sms_record_result_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `campaign_type` varchar(50) DEFAULT NULL COMMENT '业务类型编码：uptown-小区商机',
  `business_type` varchar(40) DEFAULT NULL COMMENT '商机类型编码：80-我往到期，82-潜在宽带，81-异网宽带',
  `success_num` int(11) DEFAULT NULL COMMENT '成功发送数量',
  `send_time` datetime DEFAULT NULL COMMENT '发送时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `code` varchar(255) DEFAULT NULL COMMENT '编码',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '区域编码',
  `all_parent_code` varchar(200) DEFAULT NULL COMMENT '全部父节点网格编码',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_biz_building_marketing_record_unique_build_mark_templ_send` (`business_type`,`send_time`) USING BTREE,
  KEY `index_biz_building_marketing_record_marketing_code` (`business_type`),
  KEY `index_biz_building_marketing_record_send_time` (`send_time`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COMMENT='短信下发记录信息';

-- ----------------------------
-- Table structure for t_biz_sms_record_uptownresult_appd_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_sms_record_uptownresult_appd_m`;
CREATE TABLE `t_biz_sms_record_uptownresult_appd_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `campaign_type` varchar(50) DEFAULT NULL COMMENT '业务类型编码：uptown-小区商机',
  `business_type` varchar(40) DEFAULT NULL COMMENT '商机类型编码：80-我往到期，82-潜在宽带，81-异网宽带',
  `success_num` int(11) DEFAULT NULL COMMENT '成功发送数量',
  `send_time` datetime DEFAULT NULL COMMENT '发送时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `uptown_code` varchar(255) DEFAULT NULL COMMENT '编码',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_biz_building_marketing_record_unique_build_mark_templ_send` (`business_type`,`send_time`) USING BTREE,
  KEY `index_biz_building_marketing_record_marketing_code` (`business_type`),
  KEY `index_biz_building_marketing_record_send_time` (`send_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='短信下发记录信息';

-- ----------------------------
-- Table structure for t_biz_sms_template_approve_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_sms_template_approve_m`;
CREATE TABLE `t_biz_sms_template_approve_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `approve_user` varchar(50) DEFAULT NULL COMMENT '审批人',
  `approve_date` datetime DEFAULT NULL COMMENT '审批时间',
  `approve_userName` varchar(100) DEFAULT NULL COMMENT '审批人姓名',
  `oper_status` varchar(4) NOT NULL COMMENT '状态：0-待审批,1-审批通过,2-审批不通过',
  `oper_reason` varchar(255) DEFAULT NULL COMMENT '审批不通过原因',
  `patch_no` varchar(50) DEFAULT NULL COMMENT '批次号',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COMMENT='短信模板审批表';

-- ----------------------------
-- Table structure for t_biz_sms_template_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_sms_template_m`;
CREATE TABLE `t_biz_sms_template_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `code` varchar(50) DEFAULT NULL COMMENT '模板编码',
  `name` varchar(200) NOT NULL COMMENT '模板名称',
  `content` text NOT NULL COMMENT '模板内容',
  `var_str` varchar(100) DEFAULT NULL COMMENT '变量选择',
  `def_lan` varchar(120) DEFAULT NULL COMMENT '自定义用语',
  `grid_code` varchar(50) NOT NULL COMMENT '区域编码',
  `campaign_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '业务类型编码：uptown-小区商机',
  `campaign_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '业务类型名称',
  `business_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '商机类型编码：80-我往到期，82-潜在宽带，81-异网宽带',
  `business_name` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '商机类型名称',
  `oper_status` varchar(4) NOT NULL COMMENT '状态：0-待审批,1-审批通过,2-审批不通过',
  `effect_date` datetime NOT NULL COMMENT '生效时间',
  `invalid_date` datetime NOT NULL COMMENT '失效时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  `oper_reason` varchar(255) DEFAULT NULL COMMENT '审批不通过原因',
  `approve_user` varchar(50) DEFAULT NULL COMMENT '审批人',
  `approve_date` datetime DEFAULT NULL COMMENT '审批时间',
  `full_grid_code` varchar(160) DEFAULT NULL COMMENT '完整区域编码',
  `userId` varchar(100) DEFAULT NULL COMMENT '创建人工号',
  `userNameCn` varchar(100) DEFAULT NULL COMMENT '创建人姓名',
  `approve_userName` varchar(100) DEFAULT NULL COMMENT '审批人姓名',
  `uptown_code` varchar(255) DEFAULT NULL COMMENT '小区编码',
  `uptown_name` varchar(100) DEFAULT NULL COMMENT '小区名称',
  `level` int(11) DEFAULT NULL COMMENT '区域层级',
  `patch_no` varchar(50) DEFAULT NULL COMMENT '批次号',
  `status` varchar(4) DEFAULT NULL COMMENT '1：有效，0：无效',
  PRIMARY KEY (`id`),
  KEY `index_biz_sms_template_m_code` (`code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=349 DEFAULT CHARSET=utf8mb4 COMMENT='短信模板表';

-- ----------------------------
-- Table structure for t_biz_sms_template_role_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_sms_template_role_m`;
CREATE TABLE `t_biz_sms_template_role_m` (
  `id` bigint(19) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `role_id` varchar(50) DEFAULT NULL COMMENT '角色ID，关联iam_public.uc_instance_role_t.id',
  `role_name` varchar(200) DEFAULT NULL COMMENT '角色名称，关联iam_public.uc_instance_role_t.role_name',
  `role_type` varchar(4) DEFAULT NULL COMMENT '角色分类，a-被审批、审批类型，b-被审批类型',
  `status` varchar(4) DEFAULT NULL COMMENT '状态：0-无效,1-有效',
  `remark` varchar(200) DEFAULT NULL COMMENT '备注',
  `create_user` varchar(50) DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='短信模板角色控制表';

-- ----------------------------
-- Table structure for t_biz_station_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_station_m`;
CREATE TABLE `t_biz_station_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `city_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '地市编码',
  `city_name` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '地市名称',
  `district_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '区县编码',
  `district_name` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '区县名称',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '区域编码',
  `grid_name` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '网格名称',
  `code` varchar(100) NOT NULL COMMENT '基站编码',
  `name` varchar(200) DEFAULT NULL COMMENT '基站名称',
  `local_cd` varchar(50) DEFAULT NULL COMMENT '位置代码LOCAL_CD（十六进制）',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `bundary_coordinates` geometry DEFAULT NULL,
  `net_type` varchar(50) NOT NULL COMMENT '网络类型',
  `cover_type` varchar(50) DEFAULT NULL COMMENT '覆盖类型',
  `town_name` varchar(200) DEFAULT NULL COMMENT '镇名称',
  `town_cd` varchar(50) DEFAULT NULL COMMENT '镇代码',
  `is_delete` bit(1) DEFAULT b'1' COMMENT '0表示已删除，1表示未删除',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_biz_station_m_unique_key_code` (`code`) USING BTREE,
  KEY `index_biz_station_m_grid_code` (`grid_code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='基站表';

-- ----------------------------
-- Table structure for t_biz_template_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_template_m`;
CREATE TABLE `t_biz_template_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `code` varchar(50) NOT NULL COMMENT '模板编码',
  `name` varchar(200) DEFAULT NULL COMMENT '模板名称',
  `content` text COMMENT '模板内容',
  `preview_content` text COMMENT '预览内容',
  `seq` int(10) DEFAULT NULL COMMENT '序号',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_biz_template_m_unique_code` (`code`) USING BTREE,
  KEY `index_biz_template_m_code` (`code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='短信模板表';

-- ----------------------------
-- Table structure for t_biz_user_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_user_m`;
CREATE TABLE `t_biz_user_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `phone` varchar(50) DEFAULT NULL COMMENT '手机号',
  `app_phone` varchar(255) DEFAULT NULL COMMENT '安装掌厅应用的手机号',
  `bw_account` varchar(50) DEFAULT NULL COMMENT '宽带账户',
  `bw_account_encrypt` varchar(50) DEFAULT NULL COMMENT '宽带账户加密',
  `bw_flag` varchar(50) DEFAULT NULL COMMENT '宽带标识',
  `user_id` varchar(50) DEFAULT NULL COMMENT '用户ID，业务数据，非w3账号',
  `user_name` varchar(200) DEFAULT NULL COMMENT '姓名',
  `age` varchar(50) DEFAULT NULL COMMENT '年龄',
  `sex` varchar(50) DEFAULT NULL COMMENT '性别',
  `role` varchar(50) DEFAULT NULL COMMENT '角色（是否是主值号）：主号码，成员',
  `district` varchar(50) DEFAULT NULL COMMENT '区县市',
  `uptown` varchar(200) DEFAULT NULL COMMENT '小区名称',
  `uptown_code` varchar(50) DEFAULT NULL COMMENT '小区编码',
  `shopping_hall` varchar(50) DEFAULT NULL COMMENT '归属营业部',
  `open_date` datetime DEFAULT NULL COMMENT '开户时间',
  `access_type` varchar(50) DEFAULT NULL COMMENT '接入方式',
  `mix_price` varchar(50) DEFAULT NULL COMMENT '融合资费',
  `broadband_price` varchar(50) DEFAULT NULL COMMENT '宽带资费',
  `bw` int(11) DEFAULT NULL COMMENT '宽带带宽',
  `phone_price` varchar(50) DEFAULT NULL COMMENT '手机套餐资费',
  `operator` varchar(50) DEFAULT NULL COMMENT '运营商',
  `imei` varchar(50) DEFAULT NULL COMMENT 'IMEI码',
  `imsi` varchar(50) DEFAULT NULL COMMENT 'IMSI码',
  `brand` varchar(50) DEFAULT NULL COMMENT '品牌',
  `is_phoneuser` bit(1) DEFAULT NULL COMMENT '是否手机用户',
  `is_bwuser` bit(1) DEFAULT NULL COMMENT '是否宽带用户',
  `grid` varchar(50) DEFAULT NULL COMMENT '关联网格',
  `avg_arpu` decimal(10,4) DEFAULT NULL COMMENT '平均ARPU',
  `avg_duration` decimal(10,4) DEFAULT NULL COMMENT '平均宽带时长',
  `avg_traffic` decimal(20,4) DEFAULT NULL COMMENT '平均宽带流量',
  `is_handhall_activeuser` bit(1) DEFAULT NULL COMMENT '是否掌厅活跃用户',
  `is_differentbw` bit(1) DEFAULT NULL COMMENT '是否异网宽带',
  `is_publicno_activeuser` bit(1) DEFAULT NULL COMMENT '是否公众号活跃用户',
  `collect_date` datetime DEFAULT NULL COMMENT '数据日期',
  `public_networkip` varchar(50) DEFAULT NULL COMMENT '公网IP',
  `ne_id` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '网元ID',
  `ne_name` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '网元名称',
  `pon_port_seq` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT 'PON端口序号',
  `onu_name` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT 'ONU名称',
  `status` varchar(50) DEFAULT NULL COMMENT '账号状态',
  `extend_column` json DEFAULT NULL,
  `create_user` varchar(50) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `modify_user` varchar(50) DEFAULT NULL,
  `modify_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_biz_user_unique_key_phone` (`phone`) USING BTREE,
  KEY `index_biz_user_bw_account` (`bw_account`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='业务用户表（手机和宽带账号基本信息表）';

-- ----------------------------
-- Table structure for t_biz_video_experience_m
-- ----------------------------
DROP TABLE IF EXISTS `t_biz_video_experience_m`;
CREATE TABLE `t_biz_video_experience_m` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `grid_code` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '网格编码',
  `account` varchar(50) NOT NULL COMMENT '用户账号',
  `account_encrypt` varchar(50) DEFAULT NULL COMMENT '宽带账号加密',
  `video_start_time` datetime DEFAULT NULL COMMENT '视频事务开始时间',
  `video_end_time` datetime DEFAULT NULL COMMENT '视频事务结束时间',
  `video_id` varchar(50) DEFAULT NULL COMMENT '视频id',
  `video_website` varchar(50) DEFAULT NULL COMMENT '视频网站名称',
  `cache_time` int(20) DEFAULT '0' COMMENT '初始缓冲时延(ms)',
  `carton_rate` decimal(10,2) DEFAULT '0.00' COMMENT '卡顿时长占比(%)',
  `up_rtt` decimal(10,2) DEFAULT NULL COMMENT '上行数传RTT(ms)',
  `down_rtt` decimal(10,2) DEFAULT NULL COMMENT '下行数传RTT(ms)',
  `client_delay` decimal(10,2) DEFAULT NULL COMMENT 'Client Delay(ms)',
  `server_delay` decimal(10,2) DEFAULT NULL COMMENT 'Server Delay(ms)',
  `equipment_type` varchar(50) DEFAULT NULL COMMENT '设备类型',
  `statistical_month` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '统计月份',
  `extend_column` json DEFAULT NULL,
  `create_user` varchar(50) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `modify_user` varchar(50) DEFAULT NULL,
  `modify_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_video_experience_unique_key_account` (`account`) USING BTREE,
  KEY `index_video_experience_account_encrypt` (`account_encrypt`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='视频体验数据表';

-- ----------------------------
-- Table structure for t_broadband_user_address_modify_apply_m
-- ----------------------------
DROP TABLE IF EXISTS `t_broadband_user_address_modify_apply_m`;
CREATE TABLE `t_broadband_user_address_modify_apply_m` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `broadband_account` varchar(50) DEFAULT NULL COMMENT '宽带账户',
  `old_room_id` varchar(500) DEFAULT NULL COMMENT '旧九级地址ID全路径',
  `old_room_name` varchar(500) DEFAULT NULL COMMENT '旧九级地址名称全路径',
  `new_room_id` varchar(500) DEFAULT NULL COMMENT '新九级地址ID全路径',
  `new_room_name` varchar(500) DEFAULT NULL COMMENT '新九级地址名称全路径',
  `reason` varchar(200) DEFAULT NULL COMMENT '更新原因',
  `apply_time` varchar(50) DEFAULT NULL COMMENT '申请时间',
  `apply_status` varchar(50) DEFAULT NULL COMMENT '申请状态',
  `applicant_number` varchar(50) DEFAULT NULL COMMENT '申请人员工号',
  `applicant_name` varchar(50) DEFAULT NULL COMMENT '申请人员姓名',
  `applicant_phone` varchar(255) DEFAULT NULL COMMENT '申请人联系电话',
  `flow_id` varchar(50) DEFAULT NULL COMMENT '资管流水号',
  `return_code` varchar(50) DEFAULT NULL COMMENT '资管返回码',
  `return_desc` varchar(50) DEFAULT NULL COMMENT '资管返回信息',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='宽带用户地址修改申请';

-- ----------------------------
-- Table structure for t_broadband_user_info_m
-- ----------------------------
DROP TABLE IF EXISTS `t_broadband_user_info_m`;
CREATE TABLE `t_broadband_user_info_m` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `broadband_account` varchar(200) DEFAULT NULL COMMENT '宽带账户',
  `room_all_address_id` varchar(500) DEFAULT NULL COMMENT '九级地址id全路径',
  `user_name` varchar(500) DEFAULT NULL COMMENT '用户名',
  `phone` varchar(500) DEFAULT NULL COMMENT '联系手机号',
  `broadband_accept_mode` varchar(50) DEFAULT NULL COMMENT '宽带接入方式',
  `room_number` varchar(50) DEFAULT NULL COMMENT '房号名称',
  `broadband_fee` varchar(50) DEFAULT NULL COMMENT '宽带资费',
  `broadband_rate` varchar(50) DEFAULT NULL COMMENT '宽带速率',
  `broadband_expire_date` varchar(50) DEFAULT NULL COMMENT '宽带到期时间',
  `operator` varchar(50) DEFAULT NULL COMMENT '运营商',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `broadband_account_index` (`broadband_account`,`room_all_address_id`) USING BTREE,
  KEY `room_all_address_id_index` (`room_all_address_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='宽带用户信息(大数据)';

-- ----------------------------
-- Table structure for t_building_address_m
-- ----------------------------
DROP TABLE IF EXISTS `t_building_address_m`;
CREATE TABLE `t_building_address_m` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `building_id` varchar(50) DEFAULT NULL COMMENT '楼宇ID',
  `building_name` varchar(200) DEFAULT NULL COMMENT '楼宇名称',
  `uptown_code` varchar(50) DEFAULT NULL COMMENT '归属小区编码',
  `channel_employee_number` varchar(50) DEFAULT NULL COMMENT '渠道员工工号',
  `all_address_id` varchar(500) DEFAULT NULL COMMENT '六级地址id全路径',
  `all_address_name` varchar(3000) DEFAULT NULL COMMENT '六级地址名称全路径',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `building_id_index` (`building_id`) USING BTREE,
  KEY `uptown_code_index` (`uptown_code`) USING BTREE,
  KEY `channel_employee_number_index` (`channel_employee_number`) USING BTREE,
  KEY `all_address_id_index` (`all_address_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='楼宇(CRM)';

-- ----------------------------
-- Table structure for t_building_floor_address_m
-- ----------------------------
DROP TABLE IF EXISTS `t_building_floor_address_m`;
CREATE TABLE `t_building_floor_address_m` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `floor_id` varchar(50) DEFAULT NULL COMMENT '楼层ID',
  `floor_name` varchar(200) DEFAULT NULL COMMENT '楼层名称',
  `building_unit_id` varchar(50) DEFAULT NULL COMMENT '归属楼宇单元ID',
  `all_address_id` varchar(500) DEFAULT NULL COMMENT '八级地址id全路径',
  `all_address_name` varchar(3000) DEFAULT NULL COMMENT '八级地址名称全路径',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `floor_id_index` (`floor_id`) USING BTREE,
  KEY `building_unit_id_index` (`building_unit_id`) USING BTREE,
  KEY `all_address_id_index` (`all_address_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='楼层(CRM)';

-- ----------------------------
-- Table structure for t_building_room_address_m
-- ----------------------------
DROP TABLE IF EXISTS `t_building_room_address_m`;
CREATE TABLE `t_building_room_address_m` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `room_id` varchar(50) DEFAULT NULL COMMENT '房间ID/九级地址ID',
  `room_name` varchar(200) DEFAULT NULL COMMENT '九级地址名称',
  `all_address_id` varchar(500) DEFAULT NULL COMMENT '九级地址id全路径',
  `all_address_name` varchar(3000) DEFAULT NULL COMMENT '九级地址名称全路径',
  `building_floor_id` varchar(50) DEFAULT NULL COMMENT '归属楼层ID',
  `house_number` varchar(50) DEFAULT NULL COMMENT '门牌号',
  `user_num` varchar(50) DEFAULT NULL COMMENT '用户人数',
  `user_name` varchar(500) DEFAULT NULL COMMENT '用户姓名',
  `operator` varchar(50) DEFAULT NULL COMMENT '运营商',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `room_id_index` (`room_id`) USING BTREE,
  KEY `all_address_id_index` (`all_address_id`) USING BTREE,
  KEY `building_floor_id_index` (`building_floor_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='房间信息(CRM)';

-- ----------------------------
-- Table structure for t_building_unit_address_m
-- ----------------------------
DROP TABLE IF EXISTS `t_building_unit_address_m`;
CREATE TABLE `t_building_unit_address_m` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `building_unit_id` varchar(50) DEFAULT NULL COMMENT '楼宇单元ID',
  `building_unit_name` varchar(200) DEFAULT NULL COMMENT '楼宇单元名称',
  `building_id` varchar(50) DEFAULT NULL COMMENT '归属楼宇ID',
  `all_address_id` varchar(500) DEFAULT NULL COMMENT '七级地址id全路径',
  `all_address_name` varchar(3000) DEFAULT NULL COMMENT '七级地址名称全路径',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `building_unit_id_index` (`building_unit_id`) USING BTREE,
  KEY `building_id_index` (`building_id`) USING BTREE,
  KEY `all_address_id_index` (`all_address_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='楼宇单元(CRM)';

-- ----------------------------
-- Table structure for t_channel_baseinfo_m
-- ----------------------------
DROP TABLE IF EXISTS `t_channel_baseinfo_m`;
CREATE TABLE `t_channel_baseinfo_m` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `channel_id` varchar(50) DEFAULT NULL COMMENT '渠道编码',
  `channel_name` varchar(100) DEFAULT NULL COMMENT '渠道名称',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '归属区域编码',
  `mgr_id` varchar(50) DEFAULT NULL COMMENT '渠道经理工号',
  `mgr_name` varchar(50) DEFAULT NULL COMMENT '渠道经理姓名',
  `status` varchar(50) DEFAULT NULL COMMENT '渠道状态',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `channel_id_index` (`channel_id`) USING BTREE,
  KEY `grid_code_index` (`grid_code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='渠道基本信息(CRM)';

-- ----------------------------
-- Table structure for t_channel_employee_ownership_m
-- ----------------------------
DROP TABLE IF EXISTS `t_channel_employee_ownership_m`;
CREATE TABLE `t_channel_employee_ownership_m` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `employee_id` varchar(50) DEFAULT NULL COMMENT '渠道员工工号',
  `channel_id` varchar(50) DEFAULT NULL COMMENT '渠道编码',
  `channel_user_name` varchar(200) DEFAULT NULL COMMENT '渠道员工姓名',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `employee_id_index` (`employee_id`) USING BTREE,
  KEY `channel_id_index` (`channel_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='渠道员工归属';

-- ----------------------------
-- Table structure for t_cluster_buildings_index_m
-- ----------------------------
DROP TABLE IF EXISTS `t_cluster_buildings_index_m`;
CREATE TABLE `t_cluster_buildings_index_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `cluster_code` varchar(50) NOT NULL COMMENT '聚类编码',
  `cluster_buildings_code` varchar(50) NOT NULL COMMENT '楼栋编码',
  `building_prot_rate` decimal(10,4) DEFAULT NULL COMMENT '楼栋端口占有率',
  `building_diffnet_rate` decimal(10,4) DEFAULT NULL COMMENT '楼栋异网占比',
  `statistics_time` date DEFAULT NULL COMMENT '统计时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_cluster_buildings_index_unique_key_cluster_buildings_stat` (`cluster_code`,`cluster_buildings_code`,`statistics_time`) USING BTREE,
  KEY `index_cluster_buildings_index_m_cluster_code` (`cluster_code`) USING BTREE,
  KEY `index_cluster_buildings_index_m_cluster_buildings_code` (`cluster_buildings_code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='聚类楼栋指标表';

-- ----------------------------
-- Table structure for t_cluster_buildings_m
-- ----------------------------
DROP TABLE IF EXISTS `t_cluster_buildings_m`;
CREATE TABLE `t_cluster_buildings_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `cluster_code` varchar(50) NOT NULL COMMENT '聚类编码',
  `code` varchar(50) NOT NULL COMMENT '楼栋编码',
  `address` varchar(300) DEFAULT NULL COMMENT '楼栋地址',
  `name` varchar(200) DEFAULT NULL COMMENT '楼栋名称',
  `floor_num` int(10) DEFAULT NULL COMMENT '楼层数',
  `unit_num` int(10) DEFAULT NULL COMMENT '单元数',
  `floor_household_num` int(10) DEFAULT NULL COMMENT '每层户数',
  `house_num` int(10) DEFAULT NULL COMMENT '楼栋总户数',
  `sourcetype` int(10) DEFAULT NULL COMMENT '数据来源: 2亚信,1 FBB',
  `status` varchar(50) DEFAULT NULL COMMENT '状态:有效1/无效0/已删除2/待审批3',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_cluster_buildings_unique_key_cluster_code_code` (`cluster_code`,`code`) USING BTREE,
  KEY `index_cluster_buildings_cluster_code` (`cluster_code`) USING BTREE,
  KEY `index_cluster_buildings_code` (`code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COMMENT='聚类楼栋表';

-- ----------------------------
-- Table structure for t_cluster_buildings_unit_index_m
-- ----------------------------
DROP TABLE IF EXISTS `t_cluster_buildings_unit_index_m`;
CREATE TABLE `t_cluster_buildings_unit_index_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `cluster_code` varchar(50) NOT NULL COMMENT '聚类编码',
  `cluster_buildings_code` varchar(50) NOT NULL COMMENT '楼栋编号',
  `cluster_buildings_unit_code` varchar(50) NOT NULL COMMENT '单元编号',
  `unit_diffnet_rate` decimal(10,4) DEFAULT NULL COMMENT '单元的异网占比',
  `unit_port_rate` decimal(10,4) DEFAULT NULL COMMENT '单元的端口占有率',
  `statistics_time` date DEFAULT NULL COMMENT '统计时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_cluster_buildings_unit_index_unique_key_cluster_code_stat` (`cluster_code`,`cluster_buildings_code`,`cluster_buildings_unit_code`,`statistics_time`) USING BTREE,
  KEY `index_cluster_buildings_unit_index_m_cluster_code` (`cluster_code`) USING BTREE,
  KEY `index_cluster_buildings_unit_index_m_cluster_buildings_code` (`cluster_buildings_code`) USING BTREE,
  KEY `index_cluster_buildings_unit_index_m_cluster_buildings_unit_code` (`cluster_buildings_unit_code`) USING BTREE,
  KEY `index_cluster_buildings_unit_index_m_statistics_time` (`statistics_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='聚类楼栋单元指标表';

-- ----------------------------
-- Table structure for t_cluster_buildings_unit_m
-- ----------------------------
DROP TABLE IF EXISTS `t_cluster_buildings_unit_m`;
CREATE TABLE `t_cluster_buildings_unit_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `cluster_code` varchar(50) NOT NULL COMMENT '聚类编码',
  `cluster_buildings_code` varchar(50) NOT NULL COMMENT '楼栋编号',
  `code` varchar(50) NOT NULL COMMENT '单元编号',
  `name` varchar(200) DEFAULT NULL COMMENT '单元名称',
  `address` varchar(300) DEFAULT NULL COMMENT '单元地址',
  `floor_num` int(10) DEFAULT NULL COMMENT '楼层数',
  `status` varchar(50) DEFAULT NULL COMMENT '状态:有效1/无效0/已删除2/待审批3',
  `sourcetype` int(10) DEFAULT NULL COMMENT '数据来源',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_unit_unique_key_buildings_code_cluster_code_code` (`cluster_code`,`cluster_buildings_code`,`code`) USING BTREE,
  KEY `index_cluster_unit_cluster_code` (`cluster_code`) USING BTREE,
  KEY `index_cluster_unit_cluster_buildings_code` (`cluster_buildings_code`) USING BTREE,
  KEY `index_cluster_unit_code` (`code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COMMENT='聚类楼栋单元表';

-- ----------------------------
-- Table structure for t_cluster_e
-- ----------------------------
DROP TABLE IF EXISTS `t_cluster_e`;
CREATE TABLE `t_cluster_e` (
  `id` bigint(19) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `cluster_code` varchar(50) NOT NULL COMMENT '聚类编码',
  `is_cmty_store` bit(1) DEFAULT NULL COMMENT '是否有社区店',
  `cmty_store_name` varchar(200) DEFAULT NULL COMMENT '社区店名称',
  `cmty_store_type` varchar(50) DEFAULT NULL COMMENT '社区店类型',
  `cmty_store_position` varchar(200) DEFAULT NULL COMMENT '社区店位置',
  `property_name` varchar(200) DEFAULT NULL COMMENT '物业名称',
  `property_tel` varchar(50) DEFAULT NULL COMMENT '物业公司电话',
  `property_linkman` varchar(50) DEFAULT NULL COMMENT '物业联系人',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_cluster_unique_key_cluster_code` (`cluster_code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='聚类扩展表';

-- ----------------------------
-- Table structure for t_cluster_household_chargesinfo_e
-- ----------------------------
DROP TABLE IF EXISTS `t_cluster_household_chargesinfo_e`;
CREATE TABLE `t_cluster_household_chargesinfo_e` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `cluster_code` varchar(50) NOT NULL COMMENT '聚类编码',
  `cluster_buildings_code` varchar(50) NOT NULL COMMENT '楼栋编号',
  `cluster_buildings_unit_code` varchar(50) NOT NULL COMMENT '单元名称',
  `cluster_household_code` varchar(50) NOT NULL COMMENT '房间号',
  `business_type` varchar(200) NOT NULL COMMENT '业务类型:1 宽带/2 固网IMS/3 个人套餐/4 魔百和/5 和目',
  `operator` varchar(50) NOT NULL COMMENT '运营商:1 联通/2 电信/3 移动/4 广电/5 长城',
  `expenses_fee` varchar(100) NOT NULL DEFAULT '0' COMMENT '资费',
  `expire_time` date DEFAULT NULL COMMENT '到期时间',
  `tel_number` varchar(50) DEFAULT NULL COMMENT '联系号码',
  `city_name` varchar(200) DEFAULT NULL COMMENT '归属地市',
  `is_local` bit(1) DEFAULT NULL COMMENT '是否本地市 1是 0否',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  PRIMARY KEY (`id`),
  KEY `index_cluster_hoursehold_chargesinfo_cluster_code` (`cluster_code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='聚类房号资费表';

-- ----------------------------
-- Table structure for t_cluster_household_m
-- ----------------------------
DROP TABLE IF EXISTS `t_cluster_household_m`;
CREATE TABLE `t_cluster_household_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `cluster_code` varchar(50) NOT NULL COMMENT '聚类编码',
  `cluster_buildings_code` varchar(50) NOT NULL COMMENT '楼栋编号',
  `cluster_buildings_unit_code` varchar(50) NOT NULL COMMENT '单元编号',
  `in_floor_num` varchar(50) DEFAULT NULL COMMENT '所在楼层',
  `code` varchar(50) NOT NULL COMMENT '房号编码',
  `name` varchar(200) DEFAULT NULL COMMENT '房号名称',
  `address` varchar(300) DEFAULT NULL COMMENT '房号地址',
  `family_num` int(10) DEFAULT NULL COMMENT '家庭成员数',
  `tel_number` varchar(50) DEFAULT NULL COMMENT '联系号码',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `status` varchar(50) DEFAULT NULL COMMENT '状态:有效1/无效0/已删除2/待审批3',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_hoursehold_unique_key_cluster_buildings_unit_code` (`cluster_code`,`cluster_buildings_code`,`cluster_buildings_unit_code`,`code`) USING BTREE,
  KEY `index_cluster_hoursehold_cluster_buildings_unit_code` (`cluster_code`,`cluster_buildings_code`,`cluster_buildings_unit_code`) USING BTREE,
  KEY `index_cluster_hoursehold_code` (`code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=295 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='聚类房号表';

-- ----------------------------
-- Table structure for t_cluster_m
-- ----------------------------
DROP TABLE IF EXISTS `t_cluster_m`;
CREATE TABLE `t_cluster_m` (
  `id` bigint(19) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `code` varchar(50) NOT NULL COMMENT '聚类编码',
  `name` varchar(200) DEFAULT NULL COMMENT '聚类名称',
  `type` varchar(50) DEFAULT NULL COMMENT '聚类类型:城市小区1/开放小区2/封闭小区3/企业宿舍4/机关宿舍5/自然村6/农村社区7/封闭8/高校校园9/普通校园10',
  `grid_code` varchar(200) DEFAULT NULL COMMENT '区域编码',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `bundary_coordinates` geometry NOT NULL COMMENT '边界坐标',
  `is_gps_modify` bit(1) DEFAULT NULL COMMENT '经纬度是否已修改 1是 0否',
  `city_code` varchar(50) DEFAULT NULL COMMENT '城市编码',
  `city_name` varchar(200) DEFAULT NULL COMMENT '城市名称',
  `district_code` varchar(50) DEFAULT NULL COMMENT '区县编码',
  `district_name` varchar(200) DEFAULT NULL COMMENT '区县名称',
  `address` varchar(500) DEFAULT NULL COMMENT '地址',
  `manager` varchar(50) DEFAULT NULL COMMENT '网格经理',
  `manager_phone` varchar(50) DEFAULT NULL COMMENT '网格经理电话',
  `is_cover` bit(1) DEFAULT NULL COMMENT '是否覆盖',
  `sourcetype` int(10) DEFAULT NULL COMMENT '数据来源',
  `status` varchar(50) DEFAULT NULL COMMENT '状态:有效1/无效0/已删除2/待审批3',
  `is_confirmed` bit(1) DEFAULT NULL COMMENT '是否已确认:已确认1/未确认0',
  `level` varchar(50) DEFAULT NULL COMMENT '聚类等级类型:高价值小区1/低占小区2/空白小区3',
  `is_verify` bit(1) DEFAULT NULL COMMENT '是否核实 1是 0否',
  `outer_grid_code` varchar(200) DEFAULT NULL COMMENT '网络区域编码',
  `outer_bundary_coordinates` geometry DEFAULT NULL COMMENT '网络边界坐标',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_uptown_unique_key_cluster_code` (`code`) USING BTREE,
  KEY `index_cluster_grid_code` (`grid_code`) USING BTREE,
  KEY `index_cluster_city_code` (`city_code`) USING BTREE,
  KEY `index_cluster_cnty_code` (`district_code`) USING BTREE,
  SPATIAL KEY `index_cluster_spatIdx` (`bundary_coordinates`),
  FULLTEXT KEY `ftindex_cluster_name` (`name`) /*!50100 WITH PARSER `ngram` */ 
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='聚类表';

-- ----------------------------
-- Table structure for t_cluster_resource_index_m
-- ----------------------------
DROP TABLE IF EXISTS `t_cluster_resource_index_m`;
CREATE TABLE `t_cluster_resource_index_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `cluster_code` varchar(50) NOT NULL COMMENT '聚类编码',
  `bw_arrival` int(10) DEFAULT NULL COMMENT '企宽到达',
  `month_dw_add` int(10) DEFAULT NULL COMMENT '企宽月新增',
  `day_dw_add` int(10) DEFAULT NULL COMMENT '企宽日新增',
  `cover_user_nums` int(10) DEFAULT NULL COMMENT '覆盖用户数',
  `port_num` int(10) DEFAULT NULL COMMENT '端口数',
  `port_avail_rate` decimal(10,4) DEFAULT NULL COMMENT '端口实装率',
  `magicbai_user_arrival` int(10) DEFAULT NULL COMMENT '魔百和到达',
  `magicbai_permeability` decimal(10,4) DEFAULT NULL COMMENT '魔百和渗透率',
  `ims_user_nums` int(10) DEFAULT NULL COMMENT 'IMS到达',
  `ims_permeability` decimal(10,4) DEFAULT NULL COMMENT 'IMS渗透率',
  `year_dw_offnet` int(10) DEFAULT NULL COMMENT '企宽年离网',
  `month_dw_offnet` int(10) DEFAULT NULL COMMENT '企宽月离网',
  `statistics_time` date DEFAULT NULL COMMENT '统计时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_cluster_unique_key_cluster_code` (`cluster_code`,`statistics_time`) USING BTREE,
  KEY `index_cluster_cluster_code` (`cluster_code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='聚类资源点指标表';

-- ----------------------------
-- Table structure for t_cluster_touch_e
-- ----------------------------
DROP TABLE IF EXISTS `t_cluster_touch_e`;
CREATE TABLE `t_cluster_touch_e` (
  `id` bigint(19) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `grid_code` varchar(200) DEFAULT NULL COMMENT '区域编码',
  `cluster_code` varchar(50) NOT NULL COMMENT '聚类编码',
  `outer_building_num` int(10) DEFAULT NULL COMMENT '网络侧楼宇数',
  `outer_unit_num` int(10) DEFAULT NULL COMMENT '网络侧单元数',
  `outer_family_num` int(10) DEFAULT NULL COMMENT '网络侧家庭户数',
  `outer_total_port_count` int(10) DEFAULT NULL COMMENT '网络侧总端口数',
  `outer_free_port_count` int(10) DEFAULT NULL COMMENT '网络侧剩余端口数',
  `touch_building_num` int(10) DEFAULT NULL COMMENT '摸排楼宇数',
  `touch_unit_num` int(10) DEFAULT NULL COMMENT '摸排单元数',
  `touch_family_num` int(10) DEFAULT NULL COMMENT '摸排家庭户数',
  `touch_port_count` int(10) DEFAULT NULL COMMENT '摸排端口数',
  `user_count` int(10) DEFAULT NULL COMMENT '用户数',
  `building_number` int(10) DEFAULT NULL COMMENT '楼宇数',
  `floor_num` int(10) DEFAULT NULL COMMENT '楼层数',
  `unit_num` int(10) DEFAULT NULL COMMENT '单元数',
  `covered_building_num` int(10) DEFAULT NULL COMMENT '已覆盖移动宽带楼宇数',
  `compete_cover` varchar(50) DEFAULT NULL COMMENT '竞争对手覆盖情况',
  `is_cover` bit(1) DEFAULT NULL COMMENT '移动宽带是否覆盖 1是 0否',
  `unicom_bwnum` int(10) DEFAULT NULL COMMENT '联通宽带数',
  `telecom_bwnum` int(10) DEFAULT NULL COMMENT '电信宽带数',
  `odb_type` varchar(50) DEFAULT NULL COMMENT '分纤箱类型',
  `odb_num` int(10) DEFAULT NULL COMMENT '分纤箱数量',
  `problem` varchar(50) DEFAULT NULL COMMENT '聚类存在问题A/B/C/D/E/F',
  `is_verify` bit(1) DEFAULT NULL COMMENT '是否核实 1是 0否',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_uptown_unique_key_cluster_code` (`cluster_code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='聚类摸排扩展表';

-- ----------------------------
-- Table structure for t_dummy_user
-- ----------------------------
DROP TABLE IF EXISTS `t_dummy_user`;
CREATE TABLE `t_dummy_user` (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_code` varchar(50) DEFAULT '0',
  `user_name` varchar(50) NOT NULL,
  `age` int(11) DEFAULT '0',
  `address_home` varchar(50) DEFAULT NULL,
  `salary` decimal(7,2) DEFAULT '0.00',
  `birth_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for t_enterprise_business_e
-- ----------------------------
DROP TABLE IF EXISTS `t_enterprise_business_e`;
CREATE TABLE `t_enterprise_business_e` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `enterprise_code` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '集团编码',
  `business_type` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '业务类型',
  `operator` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '运营商',
  `tariff_price` varchar(50) DEFAULT NULL COMMENT '资费价格',
  `quantity` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '数量',
  `expire_time` date DEFAULT NULL COMMENT '到期时间',
  `remark` text CHARACTER SET utf8 COMMENT '备注',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `index_t_enterprise_business_e_enterprise_code` (`enterprise_code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='企业已办业务信息表';

-- ----------------------------
-- Table structure for t_enterprise_business_opportunity_e
-- ----------------------------
DROP TABLE IF EXISTS `t_enterprise_business_opportunity_e`;
CREATE TABLE `t_enterprise_business_opportunity_e` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `enterprise_code` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '集团编码',
  `business` varchar(200) CHARACTER SET utf8 DEFAULT NULL COMMENT '企业商机',
  `opportunity_desc` text CHARACTER SET utf8 COMMENT '需求说明',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `index_t_enterprise_business_opportunity_enterprise_code` (`enterprise_code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='企业业务商机表';

-- ----------------------------
-- Table structure for t_enterprise_index_m
-- ----------------------------
DROP TABLE IF EXISTS `t_enterprise_index_m`;
CREATE TABLE `t_enterprise_index_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `enterprise_code` varchar(50) NOT NULL COMMENT '集团编码',
  `enterprise_member_num` int(10) DEFAULT NULL COMMENT '集团成员数',
  `v_member_num` int(10) DEFAULT NULL COMMENT 'V网成员数',
  `enterprise_product_num` int(10) DEFAULT NULL COMMENT '集团产品数',
  `infor_pretax_income` int(10) DEFAULT NULL COMMENT '信息化税前收入',
  `statistics_time` date NOT NULL COMMENT '统计时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_enterprise_index_m_unique_key_enterprise_code_stat_time` (`enterprise_code`,`statistics_time`) USING BTREE,
  KEY `index_enterprise_index_m_enterprise_code` (`enterprise_code`),
  KEY `index_enterprise_index_m_statistics_time` (`statistics_time`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='集团指标表';

-- ----------------------------
-- Table structure for t_enterprise_user_business_e
-- ----------------------------
DROP TABLE IF EXISTS `t_enterprise_user_business_e`;
CREATE TABLE `t_enterprise_user_business_e` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `enterprise_code` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '集团编码',
  `user_phone` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '用户手机号码',
  `business_name` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '业务名称',
  `business_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '业务代码',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `index_t_enterprise_user_business_e_enterprise_code` (`enterprise_code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='企业用户业务表';

-- ----------------------------
-- Table structure for t_grid_busi_uptwon_index_m
-- ----------------------------
DROP TABLE IF EXISTS `t_grid_busi_uptwon_index_m`;
CREATE TABLE `t_grid_busi_uptwon_index_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `grid_code` varchar(50) NOT NULL COMMENT '区域编码',
  `bw_self_num` int(10) DEFAULT NULL COMMENT '我网宽带',
  `potential_bw_num` int(10) DEFAULT NULL COMMENT '潜在宽带',
  `diffnet_bw_num` int(10) DEFAULT NULL COMMENT '异网宽带',
  `magicbai_num` int(10) DEFAULT NULL COMMENT '魔百和',
  `voice_rc_num` int(10) DEFAULT NULL COMMENT '语音遥控器',
  `he_busi_num` int(10) DEFAULT NULL COMMENT '和目业务',
  `family_network_num` int(10) DEFAULT NULL COMMENT '亲情网',
  `share_flow_num` int(10) DEFAULT NULL COMMENT '流量共享',
  `lovefamily_package_num` int(10) DEFAULT NULL COMMENT '爱家套餐',
  `family_fixedline_num` int(10) DEFAULT NULL COMMENT '家庭固话',
  `rearview_mirror_num` int(10) DEFAULT NULL COMMENT '后视镜',
  `vehicleowner_service_num` int(10) DEFAULT NULL COMMENT '车主服务',
  `statistics_time` date NOT NULL COMMENT '统计时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_grid_busi_uptown_index_unique_key_grid_code_stat_time` (`grid_code`,`statistics_time`) USING BTREE,
  KEY `index_grid_busi_uptown_index_grid_code` (`grid_code`),
  KEY `index_grid_busi_uptown_index_statistics_time` (`statistics_time`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='区域小区商机指标表';

-- ----------------------------
-- Table structure for t_grid_level_m
-- ----------------------------
DROP TABLE IF EXISTS `t_grid_level_m`;
CREATE TABLE `t_grid_level_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `code` varchar(50) NOT NULL COMMENT '编码',
  `name` varchar(200) DEFAULT NULL COMMENT '名称',
  `name_en` varchar(200) DEFAULT NULL COMMENT '国际化名称',
  `level` int(11) DEFAULT NULL COMMENT '层级',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_unioue_key_grid_code` (`code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='区域层级表';

-- ----------------------------
-- Table structure for t_grid_m
-- ----------------------------
DROP TABLE IF EXISTS `t_grid_m`;
CREATE TABLE `t_grid_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `code` varchar(50) NOT NULL COMMENT '区域编码',
  `parent_code` varchar(50) DEFAULT NULL COMMENT '父级区域编码',
  `all_parent_code` varchar(10000) DEFAULT NULL COMMENT '全部父节点网格编码',
  `old_grid_code` text COMMENT '旧区域编码树：以逗号分隔',
  `name` varchar(500) DEFAULT NULL COMMENT '区域名称',
  `full_name` varchar(300) DEFAULT NULL COMMENT '区域全名称',
  `type` varchar(50) DEFAULT NULL COMMENT '网格类型：营销网格、规划网格等',
  `business_type` varchar(50) DEFAULT NULL COMMENT '业务类型:社区1/商圈2/楼宇3/校园4',
  `bundary` mediumtext COMMENT '边界',
  `level` int(11) DEFAULT NULL COMMENT '层级',
  `headperson` varchar(50) DEFAULT NULL COMMENT '区域负责人名称',
  `headperson_code` varchar(50) DEFAULT NULL COMMENT '区域负责人工号',
  `headperson_tel` varchar(50) DEFAULT NULL COMMENT '网格负责人电话',
  `center_longitude` decimal(18,8) DEFAULT NULL COMMENT '网格中心点经度',
  `center_latitude` decimal(18,8) DEFAULT NULL COMMENT '网格中心点纬度',
  `area` decimal(10,2) DEFAULT NULL COMMENT '面积',
  `grid_status` varchar(50) DEFAULT '1' COMMENT '1 有效,0 无效,2 已删除',
  `email` varchar(200) DEFAULT NULL COMMENT '邮箱',
  `relate_org_code` varchar(50) DEFAULT NULL COMMENT '关联的组织机构编码',
  `relate_org` varchar(100) DEFAULT NULL COMMENT '关联的组织机构名称',
  `priority` int(11) DEFAULT NULL COMMENT '优先级',
  `short_name` varchar(50) DEFAULT NULL COMMENT '短名称',
  `is_town` bit(1) DEFAULT NULL COMMENT '是否乡镇经营部: 1 是，0 否',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  `bundary_coordinate` geometry NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_unique_t_grid_m` (`code`) USING BTREE,
  KEY `index_grid_name` (`name`) USING BTREE,
  SPATIAL KEY `spatIdx` (`bundary_coordinate`),
  KEY `index_parent_code` (`parent_code`) USING BTREE,
  KEY `index_grid_status` (`grid_status`,`level`,`code`) USING BTREE,
  FULLTEXT KEY `index_all_parent_code` (`all_parent_code`)
) ENGINE=InnoDB AUTO_INCREMENT=154587 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='网格基础信息表';

-- ----------------------------
-- Table structure for t_grid_m_copy
-- ----------------------------
DROP TABLE IF EXISTS `t_grid_m_copy`;
CREATE TABLE `t_grid_m_copy` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `code` varchar(50) NOT NULL COMMENT '区域编码',
  `parent_code` varchar(50) DEFAULT NULL COMMENT '父级区域编码',
  `all_parent_code` varchar(10000) DEFAULT NULL COMMENT '全部父节点网格编码',
  `old_grid_code` text COMMENT '旧区域编码树：以逗号分隔',
  `name` varchar(500) DEFAULT NULL COMMENT '区域名称',
  `full_name` varchar(300) DEFAULT NULL COMMENT '区域全名称',
  `type` varchar(50) DEFAULT NULL COMMENT '网格类型：营销网格、规划网格等',
  `business_type` varchar(50) DEFAULT NULL COMMENT '业务类型:社区1/商圈2/楼宇3/校园4',
  `bundary` mediumtext COMMENT '边界',
  `level` int(11) DEFAULT NULL COMMENT '层级',
  `headperson` varchar(50) DEFAULT NULL COMMENT '区域负责人名称',
  `headperson_code` varchar(50) DEFAULT NULL COMMENT '区域负责人工号',
  `headperson_tel` varchar(50) DEFAULT NULL COMMENT '网格负责人电话',
  `center_longitude` decimal(18,8) DEFAULT NULL COMMENT '网格中心点经度',
  `center_latitude` decimal(18,8) DEFAULT NULL COMMENT '网格中心点纬度',
  `area` decimal(10,2) DEFAULT NULL COMMENT '面积',
  `grid_status` varchar(50) DEFAULT '1' COMMENT '1 有效,0 无效,2 已删除',
  `email` varchar(200) DEFAULT NULL COMMENT '邮箱',
  `relate_org_code` varchar(50) DEFAULT NULL COMMENT '关联的组织机构编码',
  `relate_org` varchar(100) DEFAULT NULL COMMENT '关联的组织机构名称',
  `priority` int(11) DEFAULT NULL COMMENT '优先级',
  `short_name` varchar(50) DEFAULT NULL COMMENT '短名称',
  `is_town` bit(1) DEFAULT NULL COMMENT '是否乡镇经营部: 1 是，0 否',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  `bundary_coordinate` geometry NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_unique_t_grid_m` (`code`) USING BTREE,
  KEY `index_grid_name` (`name`) USING BTREE,
  SPATIAL KEY `spatIdx` (`bundary_coordinate`),
  KEY `index_parent_code` (`parent_code`) USING BTREE,
  KEY `index_grid_status` (`grid_status`,`level`,`code`) USING BTREE,
  FULLTEXT KEY `index_all_parent_code` (`all_parent_code`)
) ENGINE=InnoDB AUTO_INCREMENT=154569 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='网格基础信息表';

-- ----------------------------
-- Table structure for t_grid_m_vt
-- ----------------------------
DROP TABLE IF EXISTS `t_grid_m_vt`;
CREATE TABLE `t_grid_m_vt` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `code` varchar(50) NOT NULL COMMENT '区域编码',
  `parent_code` varchar(50) DEFAULT NULL COMMENT '父级区域编码',
  `all_parent_code` varchar(200) DEFAULT NULL COMMENT '全部父节点网格编码',
  `old_grid_code` text COMMENT '旧区域编码树：以逗号分隔',
  `name` varchar(300) DEFAULT NULL COMMENT '区域名称',
  `full_name` varchar(300) DEFAULT NULL COMMENT '区域全名称',
  `type` varchar(50) DEFAULT NULL COMMENT '网格类型：营销网格、规划网格等',
  `business_type` varchar(50) DEFAULT NULL COMMENT '业务类型:社区1/商圈2/楼宇3/校园4',
  `bundary` mediumtext COMMENT '边界',
  `bundary_coordinate` geometry NOT NULL COMMENT '边界',
  `level` int(11) DEFAULT NULL COMMENT '层级',
  `headperson` varchar(50) DEFAULT NULL COMMENT '区域负责人名称',
  `headperson_code` varchar(50) DEFAULT NULL COMMENT '区域负责人工号',
  `headperson_tel` varchar(50) DEFAULT NULL COMMENT '网格负责人电话',
  `center_longitude` decimal(18,8) DEFAULT NULL COMMENT '网格中心点经度',
  `center_latitude` decimal(18,8) DEFAULT NULL COMMENT '网格中心点纬度',
  `area` decimal(10,2) DEFAULT NULL COMMENT '面积',
  `grid_status` varchar(50) DEFAULT '1' COMMENT '1 有效,0 无效,2 已删除',
  `email` varchar(200) DEFAULT NULL COMMENT '邮箱',
  `relate_org_code` varchar(50) DEFAULT NULL COMMENT '关联的组织机构编码',
  `relate_org` varchar(100) DEFAULT NULL COMMENT '关联的组织机构名称',
  `priority` int(11) DEFAULT NULL COMMENT '优先级',
  `short_name` varchar(50) DEFAULT NULL COMMENT '短名称',
  `is_town` bit(1) DEFAULT NULL COMMENT '是否乡镇经营部: 1 是，0 否',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_unique_code` (`code`) USING BTREE,
  KEY `index_grid_status` (`grid_status`) USING BTREE,
  KEY `index_all_parent_code` (`all_parent_code`) USING BTREE,
  KEY `index_grid_name` (`name`) USING BTREE,
  KEY `spatIdx` (`bundary_coordinate`(32)),
  KEY `index_level` (`level`) USING BTREE,
  KEY `index_parent_code` (`code`) USING BTREE,
  FULLTEXT KEY `index_full_text_name` (`name`),
  FULLTEXT KEY `index_full_text_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=101200 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='网格基础信息表';

-- ----------------------------
-- Table structure for t_grid_merge_record_m
-- ----------------------------
DROP TABLE IF EXISTS `t_grid_merge_record_m`;
CREATE TABLE `t_grid_merge_record_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `resource_type` varchar(50) NOT NULL COMMENT '资源点类型(website/building/minorenterprise/uptown/sector)',
  `batch_no` varchar(32) NOT NULL COMMENT '批次号',
  `resource_code` varchar(500) NOT NULL COMMENT '资源点编码(渠道、楼宇、中小企业、家客小区、基站等)',
  `grid_code` varchar(200) NOT NULL COMMENT '区域编码',
  `status` varchar(50) DEFAULT NULL COMMENT '状态 1：生效；0：失效',
  `approver` varchar(50) DEFAULT NULL COMMENT '审批人(基站归属变更需要审批，记录审批人信息)',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `index_t_grid_merge_record_batch_no` (`batch_no`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=88327 DEFAULT CHARSET=utf8mb4 COMMENT='网格合并存储过程资源归档中间表';

-- ----------------------------
-- Table structure for t_grid_resource_index_m
-- ----------------------------
DROP TABLE IF EXISTS `t_grid_resource_index_m`;
CREATE TABLE `t_grid_resource_index_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `grid_code` varchar(50) NOT NULL COMMENT '资源点(渠道、楼宇、中小企业、家客小区、基站、聚类等)所属区域编码',
  `resource_type` varchar(50) NOT NULL COMMENT '资源类型：website/building/minorenterprise/uptown/sector/cluster/enterprise',
  `port_avail_rate` decimal(10,4) DEFAULT NULL COMMENT '端口利用率',
  `dw_permeability` decimal(10,4) DEFAULT NULL COMMENT '宽带渗透率',
  `fuse_dw_rate` decimal(10,4) DEFAULT NULL COMMENT '融合宽带率',
  `building_num` int(10) DEFAULT NULL COMMENT '楼宇数',
  `enterprise_num` int(10) DEFAULT NULL COMMENT '企业登记数',
  `marketing_self_num` int(10) DEFAULT NULL COMMENT '我网营销数',
  `marketing_other_num` int(10) DEFAULT NULL COMMENT '异网营销数',
  `uptown_num` int(10) DEFAULT NULL COMMENT '小区总数',
  `bw_arrival` int(10) DEFAULT NULL COMMENT '宽带到达',
  `day_dw_add` int(10) DEFAULT NULL COMMENT '宽带日新增',
  `month_dw_add` int(10) DEFAULT NULL COMMENT '宽带月新增',
  `month_netadd` int(10) DEFAULT NULL COMMENT '宽带月净增',
  `magicbai_netadd` int(10) DEFAULT NULL COMMENT '魔百和月净增',
  `magicbai_user_arrival` int(10) DEFAULT NULL COMMENT '魔百和到达',
  `magicbai_permeability` decimal(10,4) DEFAULT NULL COMMENT '魔百和渗透率',
  `ecology_busi_permeability` decimal(10,4) DEFAULT NULL COMMENT '生态业务渗透率',
  `customer_realinstall_rate` decimal(10,4) DEFAULT NULL COMMENT '客户实装率',
  `bw_year_keeprate` decimal(10,4) DEFAULT NULL COMMENT '宽带年化保有率',
  `magicbai_year_keeprate` decimal(10,4) DEFAULT NULL COMMENT '魔百和年化保有率',
  `magicbai_monthadd` int(10) DEFAULT NULL COMMENT '魔百和日新增',
  `magicbai_sale_rate` decimal(10,4) DEFAULT NULL COMMENT '魔百和搭售率（%）',
  `same_loading_rcrate` decimal(10,4) DEFAULT NULL COMMENT '遥控器同裝率（%）',
  `magicbai_yearpackage` decimal(10,4) DEFAULT NULL COMMENT '魔百和年包',
  `voice_invite_rc` int(10) DEFAULT NULL COMMENT '语音邀遥控器',
  `port_num` int(10) DEFAULT NULL COMMENT '端口数',
  `cover_user_nums` int(10) DEFAULT NULL COMMENT '覆盖用户数',
  `ims_user_nums` int(10) DEFAULT NULL COMMENT 'IMS到达',
  `ims_permeability` decimal(10,4) DEFAULT NULL COMMENT 'IMS渗透率',
  `year_dw_offnet` int(10) DEFAULT NULL COMMENT '企宽年离网',
  `month_dw_offnet` int(10) DEFAULT NULL COMMENT '企宽月离网',
  `all_business_num` int(10) DEFAULT NULL COMMENT '总商机数',
  `touch_business_num` int(10) DEFAULT NULL COMMENT '商机接触数',
  `reach_business_num` int(10) DEFAULT NULL COMMENT '商机达成数',
  `family_num` int(10) DEFAULT NULL COMMENT '家庭数',
  `free_port_num` int(10) DEFAULT NULL COMMENT '剩余端口数',
  `year_bw_add` int(10) DEFAULT NULL COMMENT '宽带年净增',
  `ecology_arrival` int(10) DEFAULT NULL COMMENT '生态到达',
  `month_ecology_add` int(10) DEFAULT NULL COMMENT '生态月净增',
  `enterprise_member_num` int(10) DEFAULT NULL COMMENT '集团成员数',
  `v_member_num` int(10) DEFAULT NULL COMMENT 'V网成员数',
  `valid_v_member_num` int(10) DEFAULT NULL COMMENT '有效V网成员数',
  `v_permeability` decimal(10,4) DEFAULT NULL COMMENT 'V网渗透率',
  `enterprise_product_num` int(10) DEFAULT NULL COMMENT '集团产品数',
  `infor_pretax_income` int(10) DEFAULT NULL COMMENT '信息化税前收入',
  `statistics_time` date NOT NULL COMMENT '统计时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_grid_resource_index_unique_key_grid_code_resource_type_sta` (`grid_code`,`resource_type`,`statistics_time`) USING BTREE,
  KEY `index_grid_resource_index_grid_code` (`grid_code`) USING BTREE,
  KEY `index_grid_resource_index_statistics_time` (`statistics_time`)
) ENGINE=InnoDB AUTO_INCREMENT=2472 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='区域资源点指标表';

-- ----------------------------
-- Table structure for t_grid_resource_record_m
-- ----------------------------
DROP TABLE IF EXISTS `t_grid_resource_record_m`;
CREATE TABLE `t_grid_resource_record_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `resource_type` varchar(50) NOT NULL COMMENT '资源点类型(website/building/minorenterprise/uptown/sector)',
  `resource_code` varchar(500) NOT NULL COMMENT '资源点编码(渠道、楼宇、中小企业、家客小区、基站等)',
  `grid_code` varchar(200) NOT NULL COMMENT '区域编码',
  `status` varchar(50) DEFAULT NULL COMMENT '状态 1：生效；0：失效',
  `approver` varchar(50) DEFAULT NULL COMMENT '审批人(基站归属变更需要审批，记录审批人信息)',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `index_grid_resource_record_resource_code` (`resource_code`) USING BTREE,
  KEY `index_grid_resource_record_resource_type` (`resource_type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=67770 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='资源点和区域关系记录表';

-- ----------------------------
-- Table structure for t_grid_statistics
-- ----------------------------
DROP TABLE IF EXISTS `t_grid_statistics`;
CREATE TABLE `t_grid_statistics` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `grid_code` varchar(50) NOT NULL COMMENT '区域编码',
  `level` varchar(50) NOT NULL COMMENT '区域层级',
  `type` varchar(50) NOT NULL COMMENT '统计类型: 区域统计信息 info、区域资源点数量统计 pointcount、区域资源统计信息arearesource、区域资源指标：website/building/minorenterprise/uptown/ sector/cluster/enterprise',
  `key` varchar(100) NOT NULL COMMENT '键',
  `value` varchar(200) NOT NULL COMMENT '值',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `statistics_time` date NOT NULL COMMENT '统计时间',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_grid_statistics_unique_key_grid_code_key_statistics_time` (`grid_code`,`key`,`statistics_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=17251384 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='区域统计扩展键值表';

-- ----------------------------
-- Table structure for t_grid_statistics_displayconfig
-- ----------------------------
DROP TABLE IF EXISTS `t_grid_statistics_displayconfig`;
CREATE TABLE `t_grid_statistics_displayconfig` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `grid_statistics_key` varchar(100) NOT NULL COMMENT '区域统计扩展KEY值',
  `type` varchar(50) DEFAULT NULL COMMENT '统计类型:区域统计信息 info、区域资源点数量统计 pointcount',
  `name` varchar(200) NOT NULL COMMENT '名称',
  `seq` int(10) DEFAULT NULL COMMENT '序号,用于配置显示顺序',
  `group` varchar(200) DEFAULT NULL COMMENT '统计组别:用于多页签显示',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_grid_statistics_displayconfig_unique_key_type` (`grid_statistics_key`,`type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=12409957 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='区域统计扩展键值显示配置表';

-- ----------------------------
-- Table structure for t_grid_statistics_displayconfig_copy
-- ----------------------------
DROP TABLE IF EXISTS `t_grid_statistics_displayconfig_copy`;
CREATE TABLE `t_grid_statistics_displayconfig_copy` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '区域编码',
  `grid_statistics_key` varchar(100) NOT NULL COMMENT '区域统计扩展KEY值',
  `type` varchar(50) DEFAULT NULL COMMENT '统计类型:区域统计信息 info、区域资源点数量统计 pointcount',
  `name` varchar(200) NOT NULL COMMENT '名称',
  `seq` int(10) DEFAULT NULL COMMENT '序号,用于配置显示顺序',
  `group` varchar(200) DEFAULT NULL COMMENT '统计组别:用于多页签显示',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_grid_statistics_displayconfig_unique_key_grid_code_key` (`grid_code`,`grid_statistics_key`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=12406251 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='区域统计扩展键值显示配置表';

-- ----------------------------
-- Table structure for t_home_test_hp
-- ----------------------------
DROP TABLE IF EXISTS `t_home_test_hp`;
CREATE TABLE `t_home_test_hp` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段列',
  `create_user` varchar(50) DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  `t_price` bigint(19) DEFAULT NULL COMMENT '使用价格',
  `t_gender` bigint(1) DEFAULT NULL COMMENT '性别',
  `t_homezone` bigint(19) DEFAULT NULL COMMENT '区号',
  `t_test_bool` bit(1) DEFAULT NULL COMMENT '测试布尔值',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='用户住宅信息_hp';

-- ----------------------------
-- Table structure for t_line_device_m
-- ----------------------------
DROP TABLE IF EXISTS `t_line_device_m`;
CREATE TABLE `t_line_device_m` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `city_id` int(11) DEFAULT NULL COMMENT '地市编号',
  `district_id` int(11) DEFAULT NULL COMMENT '区县编号',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '所属区域编码',
  `site_id` int(11) DEFAULT NULL COMMENT '站点编号',
  `room_id` int(11) DEFAULT NULL COMMENT '机房编号',
  `netpoint_id` int(11) DEFAULT NULL COMMENT '网络资源点编号',
  `facility_id` int(11) DEFAULT NULL COMMENT '设施编号',
  `name` varchar(200) DEFAULT NULL COMMENT '名称',
  `type` varchar(50) DEFAULT NULL COMMENT '类型',
  `level` varchar(50) DEFAULT NULL COMMENT '等级',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `address` varchar(500) DEFAULT NULL COMMENT '地址',
  `vender` varchar(50) DEFAULT NULL COMMENT '厂商',
  `property_right_type` varchar(50) DEFAULT NULL COMMENT '产权性质',
  `property_right_unit` varchar(50) DEFAULT NULL COMMENT '产权单位',
  `total_port_count` int(11) DEFAULT NULL COMMENT '总端子数',
  `used_port_count` int(11) DEFAULT NULL COMMENT '已用端子数',
  `network_status` varchar(50) DEFAULT NULL COMMENT '生命周期状态',
  `website_code` varchar(50) DEFAULT NULL COMMENT '网点编码',
  `extend_column` json DEFAULT NULL,
  `create_user` varchar(50) DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_line_device_m_unique_key_name` (`name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='无源设备';

-- ----------------------------
-- Table structure for t_minor_enterprise_business_intent_e
-- ----------------------------
DROP TABLE IF EXISTS `t_minor_enterprise_business_intent_e`;
CREATE TABLE `t_minor_enterprise_business_intent_e` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `minor_enterprise_code` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '集团商机编码',
  `business_name` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '业务名称',
  `business_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '业务代码',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `index_t_minor_enterprise_intent_business_e_minor_enterprise_code` (`minor_enterprise_code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='企业商机业务意向信息表';

-- ----------------------------
-- Table structure for t_mobile_grid_m
-- ----------------------------
DROP TABLE IF EXISTS `t_mobile_grid_m`;
CREATE TABLE `t_mobile_grid_m` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `phone` varchar(50) DEFAULT NULL COMMENT '手机号',
  `grid_code` varchar(200) DEFAULT NULL COMMENT '归属区域编码',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `phone_index` (`phone`) USING BTREE,
  KEY `grid_code_index` (`grid_code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='移动用户归属网格（大数据）';

-- ----------------------------
-- Table structure for t_net_board_m
-- ----------------------------
DROP TABLE IF EXISTS `t_net_board_m`;
CREATE TABLE `t_net_board_m` (
  `id` bigint(20) NOT NULL COMMENT '自动ID',
  `city_id` int(11) DEFAULT NULL COMMENT '地市编号',
  `district_id` int(11) DEFAULT NULL COMMENT '区县编号',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '所属区域编码',
  `ne_id` int(11) DEFAULT NULL COMMENT '网元编号',
  `board_model` varchar(50) DEFAULT NULL COMMENT '单板型号',
  `board_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '单板类型：',
  `slot_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '槽位号',
  `subcard_id` varchar(50) DEFAULT NULL COMMENT '子卡编号(编号1、编号2)',
  `port_count` int(11) DEFAULT NULL COMMENT '端口总数',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='单板';

-- ----------------------------
-- Table structure for t_net_cable_segment_m
-- ----------------------------
DROP TABLE IF EXISTS `t_net_cable_segment_m`;
CREATE TABLE `t_net_cable_segment_m` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `city_id` int(11) DEFAULT NULL COMMENT '地市编号',
  `district_id` int(11) DEFAULT NULL COMMENT '区县编号',
  `business_grid_id` int(11) DEFAULT NULL COMMENT '综合业务区编号',
  `cable_name` varchar(200) DEFAULT NULL COMMENT '所属光缆名称',
  `cable_id` int(11) DEFAULT NULL COMMENT '所属光缆编号',
  `name` varchar(200) DEFAULT NULL COMMENT '名称',
  `type` varchar(50) DEFAULT NULL COMMENT '类型',
  `level` varchar(50) DEFAULT NULL COMMENT '等级',
  `a_device_id` int(11) DEFAULT NULL COMMENT '源设备编号',
  `a_device_name` varchar(200) DEFAULT NULL COMMENT '源设备名称',
  `z_device_id` int(11) DEFAULT NULL COMMENT '宿设备编号',
  `z_device_name` varchar(200) DEFAULT NULL COMMENT '宿设备名称',
  `lay_method` varchar(50) DEFAULT NULL COMMENT '敷设方式',
  `diameter` double DEFAULT NULL COMMENT '直径',
  `length` double DEFAULT NULL COMMENT '长度',
  `calc_length` double DEFAULT NULL COMMENT '计算长度',
  `path` geometry DEFAULT NULL COMMENT '路径_4326',
  `path_gcj` geometry DEFAULT NULL COMMENT '路径_火星',
  `vender` varchar(50) DEFAULT NULL COMMENT '厂商',
  `property_right_type` varchar(50) DEFAULT NULL COMMENT '产权性质',
  `property_right_unit` varchar(50) DEFAULT NULL COMMENT '产权单位',
  `network_status` varchar(50) DEFAULT NULL COMMENT '生命周期状态',
  `is_dirty` int(11) DEFAULT NULL,
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `t_name` (`name`) USING BTREE,
  KEY `t_level` (`level`) USING BTREE,
  KEY `i_district_id` (`district_id`) USING BTREE,
  KEY `i_business_grid_id` (`business_grid_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='缆线段';

-- ----------------------------
-- Table structure for t_net_create_table
-- ----------------------------
DROP TABLE IF EXISTS `t_net_create_table`;
CREATE TABLE `t_net_create_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `table_script` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Table structure for t_net_facility_m
-- ----------------------------
DROP TABLE IF EXISTS `t_net_facility_m`;
CREATE TABLE `t_net_facility_m` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `city_id` int(11) DEFAULT NULL COMMENT '地市编号',
  `district_id` int(11) DEFAULT NULL COMMENT '区县编号',
  `business_grid_id` int(11) DEFAULT NULL COMMENT '综合业务区编号',
  `name` varchar(200) DEFAULT NULL COMMENT '名称',
  `type` varchar(50) DEFAULT NULL COMMENT '类型',
  `is_joint_point` bit(1) DEFAULT NULL COMMENT '是否接头点',
  `longitude` double DEFAULT NULL COMMENT '经度',
  `latitude` double DEFAULT NULL COMMENT '纬度',
  `location` geometry DEFAULT NULL COMMENT '坐标_4326',
  `location_gcj` geometry DEFAULT NULL COMMENT '坐标_火星',
  `address` varchar(500) DEFAULT NULL COMMENT '地址',
  `vender` varchar(50) DEFAULT NULL COMMENT '厂商',
  `property_right_type` varchar(50) DEFAULT NULL COMMENT '产权性质',
  `property_right_unit` varchar(50) DEFAULT NULL COMMENT '产权单位',
  `network_status` varchar(50) DEFAULT NULL COMMENT '生命周期状态',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_city` (`city_id`) USING BTREE,
  KEY `idx_district` (`district_id`) USING BTREE,
  KEY `idx_grid` (`business_grid_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='设施';

-- ----------------------------
-- Table structure for t_net_link_m
-- ----------------------------
DROP TABLE IF EXISTS `t_net_link_m`;
CREATE TABLE `t_net_link_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '所属区域编码',
  `name` varchar(500) DEFAULT NULL COMMENT '链路名称',
  `type` varchar(50) DEFAULT NULL COMMENT '链路类型',
  `capacity` varchar(50) DEFAULT NULL COMMENT '容量',
  `a_ne_id` int(11) DEFAULT NULL COMMENT '源网元编号',
  `a_port_id` int(11) DEFAULT NULL COMMENT '源端口编号',
  `z_ne_id` int(11) DEFAULT NULL COMMENT '宿网元编号',
  `z_port_id` int(11) DEFAULT NULL COMMENT '宿端口编号',
  `interface_type` varchar(50) DEFAULT NULL COMMENT '接口类型',
  `interface_l1` varchar(50) DEFAULT NULL COMMENT 'L1接口',
  `interface_l2` varchar(50) DEFAULT NULL COMMENT 'L2接口',
  `interface_l3` varchar(50) DEFAULT NULL COMMENT 'L3接口',
  `level` varchar(200) DEFAULT NULL COMMENT '层级关系',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  `task_id` varchar(50) DEFAULT NULL COMMENT '任务ID',
  `city_id` bigint(20) DEFAULT NULL COMMENT '城市ID',
  `rate` double DEFAULT NULL COMMENT '链路速率',
  `status` varchar(50) DEFAULT NULL COMMENT '链路状态',
  `a_port_number` varchar(50) DEFAULT NULL COMMENT '源端口',
  `z_port_number` varchar(50) DEFAULT NULL COMMENT '宿端口',
  `remark` varchar(1024) DEFAULT NULL COMMENT '备注',
  `extend_field` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='链路';

-- ----------------------------
-- Table structure for t_net_link_traffic_e
-- ----------------------------
DROP TABLE IF EXISTS `t_net_link_traffic_e`;
CREATE TABLE `t_net_link_traffic_e` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编码',
  `link_id` int(11) DEFAULT NULL COMMENT '链路编号',
  `name` varchar(200) DEFAULT NULL COMMENT '名称',
  `traffic_level` varchar(50) DEFAULT NULL COMMENT '链路级别：link/service',
  `service_type` varchar(50) DEFAULT NULL COMMENT '业务类型',
  `data_time` datetime DEFAULT NULL COMMENT '流量时间',
  `receive_max_traffic` decimal(10,2) DEFAULT NULL COMMENT '接收方向接口带宽最大值',
  `receive_max_utilization` decimal(10,2) DEFAULT NULL COMMENT '接收最大流量利用率（%）',
  `receive_min_traffic` decimal(10,2) DEFAULT NULL COMMENT '接收方向接口带宽最小值',
  `receive_min_utilization` decimal(10,2) DEFAULT NULL COMMENT '接收最小流量利用率（%）',
  `receive_mean_traffic` decimal(10,2) DEFAULT NULL COMMENT '接收方向流量均值',
  `receive_mean_utilization` decimal(10,2) DEFAULT NULL COMMENT '接收平均流量利用率（%）',
  `send_max_traffic` decimal(10,2) DEFAULT NULL COMMENT '发送方向接口带宽最大值',
  `send_max_utilization` decimal(10,2) DEFAULT NULL COMMENT '发送方向最大流量利用率（%）',
  `send_min_traffic` decimal(10,2) DEFAULT NULL COMMENT '发送方向接口带宽最小值',
  `send_min_utilization` decimal(10,2) DEFAULT NULL COMMENT '发送方向最小流量利用率（%）',
  `send_mean_traffic` decimal(10,2) DEFAULT NULL COMMENT '发送方向流量均值',
  `send_mean_utilization` decimal(10,2) DEFAULT NULL COMMENT '发送方向平均流量利用率（%）',
  `extend_column` json DEFAULT NULL,
  `create_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `modify_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `modify_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='链路流量扩展表';

-- ----------------------------
-- Table structure for t_net_ne_m
-- ----------------------------
DROP TABLE IF EXISTS `t_net_ne_m`;
CREATE TABLE `t_net_ne_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '所属区域编码',
  `site_id` int(11) DEFAULT NULL COMMENT '站点编号',
  `room_id` int(11) DEFAULT NULL COMMENT '机房编号',
  `netpoint_id` int(11) DEFAULT NULL COMMENT '网络资源点编号',
  `code` varchar(50) DEFAULT NULL COMMENT '编码',
  `name` varchar(500) DEFAULT NULL COMMENT '网元名称',
  `type` varchar(50) DEFAULT NULL COMMENT '类型',
  `model` varchar(50) DEFAULT NULL COMMENT '型号',
  `level` varchar(50) DEFAULT NULL COMMENT '等级',
  `ip_address` varchar(200) DEFAULT NULL COMMENT 'IP地址',
  `lsr_id` varchar(50) DEFAULT NULL COMMENT 'LSR ID',
  `software_version` varchar(50) DEFAULT NULL COMMENT '软件版本',
  `subnet` varchar(500) DEFAULT NULL COMMENT '子网',
  `subnet_path` varchar(5000) DEFAULT NULL COMMENT '子网路径',
  `longitude` double DEFAULT NULL COMMENT '经度',
  `latitude` double DEFAULT NULL COMMENT '纬度',
  `location` geometry DEFAULT NULL COMMENT '坐标_4326',
  `location_gcj` geometry DEFAULT NULL COMMENT '坐标_火星',
  `address` varchar(500) DEFAULT NULL COMMENT '地址',
  `total_port_count` int(11) DEFAULT NULL COMMENT '总端口数',
  `available_port_count` int(11) DEFAULT NULL COMMENT '可用端口数',
  `vender` varchar(50) DEFAULT NULL COMMENT '厂商',
  `property_right_type` varchar(50) DEFAULT NULL COMMENT '产权性质',
  `property_right_unit` varchar(50) DEFAULT NULL COMMENT '产权单位',
  `network_status` varchar(50) DEFAULT NULL COMMENT '生命周期状态',
  `role` varchar(200) DEFAULT NULL COMMENT '网元角色(CR、SR、ACC、AG、AGG、asg)',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='网元';

-- ----------------------------
-- Table structure for t_net_path_flow_e
-- ----------------------------
DROP TABLE IF EXISTS `t_net_path_flow_e`;
CREATE TABLE `t_net_path_flow_e` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `path_id` varchar(50) DEFAULT NULL COMMENT '路径ID',
  `path_hops` int(11) DEFAULT NULL COMMENT '当前跳数',
  `ne_id` int(11) DEFAULT NULL COMMENT '网元编号',
  `ne_name` varchar(200) DEFAULT NULL COMMENT '网元名称',
  `ingress_interface_name` varchar(200) DEFAULT NULL COMMENT '入端口名称',
  `egress_interface_name` varchar(200) DEFAULT NULL COMMENT '出端口名称',
  `data_time` datetime DEFAULT NULL COMMENT '数据时间',
  `create_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='流量路径扩展表';

-- ----------------------------
-- Table structure for t_net_path_flow_m
-- ----------------------------
DROP TABLE IF EXISTS `t_net_path_flow_m`;
CREATE TABLE `t_net_path_flow_m` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `flow_id` int(11) DEFAULT NULL COMMENT 'flow编号',
  `path_id` varchar(50) DEFAULT NULL COMMENT '路径ID',
  `flow_name` varchar(200) DEFAULT NULL COMMENT '流量名称',
  `flow_type` varchar(50) DEFAULT NULL COMMENT '流量类型',
  `path_layer` varchar(50) DEFAULT NULL COMMENT '路径等级',
  `path_mode` varchar(50) DEFAULT NULL COMMENT '路径模式',
  `path_priority` varchar(50) DEFAULT NULL COMMENT '路径级别',
  `path_role` varchar(50) DEFAULT NULL COMMENT '路径角色',
  `sum_hops` int(11) DEFAULT NULL COMMENT '总跳数',
  `have_mandatory_point` bit(1) DEFAULT NULL COMMENT '是否有必经节点',
  `mandatory_point_nename` varchar(200) DEFAULT NULL COMMENT '必经节点名称',
  `site_quantity` int(11) DEFAULT NULL COMMENT '站点数量',
  `data_time` datetime DEFAULT NULL COMMENT '数据时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='流量路径基础表';

-- ----------------------------
-- Table structure for t_net_port_m
-- ----------------------------
DROP TABLE IF EXISTS `t_net_port_m`;
CREATE TABLE `t_net_port_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '所属区域编码',
  `ne_id` int(11) DEFAULT NULL COMMENT '网元编号',
  `board_model` varchar(50) DEFAULT NULL COMMENT '单板型号',
  `slot_number` int(11) DEFAULT NULL COMMENT '槽位号',
  `number` varchar(50) DEFAULT NULL COMMENT '端口号',
  `type` varchar(50) DEFAULT NULL COMMENT '类型 Trunk、Virtual-Ethernet、GlobalVE、L2VE、L3VE',
  `speed_rate` varchar(50) DEFAULT NULL COMMENT '速率 FE/GE/10GE/100GE/200GE',
  `ip_address` varchar(50) DEFAULT NULL COMMENT 'IP地址',
  `is_used` bit(1) DEFAULT NULL COMMENT '是否占用',
  `remark` varchar(1024) DEFAULT NULL COMMENT '描述',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='端口';

-- ----------------------------
-- Table structure for t_net_subnet_m
-- ----------------------------
DROP TABLE IF EXISTS `t_net_subnet_m`;
CREATE TABLE `t_net_subnet_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '所属区域编码',
  `name` varchar(500) DEFAULT NULL COMMENT '子网名称',
  `parent_name` varchar(500) DEFAULT NULL COMMENT '父子网名称',
  `type` varchar(50) DEFAULT NULL COMMENT '子网类型(接入子网、汇聚子网)',
  `level` int(11) DEFAULT NULL COMMENT '层级',
  `path` varchar(5000) DEFAULT NULL COMMENT '子网路径',
  `subnet_path` varchar(500) DEFAULT NULL COMMENT '子网路径',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='子网元';

-- ----------------------------
-- Table structure for t_primary_address_m
-- ----------------------------
DROP TABLE IF EXISTS `t_primary_address_m`;
CREATE TABLE `t_primary_address_m` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `address_id` varchar(50) DEFAULT NULL COMMENT '一级地址ID',
  `address_name` varchar(200) DEFAULT NULL COMMENT '一级地址名称',
  `all_address_id` varchar(500) DEFAULT NULL COMMENT '一级地址id全路径',
  `all_address_name` varchar(3000) DEFAULT NULL COMMENT '一级地址名称全路径',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='一级地址(CRM)';

-- ----------------------------
-- Table structure for t_resource_all
-- ----------------------------
DROP TABLE IF EXISTS `t_resource_all`;
CREATE TABLE `t_resource_all` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `grid_code` varchar(200) DEFAULT NULL COMMENT '归属责任田',
  `all_parent_code` varchar(10000) DEFAULT NULL COMMENT '全部父节点网格编码',
  `code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '资源code',
  `name` varchar(200) NOT NULL COMMENT '资源名称',
  `bundary_coordinates` geometry NOT NULL COMMENT '资源坐标，请插入基础资源的时候直接忽略坐标为0的数据，插入后也无意义',
  `res_type_code` varchar(50) NOT NULL COMMENT 'resTypeCode-资源编码/资源类型，自己酌情修改字段长度与备注',
  `icon_type` varchar(50) NOT NULL COMMENT 'iconType-资源图标，自己酌情修改字段长度与备注',
  `res_content` varchar(200) DEFAULT NULL COMMENT '资源内容',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `create_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_unique_key_code` (`code`,`res_type_code`),
  KEY `index_grid_code` (`grid_code`) USING BTREE,
  KEY `spidx` (`bundary_coordinates`(32)),
  FULLTEXT KEY `index_all_parent_code` (`all_parent_code`)
) ENGINE=InnoDB AUTO_INCREMENT=515654 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='资源整合表，所有坐标有问题，或者固定查询类型（例如cover_type = 聚类场景）均在入此表的时候限制';

-- ----------------------------
-- Table structure for t_secondary_address_m
-- ----------------------------
DROP TABLE IF EXISTS `t_secondary_address_m`;
CREATE TABLE `t_secondary_address_m` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `address_id` varchar(50) DEFAULT NULL COMMENT '二级地址ID',
  `address_name` varchar(200) DEFAULT NULL COMMENT '二级地址名称',
  `all_address_id` varchar(500) DEFAULT NULL COMMENT '二级地址id全路径',
  `all_address_name` varchar(3000) DEFAULT NULL COMMENT '二级地址名称全路径',
  `first_address_id` varchar(50) DEFAULT NULL COMMENT '一级地址ID',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='二级地址(CRM)';

-- ----------------------------
-- Table structure for t_spc_city_m
-- ----------------------------
DROP TABLE IF EXISTS `t_spc_city_m`;
CREATE TABLE `t_spc_city_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `code` varchar(50) DEFAULT NULL COMMENT '编码',
  `name` varchar(200) DEFAULT NULL COMMENT '名称',
  `area` double DEFAULT NULL COMMENT '面积',
  `boundary` geometry DEFAULT NULL COMMENT '边界',
  `extend_column` json DEFAULT NULL,
  `create_user` varchar(50) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `modify_user` varchar(50) DEFAULT NULL,
  `modify_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='地市';

-- ----------------------------
-- Table structure for t_spc_netpoint_m
-- ----------------------------
DROP TABLE IF EXISTS `t_spc_netpoint_m`;
CREATE TABLE `t_spc_netpoint_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `city_id` int(11) DEFAULT NULL COMMENT '地市编号',
  `district_id` int(11) DEFAULT NULL COMMENT '区县编号',
  `business_grid_id` int(11) DEFAULT NULL COMMENT '综合业务区编号',
  `name` varchar(200) DEFAULT NULL COMMENT '名称',
  `type` varchar(50) DEFAULT NULL COMMENT '类型',
  `longitude` double DEFAULT NULL COMMENT '经度',
  `latitude` double DEFAULT NULL COMMENT '纬度',
  `location` geometry DEFAULT NULL COMMENT '边界_4326',
  `location_gcj` geometry DEFAULT NULL COMMENT '边界_火星',
  `address` varchar(500) DEFAULT NULL COMMENT '地址',
  `property_right_type` varchar(50) DEFAULT NULL COMMENT '产权性质',
  `property_right_unit` varchar(50) DEFAULT NULL COMMENT '产权单位',
  `network_status` varchar(50) DEFAULT NULL COMMENT '生命周期状态',
  `extend_column` json DEFAULT NULL,
  `create_user` varchar(50) DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='网络资源点';

-- ----------------------------
-- Table structure for t_spc_room_m
-- ----------------------------
DROP TABLE IF EXISTS `t_spc_room_m`;
CREATE TABLE `t_spc_room_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `city_id` int(11) DEFAULT NULL COMMENT '地市编号',
  `district_id` int(11) DEFAULT NULL COMMENT '区县编号',
  `business_grid_id` int(11) DEFAULT NULL COMMENT '综合业务区编号',
  `site_id` int(11) DEFAULT NULL COMMENT '站点编号',
  `name` varchar(500) DEFAULT NULL COMMENT '名称',
  `floor` int(11) DEFAULT NULL COMMENT '楼层',
  `type` varchar(50) DEFAULT NULL COMMENT '类型',
  `level` varchar(50) DEFAULT NULL COMMENT '等级',
  `business_level` varchar(200) DEFAULT NULL COMMENT '业务等级',
  `total_space` int(11) DEFAULT NULL COMMENT '总空间',
  `remain_space` int(11) DEFAULT NULL COMMENT '剩余空间',
  `total_power` int(11) DEFAULT NULL COMMENT '总动力',
  `remain_power` int(11) DEFAULT NULL COMMENT '剩余动力',
  `property_right_type` varchar(50) DEFAULT NULL COMMENT '产权性质',
  `property_right_unit` varchar(50) DEFAULT NULL COMMENT '产权单位',
  `longitude` double DEFAULT NULL COMMENT '经度',
  `latitude` double DEFAULT NULL COMMENT '纬度',
  `location` geometry DEFAULT NULL COMMENT '坐标_4326',
  `location_gcj` geometry DEFAULT NULL COMMENT '坐标_火星',
  `address` varchar(500) DEFAULT NULL COMMENT '地址',
  `network_status` varchar(50) DEFAULT NULL COMMENT '生命周期状态',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='机房';

-- ----------------------------
-- Table structure for t_spc_site_m
-- ----------------------------
DROP TABLE IF EXISTS `t_spc_site_m`;
CREATE TABLE `t_spc_site_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `city_id` int(11) DEFAULT NULL COMMENT '地市编号',
  `district_id` int(11) DEFAULT NULL COMMENT '区县编号',
  `business_grid_id` int(11) DEFAULT NULL COMMENT '综合业务区编号',
  `code` varchar(50) DEFAULT NULL COMMENT '编码',
  `name` varchar(500) DEFAULT NULL COMMENT '名称',
  `type` varchar(50) DEFAULT NULL COMMENT '类型',
  `category` varchar(50) DEFAULT NULL COMMENT '分类',
  `longitude` double(20,15) DEFAULT NULL COMMENT '经度',
  `latitude` double(20,15) DEFAULT NULL COMMENT '纬度',
  `location` geometry DEFAULT NULL,
  `location_gcj` geometry DEFAULT NULL COMMENT '坐标_火星',
  `address` varchar(500) DEFAULT NULL COMMENT '地址',
  `property_right_type` varchar(50) DEFAULT NULL COMMENT '产权性质',
  `property_right_unit` varchar(50) DEFAULT NULL COMMENT '产权单位',
  `network_status` varchar(50) DEFAULT NULL COMMENT '生命周期状态',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='站点';

-- ----------------------------
-- Table structure for t_temp_biz_bigfamily_portrait_m
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_biz_bigfamily_portrait_m`;
CREATE TABLE `t_temp_biz_bigfamily_portrait_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `code` varchar(50) NOT NULL COMMENT '家庭画像编码',
  `family_network_status` varchar(50) DEFAULT NULL COMMENT '亲情网',
  `family_network_num` int(10) DEFAULT NULL COMMENT '亲情网可办理人数',
  `family_network_recommend` varchar(500) DEFAULT NULL COMMENT '亲情网推荐话术',
  `lovefamily_package_status` varchar(50) DEFAULT NULL COMMENT '爱家套餐',
  `lovefamily_package_level` varchar(200) DEFAULT NULL COMMENT '爱家套餐档次',
  `lovefamily_package_recommend` varchar(500) DEFAULT NULL COMMENT '爱家套餐推荐话术',
  `rearview_mirror_status` varchar(50) DEFAULT NULL COMMENT '后视镜',
  `rearview_mirror_recommend` varchar(500) DEFAULT NULL COMMENT '后视镜推荐话术',
  `vehicleowner_service_status` varchar(50) DEFAULT NULL COMMENT '车主服务',
  `vehicleowner_service_recommend` varchar(500) DEFAULT NULL COMMENT '车主服务推荐话术',
  `family_num` int(10) DEFAULT NULL COMMENT '家庭成员数',
  `self_net_num` int(10) DEFAULT NULL COMMENT '我网成员',
  `diffnet_net_num` int(10) DEFAULT NULL COMMENT '异网成员',
  `main_phone` varchar(50) DEFAULT NULL COMMENT '家庭主号',
  `family_members_remark` varchar(200) DEFAULT NULL COMMENT '家庭成员备注',
  `remark` varchar(500) DEFAULT NULL COMMENT '其他',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='大家庭画像临时表';

-- ----------------------------
-- Table structure for t_temp_biz_building_index_m
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_biz_building_index_m`;
CREATE TABLE `t_temp_biz_building_index_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `building_code` varchar(50) NOT NULL COMMENT '楼宇编码',
  `self_user_num` int(10) DEFAULT NULL COMMENT '我网用户数',
  `other_user_num` int(10) DEFAULT NULL COMMENT '异网用户数',
  `statistics_time` date NOT NULL COMMENT '统计时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='楼宇指标临时表';

-- ----------------------------
-- Table structure for t_temp_biz_building_m
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_biz_building_m`;
CREATE TABLE `t_temp_biz_building_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '区域编码',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `bundary_coordinates` geometry NOT NULL COMMENT '边界坐标',
  `code` varchar(50) NOT NULL COMMENT '楼宇编码',
  `name` varchar(200) DEFAULT NULL COMMENT '楼宇名称',
  `floornum` int(10) DEFAULT NULL COMMENT '楼层数',
  `cusyomer_name` varchar(50) DEFAULT NULL COMMENT '客户名称',
  `cusyomer_phone` varchar(50) DEFAULT NULL COMMENT '客户联系电话',
  `cover_total` varchar(50) DEFAULT NULL COMMENT '覆盖总数',
  `cover_way` int(10) DEFAULT NULL COMMENT '覆盖方式',
  `open_account_num` varchar(50) DEFAULT NULL COMMENT '已开户数',
  `production_date` date DEFAULT NULL COMMENT '投产日期',
  `broadband_type` int(10) DEFAULT NULL COMMENT '宽带类型',
  `building_value` varchar(50) DEFAULT NULL COMMENT '楼宇价值',
  `route_type` int(10) DEFAULT NULL COMMENT '路由类型',
  `cusyomer_total` varchar(50) DEFAULT NULL COMMENT '客户总数',
  `sign_cusyomer_total` varchar(50) DEFAULT NULL COMMENT '已注册用户数',
  `is_agree_insert` varchar(50) DEFAULT NULL COMMENT '物业是否同意接入',
  `dedic_line_num` varchar(50) DEFAULT NULL COMMENT '专线数',
  `dedic_line_mon_income` varchar(50) DEFAULT NULL COMMENT '专线月收入',
  `remarks` varchar(50) DEFAULT NULL COMMENT '备注',
  `lytype` int(10) DEFAULT NULL COMMENT '楼宇性质',
  `addr` varchar(500) DEFAULT NULL COMMENT '详细地址',
  `xqid` int(10) DEFAULT NULL COMMENT '小区id',
  `street` varchar(200) DEFAULT NULL COMMENT '道路',
  `housenumber` varchar(50) DEFAULT NULL COMMENT '门牌',
  `area` decimal(10,2) DEFAULT NULL COMMENT '面积',
  `inblock` varchar(200) DEFAULT NULL COMMENT '乡镇街道办',
  `ratecoverage` varchar(50) DEFAULT NULL COMMENT '资源到达情况',
  `regioncode` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '区县编码',
  `regionname` varchar(200) DEFAULT NULL COMMENT '区县名称',
  `xqname` varchar(200) DEFAULT NULL COMMENT '小区名称',
  `esoptype` int(10) DEFAULT NULL COMMENT 'esop类型',
  `livefirerate` decimal(5,2) DEFAULT NULL COMMENT '实装率',
  `rescontentment` varchar(50) DEFAULT NULL COMMENT '(保留字段)资源到达情况取值：1/2/3/4/5/6/7\r\n1.设备已达\r\n2.光缆入户\r\n3.光缆到楼层\r\n4.光缆到红线内\r\n5.50米范围内有光缆\r\n6.管道到红线内\r\n7.50米范围内有管道\r\n8.未覆盖',
  `actualinvestment` varchar(50) DEFAULT NULL COMMENT '实际投资额(每栋楼宇实际建设投入的资金数)',
  `sourcetype` int(10) DEFAULT NULL COMMENT '楼宇数据来源 1：网格系统录入，2：大数据，3：地市收集，4：省公司收集，5：CRM，6：互联网',
  `covermode` int(10) DEFAULT NULL COMMENT '覆盖场景类型 1 高价值写字楼 2 普通写字楼 3 专业市场 4 机关单位、大企业、星级酒店 5 学校、厂区、医院、政府办公区 6 工业园厂区',
  `build_status` int(10) DEFAULT NULL COMMENT '楼宇状态',
  `update_date` date DEFAULT NULL COMMENT '楼宇更新时间',
  `order_source` int(10) DEFAULT NULL COMMENT '楼宇来源 1手工录入',
  `build_way` int(10) DEFAULT NULL COMMENT '建设方式',
  `build_type` int(10) DEFAULT NULL COMMENT '楼宇分类',
  `first_finish_date` date DEFAULT NULL COMMENT '初次完工时间',
  `last_finish_date` date DEFAULT NULL COMMENT '最后完工时间',
  `first_open_way` int(10) DEFAULT NULL COMMENT '初次开通方式',
  `last_open_way` int(10) DEFAULT NULL COMMENT '最后开通方式',
  `first_open_date` date DEFAULT NULL COMMENT '初次开通时间',
  `last_open_date` date DEFAULT NULL COMMENT '最后开通时间',
  `isfinish` int(10) DEFAULT NULL COMMENT '是否已完工 1已完工 2未完工',
  `real_ratecoverage` varchar(50) DEFAULT NULL COMMENT '实际资源到达情况',
  `serviceorderno` varchar(50) DEFAULT NULL COMMENT '服开工单流水号',
  `productname` varchar(50) DEFAULT NULL COMMENT '产品名称',
  `openingtype` varchar(50) DEFAULT NULL COMMENT '传输接入方式',
  `isconstruction` int(10) DEFAULT NULL COMMENT '是否需要工程建设 1是 2否',
  `businessopen_sync_date` date DEFAULT NULL COMMENT '业务开通同步时间',
  `specialcheck` int(10) DEFAULT NULL COMMENT '专项检查 1是 2否',
  `belongtype` int(10) DEFAULT NULL COMMENT '楼宇归属 1、城镇 2、农村',
  `building` varchar(100) DEFAULT NULL COMMENT '楼栋',
  `subscode` varchar(50) DEFAULT NULL COMMENT '服开crm编号',
  `is_cover_ims` bit(1) DEFAULT NULL COMMENT '是否覆盖移动ims',
  `is_cover_mobile` bit(1) DEFAULT NULL COMMENT '是否覆盖移动宽带网线',
  `is_cover_mobilecell` bit(1) DEFAULT NULL COMMENT '是否覆盖移动室分基站',
  `mobile_num` int(10) DEFAULT NULL COMMENT '移动宽带数',
  `broadband_share` decimal(10,4) DEFAULT NULL COMMENT '宽带份额',
  `manager` varchar(50) DEFAULT NULL COMMENT '网格经理',
  `manager_phone` varchar(50) DEFAULT NULL COMMENT '网格经理电话',
  `lt_num` int(10) DEFAULT NULL COMMENT 'LT宽带数',
  `telecommunication_num` int(10) DEFAULT NULL COMMENT '电信宽带数',
  `bundary` mediumtext,
  `enterprise_num` int(10) DEFAULT NULL COMMENT '企业数量',
  `cover_scene` varchar(50) DEFAULT NULL COMMENT '覆盖场景:家庭场景\\校园场景\\聚类覆盖\n',
  `addr_type` varchar(50) DEFAULT NULL COMMENT '地址类型',
  `device_type` varchar(100) DEFAULT NULL COMMENT '覆盖设备类型',
  `free_port_count` int(10) DEFAULT NULL COMMENT '空闲端口数',
  `dw_portion` decimal(10,4) DEFAULT NULL COMMENT '宽带占比',
  `property_name` varchar(50) DEFAULT NULL COMMENT '物业信息',
  `property_tel` varchar(50) DEFAULT NULL COMMENT '物业联系电话',
  `property_keyperson` varchar(300) DEFAULT NULL COMMENT '物业关键人信息',
  `property_keyperson_tel` varchar(50) DEFAULT NULL COMMENT '物业关键人联系电话',
  `city_code` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '城市编码',
  `city_name` varchar(200) DEFAULT NULL COMMENT '城市名称',
  `status` varchar(50) DEFAULT NULL COMMENT '状态 1：生效；0：失效',
  `is_confirmed` bit(1) DEFAULT NULL COMMENT '是否已确认 1、已确认 0、未确认',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10001 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='楼宇临时表';

-- ----------------------------
-- Table structure for t_temp_biz_building_marketing
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_biz_building_marketing`;
CREATE TABLE `t_temp_biz_building_marketing` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `building_code` varchar(50) NOT NULL COMMENT '楼宇编码',
  `marketing_code` varchar(50) NOT NULL COMMENT '活动编码',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='楼宇营销活动关系临时表';

-- ----------------------------
-- Table structure for t_temp_biz_enterprise
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_biz_enterprise`;
CREATE TABLE `t_temp_biz_enterprise` (
  `grid_code` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `entcode` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='集团临时表';

-- ----------------------------
-- Table structure for t_temp_biz_enterprise_m
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_biz_enterprise_m`;
CREATE TABLE `t_temp_biz_enterprise_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '区域编码',
  `code` varchar(50) NOT NULL COMMENT '集团编码',
  `name` varchar(200) DEFAULT NULL COMMENT '集团名称',
  `type` varchar(50) DEFAULT NULL COMMENT '集团类型',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `bundary_coordinates` geometry NOT NULL,
  `level` varchar(50) DEFAULT NULL COMMENT '集团等级',
  `customer_manager` varchar(50) DEFAULT NULL COMMENT '客户经理',
  `building_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '楼宇编码',
  `building_name` varchar(200) CHARACTER SET utf8 DEFAULT NULL COMMENT '楼宇名称',
  `address` varchar(200) DEFAULT NULL COMMENT '集团地址',
  `area_code` varchar(50) DEFAULT NULL COMMENT '城市编码',
  `area_name` varchar(200) DEFAULT NULL COMMENT '城市名称',
  `cnty_code` varchar(50) DEFAULT NULL COMMENT '区县编码',
  `cnty_name` varchar(200) DEFAULT NULL COMMENT '区县名称',
  `firstlevel_address` varchar(50) DEFAULT NULL COMMENT '一级地址',
  `twolevel_address` varchar(50) DEFAULT NULL COMMENT '二级地址',
  `threelevel_address` varchar(50) DEFAULT NULL COMMENT '三级地址',
  `fourlevel_address` varchar(50) DEFAULT NULL COMMENT '四级地址',
  `fivelevel_address` varchar(50) DEFAULT NULL COMMENT '五级地址',
  `sixlevel_address` varchar(50) DEFAULT NULL COMMENT '六级地址',
  `sevenlevel_address` varchar(50) DEFAULT NULL COMMENT '七级地址',
  `sourcetype` int(10) DEFAULT NULL COMMENT '数据来源 1：网格系统录入，2：大数据，3：地市收集，4：省公司收集，5：CRM，6：互联网',
  `status` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '状态:有效1/无效0/已删除2/待审批3/离网4/潜在5/集团预销户6',
  `is_confirmed` bit(1) DEFAULT NULL COMMENT '是否已确认 1、已确认 0、未确认',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='集团临时表';

-- ----------------------------
-- Table structure for t_temp_biz_marketing_m
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_biz_marketing_m`;
CREATE TABLE `t_temp_biz_marketing_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `code` varchar(50) NOT NULL COMMENT '营销活动编码',
  `name` varchar(200) DEFAULT NULL COMMENT '营销活动名称',
  `begin_time` datetime DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='营销活动临时表';

-- ----------------------------
-- Table structure for t_temp_biz_mobile_effectiveuser_statistics
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_biz_mobile_effectiveuser_statistics`;
CREATE TABLE `t_temp_biz_mobile_effectiveuser_statistics` (
  `field` varchar(50) NOT NULL COMMENT '责任田编码',
  `effectiveuser_statistics` int(11) DEFAULT NULL COMMENT '移动有效个人用户统计数'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='移动有效个人客户统计表';

-- ----------------------------
-- Table structure for t_temp_biz_phone_building
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_biz_phone_building`;
CREATE TABLE `t_temp_biz_phone_building` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `phone` varchar(50) NOT NULL COMMENT '手机号码',
  `building_code` varchar(50) NOT NULL COMMENT '楼宇编码',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='手机楼宇关系临时表';

-- ----------------------------
-- Table structure for t_temp_biz_phone_index_info
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_biz_phone_index_info`;
CREATE TABLE `t_temp_biz_phone_index_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `phone` varchar(50) NOT NULL COMMENT '手机号',
  `name` varchar(50) DEFAULT NULL COMMENT '手机号姓名',
  `city_name` varchar(200) DEFAULT NULL COMMENT '归属地市',
  `package_grade` varchar(50) DEFAULT NULL COMMENT '统一套餐档次',
  `main_products` varchar(100) DEFAULT NULL COMMENT '主体产品',
  `wait_upgrade_grade` varchar(50) DEFAULT NULL COMMENT '待升级流量模组档次',
  `user_grade` varchar(50) DEFAULT NULL COMMENT '全球通用户级别',
  `regionname` varchar(50) DEFAULT NULL COMMENT '区县名称',
  `online_times` int(10) DEFAULT NULL COMMENT '在网时长',
  `customer_star` varchar(50) DEFAULT NULL COMMENT '客户星级',
  `integral` int(10) DEFAULT NULL COMMENT '积分',
  `package_date` date DEFAULT NULL COMMENT '套餐账期日',
  `last_month_arpu` decimal(10,4) DEFAULT NULL COMMENT '上月ARPU值',
  `beforelast_month_arpu` decimal(10,4) DEFAULT NULL COMMENT '上上月ARPU值',
  `three_month_arpu` decimal(10,4) DEFAULT NULL COMMENT '近三个月ARPU值',
  `high_user` varchar(50) DEFAULT NULL COMMENT '中高端用户',
  `handhall_user` varchar(50) DEFAULT NULL COMMENT '掌厅用户',
  `currentmonth_handhall_user` varchar(50) DEFAULT NULL COMMENT '本月掌厅活用用户',
  `school_user` varchar(50) DEFAULT NULL COMMENT '校园用户',
  `non_fourg` varchar(50) DEFAULT NULL COMMENT '2/3G高流量非4G终端',
  `customer_fourg` varchar(50) DEFAULT NULL COMMENT '4G终端非4G资费客户',
  `prestorage_agreement` varchar(50) DEFAULT NULL COMMENT '预存协议款',
  `prestorage_due_time` date DEFAULT NULL COMMENT '协议款到期时间',
  `give_agreement` varchar(50) DEFAULT NULL COMMENT '赠送协议款',
  `give_due_time` date DEFAULT NULL COMMENT '赠送协议款到期时间',
  `last_month_mou` decimal(10,4) DEFAULT NULL COMMENT '上月MOU',
  `beforelast_month_mou` decimal(10,4) DEFAULT NULL COMMENT '上上月MOU',
  `is_happyfamily_user` bit(1) DEFAULT NULL COMMENT '是否欢乐家庭用户',
  `potential_netfamily_customer` varchar(50) DEFAULT NULL COMMENT '家庭网潜在客户',
  `is_use_fourgflow` bit(1) DEFAULT NULL COMMENT '是否产生4G流量',
  `is_order_fourg_flowpackage` bit(1) DEFAULT NULL COMMENT '是否订购4G流量包',
  `overlay_package_grade` decimal(10,4) DEFAULT NULL COMMENT '订购叠加包档次',
  `currentmonth_flow` decimal(10,4) DEFAULT NULL COMMENT '本月产生的流量(MB)',
  `currentmonth_saturation` decimal(10,4) DEFAULT NULL COMMENT '本月流量饱和度',
  `last_month_dou` decimal(10,4) DEFAULT NULL COMMENT '上月DOU',
  `beforelast_month_dou` decimal(10,4) DEFAULT NULL,
  `is_exceedpackage_user` bit(1) DEFAULT NULL COMMENT '是否超套餐用户',
  `migu_music_member` varchar(50) DEFAULT NULL COMMENT '咪咕音乐会员',
  `kind_comic_user` varchar(50) DEFAULT NULL COMMENT '和动漫用户',
  `is_read` bit(1) DEFAULT NULL COMMENT '阅读偏好',
  `crbt` varchar(50) DEFAULT NULL COMMENT '彩铃',
  `kind_read_user` varchar(50) DEFAULT NULL COMMENT '和阅读用户',
  `is_music` bit(1) DEFAULT NULL COMMENT '音乐偏好',
  `email` varchar(50) DEFAULT NULL COMMENT '139邮箱',
  `bw_status` varchar(50) DEFAULT NULL COMMENT '宽带当前状态',
  `bw_customer_type` varchar(50) DEFAULT NULL COMMENT '宽带客户类型',
  `bw_bandwidth` int(10) DEFAULT NULL COMMENT '宽带带宽',
  `bw_due_days` int(10) DEFAULT NULL COMMENT '宽带到期天数',
  `is_install_magicbai` bit(1) DEFAULT NULL COMMENT '历史上是否安装过魔百和',
  `magicbai_install_time` datetime DEFAULT NULL COMMENT '魔百和安装时间',
  `magicbai_due_time` datetime DEFAULT NULL COMMENT '魔百和到期时间',
  `terminal_model` varchar(50) DEFAULT NULL COMMENT '终端型号',
  `terminal_type` varchar(50) DEFAULT NULL COMMENT '终端类型',
  `terminal_use_times` int(10) DEFAULT NULL COMMENT '合约机使用时长(月)',
  `contractphone_due_days` int(10) DEFAULT NULL COMMENT '合约机到期天数',
  `min_consumption` decimal(10,4) DEFAULT NULL COMMENT '保底消费额度',
  `consumption_due_time` datetime DEFAULT NULL COMMENT '保底消费到期时间',
  `statistics_time` date NOT NULL COMMENT '统计时间',
  `bw_busi_num` int(10) DEFAULT NULL COMMENT '宽带商机',
  `value_added_num` int(10) DEFAULT NULL COMMENT '增值业务',
  `family_busi_num` int(10) DEFAULT NULL COMMENT '家庭商机',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='手机个人指标信息临时表';

-- ----------------------------
-- Table structure for t_temp_biz_phone_m
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_biz_phone_m`;
CREATE TABLE `t_temp_biz_phone_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `phone` varchar(50) DEFAULT NULL COMMENT '手机号',
  `bw_account` varchar(50) DEFAULT NULL COMMENT '宽带账户',
  `user_name` varchar(200) DEFAULT NULL COMMENT '姓名',
  `age` varchar(50) DEFAULT NULL COMMENT '年龄',
  `sex` varchar(50) DEFAULT NULL COMMENT '性别',
  `role` varchar(50) DEFAULT NULL COMMENT '角色（是否是主值号）：主号码，成员',
  `grid_code` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '网格编码',
  `uptown_code` varchar(50) DEFAULT NULL COMMENT '小区编码',
  `bw` int(11) DEFAULT NULL COMMENT '宽带带宽',
  `phone_price` varchar(50) DEFAULT NULL COMMENT '手机套餐资费',
  `imsi` varchar(50) DEFAULT NULL COMMENT 'IMSI码',
  `collect_date` datetime DEFAULT NULL COMMENT '数据日期',
  `avg_arpu` decimal(10,4) DEFAULT NULL COMMENT '平均ARPU',
  `brand` varchar(50) DEFAULT NULL COMMENT '品牌',
  `city_code` varchar(50) DEFAULT NULL COMMENT '所属城市编码',
  `sector_coordinates` geometry DEFAULT NULL COMMENT '所属基站经纬度',
  `remark` varchar(500) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='手机基本信息临时表';

-- ----------------------------
-- Table structure for t_temp_biz_phone_marketing
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_biz_phone_marketing`;
CREATE TABLE `t_temp_biz_phone_marketing` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `phone` varchar(50) NOT NULL COMMENT '手机号码',
  `marketing_code` varchar(50) NOT NULL COMMENT '营销活动编码',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='手机营销活动关系临时表';

-- ----------------------------
-- Table structure for t_temp_biz_sector
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_biz_sector`;
CREATE TABLE `t_temp_biz_sector` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '区域编码',
  `station_code` varchar(100) DEFAULT NULL COMMENT '基站编码或者ID',
  `station_name` varchar(200) DEFAULT NULL COMMENT '基站名称',
  `cgi` varchar(200) NOT NULL COMMENT 'CGI',
  `bs_code` varchar(200) DEFAULT NULL COMMENT '基站名称',
  `bs_name` varchar(200) DEFAULT NULL COMMENT '位置代码LOCAL_CD（十六进制）',
  `bs_full_name` varchar(200) DEFAULT NULL COMMENT '镇名称',
  `city_name` varchar(200) DEFAULT NULL COMMENT '镇代码',
  `area_code` varchar(50) DEFAULT NULL COMMENT '城市编码',
  `area_name` varchar(200) DEFAULT NULL COMMENT '城市名称',
  `cnty_code` varchar(50) DEFAULT NULL COMMENT '区县编码',
  `cnty_name` varchar(200) DEFAULT NULL COMMENT '区县名称',
  `county_name` varchar(200) DEFAULT NULL COMMENT '覆盖类型',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `bundary_coordinates` geometry NOT NULL COMMENT '边界坐标',
  `cover_type` varchar(50) DEFAULT NULL COMMENT '覆盖类型',
  `net_type` varchar(50) DEFAULT NULL COMMENT '网络类型',
  `loc_code` varchar(100) DEFAULT NULL COMMENT '位置代码',
  `cell_code` varchar(100) DEFAULT NULL COMMENT '扇区代码',
  `cell_name` varchar(200) DEFAULT NULL COMMENT '扇区名称',
  `cell_ci` varchar(100) DEFAULT NULL,
  `status` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '状态:有效1/无效0/已删除2/待审批3/离网4/潜在5/集团预销户6',
  `is_confirmed` bit(1) DEFAULT NULL COMMENT '是否已确认 1、已确认 0、未确认',
  `sourcetype` int(10) DEFAULT NULL COMMENT '数据来源 1：网格系统录入，2：大数据，3：地市收集，4：省公司收集，5：CRM，6：互联网',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1943447 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='扇区临时表';

-- ----------------------------
-- Table structure for t_temp_biz_sector_resource
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_biz_sector_resource`;
CREATE TABLE `t_temp_biz_sector_resource` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `cgi` varchar(200) DEFAULT NULL COMMENT 'CGI',
  `resource_type` varchar(50) DEFAULT NULL COMMENT '资源点类型(building/uptown/website/minorenterprise等)',
  `resource_code` varchar(50) DEFAULT NULL COMMENT '资源点编码(楼宇、家宽小区、渠道、中小企业等)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='基站资源点临时表';

-- ----------------------------
-- Table structure for t_temp_biz_sector_users
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_biz_sector_users`;
CREATE TABLE `t_temp_biz_sector_users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '区域编码',
  `cgi` varchar(200) DEFAULT NULL COMMENT 'CGI',
  `bts_type` varchar(50) DEFAULT NULL COMMENT '类型:1 工作时间,2 休息时间',
  `user_nums` int(10) DEFAULT NULL COMMENT '用户数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='基站用户数临时表';

-- ----------------------------
-- Table structure for t_temp_biz_smallfamily_phone_detail_m
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_biz_smallfamily_phone_detail_m`;
CREATE TABLE `t_temp_biz_smallfamily_phone_detail_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `phone` varchar(50) NOT NULL COMMENT '手机号',
  `smallfamily_code` varchar(50) NOT NULL COMMENT '小家庭编码',
  `avg_dou` decimal(10,1) DEFAULT NULL COMMENT '平均DOU',
  `avg_arpu` decimal(10,1) DEFAULT NULL COMMENT '平均ARPU',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `sex` varchar(50) DEFAULT NULL COMMENT '性别',
  `city_name` varchar(200) DEFAULT NULL COMMENT '归属地市',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='家庭商机小家庭手机明细临时表';

-- ----------------------------
-- Table structure for t_temp_biz_smallfamily_phone_m
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_biz_smallfamily_phone_m`;
CREATE TABLE `t_temp_biz_smallfamily_phone_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `grid_code` varchar(50) NOT NULL COMMENT '微网格编码',
  `phone` varchar(50) NOT NULL COMMENT '手机号',
  `is_local` bit(1) DEFAULT NULL COMMENT '是否本地市 1是 0否',
  `name` varchar(50) DEFAULT NULL COMMENT '家庭主号姓名',
  `uptown_code` varchar(50) DEFAULT NULL COMMENT '小区编码',
  `uptown_name` varchar(200) DEFAULT NULL COMMENT '小区名称',
  `uptown_level` varchar(50) DEFAULT NULL COMMENT '小区等级类型:高价值小区、低占小区、空白小区',
  `phone_coordinates` geometry DEFAULT NULL COMMENT '用户位置经纬度',
  `bigfamily_code` varchar(50) DEFAULT NULL COMMENT '大家庭编码',
  `smallfamily_code` varchar(50) DEFAULT NULL COMMENT '小家庭编码',
  `bw_busi_num` int(10) DEFAULT NULL COMMENT '宽带商机',
  `value_added_num` int(10) DEFAULT NULL COMMENT '增值业务',
  `family_busi_num` int(10) DEFAULT NULL COMMENT '家庭商机',
  `is_bw` bit(1) DEFAULT NULL COMMENT '我网宽带',
  `is_diffnet_bw` bit(1) DEFAULT NULL COMMENT '异网宽带',
  `is_potential_bw` bit(1) DEFAULT NULL COMMENT '潜在宽带',
  `is_magicbai` bit(1) DEFAULT NULL COMMENT '魔百和业务',
  `is_voice_rc` bit(1) DEFAULT NULL COMMENT '语音遥控器',
  `is_family_network` bit(1) DEFAULT NULL COMMENT '亲情网',
  `is_lovefamily_package` bit(1) DEFAULT NULL COMMENT '爱家套餐',
  `is_family_fixedline` bit(1) DEFAULT NULL COMMENT '家庭固话',
  `is_rearview_mirror` bit(1) DEFAULT NULL COMMENT '后视镜',
  `is_vehicleowner_service` bit(1) DEFAULT NULL COMMENT '车主服务',
  `is_hemu` bit(1) DEFAULT NULL COMMENT '和目',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='家庭商机小家庭主号手机临时表';

-- ----------------------------
-- Table structure for t_temp_biz_smallfamily_portrait_m
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_biz_smallfamily_portrait_m`;
CREATE TABLE `t_temp_biz_smallfamily_portrait_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `code` varchar(50) NOT NULL COMMENT '家庭画像编码',
  `wifi_status` varchar(50) DEFAULT NULL COMMENT '宽带',
  `wifi_recommend` varchar(500) DEFAULT NULL COMMENT '宽带推荐话术',
  `htv_status` varchar(50) DEFAULT NULL COMMENT '魔百和',
  `htv_recommend` varchar(500) DEFAULT NULL COMMENT '魔百和推荐话术',
  `ykq_status` varchar(50) DEFAULT NULL COMMENT '语音遥控器',
  `ykq_recommend` varchar(500) DEFAULT NULL COMMENT '语音遥控器推荐话术',
  `hemu_status` varchar(50) DEFAULT NULL COMMENT '和目',
  `hemu_recommend` varchar(500) DEFAULT NULL COMMENT '和目推荐话术',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='小家庭画像临时表';

-- ----------------------------
-- Table structure for t_temp_biz_station_m
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_biz_station_m`;
CREATE TABLE `t_temp_biz_station_m` (
  `grid_code` varchar(50) DEFAULT NULL COMMENT '区域编码',
  `code` varchar(100) DEFAULT NULL COMMENT '基站ID',
  `name` varchar(200) DEFAULT NULL COMMENT '基站名称',
  `local_cd` varchar(50) DEFAULT NULL COMMENT '位置代码LOCAL_CD（十六进制）',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `net_type` varchar(50) DEFAULT NULL COMMENT '网络类型',
  `cover_type` varchar(50) DEFAULT NULL COMMENT '覆盖类型',
  `town_name` varchar(200) DEFAULT NULL COMMENT '镇名称',
  `town_cd` varchar(50) DEFAULT NULL COMMENT '镇代码',
  KEY `index_biz_station_m_grid_code` (`grid_code`) USING BTREE,
  KEY `index_biz_station_m_code` (`code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='基站临时表';

-- ----------------------------
-- Table structure for t_temp_biz_template_m
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_biz_template_m`;
CREATE TABLE `t_temp_biz_template_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `code` varchar(50) NOT NULL COMMENT '模板编码',
  `name` varchar(200) DEFAULT NULL COMMENT '模板名称',
  `content` text COMMENT '模板内容',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='短信模板临时表';

-- ----------------------------
-- Table structure for t_temp_city
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_city`;
CREATE TABLE `t_temp_city` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `citycode` varchar(50) DEFAULT NULL,
  `adcode` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '边界坐标',
  `level` varchar(10) DEFAULT NULL COMMENT '等级',
  `wkt` geometry DEFAULT NULL COMMENT '区域边界坐标',
  `wkttext` longtext COMMENT '边界坐标文本',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Table structure for t_temp_grid_all_level
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_grid_all_level`;
CREATE TABLE `t_temp_grid_all_level` (
  `code` varchar(50) NOT NULL COMMENT '区域编码',
  `name` varchar(300) DEFAULT NULL COMMENT '区域名称',
  `city_code` varchar(300) DEFAULT NULL,
  `city_name` varchar(300) DEFAULT NULL,
  `cnty_code` varchar(300) DEFAULT NULL,
  `cnty_name` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for t_temp_grid_busi_uptwon_index_m
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_grid_busi_uptwon_index_m`;
CREATE TABLE `t_temp_grid_busi_uptwon_index_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `grid_code` varchar(50) NOT NULL COMMENT '区域编码',
  `bw_self_num` int(10) DEFAULT NULL COMMENT '我网宽带',
  `potential_bw_num` int(10) DEFAULT NULL COMMENT '潜在宽带',
  `diffnet_bw_num` int(10) DEFAULT NULL COMMENT '异网宽带',
  `magicbai_num` int(10) DEFAULT NULL COMMENT '魔百和',
  `voice_rc_num` int(10) DEFAULT NULL COMMENT '语音遥控器',
  `he_busi_num` int(10) DEFAULT NULL COMMENT '和目业务',
  `family_network_num` int(10) DEFAULT NULL COMMENT '亲情网',
  `share_flow_num` int(10) DEFAULT NULL COMMENT '流量共享',
  `lovefamily_package_num` int(10) DEFAULT NULL COMMENT '爱家套餐',
  `family_fixedline_num` int(10) DEFAULT NULL COMMENT '家庭固话',
  `rearview_mirror_num` int(10) DEFAULT NULL COMMENT '后视镜',
  `vehicleowner_service_num` int(10) DEFAULT NULL COMMENT '车主服务',
  `statistics_time` date NOT NULL COMMENT '统计时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='区域小区商机指标临时表';

-- ----------------------------
-- Table structure for t_temp_grid_m
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_grid_m`;
CREATE TABLE `t_temp_grid_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `code` varchar(50) NOT NULL COMMENT '区域编码',
  `parent_code` varchar(50) DEFAULT NULL COMMENT '父级区域编码',
  `all_parent_code` varchar(200) DEFAULT NULL COMMENT '全部父节点网格编码',
  `old_grid_code` text COMMENT '旧区域编码树：以逗号分隔',
  `name` varchar(50) DEFAULT NULL COMMENT '区域名称',
  `full_name` varchar(100) DEFAULT NULL COMMENT '区域全名称',
  `type` varchar(50) DEFAULT NULL COMMENT '网格类型：营销网格、规划网格等',
  `bundary` mediumtext COMMENT '边界',
  `bundary_coordinate` geometry DEFAULT NULL COMMENT '边界',
  `level` int(11) DEFAULT NULL COMMENT '层级',
  `headperson` varchar(50) DEFAULT NULL COMMENT '区域负责人名称',
  `headperson_code` varchar(50) DEFAULT NULL COMMENT '区域负责人工号',
  `headperson_tel` varchar(50) DEFAULT NULL COMMENT '网格负责人电话',
  `center_longitude` decimal(18,8) DEFAULT NULL COMMENT '网格中心点经度',
  `center_latitude` decimal(18,8) DEFAULT NULL COMMENT '网格中心点纬度',
  `area` decimal(10,2) DEFAULT NULL COMMENT '面积',
  `grid_status` varchar(50) DEFAULT '1' COMMENT '1 有效,2 无效',
  `email` varchar(200) DEFAULT NULL COMMENT '邮箱',
  `relate_org_code` varchar(50) DEFAULT NULL COMMENT '关联的组织机构编码',
  `relate_org` varchar(100) DEFAULT NULL COMMENT '关联的组织机构名称',
  `priority` int(11) DEFAULT NULL COMMENT '优先级',
  `short_name` varchar(50) DEFAULT NULL COMMENT '短名称',
  `is_town` bit(1) DEFAULT NULL COMMENT '是否乡镇经营部: 1 是，0 否',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='网格基础信息临时表';

-- ----------------------------
-- Table structure for t_temp_grid_resource_index_m
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_grid_resource_index_m`;
CREATE TABLE `t_temp_grid_resource_index_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `grid_code` varchar(50) NOT NULL COMMENT '资源点(渠道、楼宇、中小企业、家客小区、基站等)所属区域编码',
  `resource_type` varchar(50) NOT NULL COMMENT '资源类型：website/building/minorenterprise/uptown/sector',
  `port_avail_rate` decimal(10,4) DEFAULT NULL COMMENT '端口利用率',
  `dw_permeability` decimal(10,4) DEFAULT NULL COMMENT '宽带渗透率',
  `fuse_dw_rate` decimal(10,4) DEFAULT NULL COMMENT '融合宽带率',
  `building_num` int(10) DEFAULT NULL COMMENT '楼宇数',
  `enterprise_num` int(10) DEFAULT NULL COMMENT '企业登记数',
  `marketing_self_num` int(10) DEFAULT NULL COMMENT '我网营销数',
  `marketing_other_num` int(10) DEFAULT NULL COMMENT '异网营销数',
  `uptown_num` int(10) DEFAULT NULL COMMENT '小区总数',
  `bw_arrival` int(10) DEFAULT NULL COMMENT '宽带到达',
  `day_dw_add` int(10) DEFAULT NULL COMMENT '宽带日新增',
  `month_dw_add` int(10) DEFAULT NULL COMMENT '宽带月新增',
  `month_netadd` int(10) DEFAULT NULL COMMENT '宽带月净增',
  `magicbai_netadd` int(10) DEFAULT NULL COMMENT '魔百和月净增',
  `magicbai_user_arrival` int(10) DEFAULT NULL COMMENT '魔百和到达',
  `magicbai_permeability` decimal(10,4) DEFAULT NULL COMMENT '魔百和渗透率',
  `ecology_busi_permeability` decimal(10,4) DEFAULT NULL COMMENT '生态业务渗透率',
  `customer_realinstall_rate` decimal(10,4) DEFAULT NULL COMMENT '客户实装率',
  `bw_year_keeprate` decimal(10,4) DEFAULT NULL COMMENT '宽带年化保有率',
  `magicbai_year_keeprate` decimal(10,4) DEFAULT NULL COMMENT '魔百和年化保有率',
  `magicbai_monthadd` int(10) DEFAULT NULL COMMENT '魔百和日新增',
  `magicbai_sale_rate` decimal(10,4) DEFAULT NULL COMMENT '魔百和搭售率（%）',
  `same_loading_rcrate` decimal(10,4) DEFAULT NULL COMMENT '遥控器同裝率（%）',
  `magicbai_yearpackage` decimal(10,4) DEFAULT NULL COMMENT '魔百和年包',
  `voice_invite_rc` int(10) DEFAULT NULL COMMENT '语音邀遥控器',
  `port_num` int(10) DEFAULT NULL COMMENT '端口数',
  `statistics_time` date NOT NULL COMMENT '统计时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='区域资源点指标临时表';

-- ----------------------------
-- Table structure for t_temp_grid_resource_record_m
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_grid_resource_record_m`;
CREATE TABLE `t_temp_grid_resource_record_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `resource_type` varchar(50) NOT NULL COMMENT '资源点类型(website/building/minorenterprise/uptown/sector)',
  `resource_code` varchar(50) NOT NULL COMMENT '资源点编码(渠道、楼宇、中小企业、家客小区、基站等)',
  `grid_code` varchar(200) NOT NULL COMMENT '区域编码',
  `status` varchar(50) DEFAULT NULL COMMENT '状态 1：生效；0：失效',
  `approver` varchar(50) DEFAULT NULL COMMENT '审批人(基站归属变更需要审批，记录审批人信息)',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='资源点和区域关系记录业务临时表';

-- ----------------------------
-- Table structure for t_temp_grid_statistics
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_grid_statistics`;
CREATE TABLE `t_temp_grid_statistics` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `grid_code` varchar(50) NOT NULL COMMENT '区域编码',
  `level` varchar(50) NOT NULL COMMENT '区域层级',
  `key` varchar(100) NOT NULL COMMENT '键',
  `value` varchar(200) NOT NULL COMMENT '值',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `statistics_time` date NOT NULL COMMENT '统计时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7156561 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='区域统计扩展键值表';

-- ----------------------------
-- Table structure for t_temp_grid2
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_grid2`;
CREATE TABLE `t_temp_grid2` (
  `code` varchar(50) NOT NULL COMMENT '区域编码',
  `name` varchar(50) DEFAULT NULL COMMENT '区域名称',
  `all_parent_code` varchar(200) DEFAULT NULL COMMENT '全部父节点网格编码'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for t_temp_uptown_buildings_index_m
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_uptown_buildings_index_m`;
CREATE TABLE `t_temp_uptown_buildings_index_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `uptown_code` varchar(50) NOT NULL COMMENT '小区编码',
  `uptown_buildings_code` varchar(50) NOT NULL COMMENT '楼栋编码',
  `building_prot_rate` decimal(10,4) DEFAULT NULL COMMENT '楼栋端口占有率',
  `building_diffnet_rate` decimal(10,4) DEFAULT NULL COMMENT '楼栋异网占比',
  `statistics_time` date DEFAULT NULL COMMENT '统计时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='小区楼栋指标临时表';

-- ----------------------------
-- Table structure for t_temp_uptown_buildings_m
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_uptown_buildings_m`;
CREATE TABLE `t_temp_uptown_buildings_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `uptown_code` varchar(50) NOT NULL COMMENT '小区编码',
  `code` varchar(50) NOT NULL COMMENT '楼栋编码',
  `name` varchar(200) DEFAULT NULL COMMENT '楼栋名称',
  `address` varchar(300) DEFAULT NULL COMMENT '楼栋地址',
  `floor_num` int(10) DEFAULT NULL COMMENT '楼层数',
  `unit_num` int(10) DEFAULT NULL COMMENT '单元数',
  `floor_household_num` int(10) DEFAULT NULL COMMENT '每层户数',
  `house_num` int(10) DEFAULT NULL COMMENT '楼栋总户数',
  `sourcetype` int(10) DEFAULT NULL COMMENT '数据来源:MPP(亚信),FBB',
  `status` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '状态:有效1/无效0/已删除2/待审批3',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='小区楼栋临时表';

-- ----------------------------
-- Table structure for t_temp_uptown_buildings_unit_index_m
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_uptown_buildings_unit_index_m`;
CREATE TABLE `t_temp_uptown_buildings_unit_index_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `uptown_code` varchar(50) NOT NULL COMMENT '小区编码',
  `uptown_buildings_code` varchar(50) NOT NULL COMMENT '楼栋编号',
  `uptown_buildings_unit_code` varchar(50) NOT NULL COMMENT '单元编号',
  `unit_diffnet_rate` decimal(10,4) DEFAULT NULL COMMENT '单元的异网占比',
  `unit_port_rate` decimal(10,4) DEFAULT NULL COMMENT '单元的端口占有率',
  `statistics_time` date DEFAULT NULL COMMENT '统计时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='小区楼栋单元指标临时表';

-- ----------------------------
-- Table structure for t_temp_uptown_buildings_unit_m
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_uptown_buildings_unit_m`;
CREATE TABLE `t_temp_uptown_buildings_unit_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `uptown_code` varchar(50) NOT NULL COMMENT '小区编码',
  `uptown_buildings_code` varchar(50) NOT NULL COMMENT '楼栋编号',
  `code` varchar(50) NOT NULL COMMENT '单元编号',
  `name` varchar(200) DEFAULT NULL COMMENT '单元名称',
  `address` varchar(300) DEFAULT NULL COMMENT '单元地址',
  `floor_num` int(10) DEFAULT NULL COMMENT '楼层数',
  `status` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '状态:有效1/无效0/已删除2/待审批3',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='小区楼栋单元临时表';

-- ----------------------------
-- Table structure for t_temp_uptown_household_chargesinfo_e
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_uptown_household_chargesinfo_e`;
CREATE TABLE `t_temp_uptown_household_chargesinfo_e` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `uptown_code` varchar(50) NOT NULL COMMENT '小区编码',
  `uptown_buildings_code` varchar(50) NOT NULL COMMENT '楼栋编号',
  `uptown_buildings_unit_code` varchar(50) NOT NULL COMMENT '单元名称',
  `uptown_household_code` varchar(50) NOT NULL COMMENT '房间号',
  `business_type` varchar(200) NOT NULL COMMENT '业务类型',
  `operator` varchar(50) NOT NULL COMMENT '运营商',
  `expenses_fee` varchar(100) NOT NULL DEFAULT '0' COMMENT '资费',
  `expire_time` date DEFAULT NULL COMMENT '到期时间',
  `tel_number` varchar(50) DEFAULT NULL COMMENT '联系号码',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='小区房号资费临时表';

-- ----------------------------
-- Table structure for t_temp_uptown_household_m
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_uptown_household_m`;
CREATE TABLE `t_temp_uptown_household_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `uptown_code` varchar(50) NOT NULL COMMENT '小区编码',
  `uptown_buildings_code` varchar(50) NOT NULL COMMENT '楼栋编号',
  `uptown_buildings_unit_code` varchar(50) NOT NULL COMMENT '单元编号',
  `in_floor_num` varchar(50) DEFAULT NULL COMMENT '所在楼层',
  `code` varchar(50) NOT NULL COMMENT '房号编码',
  `name` varchar(200) DEFAULT NULL COMMENT '房号名称',
  `address` varchar(300) DEFAULT NULL COMMENT '房号地址',
  `family_num` int(10) DEFAULT NULL COMMENT '家庭成员数',
  `tel_number` varchar(50) DEFAULT NULL COMMENT '联系号码',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `status` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '状态:有效1/无效0/已删除2/待审批3',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='小区房号临时表';

-- ----------------------------
-- Table structure for t_temp_uptown_m
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_uptown_m`;
CREATE TABLE `t_temp_uptown_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `code` varchar(50) NOT NULL COMMENT '小区编码',
  `name` varchar(200) DEFAULT NULL COMMENT '小区名称',
  `type` varchar(50) DEFAULT NULL COMMENT '小区类型: 1 高价值低占小区 ',
  `grid_code` varchar(200) DEFAULT NULL COMMENT '区域编码',
  `business_department` varchar(200) DEFAULT NULL COMMENT '归属营业厅',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `bundary_coordinates` geometry NOT NULL COMMENT '边界坐标',
  `is_gps_modify` bit(1) DEFAULT NULL COMMENT '经纬度是否已修改 1是 0否',
  `city_code` varchar(50) DEFAULT NULL COMMENT '城市编码',
  `city_name` varchar(200) DEFAULT NULL COMMENT '城市名称',
  `cnty_code` varchar(50) DEFAULT NULL COMMENT '区县编码',
  `cnty_name` varchar(200) DEFAULT NULL COMMENT '区县名称',
  `district_name` varchar(200) DEFAULT NULL COMMENT '行政区域名称',
  `houseprice` decimal(10,2) DEFAULT NULL COMMENT '房价',
  `actual_householdcount` int(11) DEFAULT NULL COMMENT '小区入住总户数',
  `address` varchar(500) DEFAULT NULL COMMENT '地址',
  `building_date` date DEFAULT NULL COMMENT '建成时间',
  `flatlevel_buildingcount` int(11) DEFAULT NULL COMMENT '平层楼栋数',
  `manylevel_buildingcount` int(11) DEFAULT NULL COMMENT '多层楼栋数',
  `hightlevel_buildingcount` int(11) DEFAULT NULL COMMENT '高层楼栋数',
  `building_householdcount` int(11) DEFAULT NULL COMMENT '小区建筑总户数',
  `total_buildingcount` int(11) DEFAULT NULL COMMENT '小区总栋数',
  `property_name` varchar(200) DEFAULT NULL COMMENT '物业名称',
  `property_tel` varchar(50) DEFAULT NULL COMMENT '物业公司电话',
  `fullresources_id` varchar(50) DEFAULT NULL COMMENT '综合资源id',
  `fullresources_name` varchar(200) DEFAULT NULL COMMENT '综合资源名称',
  `total_port_count` int(11) DEFAULT NULL COMMENT '总端口数',
  `free_port_count` int(11) DEFAULT NULL COMMENT '空余端口数',
  `user_count` int(11) DEFAULT NULL COMMENT '用户数',
  `marketing_center` varchar(200) DEFAULT NULL COMMENT '营销中心',
  `one_level_address` varchar(500) DEFAULT NULL COMMENT '一级地址',
  `two_level_address` varchar(500) DEFAULT NULL COMMENT '二级地址',
  `three_level_address` varchar(500) DEFAULT NULL COMMENT '三级地址',
  `four_level_address` varchar(500) DEFAULT NULL COMMENT '四级地址',
  `five_level_address` varchar(500) DEFAULT NULL COMMENT '五级地址',
  `cover_type` varchar(50) DEFAULT NULL COMMENT '覆盖类型',
  `region_atr` varchar(50) DEFAULT NULL COMMENT '地域属性',
  `address_source` varchar(50) DEFAULT NULL COMMENT '地址来源',
  `net_source` varchar(50) DEFAULT NULL COMMENT '网络来源',
  `is_homecustomer` bit(1) DEFAULT NULL COMMENT '是否家客小区',
  `relation_cmtyname` varchar(200) DEFAULT NULL COMMENT '关联社区名称',
  `building_number` int(10) DEFAULT NULL COMMENT '楼宇数',
  `covered_building_num` int(10) DEFAULT NULL COMMENT '已覆盖移动宽带楼宇数',
  `uncovered_building_num` int(10) DEFAULT NULL COMMENT '未覆盖楼宇数',
  `broadband_share` decimal(10,4) DEFAULT NULL COMMENT '宽带份额',
  `manager` varchar(50) DEFAULT NULL,
  `manager_phone` varchar(50) DEFAULT NULL COMMENT '网格经理电话',
  `is_cover` bit(1) DEFAULT NULL COMMENT '是否覆盖',
  `unit_num` int(10) DEFAULT NULL COMMENT '单元数',
  `property_linkman` varchar(50) DEFAULT NULL COMMENT '物业联系人',
  `sourcetype` int(10) DEFAULT NULL COMMENT '数据来源',
  `is_cmty_store` bit(1) DEFAULT NULL COMMENT '是否有社区店',
  `cmty_store_name` varchar(200) DEFAULT NULL COMMENT '社区店名称',
  `cmty_store_type` varchar(50) DEFAULT NULL COMMENT '社区店类型',
  `cmty_store_position` varchar(200) DEFAULT NULL COMMENT '社区店位置',
  `status` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '状态:有效1/无效0/已删除2/待审批3',
  `is_confirmed` bit(1) DEFAULT NULL COMMENT '是否已确认 1、已确认 0、未确认',
  `level` varchar(50) DEFAULT NULL COMMENT '小区等级类型:高价值小区、低占小区、空白小区',
  `is_demolition` bit(1) DEFAULT NULL COMMENT '是否拆迁小区',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='小区临时表';

-- ----------------------------
-- Table structure for t_temp_uptown_resource_index_m
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_uptown_resource_index_m`;
CREATE TABLE `t_temp_uptown_resource_index_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `uptown_code` varchar(50) NOT NULL COMMENT '小区编码',
  `port_avail_rate` decimal(10,4) DEFAULT NULL COMMENT '端口利用率 ',
  `dw_permeability` decimal(10,4) DEFAULT NULL COMMENT '宽带渗透率',
  `month_avg_arpu` decimal(10,4) DEFAULT NULL COMMENT '月均ARPU值',
  `month_avg_dou` decimal(10,4) DEFAULT NULL COMMENT '月均DOU值',
  `marketing_business` int(10) DEFAULT NULL COMMENT '营销商机',
  `mobile_bwuser_arrival` int(10) DEFAULT NULL COMMENT '移动宽带用户到达',
  `magicbai_user_arrival` int(10) DEFAULT NULL COMMENT '魔百和用户到达',
  `magicbai_permeability` decimal(10,4) DEFAULT NULL COMMENT '魔百和渗透率',
  `mobile_user_rate` decimal(10,4) DEFAULT NULL COMMENT '移动用户占比',
  `mobile_bwnum` int(10) DEFAULT NULL COMMENT '移动宽带数',
  `unicom_bwnum` int(10) DEFAULT NULL COMMENT '联通宽带数',
  `telecom_bwnum` int(10) DEFAULT NULL COMMENT '电信宽带数',
  `month_dw_add` int(10) DEFAULT NULL COMMENT '宽带月新增',
  `month_netadd` int(10) DEFAULT NULL COMMENT '宽带月净增',
  `magicbai_add` int(10) DEFAULT NULL COMMENT '魔百和月新增',
  `magicbai_netadd` int(10) DEFAULT NULL COMMENT '魔百和月净增',
  `mobile_top1_name` varchar(200) DEFAULT NULL COMMENT '移网TOP1资费名称',
  `mobile_top1_rate` decimal(10,4) DEFAULT NULL COMMENT '移网TOP1资费占比',
  `inmonth_due_usernum` int(10) DEFAULT NULL COMMENT '我网一个月内到期宽带用户数',
  `bw_self_usernum` int(10) DEFAULT NULL COMMENT '我网宽带用户数',
  `potential_bw_usernum` int(10) DEFAULT NULL COMMENT '潜在宽带用户数',
  `diffnet_bw_usernum` int(10) DEFAULT NULL COMMENT '异网宽带用户数',
  `ecology_busi_permeability` decimal(10,4) DEFAULT NULL COMMENT '生态业务渗透率',
  `customer_realinstall_rate` decimal(10,4) DEFAULT NULL COMMENT '客户实装率',
  `statistics_time` date DEFAULT NULL COMMENT '统计时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='小区资源点指标临时表';

-- ----------------------------
-- Table structure for t_temp_uptown_user_portrait_m
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_uptown_user_portrait_m`;
CREATE TABLE `t_temp_uptown_user_portrait_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `uptown_code` varchar(50) NOT NULL COMMENT '小区编码',
  `uptown_buildings_code` varchar(50) DEFAULT NULL COMMENT '楼栋编号',
  `uptown_buildings_unit_code` varchar(50) DEFAULT NULL COMMENT '单元编号',
  `uptown_household_code` varchar(50) DEFAULT NULL COMMENT '房间号',
  `main_phone` varchar(50) DEFAULT NULL COMMENT '主手机号',
  `vice_phone` varchar(50) NOT NULL COMMENT '副手机号',
  `family_num` int(10) DEFAULT NULL COMMENT '大家庭人数',
  `cy_num` int(10) DEFAULT NULL COMMENT '大家庭成员数',
  `ww_num` int(10) DEFAULT NULL COMMENT '大家庭我网用户数',
  `yw_num` int(10) DEFAULT NULL COMMENT '大家庭异网用户数',
  `is_yye` bit(1) DEFAULT NULL COMMENT '大家庭中是否有婴幼儿',
  `is_xx` bit(1) DEFAULT NULL COMMENT '大家庭中是否有小学儿童',
  `is_zx` bit(1) DEFAULT NULL COMMENT '大家庭中是否有中学生',
  `is_old` bit(1) DEFAULT NULL COMMENT '大家庭中是否有老人',
  `is_car` bit(1) DEFAULT NULL COMMENT '大家庭是否有车',
  `class_small` varchar(50) DEFAULT NULL COMMENT '小家庭编号',
  `wifi_type` int(10) DEFAULT NULL COMMENT '小家庭宽带类型;1--开通宽带的人2--被覆盖的人3--使用异网宽带的人6--没有宽带的用户',
  `yudaoqi` int(10) DEFAULT NULL COMMENT '是否宽带预到期用户;4--异网宽带预到期用户5--我网宽带预到期用户',
  `wifi_end_date` date DEFAULT NULL COMMENT '我网宽带预到期时间',
  `full_address` varchar(300) DEFAULT NULL COMMENT '宽带安装地址',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `hs_htv` varchar(50) DEFAULT NULL COMMENT '魔百和业务标签;1-已开通2-未开通，请推荐（推荐理由）3-未开通，不推荐',
  `mbh_reason` varchar(200) DEFAULT NULL COMMENT '魔百和推荐理由',
  `hs_ykq` varchar(50) DEFAULT NULL COMMENT '语音遥控器业务标签;1-已开通2-未开通，请推荐（推荐理由）3-未开通，不推荐',
  `ykq_reason` varchar(50) DEFAULT NULL COMMENT '语音遥控器推荐理由',
  `hs_guhua` varchar(50) DEFAULT NULL COMMENT '家庭固话业务标签;1-已开通2-未开通，请推荐（推荐理由）3-未开通，不推荐',
  `guhua_reason` varchar(200) DEFAULT NULL COMMENT '家庭固话推荐理由',
  `hs_hemu` varchar(50) DEFAULT NULL COMMENT '和目业务标签;1-已开通2-未开通，请推荐（推荐理由）3-未开通，不推荐',
  `hemu_reason` varchar(200) DEFAULT NULL COMMENT '和目推荐理由',
  `hs_duanhao` varchar(50) DEFAULT NULL COMMENT '家庭短号业务标签;1-已开通2-未开通，请推荐（推荐理由）3-未开通，不推荐',
  `duanhao_reason` varchar(200) DEFAULT NULL COMMENT '家庭短号推荐理由',
  `hs_liuliang` varchar(50) DEFAULT NULL COMMENT '共享流量业务标签;1-已开通2-未开通，请推荐（推荐理由）3-未开通，不推荐;目前提供的编码并未找到对应的用户群，以及共享流量推荐业务的口径待确认、',
  `fuka_reason` varchar(200) DEFAULT NULL COMMENT '副卡推荐理由;副卡由家庭来呈现效果并不好，副卡业务的限制略大',
  `call_all_num` int(10) DEFAULT NULL COMMENT '小家庭成员月通话次数汇总',
  `call_class_num` int(10) DEFAULT NULL COMMENT '小家庭成员与大家庭成员月通话次数汇总',
  `call_enterprise_num` int(10) DEFAULT NULL COMMENT '小家庭成员与工作圈成员月通话次数汇总',
  `arpu` decimal(10,4) DEFAULT NULL COMMENT '小家庭成员近三月平均arpu汇总',
  `mou` decimal(10,4) DEFAULT NULL COMMENT '小家庭成员近三月平均通话分钟数汇总',
  `zhu_mou` decimal(10,4) DEFAULT NULL COMMENT '小家庭成员近三个平均主叫通话分钟数汇总',
  `dou` decimal(10,4) DEFAULT NULL COMMENT '小家庭成员近三个月平均使用流量汇总;单位：M',
  `tytc_monthfee_ld` decimal(10,4) DEFAULT NULL COMMENT '小家庭成员上月套餐费汇总',
  `dou_zhu` decimal(10,4) DEFAULT NULL COMMENT '小家庭成员包月套餐总流量数汇总;单位：G',
  `mou_zhu` int(10) DEFAULT NULL COMMENT '小家庭成员包月套餐总通话分钟数汇总',
  `fee_wifi` decimal(10,4) DEFAULT NULL COMMENT '小家庭成员宽带费用汇总',
  `comm_price` decimal(10,4) DEFAULT NULL COMMENT '小家庭用户居住小区房价',
  `rel_price` decimal(10,4) DEFAULT NULL COMMENT '小家庭用户平均终端价格',
  `bhd_avg` decimal(10,4) DEFAULT NULL COMMENT '小家庭成员用户近三月流量平均饱和度',
  `mo_call_duration` int(10) DEFAULT NULL COMMENT '小家庭成员与大家庭成员的总主叫通话时长;所有小家庭用户的时长进行汇总',
  `video_visit_flow` decimal(10,4) DEFAULT NULL COMMENT '小家庭成员月视频流量汇总;单位：G',
  `statistics_time` date NOT NULL COMMENT '统计时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='家客小区用户画像临时表';

-- ----------------------------
-- Table structure for t_temp_website_competition_m
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_website_competition_m`;
CREATE TABLE `t_temp_website_competition_m` (
  `website_code` varchar(50) NOT NULL COMMENT '渠道编码',
  `website_name` varchar(200) DEFAULT NULL COMMENT '渠道名称',
  `city` varchar(50) DEFAULT NULL COMMENT '地市',
  `district` varchar(50) DEFAULT NULL COMMENT '区县',
  `operator` varchar(200) DEFAULT NULL COMMENT '所属运营商',
  `address` varchar(200) DEFAULT NULL COMMENT '详细地址',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  KEY `index_temp_website_competition_website_code` (`website_code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='网点竞争渠道临时表';

-- ----------------------------
-- Table structure for t_temp_website_m
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_website_m`;
CREATE TABLE `t_temp_website_m` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '区域编码',
  `code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `unify_code` varchar(50) DEFAULT NULL COMMENT '渠道全国统一编码',
  `name` varchar(200) DEFAULT NULL COMMENT '渠道名称',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `coordinates` geometry NOT NULL COMMENT '边界坐标',
  `type` varchar(50) DEFAULT NULL COMMENT '渠道类型:1-自营厅,2-加盟厅,3-社会渠道,5-竞争渠道',
  `sub_type` varchar(50) DEFAULT NULL COMMENT '渠道子类型',
  `three_sub_type` varchar(50) DEFAULT NULL COMMENT '渠道三级类型',
  `address` varchar(200) DEFAULT NULL COMMENT '渠道地址',
  `area_code` varchar(50) DEFAULT NULL COMMENT '城市编码',
  `area_name` varchar(200) DEFAULT NULL COMMENT '城市名称',
  `cnty_code` varchar(50) DEFAULT NULL COMMENT '区县编码',
  `cnty_name` varchar(200) DEFAULT NULL COMMENT '区县名称',
  `scale` varchar(50) DEFAULT NULL COMMENT '网点规模',
  `headperson` varchar(50) DEFAULT NULL COMMENT '网点负责人1',
  `headperson_tel` varchar(50) DEFAULT NULL COMMENT '网点负责人1电话',
  `headperson2` varchar(50) DEFAULT NULL COMMENT '网点负责人2',
  `headperson2_tel` varchar(50) DEFAULT NULL COMMENT '网点负责人2',
  `channel_useraccount` varchar(50) DEFAULT NULL COMMENT '渠道经理账号',
  `channel_username` varchar(50) DEFAULT NULL COMMENT '渠道经理姓名',
  `channel_usertel` varchar(50) DEFAULT NULL COMMENT '渠道经理电话',
  `channel_status_time` datetime DEFAULT NULL COMMENT '渠道状态更改时间',
  `gent_code` varchar(50) DEFAULT NULL COMMENT '代理商编码',
  `operator` varchar(50) DEFAULT NULL COMMENT '运营商',
  `office_hours` varchar(200) DEFAULT NULL COMMENT '营业时间',
  `agent_time` datetime DEFAULT NULL COMMENT '渠道建立时间',
  `creator_name` varchar(50) DEFAULT NULL COMMENT '渠道记录创建人',
  `picture_url` varchar(2000) DEFAULT NULL COMMENT '图片URL',
  `sourcetype` int(10) DEFAULT NULL COMMENT '数据来源',
  `status` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '渠道状态:有效1/无效0/已删除2/待审批3',
  `is_confirmed` bit(1) DEFAULT NULL COMMENT '是否已确认 1、已确认 0、未确认',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='网点基础信息临时表';

-- ----------------------------
-- Table structure for t_temp_website_selfhall_e
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_website_selfhall_e`;
CREATE TABLE `t_temp_website_selfhall_e` (
  `website_code` varchar(50) DEFAULT NULL COMMENT '渠道编码',
  `website_name` varchar(200) DEFAULT NULL COMMENT '营业厅名称',
  `city` varchar(50) DEFAULT NULL COMMENT '地市',
  `business_type` varchar(50) DEFAULT NULL COMMENT '经营类型',
  `regional_type` varchar(50) DEFAULT NULL COMMENT '区域类型',
  `office_hours` varchar(200) DEFAULT NULL COMMENT '营业时间',
  `address` varchar(500) DEFAULT NULL COMMENT '地址',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `status` varchar(50) DEFAULT NULL COMMENT '状态',
  `is_queue_machine` bit(1) DEFAULT NULL COMMENT '是否有排队叫号机',
  `vip_seats_number` int(11) DEFAULT NULL COMMENT 'VIP设置-VIP专席数',
  `vip_room_number` varchar(50) DEFAULT NULL COMMENT 'VIP设置-VIP室数',
  `is_self_service` bit(1) DEFAULT NULL COMMENT '是否有24小时自助终端区',
  `seats_number` int(11) DEFAULT NULL COMMENT '坐席数量',
  `self_service_number` int(11) DEFAULT NULL COMMENT '自助终端台数',
  `is_smart_home` bit(1) DEFAULT NULL COMMENT '是否有智慧家庭专区',
  `is_covered_100bw` bit(1) DEFAULT NULL COMMENT '是否已覆盖百兆宽带',
  `is_download_app` bit(1) DEFAULT NULL COMMENT '是否具备应用下载能力',
  `download_app_type` varchar(50) DEFAULT NULL COMMENT '应用下载平台类型',
  `vi_version` varchar(50) DEFAULT NULL COMMENT 'VI-VI版本',
  `signboard_height` decimal(10,2) DEFAULT NULL COMMENT '外观-店招高度（m）',
  `store_width` decimal(10,2) DEFAULT NULL COMMENT '外观-店招宽度（m）',
  `latest_renovation_time` date DEFAULT NULL COMMENT '最近一次整厅装修-时间',
  `latest_renovation_amount` decimal(20,8) DEFAULT NULL COMMENT '最近一次整厅装修-金额',
  `latest_renovation_capitalsource` varchar(50) DEFAULT NULL COMMENT '最近一次整厅装修-资金来源',
  `latest_renovation_projectno` varchar(50) DEFAULT NULL COMMENT '最近一次整厅装修-投资项目编号',
  `property_nature` varchar(50) DEFAULT NULL COMMENT '物业性质',
  `lease_begin_time` date DEFAULT NULL COMMENT '租赁起始时间',
  `lease_end_time` date DEFAULT NULL COMMENT '租赁到期时间',
  `avg_rent` decimal(10,2) DEFAULT NULL COMMENT '月均租金',
  `floor_area` decimal(10,2) DEFAULT NULL COMMENT '面积-建筑面积',
  `practical_area` decimal(10,2) DEFAULT NULL COMMENT '面积-实用面积',
  `office_area` decimal(10,2) DEFAULT NULL COMMENT '面积-营业面积',
  `back_actual_area` decimal(10,2) DEFAULT NULL COMMENT '面积-后台实用面积',
  `leadinto_cooper` varchar(50) DEFAULT NULL COMMENT '引入的合作商公司',
  `leadinto_website_code` varchar(50) DEFAULT NULL COMMENT '引入合作商的渠道编码',
  `cooper_business_type` varchar(50) DEFAULT NULL COMMENT '合作商经营类型',
  `cooper_counter_number` int(11) DEFAULT NULL COMMENT '合作商柜台数',
  `cooper_person_number` int(11) DEFAULT NULL COMMENT '合作商进驻人员数量',
  `promise_business` varchar(50) DEFAULT NULL COMMENT '承诺业务',
  `promise_business_number` varchar(50) DEFAULT NULL COMMENT '承诺业务量',
  `arrival_time` date DEFAULT NULL COMMENT '进驻时间',
  KEY `index_temp_website_selfhall_website_code` (`website_code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='网点自营厅/加盟厅临时表';

-- ----------------------------
-- Table structure for t_temp_website_society_e
-- ----------------------------
DROP TABLE IF EXISTS `t_temp_website_society_e`;
CREATE TABLE `t_temp_website_society_e` (
  `website_code` varchar(50) DEFAULT NULL COMMENT '渠道编码',
  `website_name` varchar(200) DEFAULT NULL COMMENT '渠道名称',
  `owned_company` varchar(200) DEFAULT NULL COMMENT '归属地市公司',
  `grid_name` varchar(200) DEFAULT NULL COMMENT '微区域/网格名称',
  `channel_username` varchar(50) DEFAULT NULL COMMENT '渠道经理姓名',
  `channel_usertel` varchar(50) DEFAULT NULL COMMENT '渠道经理手机号码',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `address` varchar(200) DEFAULT NULL COMMENT '详细地址',
  `cooper_start_time` date DEFAULT NULL COMMENT '合作开始时间',
  `star_level` int(11) DEFAULT NULL COMMENT '渠道星级',
  `status` varchar(50) DEFAULT NULL COMMENT '状态',
  `chain_nature` varchar(50) DEFAULT NULL COMMENT '连锁性质',
  `chain_name` varchar(200) DEFAULT NULL COMMENT '连锁名称',
  `exclusiveness` varchar(50) DEFAULT NULL COMMENT '排他性',
  KEY `index_temp_website_society_website_code` (`website_code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='网点社会渠道临时表';

-- ----------------------------
-- Table structure for t_test_abc
-- ----------------------------
DROP TABLE IF EXISTS `t_test_abc`;
CREATE TABLE `t_test_abc` (
  `id` int(10) DEFAULT NULL COMMENT '编号',
  `age` int(10) DEFAULT NULL COMMENT '年龄'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='测试扩展';

-- ----------------------------
-- Table structure for t_test_name
-- ----------------------------
DROP TABLE IF EXISTS `t_test_name`;
CREATE TABLE `t_test_name` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段列',
  `create_user` varchar(50) DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  `name` varchar(50) DEFAULT NULL COMMENT '名称',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='测试名称';

-- ----------------------------
-- Table structure for t_third_address_m
-- ----------------------------
DROP TABLE IF EXISTS `t_third_address_m`;
CREATE TABLE `t_third_address_m` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `address_id` varchar(50) DEFAULT NULL COMMENT '三级地址ID',
  `address_name` varchar(200) DEFAULT NULL COMMENT '三级地址名称',
  `all_address_id` varchar(500) DEFAULT NULL COMMENT '三级地址id全路径',
  `all_address_name` varchar(3000) DEFAULT NULL COMMENT '三级地址名称全路径',
  `secondary_address_id` varchar(50) DEFAULT NULL COMMENT '二级地址ID',
  `create_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  `extend_column` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='三级地址(CRM)';

-- ----------------------------
-- Table structure for t_uptown_address_m
-- ----------------------------
DROP TABLE IF EXISTS `t_uptown_address_m`;
CREATE TABLE `t_uptown_address_m` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `uptown_code` varchar(50) DEFAULT NULL COMMENT '小区id/五级地址id',
  `uptown_name` varchar(500) DEFAULT NULL COMMENT '小区名称',
  `all_address_id` varchar(500) DEFAULT NULL COMMENT '五级地址id全路径',
  `all_address_name` varchar(3000) DEFAULT NULL COMMENT '小区地址/五级地址名称全路径',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '归属区域编码',
  `channel_code` varchar(50) DEFAULT NULL COMMENT '归属渠道编码',
  `create_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  `fourthly_address_id` varchar(50) DEFAULT NULL COMMENT '四级地址ID',
  PRIMARY KEY (`id`),
  KEY `uptown_code_index` (`uptown_code`) USING BTREE,
  KEY `all_address_id_index` (`all_address_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='家客小区(CRM)';

-- ----------------------------
-- Table structure for t_uptown_blind_weakness_m
-- ----------------------------
DROP TABLE IF EXISTS `t_uptown_blind_weakness_m`;
CREATE TABLE `t_uptown_blind_weakness_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `grid_code` varchar(200) DEFAULT NULL COMMENT '区域编码',
  `code` varchar(50) NOT NULL COMMENT '小区编码',
  `name` varchar(200) DEFAULT NULL COMMENT '小区名称',
  `type` varchar(50) DEFAULT NULL COMMENT '类型: 0  盲区，1 弱区，2 正常',
  `bundary_coordinates` geometry NOT NULL,
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_uptown_blind_weakness_unique_key_code` (`code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='小区盲弱点总表';

-- ----------------------------
-- Table structure for t_uptown_buildings_index_m
-- ----------------------------
DROP TABLE IF EXISTS `t_uptown_buildings_index_m`;
CREATE TABLE `t_uptown_buildings_index_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `uptown_code` varchar(50) NOT NULL COMMENT '小区编码',
  `uptown_buildings_code` varchar(50) NOT NULL COMMENT '楼栋编码',
  `building_prot_rate` decimal(10,4) DEFAULT NULL COMMENT '楼栋端口占有率',
  `building_diffnet_rate` decimal(10,4) DEFAULT NULL COMMENT '楼栋异网占比',
  `statistics_time` date DEFAULT NULL COMMENT '统计时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_uptown_buildings_index_m_unique_key_uptown_buildings_stat` (`uptown_code`,`uptown_buildings_code`,`statistics_time`) USING BTREE,
  KEY `index_uptown_buildings_index_m_uptown_code` (`uptown_code`) USING BTREE,
  KEY `index_uptown_buildings_index_m_uptown_buildings_code` (`uptown_buildings_code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=77365 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='小区楼栋指标表';

-- ----------------------------
-- Table structure for t_uptown_buildings_m
-- ----------------------------
DROP TABLE IF EXISTS `t_uptown_buildings_m`;
CREATE TABLE `t_uptown_buildings_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `uptown_code` varchar(50) NOT NULL COMMENT '小区编码',
  `code` varchar(50) NOT NULL COMMENT '楼栋编码',
  `address` varchar(300) DEFAULT NULL COMMENT '楼栋地址',
  `name` varchar(200) DEFAULT NULL COMMENT '楼栋名称',
  `floor_num` int(10) DEFAULT NULL COMMENT '楼层数',
  `unit_num` int(10) DEFAULT NULL COMMENT '单元数',
  `floor_household_num` int(10) DEFAULT NULL COMMENT '每层户数',
  `house_num` int(10) DEFAULT NULL COMMENT '楼栋总户数',
  `sourcetype` int(10) DEFAULT NULL COMMENT '数据来源: 2亚信,1 FBB',
  `status` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '状态:有效1/无效0/已删除2/待审批3',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_uptown_buildings_unique_key_uptown_code_code` (`uptown_code`,`code`) USING BTREE,
  KEY `index_uptown_buildings_uptown_code` (`uptown_code`) USING BTREE,
  KEY `index_uptown_buildings_code` (`code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=154699 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Table structure for t_uptown_buildings_unit_index_m
-- ----------------------------
DROP TABLE IF EXISTS `t_uptown_buildings_unit_index_m`;
CREATE TABLE `t_uptown_buildings_unit_index_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `uptown_code` varchar(50) NOT NULL COMMENT '小区编码',
  `uptown_buildings_code` varchar(50) NOT NULL COMMENT '楼栋编号',
  `uptown_buildings_unit_code` varchar(50) NOT NULL COMMENT '单元编号',
  `unit_diffnet_rate` decimal(10,4) DEFAULT NULL COMMENT '单元的异网占比',
  `unit_port_rate` decimal(10,4) DEFAULT NULL COMMENT '单元的端口占有率',
  `statistics_time` date DEFAULT NULL COMMENT '统计时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_uptown_buildings_unit_index_m_unique_key_uptown_code_stat` (`uptown_code`,`uptown_buildings_code`,`uptown_buildings_unit_code`,`statistics_time`) USING BTREE,
  KEY `index_uptown_buildings_unit_index_m_uptown_code` (`uptown_code`) USING BTREE,
  KEY `index_uptown_buildings_unit_index_m_uptown_buildings_code` (`uptown_buildings_code`) USING BTREE,
  KEY `index_uptown_buildings_unit_index_m_uptown_buildings_unit_code` (`uptown_buildings_unit_code`) USING BTREE,
  KEY `index_uptown_buildings_unit_index_m_statistics_time` (`statistics_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=154511 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='小区楼栋单元指标表';

-- ----------------------------
-- Table structure for t_uptown_buildings_unit_m
-- ----------------------------
DROP TABLE IF EXISTS `t_uptown_buildings_unit_m`;
CREATE TABLE `t_uptown_buildings_unit_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `uptown_code` varchar(50) NOT NULL COMMENT '小区编码',
  `uptown_buildings_code` varchar(50) NOT NULL COMMENT '楼栋编号',
  `code` varchar(50) NOT NULL COMMENT '单元编号',
  `name` varchar(200) DEFAULT NULL COMMENT '单元名称',
  `address` varchar(300) DEFAULT NULL COMMENT '单元地址',
  `floor_num` int(10) DEFAULT NULL COMMENT '楼层数',
  `status` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '状态:有效1/无效0/已删除2/待审批3',
  `sourcetype` int(10) DEFAULT NULL COMMENT '数据来源',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_unit_unique_key_buildings_code_uptown_code_code` (`uptown_code`,`uptown_buildings_code`,`code`) USING BTREE,
  KEY `index_uptown_unit_uptown_code` (`uptown_code`) USING BTREE,
  KEY `index_uptown_unit_uptown_buildings_code` (`uptown_buildings_code`) USING BTREE,
  KEY `index_uptown_unit_code` (`code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2436004 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='小区楼栋单元表';

-- ----------------------------
-- Table structure for t_uptown_household_business_style
-- ----------------------------
DROP TABLE IF EXISTS `t_uptown_household_business_style`;
CREATE TABLE `t_uptown_household_business_style` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `parent_type` varchar(200) NOT NULL COMMENT '业务大类:1本网/异网  2办理业务  3投诉  4未知',
  `parent_name` varchar(200) NOT NULL COMMENT '业务大类:1本网/异网  2办理业务  3投诉  4未知',
  `business_type` varchar(50) NOT NULL COMMENT '子类业务类型',
  `business_name` varchar(50) NOT NULL COMMENT '子类业务名称',
  `colour_code` varchar(50) NOT NULL COMMENT '展示颜色编码',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `status` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '状态:有效1/无效0/已删除2/待审批3',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COMMENT='小区房号业务图标展示样式表';

-- ----------------------------
-- Table structure for t_uptown_household_chargesinfo_e
-- ----------------------------
DROP TABLE IF EXISTS `t_uptown_household_chargesinfo_e`;
CREATE TABLE `t_uptown_household_chargesinfo_e` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `uptown_code` varchar(50) NOT NULL COMMENT '小区编码',
  `uptown_buildings_code` varchar(50) NOT NULL COMMENT '楼栋编号',
  `uptown_buildings_unit_code` varchar(50) NOT NULL COMMENT '单元名称',
  `uptown_household_code` varchar(50) NOT NULL COMMENT '房间号',
  `business_type` varchar(200) NOT NULL COMMENT '业务类型:1 宽带/2 固网IMS/3 个人套餐/4 魔百和/5 和目',
  `source` varchar(200) NOT NULL COMMENT '业务来源 1系统  2自登记',
  `operator` varchar(50) NOT NULL COMMENT '运营商:1 联通/2 电信/3 移动/4 广电/5 长城',
  `expenses_fee` varchar(100) NOT NULL DEFAULT '0' COMMENT '资费',
  `expire_time` date DEFAULT NULL COMMENT '到期时间',
  `tel_number` varchar(50) DEFAULT NULL COMMENT '联系号码',
  `city_name` varchar(200) DEFAULT NULL COMMENT '归属地市',
  `is_local` bit(1) DEFAULT NULL COMMENT '是否本地市 1是 0否',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  `delete_user` varchar(50) DEFAULT NULL COMMENT '删除人',
  `delete_date` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `index_uptown_hoursehold_chargesinfo_uptown_code` (`uptown_code`,`uptown_buildings_code`,`uptown_buildings_unit_code`,`uptown_household_code`) USING BTREE,
  KEY `index_uptown_hoursehold_chargesinfo_expire_time` (`expire_time`)
) ENGINE=InnoDB AUTO_INCREMENT=369217 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='小区房号资费表';

-- ----------------------------
-- Table structure for t_uptown_household_complain
-- ----------------------------
DROP TABLE IF EXISTS `t_uptown_household_complain`;
CREATE TABLE `t_uptown_household_complain` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `uptown_code` varchar(50) NOT NULL COMMENT '小区编码',
  `uptown_buildings_code` varchar(50) NOT NULL COMMENT '楼栋编号',
  `uptown_buildings_unit_code` varchar(50) NOT NULL COMMENT '单元名称',
  `uptown_household_code` varchar(50) NOT NULL COMMENT '房间号',
  `complain_time` date DEFAULT NULL COMMENT '投诉时间',
  `complain_content` varchar(500) DEFAULT NULL COMMENT '投诉内容',
  `tel_number` varchar(50) DEFAULT NULL COMMENT '联系号码',
  `status` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '状态:已处理1/未处理0',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='小区房号投诉表';

-- ----------------------------
-- Table structure for t_uptown_household_m
-- ----------------------------
DROP TABLE IF EXISTS `t_uptown_household_m`;
CREATE TABLE `t_uptown_household_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `uptown_code` varchar(50) NOT NULL COMMENT '小区编码',
  `uptown_buildings_code` varchar(50) NOT NULL COMMENT '楼栋编号',
  `uptown_buildings_unit_code` varchar(50) NOT NULL COMMENT '单元编号',
  `in_floor_num` varchar(50) DEFAULT NULL COMMENT '所在楼层',
  `code` varchar(50) NOT NULL COMMENT '房号编码',
  `name` varchar(200) DEFAULT NULL COMMENT '房号名称',
  `address` varchar(300) DEFAULT NULL COMMENT '房号地址',
  `family_num` int(10) DEFAULT NULL COMMENT '家庭成员数',
  `tel_number` varchar(50) DEFAULT NULL COMMENT '联系号码',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `status` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '状态:有效1/无效0/已删除2/待审批3',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_hoursehold_unique_key_uptown_buildings_unit_code` (`uptown_code`,`uptown_buildings_code`,`uptown_buildings_unit_code`,`code`) USING BTREE,
  KEY `index_uptown_hoursehold_uptown_buildings_unit_code` (`uptown_code`,`uptown_buildings_code`,`uptown_buildings_unit_code`) USING BTREE,
  KEY `index_uptown_hoursehold_code` (`code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7154540 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='小区房号表';

-- ----------------------------
-- Table structure for t_uptown_m
-- ----------------------------
DROP TABLE IF EXISTS `t_uptown_m`;
CREATE TABLE `t_uptown_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `code` varchar(50) NOT NULL COMMENT '小区编码',
  `name` varchar(200) DEFAULT NULL COMMENT '小区名称',
  `type` varchar(50) DEFAULT NULL COMMENT '小区类型: 1 高价值低占小区 ',
  `grid_code` varchar(200) DEFAULT NULL COMMENT '区域编码',
  `business_department` varchar(200) DEFAULT NULL COMMENT '归属营业厅',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `is_gps_modify` bit(1) DEFAULT NULL COMMENT '经纬度是否已修改 1是 0否',
  `city_code` varchar(50) DEFAULT NULL COMMENT '城市编码',
  `city_name` varchar(200) DEFAULT NULL COMMENT '城市名称',
  `district_code` varchar(50) DEFAULT NULL COMMENT '区县编码',
  `district_name` varchar(200) DEFAULT NULL COMMENT '区县名称',
  `houseprice` decimal(10,2) DEFAULT NULL COMMENT '房价',
  `actual_householdcount` int(11) DEFAULT NULL COMMENT '小区入住总户数',
  `address` varchar(500) DEFAULT NULL COMMENT '地址',
  `building_date` date DEFAULT NULL COMMENT '建成时间',
  `flatlevel_buildingcount` int(11) DEFAULT NULL COMMENT '平层楼栋数',
  `manylevel_buildingcount` int(11) DEFAULT NULL COMMENT '多层楼栋数',
  `hightlevel_buildingcount` int(11) DEFAULT NULL COMMENT '高层楼栋数',
  `building_householdcount` int(11) DEFAULT NULL COMMENT '小区建筑总户数',
  `total_buildingcount` int(11) DEFAULT NULL COMMENT '小区总栋数',
  `property_name` varchar(200) DEFAULT NULL COMMENT '物业名称',
  `property_tel` varchar(50) DEFAULT NULL COMMENT '物业公司电话',
  `fullresources_id` varchar(50) DEFAULT NULL COMMENT '综合资源id',
  `fullresources_name` varchar(200) DEFAULT NULL COMMENT '综合资源名称',
  `total_port_count` int(11) DEFAULT NULL COMMENT '总端口数',
  `free_port_count` int(11) DEFAULT NULL COMMENT '空余端口数',
  `user_count` int(11) DEFAULT NULL COMMENT '用户数',
  `marketing_center` varchar(200) DEFAULT NULL COMMENT '营销中心',
  `one_level_address` varchar(500) DEFAULT NULL COMMENT '一级地址',
  `two_level_address` varchar(500) DEFAULT NULL COMMENT '二级地址',
  `three_level_address` varchar(500) DEFAULT NULL COMMENT '三级地址',
  `four_level_address` varchar(500) DEFAULT NULL COMMENT '四级地址',
  `five_level_address` varchar(500) DEFAULT NULL COMMENT '五级地址',
  `cover_type` varchar(50) DEFAULT NULL COMMENT '覆盖类型',
  `region_atr` varchar(50) DEFAULT NULL COMMENT '地域属性',
  `address_source` varchar(50) DEFAULT NULL COMMENT '地址来源',
  `net_source` varchar(50) DEFAULT NULL COMMENT '网络来源',
  `is_homecustomer` bit(1) DEFAULT NULL COMMENT '是否家客小区',
  `relation_cmtyname` varchar(200) DEFAULT NULL COMMENT '关联社区名称',
  `building_number` int(10) DEFAULT NULL COMMENT '楼宇数',
  `floor_num` int(10) DEFAULT NULL COMMENT '楼层数',
  `covered_building_num` int(10) DEFAULT NULL COMMENT '已覆盖移动宽带楼宇数',
  `uncovered_building_num` int(10) DEFAULT NULL COMMENT '未覆盖楼宇数',
  `lt_num` int(10) DEFAULT NULL COMMENT '联通宽带数',
  `telecommunication_num` int(10) DEFAULT NULL COMMENT '电信宽带数',
  `broadband_share` decimal(10,4) DEFAULT NULL COMMENT '宽带份额',
  `manager` varchar(50) DEFAULT NULL,
  `manager_phone` varchar(50) DEFAULT NULL COMMENT '网格经理电话',
  `is_cover` bit(1) DEFAULT NULL COMMENT '是否覆盖',
  `unit_num` int(10) DEFAULT NULL COMMENT '单元数',
  `property_linkman` varchar(50) DEFAULT NULL COMMENT '物业联系人',
  `sourcetype` int(10) DEFAULT NULL COMMENT '数据来源',
  `is_cmty_store` bit(1) DEFAULT NULL COMMENT '是否有社区店',
  `cmty_store_name` varchar(200) DEFAULT NULL COMMENT '社区店名称',
  `cmty_store_type` varchar(50) DEFAULT NULL COMMENT '社区店类型',
  `cmty_store_position` varchar(200) DEFAULT NULL COMMENT '社区店位置',
  `status` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '状态:有效1/无效0/已删除2/待审批3',
  `is_confirmed` bit(1) DEFAULT NULL COMMENT '是否已确认 1、已确认 0、未确认',
  `level` varchar(50) DEFAULT NULL COMMENT '小区等级类型:高价值小区、低占小区、空白小区',
  `is_demolition` bit(1) DEFAULT NULL COMMENT '是否拆迁小区',
  `is_verify` bit(1) DEFAULT NULL COMMENT '是否核实 1是 0否',
  `outer_grid_code` varchar(200) DEFAULT NULL COMMENT '网络区域编码',
  `outer_bundary_coordinates` geometry DEFAULT NULL COMMENT '网络边界坐标',
  `compete_cover` varchar(50) DEFAULT NULL COMMENT '竞争对手覆盖情况',
  `property_partnership` varchar(50) DEFAULT NULL COMMENT '物业关系',
  `property_partnership_remark` varchar(200) DEFAULT NULL COMMENT '物业关系备注',
  `extend_type` varchar(50) DEFAULT NULL COMMENT '扩展小区类型:0  盲区，1 弱区，2 正常',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  `bundary_coordinates` geometry NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_uptown_unique_key_uptown_code` (`code`) USING BTREE,
  KEY `index_uptown_code` (`code`) USING BTREE,
  KEY `grid_code` (`grid_code`) USING BTREE,
  KEY `index_uptown_city_code` (`city_code`) USING BTREE,
  KEY `index_uptown_cnty_code` (`district_code`) USING BTREE,
  SPATIAL KEY `spatIdx` (`bundary_coordinates`),
  FULLTEXT KEY `ftindex_uptown_name` (`name`) /*!50100 WITH PARSER `ngram` */ 
) ENGINE=InnoDB AUTO_INCREMENT=730195 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='小区表';

-- ----------------------------
-- Table structure for t_uptown_m_vt
-- ----------------------------
DROP TABLE IF EXISTS `t_uptown_m_vt`;
CREATE TABLE `t_uptown_m_vt` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `code` varchar(50) NOT NULL COMMENT '小区编码',
  `name` varchar(200) DEFAULT NULL COMMENT '小区名称',
  `type` varchar(50) DEFAULT NULL COMMENT '小区类型: 1 高价值低占小区 ',
  `grid_code` varchar(200) DEFAULT NULL COMMENT '区域编码',
  `business_department` varchar(200) DEFAULT NULL COMMENT '归属营业厅',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `bundary_coordinates` geometry NOT NULL COMMENT '边界坐标',
  `is_gps_modify` bit(1) DEFAULT NULL COMMENT '经纬度是否已修改 1是 0否',
  `city_code` varchar(50) DEFAULT NULL COMMENT '城市编码',
  `city_name` varchar(200) DEFAULT NULL COMMENT '城市名称',
  `district_code` varchar(50) DEFAULT NULL COMMENT '区县编码',
  `district_name` varchar(200) DEFAULT NULL COMMENT '区县名称',
  `houseprice` decimal(10,2) DEFAULT NULL COMMENT '房价',
  `actual_householdcount` int(11) DEFAULT NULL COMMENT '小区入住总户数',
  `address` varchar(500) DEFAULT NULL COMMENT '地址',
  `building_date` date DEFAULT NULL COMMENT '建成时间',
  `flatlevel_buildingcount` int(11) DEFAULT NULL COMMENT '平层楼栋数',
  `manylevel_buildingcount` int(11) DEFAULT NULL COMMENT '多层楼栋数',
  `hightlevel_buildingcount` int(11) DEFAULT NULL COMMENT '高层楼栋数',
  `building_householdcount` int(11) DEFAULT NULL COMMENT '小区建筑总户数',
  `total_buildingcount` int(11) DEFAULT NULL COMMENT '小区总栋数',
  `property_name` varchar(200) DEFAULT NULL COMMENT '物业名称',
  `property_tel` varchar(50) DEFAULT NULL COMMENT '物业公司电话',
  `fullresources_id` varchar(50) DEFAULT NULL COMMENT '综合资源id',
  `fullresources_name` varchar(200) DEFAULT NULL COMMENT '综合资源名称',
  `total_port_count` int(11) DEFAULT NULL COMMENT '总端口数',
  `free_port_count` int(11) DEFAULT NULL COMMENT '空余端口数',
  `user_count` int(11) DEFAULT NULL COMMENT '用户数',
  `marketing_center` varchar(200) DEFAULT NULL COMMENT '营销中心',
  `one_level_address` varchar(500) DEFAULT NULL COMMENT '一级地址',
  `two_level_address` varchar(500) DEFAULT NULL COMMENT '二级地址',
  `three_level_address` varchar(500) DEFAULT NULL COMMENT '三级地址',
  `four_level_address` varchar(500) DEFAULT NULL COMMENT '四级地址',
  `five_level_address` varchar(500) DEFAULT NULL COMMENT '五级地址',
  `cover_type` varchar(50) DEFAULT NULL COMMENT '覆盖类型',
  `region_atr` varchar(50) DEFAULT NULL COMMENT '地域属性',
  `address_source` varchar(50) DEFAULT NULL COMMENT '地址来源',
  `net_source` varchar(50) DEFAULT NULL COMMENT '网络来源',
  `is_homecustomer` bit(1) DEFAULT NULL COMMENT '是否家客小区',
  `relation_cmtyname` varchar(200) DEFAULT NULL COMMENT '关联社区名称',
  `building_number` int(10) DEFAULT NULL COMMENT '楼宇数',
  `floor_num` int(10) DEFAULT NULL COMMENT '楼层数',
  `covered_building_num` int(10) DEFAULT NULL COMMENT '已覆盖移动宽带楼宇数',
  `uncovered_building_num` int(10) DEFAULT NULL COMMENT '未覆盖楼宇数',
  `broadband_share` decimal(10,4) DEFAULT NULL COMMENT '宽带份额',
  `manager` varchar(50) DEFAULT NULL,
  `manager_phone` varchar(50) DEFAULT NULL COMMENT '网格经理电话',
  `is_cover` bit(1) DEFAULT NULL COMMENT '是否覆盖',
  `unit_num` int(10) DEFAULT NULL COMMENT '单元数',
  `property_linkman` varchar(50) DEFAULT NULL COMMENT '物业联系人',
  `sourcetype` int(10) DEFAULT NULL COMMENT '数据来源',
  `is_cmty_store` bit(1) DEFAULT NULL COMMENT '是否有社区店',
  `cmty_store_name` varchar(200) DEFAULT NULL COMMENT '社区店名称',
  `cmty_store_type` varchar(50) DEFAULT NULL COMMENT '社区店类型',
  `cmty_store_position` varchar(200) DEFAULT NULL COMMENT '社区店位置',
  `status` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '状态:有效1/无效0/已删除2/待审批3',
  `is_confirmed` bit(1) DEFAULT NULL COMMENT '是否已确认 1、已确认 0、未确认',
  `level` varchar(50) DEFAULT NULL COMMENT '小区等级类型:高价值小区、低占小区、空白小区',
  `is_demolition` bit(1) DEFAULT NULL COMMENT '是否拆迁小区',
  `is_verify` bit(1) DEFAULT NULL COMMENT '是否核实 1是 0否',
  `outer_grid_code` varchar(200) DEFAULT NULL COMMENT '网络区域编码',
  `outer_bundary_coordinates` geometry DEFAULT NULL COMMENT '网络边界坐标',
  `compete_cover` varchar(50) DEFAULT NULL COMMENT '竞争对手覆盖情况',
  `extend_type` varchar(50) DEFAULT NULL COMMENT '扩展小区类型:0  盲区，1 弱区，2 正常',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_uptown_unique_key_uptown_code` (`code`) USING BTREE,
  SPATIAL KEY `spatIdx` (`bundary_coordinates`),
  KEY `grid_code` (`grid_code`) USING BTREE,
  KEY `index_uptown_city_code` (`city_code`) USING BTREE,
  KEY `index_uptown_cnty_code` (`district_code`) USING BTREE,
  KEY `index_uptown_is_verfity` (`is_verify`),
  KEY `index_uptown_code` (`code`,`is_verify`,`cover_type`) USING BTREE,
  FULLTEXT KEY `ftindex_uptown_uptown_name` (`name`) /*!50100 WITH PARSER `ngram` */ 
) ENGINE=InnoDB AUTO_INCREMENT=10000008 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='小区表';

-- ----------------------------
-- Table structure for t_uptown_operational_m
-- ----------------------------
DROP TABLE IF EXISTS `t_uptown_operational_m`;
CREATE TABLE `t_uptown_operational_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `uptown_code` varchar(50) NOT NULL COMMENT '小区编码',
  `uptown_name` varchar(255) DEFAULT NULL COMMENT '小区名称',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '关联网格',
  `business_hall` varchar(200) DEFAULT NULL COMMENT '归属营业厅',
  `maintainer_name` varchar(50) DEFAULT NULL COMMENT '小区装维人名称',
  `maintainer_tel` varchar(50) DEFAULT NULL COMMENT '小区装维人手机号',
  `manager_name` varchar(50) DEFAULT NULL COMMENT '小区经理名称',
  `manager_tel` varchar(50) DEFAULT NULL COMMENT '小区经理手机号',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_uptown_oprational_unique_key_uptown_code` (`uptown_code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='住宅小区运维信息';

-- ----------------------------
-- Table structure for t_uptown_operator_m
-- ----------------------------
DROP TABLE IF EXISTS `t_uptown_operator_m`;
CREATE TABLE `t_uptown_operator_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `uptown_code` varchar(50) DEFAULT NULL COMMENT '小区编码',
  `uptown_name` varchar(255) DEFAULT NULL COMMENT '小区名称',
  `operator` varchar(50) DEFAULT NULL COMMENT '运营商',
  `propaganda_mode` varchar(50) DEFAULT NULL COMMENT '宣传方式',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uptown_operator_unique_key_uptown_code_operator` (`uptown_code`,`operator`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='住宅小区运营商信息';

-- ----------------------------
-- Table structure for t_uptown_resource_index_m
-- ----------------------------
DROP TABLE IF EXISTS `t_uptown_resource_index_m`;
CREATE TABLE `t_uptown_resource_index_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `uptown_code` varchar(50) NOT NULL COMMENT '小区编码',
  `port_avail_rate` decimal(10,4) DEFAULT NULL COMMENT '端口利用率 ',
  `dw_permeability` decimal(10,4) DEFAULT NULL COMMENT '宽带渗透率',
  `month_avg_arpu` decimal(10,4) DEFAULT NULL COMMENT '月均ARPU值',
  `month_avg_dou` decimal(10,4) DEFAULT NULL COMMENT '月均DOU值',
  `marketing_business` int(10) DEFAULT NULL COMMENT '营销商机',
  `mobile_bwuser_arrival` int(10) DEFAULT NULL COMMENT '移动宽带用户到达',
  `magicbai_user_arrival` int(10) DEFAULT NULL COMMENT '魔百和用户到达',
  `magicbai_permeability` decimal(10,4) DEFAULT NULL COMMENT '魔百和渗透率',
  `mobile_user_rate` decimal(10,4) DEFAULT NULL COMMENT '移动用户占比',
  `mobile_bwnum` int(10) DEFAULT NULL COMMENT '移动宽带数',
  `unicom_bwnum` int(10) DEFAULT NULL COMMENT '联通宽带数',
  `telecom_bwnum` int(10) DEFAULT NULL COMMENT '电信宽带数',
  `month_dw_add` int(10) DEFAULT NULL COMMENT '宽带月新增',
  `month_netadd` int(10) DEFAULT NULL COMMENT '宽带月净增',
  `magicbai_add` int(10) DEFAULT NULL COMMENT '魔百和月新增',
  `magicbai_netadd` int(10) DEFAULT NULL COMMENT '魔百和月净增',
  `mobile_top1_name` varchar(200) DEFAULT NULL COMMENT '移网TOP1资费名称',
  `mobile_top1_rate` decimal(10,4) DEFAULT NULL COMMENT '移网TOP1资费占比',
  `inmonth_due_usernum` int(10) DEFAULT NULL COMMENT '我网一个月内到期宽带用户数',
  `bw_self_usernum` int(10) DEFAULT NULL COMMENT '我网宽带用户数',
  `potential_bw_usernum` int(10) DEFAULT NULL COMMENT '潜在宽带用户数',
  `diffnet_bw_usernum` int(10) DEFAULT NULL COMMENT '异网宽带用户数',
  `ecology_busi_permeability` decimal(10,4) DEFAULT NULL COMMENT '生态业务渗透率',
  `customer_realinstall_rate` decimal(10,4) DEFAULT NULL COMMENT '客户实装率',
  `day_dw_add` int(10) DEFAULT NULL COMMENT '宽带日新增',
  `day_netadd` int(10) DEFAULT NULL COMMENT '宽带日净增',
  `month_dw_offnet` int(10) DEFAULT NULL COMMENT '宽带月离网',
  `year_dw_add` int(10) DEFAULT NULL COMMENT '宽带年新增',
  `year_netadd` int(10) DEFAULT NULL COMMENT '宽带年净增',
  `customer_keeprate` decimal(10,4) DEFAULT NULL COMMENT '客户保有率',
  `htv_user_nums` int(10) DEFAULT NULL COMMENT '和TV用户数',
  `htv_permeability` decimal(10,4) DEFAULT NULL COMMENT '和TV渗透率',
  `rc_user_nums` int(10) DEFAULT NULL COMMENT '遥控器用户数',
  `ims_user_nums` int(10) DEFAULT NULL COMMENT 'IMS用户数',
  `hemu_user_nums` int(10) DEFAULT NULL COMMENT '和目用户数',
  `intellectnet_user_nums` int(10) DEFAULT NULL COMMENT '智能组网用户数',
  `total_port_count` int(10) DEFAULT NULL COMMENT '总端口数',
  `use_port_count` int(10) DEFAULT NULL,
  `stock_maintenance` int(10) DEFAULT NULL COMMENT '存量维系',
  `ecology_recommend` int(10) DEFAULT NULL COMMENT '生态推荐',
  `all_business_num` int(10) DEFAULT NULL COMMENT '总商机数',
  `touch_business_num` int(10) DEFAULT NULL COMMENT '商机接触数',
  `reach_business_num` int(10) DEFAULT NULL COMMENT '商机达成数',
  `ecology_arrival` int(10) DEFAULT NULL COMMENT '生态到达',
  `month_ecology_add` int(10) DEFAULT NULL COMMENT '生态月净增',
  `statistics_time` date DEFAULT NULL COMMENT '统计时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_uptown_unique_key_uptown_code` (`uptown_code`,`statistics_time`) USING BTREE,
  KEY `index_uptown_uptown_code` (`uptown_code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=111111114 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='小区资源点指标表';

-- ----------------------------
-- Table structure for t_uptown_resource_m
-- ----------------------------
DROP TABLE IF EXISTS `t_uptown_resource_m`;
CREATE TABLE `t_uptown_resource_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '区域编码',
  `uptown_code` varchar(50) DEFAULT NULL COMMENT '小区编码',
  `uptown_name` varchar(255) DEFAULT NULL COMMENT '小区名称',
  `opticalsplitter_portcount` int(11) DEFAULT NULL COMMENT '分光器总端口数',
  `used_opticalsplitter_portcount` int(11) DEFAULT NULL COMMENT '分光器已占用端口数',
  `sign_count` int(11) DEFAULT NULL COMMENT '已签约数',
  `leave_count` int(11) DEFAULT NULL COMMENT '离网数',
  `statistics_date` date DEFAULT NULL COMMENT '统计日期',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_uptown_resource_unique_key_uptown_code` (`uptown_code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='小区资源表';

-- ----------------------------
-- Table structure for t_uptown_sector_m
-- ----------------------------
DROP TABLE IF EXISTS `t_uptown_sector_m`;
CREATE TABLE `t_uptown_sector_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `grid_code` varchar(50) NOT NULL COMMENT '区域编码',
  `uptown_code` varchar(50) NOT NULL COMMENT '小区编码',
  `uptown_name` varchar(200) DEFAULT NULL COMMENT '小区名称',
  `cgi` varchar(50) NOT NULL COMMENT 'cgi',
  `station_code` varchar(50) DEFAULT NULL COMMENT '基站编码',
  `station_name` varchar(200) DEFAULT NULL COMMENT '基站名称',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_uptown_sector_unique_key_uptown_code_cgi` (`uptown_code`,`cgi`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='小区基站表';

-- ----------------------------
-- Table structure for t_uptown_touch_e
-- ----------------------------
DROP TABLE IF EXISTS `t_uptown_touch_e`;
CREATE TABLE `t_uptown_touch_e` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `grid_code` varchar(200) DEFAULT NULL COMMENT '区域编码',
  `uptown_code` varchar(50) NOT NULL COMMENT '小区编码',
  `outer_building_num` int(10) DEFAULT NULL COMMENT '网络侧楼宇数',
  `outer_unit_num` int(10) DEFAULT NULL COMMENT '网络侧单元数',
  `outer_family_num` int(10) DEFAULT NULL COMMENT '网络侧家庭户数',
  `outer_total_port_count` int(10) DEFAULT NULL COMMENT '网络侧总端口数',
  `outer_free_port_count` int(10) DEFAULT NULL COMMENT '网络侧剩余端口数',
  `touch_building_num` int(10) DEFAULT NULL COMMENT '摸排楼宇数',
  `touch_unit_num` int(10) DEFAULT NULL COMMENT '摸排单元数',
  `touch_family_num` int(10) DEFAULT NULL COMMENT '摸排家庭户数',
  `touch_port_count` int(10) DEFAULT NULL COMMENT '摸排端口数',
  `odb_type` varchar(50) DEFAULT NULL COMMENT '分纤箱类型',
  `odb_num` int(10) DEFAULT NULL COMMENT '分纤箱数量',
  `problem` varchar(50) DEFAULT NULL COMMENT '小区存在问题A/B/C/D/E/F',
  `is_verify` bit(1) DEFAULT NULL COMMENT '是否核实 1是 0否',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_uptown_unique_key_uptown_code` (`uptown_code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COMMENT='小区摸排扩展表';

-- ----------------------------
-- Table structure for t_uptown_user_portrait_m
-- ----------------------------
DROP TABLE IF EXISTS `t_uptown_user_portrait_m`;
CREATE TABLE `t_uptown_user_portrait_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `uptown_code` varchar(50) NOT NULL COMMENT '小区编码',
  `uptown_buildings_code` varchar(50) DEFAULT NULL COMMENT '楼栋编号',
  `uptown_buildings_unit_code` varchar(50) DEFAULT NULL COMMENT '单元编号',
  `uptown_household_code` varchar(50) DEFAULT NULL COMMENT '房间号',
  `main_phone` varchar(50) DEFAULT NULL COMMENT '主手机号',
  `vice_phone` varchar(50) NOT NULL COMMENT '副手机号',
  `city_name` varchar(200) DEFAULT NULL COMMENT '归属地市',
  `is_local` bit(1) DEFAULT NULL COMMENT '是否本地市 1是 0否',
  `family_num` int(10) DEFAULT NULL COMMENT '大家庭人数',
  `cy_num` int(10) DEFAULT NULL COMMENT '大家庭成员数',
  `ww_num` int(10) DEFAULT NULL COMMENT '大家庭我网用户数',
  `yw_num` int(10) DEFAULT NULL COMMENT '大家庭异网用户数',
  `is_yye` bit(1) DEFAULT NULL COMMENT '大家庭中是否有婴幼儿',
  `is_xx` bit(1) DEFAULT NULL COMMENT '大家庭中是否有小学儿童',
  `is_zx` bit(1) DEFAULT NULL COMMENT '大家庭中是否有中学生',
  `is_old` bit(1) DEFAULT NULL COMMENT '大家庭中是否有老人',
  `is_car` bit(1) DEFAULT NULL COMMENT '大家庭是否有车',
  `class_small` varchar(50) DEFAULT NULL COMMENT '小家庭编号',
  `wifi_type` int(10) DEFAULT NULL COMMENT '小家庭宽带类型;1--开通宽带的人2--被覆盖的人3--使用异网宽带的人6--没有宽带的用户',
  `yudaoqi` int(10) DEFAULT NULL COMMENT '是否宽带预到期用户;4--异网宽带预到期用户5--我网宽带预到期用户',
  `wifi_end_date` date DEFAULT NULL COMMENT '我网宽带预到期时间',
  `full_address` varchar(300) DEFAULT NULL COMMENT '宽带安装地址',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `hs_htv` varchar(50) DEFAULT NULL COMMENT '魔百和业务标签;1-已开通2-未开通，请推荐（推荐理由）3-未开通，不推荐',
  `mbh_reason` varchar(200) DEFAULT NULL COMMENT '魔百和推荐理由',
  `hs_ykq` varchar(50) DEFAULT NULL COMMENT '语音遥控器业务标签;1-已开通2-未开通，请推荐（推荐理由）3-未开通，不推荐',
  `ykq_reason` varchar(50) DEFAULT NULL COMMENT '语音遥控器推荐理由',
  `hs_guhua` varchar(50) DEFAULT NULL COMMENT '家庭固话业务标签;1-已开通2-未开通，请推荐（推荐理由）3-未开通，不推荐',
  `guhua_reason` varchar(200) DEFAULT NULL COMMENT '家庭固话推荐理由',
  `hs_hemu` varchar(50) DEFAULT NULL COMMENT '和目业务标签;1-已开通2-未开通，请推荐（推荐理由）3-未开通，不推荐',
  `hemu_reason` varchar(200) DEFAULT NULL COMMENT '和目推荐理由',
  `hs_duanhao` varchar(50) DEFAULT NULL COMMENT '家庭短号业务标签;1-已开通2-未开通，请推荐（推荐理由）3-未开通，不推荐',
  `duanhao_reason` varchar(200) DEFAULT NULL COMMENT '家庭短号推荐理由',
  `hs_liuliang` varchar(50) DEFAULT NULL COMMENT '共享流量业务标签;1-已开通2-未开通，请推荐（推荐理由）3-未开通，不推荐;目前提供的编码并未找到对应的用户群，以及共享流量推荐业务的口径待确认、',
  `fuka_reason` varchar(200) DEFAULT NULL COMMENT '副卡推荐理由;副卡由家庭来呈现效果并不好，副卡业务的限制略大',
  `call_all_num` int(10) DEFAULT NULL COMMENT '小家庭成员月通话次数汇总',
  `call_class_num` int(10) DEFAULT NULL COMMENT '小家庭成员与大家庭成员月通话次数汇总',
  `call_enterprise_num` int(10) DEFAULT NULL COMMENT '小家庭成员与工作圈成员月通话次数汇总',
  `arpu` decimal(40,4) DEFAULT NULL COMMENT '小家庭成员近三月平均arpu汇总',
  `mou` decimal(40,4) DEFAULT NULL COMMENT '小家庭成员近三月平均通话分钟数汇总',
  `zhu_mou` decimal(40,4) DEFAULT NULL COMMENT '小家庭成员近三个平均主叫通话分钟数汇总',
  `dou` decimal(40,4) DEFAULT NULL COMMENT '小家庭成员近三个月平均使用流量汇总;单位：M',
  `tytc_monthfee_ld` decimal(30,4) DEFAULT NULL COMMENT '小家庭成员上月套餐费汇总',
  `dou_zhu` decimal(40,4) DEFAULT NULL COMMENT '小家庭成员包月套餐总流量数汇总;单位：G',
  `mou_zhu` int(10) DEFAULT NULL COMMENT '小家庭成员包月套餐总通话分钟数汇总',
  `fee_wifi` decimal(40,4) DEFAULT NULL COMMENT '小家庭成员宽带费用汇总',
  `comm_price` decimal(10,4) DEFAULT NULL COMMENT '小家庭用户居住小区房价',
  `rel_price` decimal(20,4) DEFAULT NULL COMMENT '小家庭用户平均终端价格',
  `bhd_avg` decimal(20,4) DEFAULT NULL COMMENT '小家庭成员用户近三月流量平均饱和度',
  `mo_call_duration` int(10) DEFAULT NULL COMMENT '小家庭成员与大家庭成员的总主叫通话时长;所有小家庭用户的时长进行汇总',
  `video_visit_flow` decimal(40,4) DEFAULT NULL COMMENT '小家庭成员月视频流量汇总;单位：G',
  `statistics_time` date NOT NULL COMMENT '统计时间',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_uptown_user_portrait_unique_key_code_phone_stat` (`uptown_code`,`vice_phone`) USING BTREE,
  KEY `index_uptown_user_portrait_uptown_code` (`uptown_code`),
  KEY `index_uptown_user_portrait_vice_phone` (`vice_phone`),
  KEY `index_uptown_user_portrait_statistics_time` (`statistics_time`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='家客小区用户画像表';

-- ----------------------------
-- Table structure for t_user_info_m
-- ----------------------------
DROP TABLE IF EXISTS `t_user_info_m`;
CREATE TABLE `t_user_info_m` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段列',
  `create_user` varchar(50) DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  `age` int(10) DEFAULT NULL COMMENT '年龄',
  `name` varchar(50) DEFAULT NULL COMMENT '姓名',
  `address` varchar(50) DEFAULT NULL COMMENT '地址',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='用户测试表';

-- ----------------------------
-- Table structure for t_user_portrait_m
-- ----------------------------
DROP TABLE IF EXISTS `t_user_portrait_m`;
CREATE TABLE `t_user_portrait_m` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_id` varchar(50) DEFAULT NULL COMMENT '用户ID',
  `user_name` varchar(500) DEFAULT NULL COMMENT '姓名',
  `phone` varchar(500) DEFAULT NULL COMMENT '手机号-宽带号',
  `broadband_type` varchar(50) DEFAULT NULL COMMENT '宽带类型',
  `sex` varchar(50) DEFAULT NULL COMMENT '性别',
  `star` varchar(50) DEFAULT NULL COMMENT '星级',
  `arpu` varchar(50) DEFAULT NULL COMMENT 'ARPU',
  `mou` varchar(50) DEFAULT NULL COMMENT 'MOU',
  `dou` varchar(50) DEFAULT NULL COMMENT 'DOU',
  `short_type` varchar(50) DEFAULT NULL COMMENT '短号类型',
  `broadband_expire_date` varchar(50) DEFAULT NULL COMMENT '宽带到期时间',
  `broadband_rate` varchar(50) DEFAULT NULL COMMENT '宽带速率',
  `user_brand` varchar(50) DEFAULT NULL COMMENT '用户品牌',
  `vip_type` varchar(50) DEFAULT NULL COMMENT 'vip type',
  `and_credit` varchar(50) DEFAULT NULL COMMENT '和信用',
  `family_short_number_num` varchar(50) DEFAULT NULL COMMENT '家庭短号成员数',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '网格ID',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `user_id_index` (`user_id`) USING BTREE,
  KEY `phone_index` (`phone`) USING BTREE,
  KEY `grid_code_index` (`grid_code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户画像(大数据)';

-- ----------------------------
-- Table structure for t_user_role
-- ----------------------------
DROP TABLE IF EXISTS `t_user_role`;
CREATE TABLE `t_user_role` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段列',
  `create_user` varchar(50) DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='用户角色表';

-- ----------------------------
-- Table structure for t_website_competition_m
-- ----------------------------
DROP TABLE IF EXISTS `t_website_competition_m`;
CREATE TABLE `t_website_competition_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `website_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '渠道编码',
  `website_name` varchar(200) DEFAULT NULL COMMENT '渠道名称',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '区域编码',
  `city` varchar(50) DEFAULT NULL COMMENT '地市',
  `district` varchar(50) DEFAULT NULL COMMENT '区县',
  `operator_type` varchar(50) DEFAULT NULL COMMENT '运营商类型',
  `operator` varchar(200) DEFAULT NULL COMMENT '所属运营商',
  `address` varchar(200) DEFAULT NULL COMMENT '详细地址',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  `channel_status` varchar(10) DEFAULT NULL COMMENT '渠道状态',
  `channel_status_time` datetime DEFAULT NULL COMMENT '渠道状态时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_website_competition_unique_key_website_code` (`website_code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='网点竞争渠道';

-- ----------------------------
-- Table structure for t_website_m
-- ----------------------------
DROP TABLE IF EXISTS `t_website_m`;
CREATE TABLE `t_website_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '区域编码',
  `code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '渠道编码',
  `unify_code` varchar(50) DEFAULT NULL COMMENT '渠道全国统一编码',
  `name` varchar(200) DEFAULT NULL COMMENT '渠道名称',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `is_gps_modify` bit(1) DEFAULT NULL COMMENT '经纬度是否已修改 1是 0否',
  `coordinates` geometry NOT NULL COMMENT '边界坐标',
  `type` varchar(50) DEFAULT NULL COMMENT '渠道类型:字典website_property1-自营厅,2-加盟厅,3-社会渠道,5-竞争渠道',
  `sub_type` varchar(50) DEFAULT NULL COMMENT '渠道子类型 字典website_type',
  `three_sub_type` varchar(50) DEFAULT NULL COMMENT '渠道三级类型 字典three_sub_type',
  `address` varchar(200) DEFAULT NULL COMMENT '渠道地址',
  `city_code` varchar(50) DEFAULT NULL COMMENT '城市编码',
  `city_name` varchar(200) DEFAULT NULL COMMENT '城市名称',
  `district_code` varchar(50) DEFAULT NULL COMMENT '区县编码',
  `district_name` varchar(200) DEFAULT NULL COMMENT '区县名称',
  `scale` varchar(50) DEFAULT NULL COMMENT '网点规模',
  `headperson` varchar(50) DEFAULT NULL COMMENT '网点负责人1',
  `headperson_tel` varchar(50) DEFAULT NULL COMMENT '网点负责人1电话',
  `headperson2` varchar(50) DEFAULT NULL COMMENT '网点负责人2',
  `headperson2_tel` varchar(50) DEFAULT NULL COMMENT '网点负责人2',
  `channel_useraccount` varchar(50) DEFAULT NULL COMMENT '渠道经理账号',
  `channel_username` varchar(50) DEFAULT NULL COMMENT '渠道经理姓名',
  `channel_usertel` varchar(50) DEFAULT NULL COMMENT '渠道经理电话',
  `channel_status_time` datetime DEFAULT NULL COMMENT '渠道状态更改时间',
  `gent_code` varchar(50) DEFAULT NULL COMMENT '代理商编码',
  `operator` varchar(50) DEFAULT NULL COMMENT '运营商',
  `office_hours` varchar(200) DEFAULT NULL COMMENT '营业时间',
  `agent_time` datetime DEFAULT NULL COMMENT '渠道建立时间',
  `creator_name` varchar(50) DEFAULT NULL COMMENT '渠道记录创建人',
  `picture_url` varchar(2000) DEFAULT NULL COMMENT '图片URL',
  `sourcetype` int(10) DEFAULT NULL COMMENT '数据来源',
  `status` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '渠道状态:有效1/无效0/已删除2/待审批3',
  `is_confirmed` bit(1) DEFAULT NULL COMMENT '是否已确认 1、已确认 0、未确认',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_website_m_unique_key_code` (`code`) USING BTREE,
  KEY `index_website_m_grid_code` (`grid_code`) USING BTREE,
  KEY `index_website_m_area_code` (`city_code`) USING BTREE,
  KEY `index_website_m_cnty_code` (`district_code`) USING BTREE,
  SPATIAL KEY `spatIdx` (`coordinates`),
  FULLTEXT KEY `ftindex_website_m_name` (`name`) /*!50100 WITH PARSER `ngram` */ 
) ENGINE=InnoDB AUTO_INCREMENT=2641396 DEFAULT CHARSET=utf8mb4 COMMENT='网点基础信息表';

-- ----------------------------
-- Table structure for t_website_m_vt
-- ----------------------------
DROP TABLE IF EXISTS `t_website_m_vt`;
CREATE TABLE `t_website_m_vt` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '区域编码',
  `code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '渠道编码',
  `unify_code` varchar(50) DEFAULT NULL COMMENT '渠道全国统一编码',
  `name` varchar(200) DEFAULT NULL COMMENT '渠道名称',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `coordinates` geometry NOT NULL COMMENT '边界坐标',
  `type` varchar(50) DEFAULT NULL COMMENT '渠道类型:字典website_property1-自营厅,2-加盟厅,3-社会渠道,5-竞争渠道',
  `sub_type` varchar(50) DEFAULT NULL COMMENT '渠道子类型 字典website_type',
  `three_sub_type` varchar(50) DEFAULT NULL COMMENT '渠道三级类型 字典three_sub_type',
  `address` varchar(200) DEFAULT NULL COMMENT '渠道地址',
  `city_code` varchar(50) DEFAULT NULL COMMENT '城市编码',
  `city_name` varchar(200) DEFAULT NULL COMMENT '城市名称',
  `district_code` varchar(50) DEFAULT NULL COMMENT '区县编码',
  `district_name` varchar(200) DEFAULT NULL COMMENT '区县名称',
  `scale` varchar(50) DEFAULT NULL COMMENT '网点规模',
  `headperson` varchar(50) DEFAULT NULL COMMENT '网点负责人1',
  `headperson_tel` varchar(50) DEFAULT NULL COMMENT '网点负责人1电话',
  `headperson2` varchar(50) DEFAULT NULL COMMENT '网点负责人2',
  `headperson2_tel` varchar(50) DEFAULT NULL COMMENT '网点负责人2',
  `channel_useraccount` varchar(50) DEFAULT NULL COMMENT '渠道经理账号',
  `channel_username` varchar(50) DEFAULT NULL COMMENT '渠道经理姓名',
  `channel_usertel` varchar(50) DEFAULT NULL COMMENT '渠道经理电话',
  `channel_status_time` datetime DEFAULT NULL COMMENT '渠道状态更改时间',
  `gent_code` varchar(50) DEFAULT NULL COMMENT '代理商编码',
  `operator` varchar(50) DEFAULT NULL COMMENT '运营商',
  `office_hours` varchar(200) DEFAULT NULL COMMENT '营业时间',
  `agent_time` datetime DEFAULT NULL COMMENT '渠道建立时间',
  `creator_name` varchar(50) DEFAULT NULL COMMENT '渠道记录创建人',
  `picture_url` varchar(2000) DEFAULT NULL COMMENT '图片URL',
  `sourcetype` int(10) DEFAULT NULL COMMENT '数据来源',
  `status` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '渠道状态:有效1/无效0/已删除2/待审批3',
  `is_confirmed` bit(1) DEFAULT NULL COMMENT '是否已确认 1、已确认 0、未确认',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_website_m_unique_key_code` (`code`) USING BTREE,
  KEY `index_website_m_grid_code` (`grid_code`) USING BTREE,
  SPATIAL KEY `spatIdx` (`coordinates`),
  KEY `index_website_m_area_code` (`city_code`) USING BTREE,
  KEY `index_website_m_cnty_code` (`district_code`) USING BTREE,
  FULLTEXT KEY `ftindex_website_m_name` (`name`) /*!50100 WITH PARSER `ngram` */ 
) ENGINE=InnoDB AUTO_INCREMENT=496045 DEFAULT CHARSET=utf8mb4 COMMENT='网点基础信息表';

-- ----------------------------
-- Table structure for t_website_right_m
-- ----------------------------
DROP TABLE IF EXISTS `t_website_right_m`;
CREATE TABLE `t_website_right_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `code` varchar(50) DEFAULT NULL COMMENT '渠道编码',
  `marketing_type` varchar(50) DEFAULT NULL COMMENT 'intelligence：智能营销，moment：关键时刻，family：家庭商机，uptown：小区商机.0/未赋权，1/已赋权        数据存储示例intelligence-0,moment-1,family-0,uptown-0',
  `remark` varchar(2000) DEFAULT NULL COMMENT '备注',
  `create_user` varchar(50) DEFAULT NULL COMMENT '授权人',
  `create_date` datetime DEFAULT NULL COMMENT '授权时间',
  `modify_user` varchar(50) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=622 DEFAULT CHARSET=utf8mb4 COMMENT='渠道赋权表';

-- ----------------------------
-- Table structure for t_website_selfhall_e
-- ----------------------------
DROP TABLE IF EXISTS `t_website_selfhall_e`;
CREATE TABLE `t_website_selfhall_e` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `website_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '渠道编码',
  `website_name` varchar(200) DEFAULT NULL COMMENT '营业厅名称',
  `city` varchar(50) DEFAULT NULL COMMENT '地市',
  `business_type` varchar(50) DEFAULT NULL COMMENT '经营类型',
  `regional_type` varchar(50) DEFAULT NULL COMMENT '区域类型',
  `office_hours` varchar(200) DEFAULT NULL COMMENT '营业时间',
  `address` varchar(500) DEFAULT NULL COMMENT '地址',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `status` varchar(50) DEFAULT NULL COMMENT '状态',
  `is_queue_machine` bit(1) DEFAULT NULL COMMENT '是否有排队叫号机',
  `vip_seats_number` int(11) DEFAULT NULL COMMENT 'VIP设置-VIP专席数',
  `vip_room_number` varchar(50) DEFAULT NULL COMMENT 'VIP设置-VIP室数',
  `is_self_service` bit(1) DEFAULT NULL COMMENT '是否有24小时自助终端区',
  `seats_number` int(11) DEFAULT NULL COMMENT '坐席数量',
  `self_service_number` int(11) DEFAULT NULL COMMENT '自助终端台数',
  `is_smart_home` bit(1) DEFAULT NULL COMMENT '是否有智慧家庭专区',
  `is_covered_100bw` bit(1) DEFAULT NULL COMMENT '是否已覆盖百兆宽带',
  `is_download_app` bit(1) DEFAULT NULL COMMENT '是否具备应用下载能力',
  `download_app_type` varchar(50) DEFAULT NULL COMMENT '应用下载平台类型',
  `vi_version` varchar(50) DEFAULT NULL COMMENT 'VI-VI版本',
  `signboard_height` decimal(10,2) DEFAULT NULL COMMENT '外观-店招高度（m）',
  `store_width` decimal(10,2) DEFAULT NULL COMMENT '外观-店招宽度（m）',
  `latest_renovation_time` date DEFAULT NULL COMMENT '最近一次整厅装修-时间',
  `latest_renovation_amount` decimal(20,8) DEFAULT NULL COMMENT '最近一次整厅装修-金额',
  `latest_renovation_capitalsource` varchar(50) DEFAULT NULL COMMENT '最近一次整厅装修-资金来源',
  `latest_renovation_projectno` varchar(50) DEFAULT NULL COMMENT '最近一次整厅装修-投资项目编号',
  `property_nature` varchar(50) DEFAULT NULL COMMENT '物业性质',
  `lease_begin_time` date DEFAULT NULL COMMENT '租赁起始时间',
  `lease_end_time` date DEFAULT NULL COMMENT '租赁到期时间',
  `avg_rent` decimal(10,2) DEFAULT NULL COMMENT '月均租金',
  `floor_area` decimal(10,2) DEFAULT NULL COMMENT '面积-建筑面积',
  `practical_area` decimal(10,2) DEFAULT NULL COMMENT '面积-实用面积',
  `office_area` decimal(10,2) DEFAULT NULL COMMENT '面积-营业面积',
  `back_actual_area` decimal(10,2) DEFAULT NULL COMMENT '面积-后台实用面积',
  `leadinto_cooper` varchar(50) DEFAULT NULL COMMENT '引入的合作商公司',
  `leadinto_website_code` varchar(50) DEFAULT NULL COMMENT '引入合作商的渠道编码',
  `cooper_business_type` varchar(50) DEFAULT NULL COMMENT '合作商经营类型',
  `cooper_counter_number` int(11) DEFAULT NULL COMMENT '合作商柜台数',
  `cooper_person_number` int(11) DEFAULT NULL COMMENT '合作商进驻人员数量',
  `promise_business` varchar(50) DEFAULT NULL COMMENT '承诺业务',
  `promise_business_number` varchar(50) DEFAULT NULL COMMENT '承诺业务量',
  `arrival_time` date DEFAULT NULL COMMENT '进驻时间',
  `agent_attribute` varchar(50) DEFAULT NULL COMMENT '渠道属性（实体渠道、直销渠道）',
  `super_unit` varchar(200) DEFAULT NULL COMMENT '上级单位',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  `channel_status_time` datetime DEFAULT NULL COMMENT '渠道状态时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_website_selfhall_e_unique_key_website_code` (`website_code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='网点自营厅/加盟厅';

-- ----------------------------
-- Table structure for t_website_society_e
-- ----------------------------
DROP TABLE IF EXISTS `t_website_society_e`;
CREATE TABLE `t_website_society_e` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `website_code` varchar(50) NOT NULL COMMENT '渠道编码',
  `website_name` varchar(200) DEFAULT NULL COMMENT '渠道名称',
  `owned_company` varchar(200) DEFAULT NULL COMMENT '归属地市公司',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '区域编码',
  `grid_name` varchar(200) DEFAULT NULL COMMENT '微区域/网格名称',
  `channel_username` varchar(50) DEFAULT NULL COMMENT '渠道经理姓名',
  `channel_usertel` varchar(50) DEFAULT NULL COMMENT '渠道经理手机号码',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `address` varchar(200) DEFAULT NULL COMMENT '详细地址',
  `cooper_start_time` date DEFAULT NULL COMMENT '合作开始时间',
  `star_level` int(11) DEFAULT NULL COMMENT '渠道星级',
  `status` varchar(50) DEFAULT NULL COMMENT '状态',
  `chain_nature` varchar(50) DEFAULT NULL COMMENT '连锁性质',
  `chain_name` varchar(200) DEFAULT NULL COMMENT '连锁名称',
  `exclusiveness` varchar(50) DEFAULT NULL COMMENT '排他性',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_website_society_unique_key_website_code` (`website_code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='网点社会渠道';

-- ----------------------------
-- Table structure for tb_biz_address_std_m
-- ----------------------------
DROP TABLE IF EXISTS `tb_biz_address_std_m`;
CREATE TABLE `tb_biz_address_std_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键自增ID',
  `addr_id` bigint(20) NOT NULL COMMENT '地址ID',
  `name` varchar(300) DEFAULT NULL COMMENT '本级地址名称',
  `grade` int(10) DEFAULT NULL COMMENT '地址级别',
  `jp` varchar(300) DEFAULT NULL COMMENT 'jp',
  `wb` varchar(300) DEFAULT NULL COMMENT 'wb',
  `parent_addr_id` bigint(20) DEFAULT NULL COMMENT '父级地址ID',
  `alias_addr` varchar(500) DEFAULT NULL COMMENT '地址别别名',
  `old_addr` int(10) DEFAULT NULL COMMENT '旧地址',
  `confirm` int(10) DEFAULT NULL COMMENT 'confirm',
  `addr` varchar(300) DEFAULT NULL COMMENT '地址全称',
  `addr_py` varchar(300) DEFAULT NULL COMMENT 'addr_py',
  `alias_addr_py` varchar(300) DEFAULT NULL COMMENT 'alias_addr_py',
  `confirmdate` varchar(50) DEFAULT NULL COMMENT 'confirmdate',
  `confirmdate2` varchar(50) DEFAULT NULL COMMENT 'confirmdate2',
  `amend` int(10) DEFAULT NULL COMMENT '整理状态',
  `recdate` varchar(50) DEFAULT NULL COMMENT 'recdate',
  `subdepname` varchar(50) DEFAULT NULL COMMENT 'subdepname',
  `sysflag` int(10) DEFAULT NULL COMMENT '地址级别',
  `postnumber` varchar(50) DEFAULT NULL COMMENT 'postnumber',
  `stype` varchar(10) DEFAULT NULL COMMENT 'stype',
  `num` varchar(300) DEFAULT NULL COMMENT 'num',
  `tag` bigint(20) DEFAULT NULL COMMENT 'tag',
  `ibssaddrid` bigint(20) DEFAULT NULL COMMENT 'ibssaddrid',
  `ibsend` int(10) DEFAULT NULL COMMENT 'ibsend',
  `old_parentid` bigint(20) DEFAULT NULL COMMENT 'old_parentid',
  `split_flagc` bigint(20) DEFAULT NULL COMMENT 'split_flagc',
  `split_flag` bigint(20) DEFAULT NULL COMMENT 'split_flag',
  `addrtype` int(10) DEFAULT NULL COMMENT 'addrtype',
  `regionid` varchar(100) DEFAULT NULL COMMENT '地市编码',
  `importflag` varchar(50) DEFAULT NULL COMMENT '导入批次',
  `name1` varchar(100) DEFAULT NULL COMMENT '第一级',
  `name2` varchar(100) DEFAULT NULL COMMENT '第二级',
  `name3` varchar(100) DEFAULT NULL COMMENT '第三级',
  `name4` varchar(100) DEFAULT NULL COMMENT '第四级',
  `name5` varchar(100) DEFAULT NULL COMMENT '第五级',
  `name6` varchar(100) DEFAULT NULL COMMENT '第六级',
  `name7` varchar(100) DEFAULT NULL COMMENT '第七级',
  `addrtypeex` int(10) DEFAULT NULL COMMENT 'addrtypeex',
  `addrtypeex_2` int(10) DEFAULT NULL COMMENT 'addrtypeex_2',
  `green_label` int(10) DEFAULT NULL COMMENT 'green_label',
  `grade3id` bigint(20) DEFAULT NULL COMMENT 'grade3id',
  `dotx` varchar(100) DEFAULT NULL COMMENT '经度',
  `doty` varchar(100) DEFAULT NULL COMMENT '纬度',
  `neighborhood` varchar(300) DEFAULT NULL COMMENT '所属小区',
  `resource_type` int(10) DEFAULT NULL COMMENT '资源类型',
  `bstype` int(3) DEFAULT NULL COMMENT '楼宇类型',
  `third_party_name` varchar(100) DEFAULT NULL COMMENT '第三方名称',
  `third_party_contact` varchar(100) DEFAULT NULL COMMENT '第三方联系方式',
  `picturelink` varchar(800) DEFAULT NULL COMMENT 'picturelink',
  `addrsource` int(10) DEFAULT NULL COMMENT '地址来源',
  `status` int(10) DEFAULT NULL COMMENT '状态',
  `hcovermode` int(10) DEFAULT NULL COMMENT '覆盖场景',
  `remarks` varchar(300) DEFAULT NULL COMMENT '备注',
  `shield_open_service` varchar(10) DEFAULT NULL COMMENT '屏蔽开通业务',
  `cn_way` varchar(10) DEFAULT NULL COMMENT '接入方式',
  `region_attri` int(10) DEFAULT NULL COMMENT '地域属性',
  `create_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_biz_address_std_unique_key_addr_id` (`addr_id`) USING BTREE,
  KEY `tb_biz_address_std_m_index` (`addr_id`,`grade`,`parent_addr_id`) USING BTREE,
  KEY `addr_id_index` (`addr_id`) USING BTREE,
  KEY `grade_index` (`grade`) USING BTREE,
  KEY `parent_addr_id_index` (`parent_addr_id`) USING BTREE,
  KEY `name_index` (`name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='标准地址表';

-- ----------------------------
-- Table structure for tb_biz_downtown_m
-- ----------------------------
DROP TABLE IF EXISTS `tb_biz_downtown_m`;
CREATE TABLE `tb_biz_downtown_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `code` varchar(50) NOT NULL COMMENT '楼宇编码',
  `type` varchar(50) DEFAULT NULL COMMENT '业务大类:2=集客',
  `state` varchar(50) DEFAULT NULL COMMENT '状态类型:0=未认领,1=已认领,2=新增',
  `grid_code` varchar(200) DEFAULT NULL COMMENT '归属责任田',
  `name` varchar(200) NOT NULL COMMENT '楼宇名称',
  `building_type` varchar(200) DEFAULT NULL COMMENT '楼宇类型',
  `one_level_address` varchar(500) DEFAULT NULL COMMENT '一级地址',
  `two_level_address` varchar(500) DEFAULT NULL COMMENT '二级地址',
  `three_level_address` varchar(500) DEFAULT NULL COMMENT '三级地址',
  `four_level_address` varchar(500) DEFAULT NULL COMMENT '四级地址',
  `five_level_address` varchar(500) DEFAULT NULL COMMENT '五级地址',
  `six_level_address` varchar(500) DEFAULT NULL COMMENT '六级地址',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `cover_type` varchar(50) DEFAULT NULL COMMENT '覆盖类型',
  `region_atr` varchar(50) DEFAULT NULL COMMENT '地域属性',
  `cover_res_cnt` int(11) DEFAULT NULL COMMENT '覆盖户数',
  `occupancy_rate` varchar(50) DEFAULT NULL COMMENT '入住率',
  `permeability_rate` varchar(50) DEFAULT NULL COMMENT '预计宽带渗透率',
  `difficult_type` varchar(50) DEFAULT NULL COMMENT '困难类型',
  `business_prio` varchar(50) DEFAULT NULL COMMENT '业务优先级',
  `collect_date` datetime DEFAULT NULL COMMENT '采集时间',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  `collect_account` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '采集人ID',
  `collect_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '采集人姓名',
  `charge_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '拓展协调负责人',
  `charge_tel` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '拓展协调负责人联系电话',
  `pic1` varchar(200) CHARACTER SET utf8 DEFAULT NULL COMMENT '图片1',
  `pic2` varchar(200) CHARACTER SET utf8 DEFAULT NULL COMMENT '图片2',
  `pic3` varchar(200) CHARACTER SET utf8 DEFAULT NULL COMMENT '图片3',
  `pic4` varchar(200) CHARACTER SET utf8 DEFAULT NULL COMMENT '图片4',
  `pic5` varchar(200) CHARACTER SET utf8 DEFAULT NULL COMMENT '图片5',
  `remarks` varchar(500) CHARACTER SET utf8 DEFAULT NULL COMMENT '备注',
  `shop_type` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '临街商铺类型',
  `shop_cnt` int(11) DEFAULT NULL COMMENT '临街商铺数量',
  `cover_status` varchar(50) DEFAULT NULL COMMENT '是否已覆盖:1已覆盖，2建设中，3未覆盖',
  `gx_address_id` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '管线系统地址ID',
  `user_scale` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '临用户规模',
  `coverd_shop_cnt` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '已覆盖临街商铺数量',
  `customer_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '集团客户编码',
  `claimant` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '楼宇认领人',
  `suffocate_reason` varchar(500) CHARACTER SET utf8 DEFAULT NULL COMMENT '受阻原因',
  `company_cnt` int(11) DEFAULT NULL COMMENT '楼宇企业数',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_downtown_unique_key_downtown_code` (`code`) USING BTREE,
  KEY `index_downtown_downtown_name` (`name`) USING BTREE,
  KEY `index_grid_code` (`grid_code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='商业楼宇表/中小企/集客';

-- ----------------------------
-- Table structure for tb_biz_sector_phones_stat
-- ----------------------------
DROP TABLE IF EXISTS `tb_biz_sector_phones_stat`;
CREATE TABLE `tb_biz_sector_phones_stat` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `cgi` varchar(200) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT 'CGI',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `worktime_cnt` int(11) DEFAULT NULL COMMENT '工作时间人数',
  `resttime_cnt` int(11) DEFAULT NULL COMMENT '休息时间人数',
  `worktime_hightarpu_cnt` int(11) DEFAULT NULL COMMENT '工作时间高ARPU人数',
  `worktime_lowarpu_cnt` int(11) DEFAULT NULL COMMENT '工作时间低ARPU人数',
  `resttime_hightarpu_cnt` int(11) DEFAULT NULL COMMENT '休息时间高ARPU人数',
  `resttime_lowarpu_cnt` int(11) DEFAULT NULL COMMENT '休息时间低ARPU人数',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  `longitude_t` decimal(18,8) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='扇区手机数统计';

-- ----------------------------
-- Table structure for tb_biz_uptown_building
-- ----------------------------
DROP TABLE IF EXISTS `tb_biz_uptown_building`;
CREATE TABLE `tb_biz_uptown_building` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `uptown_code` varchar(50) NOT NULL COMMENT '小区编码',
  `project_name` varchar(200) DEFAULT NULL COMMENT '工程名称',
  `design_res_cnt` int(11) DEFAULT NULL COMMENT '设计户数',
  `cnstr_unit` varchar(20) DEFAULT NULL COMMENT '施工单位',
  `design_port_cunt` int(11) DEFAULT NULL COMMENT '设计端口数',
  `estimate_mnt_time` datetime DEFAULT NULL COMMENT '预计交维时间',
  `location_unit` varchar(200) DEFAULT NULL COMMENT '选址单位',
  `mkt_manager` varchar(50) DEFAULT NULL COMMENT '营销经理',
  `project_progress` varchar(200) DEFAULT NULL,
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='家客小区建设中信息';

-- ----------------------------
-- Table structure for tb_biz_uptown_covered
-- ----------------------------
DROP TABLE IF EXISTS `tb_biz_uptown_covered`;
CREATE TABLE `tb_biz_uptown_covered` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `uptown_code` varchar(50) NOT NULL COMMENT '小区编码',
  `project_name` varchar(200) DEFAULT NULL COMMENT '工程名称',
  `mnt_res_cnt` int(11) DEFAULT NULL COMMENT '交维户数',
  `mnt_port_cnt` int(11) DEFAULT NULL COMMENT '交维端口数',
  `mnt_time` datetime DEFAULT NULL COMMENT '交维时间',
  `port_cnt` int(11) DEFAULT NULL COMMENT '端口总数',
  `already_port_cnt` int(11) DEFAULT NULL COMMENT '已使用端口数',
  `port_use_rate` decimal(10,4) DEFAULT NULL COMMENT '端口使用比率',
  `is_dilatation` bit(1) DEFAULT NULL COMMENT '是否有扩容需求',
  `location_unit` varchar(200) DEFAULT NULL COMMENT '选址单位',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='家客小区已覆盖信息';

-- ----------------------------
-- Table structure for tb_biz_uptown_dilatation_hist
-- ----------------------------
DROP TABLE IF EXISTS `tb_biz_uptown_dilatation_hist`;
CREATE TABLE `tb_biz_uptown_dilatation_hist` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `uptown_code` varchar(50) NOT NULL COMMENT '小区编码',
  `type` varchar(50) DEFAULT NULL COMMENT '扩容类型',
  `ascription` varchar(100) DEFAULT NULL COMMENT '扩容归属',
  `unit` varchar(200) DEFAULT NULL COMMENT '扩容单位',
  `progress` varchar(200) DEFAULT NULL COMMENT '扩容进度',
  `plan_complete` varchar(50) DEFAULT NULL COMMENT '扩容计划完成期',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='家客扩容历史';

-- ----------------------------
-- Table structure for tb_biz_uptown_dot
-- ----------------------------
DROP TABLE IF EXISTS `tb_biz_uptown_dot`;
CREATE TABLE `tb_biz_uptown_dot` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `uptown_code` varchar(50) NOT NULL COMMENT '小区编码',
  `picture_name` varchar(200) DEFAULT NULL COMMENT '图片名称',
  `picture_url` varchar(2000) DEFAULT NULL COMMENT '打点图片URL',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '打点图片的经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '打点图片的纬度',
  `azimuth` varchar(50) DEFAULT NULL COMMENT '打点图片的方位角',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='家客打点信息';

-- ----------------------------
-- Table structure for tb_biz_uptown_uncovered
-- ----------------------------
DROP TABLE IF EXISTS `tb_biz_uptown_uncovered`;
CREATE TABLE `tb_biz_uptown_uncovered` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `uptown_code` varchar(50) NOT NULL COMMENT '小区编码',
  `exist_dfclt` varchar(200) DEFAULT NULL COMMENT '存在困难',
  `res_cnt` int(11) DEFAULT NULL COMMENT '社区户数',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='家客小区未覆盖信息';

-- ----------------------------
-- Table structure for test_home_ext_hp
-- ----------------------------
DROP TABLE IF EXISTS `test_home_ext_hp`;
CREATE TABLE `test_home_ext_hp` (
  `id` int(10) DEFAULT NULL COMMENT '编号',
  `t_price_ext` bigint(19) DEFAULT NULL COMMENT '价格'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='用户住宅信息扩展表_hp';

-- ----------------------------
-- Table structure for test20200108
-- ----------------------------
DROP TABLE IF EXISTS `test20200108`;
CREATE TABLE `test20200108` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段列',
  `create_user` varchar(50) DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  `column1` varchar(255) DEFAULT NULL COMMENT '品牌',
  `column2` varchar(255) DEFAULT NULL COMMENT '产地',
  `column3` varchar(255) DEFAULT NULL COMMENT '销售量',
  `column4` varchar(255) DEFAULT NULL COMMENT '销售额',
  `column5` varchar(255) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='手机20200108';

-- ----------------------------
-- Table structure for testA_01
-- ----------------------------
DROP TABLE IF EXISTS `testA_01`;
CREATE TABLE `testA_01` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段列',
  `create_user` varchar(50) DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='测试表01';

-- ----------------------------
-- Table structure for to_minor_enterprise
-- ----------------------------
DROP TABLE IF EXISTS `to_minor_enterprise`;
CREATE TABLE `to_minor_enterprise` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `city_code` varchar(50) DEFAULT NULL COMMENT '城市编码',
  `city_name` varchar(200) DEFAULT NULL COMMENT '地市名称',
  `district_code` varchar(50) DEFAULT NULL COMMENT '区县编码',
  `district_name` varchar(200) DEFAULT NULL COMMENT '区县名称',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '区域编码',
  `grid_name` varchar(200) DEFAULT NULL COMMENT '区域名称',
  `minor_enterprise_code` varchar(50) NOT NULL COMMENT '中小企业编码',
  `minor_enterprise_name` varchar(200) NOT NULL COMMENT '中小企业名称',
  `minor_enterprise_address` varchar(500) DEFAULT NULL COMMENT '中小企业地址',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `bundary_coordinates` geometry NOT NULL COMMENT '空间坐标',
  `type` varchar(50) DEFAULT NULL COMMENT '分类:酒店宾馆1/沿街商铺2/中小学3/专业市场4/工业园区5/网吧6/医院7',
  `is_cover` bit(1) DEFAULT NULL COMMENT '是否覆盖',
  `building_type` varchar(50) DEFAULT NULL COMMENT '楼宇类型:uptown 家宽小区/building 楼宇',
  `building_code` varchar(50) DEFAULT NULL COMMENT '楼宇编码:对应楼宇类型的家宽小区或楼宇编码',
  `building_name` varchar(200) DEFAULT NULL COMMENT '楼宇名称:对应楼宇类型的家宽小区或楼宇名称',
  `gadmap_type` varchar(50) DEFAULT NULL COMMENT '高德分类',
  `employee_number` int(11) DEFAULT NULL COMMENT '人员数',
  `enterprise_info` varchar(500) DEFAULT NULL COMMENT '企业信息',
  `corporation_name` varchar(50) DEFAULT NULL COMMENT '法人姓名',
  `corporation_phone` varchar(50) DEFAULT NULL COMMENT '法人联系电话',
  `uptown_code` varchar(50) DEFAULT NULL COMMENT '家客小区编码',
  `uptown_name` varchar(200) DEFAULT NULL COMMENT '家客小区名称',
  `floor` varchar(1000) DEFAULT NULL COMMENT '楼层',
  `room_no` varchar(1000) DEFAULT NULL COMMENT '房号',
  `cluster_code` varchar(50) DEFAULT NULL COMMENT '聚类编码',
  `cluster_name` varchar(200) DEFAULT NULL COMMENT '聚类名称',
  `enterpris_scope` varchar(50) DEFAULT NULL COMMENT '企业经营范围',
  `enterpris_needs` varchar(500) DEFAULT NULL COMMENT '企业需求',
  `enterpris_needs_other` varchar(200) DEFAULT NULL COMMENT '企业需求其他说明',
  `statement_of_needs` varchar(500) DEFAULT NULL COMMENT '需求说明',
  `phone_num_total` varchar(50) DEFAULT NULL COMMENT '手机号码总计数量',
  `proportion` decimal(10,4) DEFAULT NULL COMMENT '在网手机数量占比',
  `is_reimbursed` bit(1) DEFAULT NULL COMMENT '话费是否统一报销',
  `network_signal` varchar(50) DEFAULT NULL COMMENT '该企业网络信号测试结果',
  `know_manager` varchar(50) DEFAULT NULL COMMENT '集团知晓客户经理',
  `is_other_office` bit(1) DEFAULT NULL COMMENT '是否有分公司或总公司',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `status` varchar(50) DEFAULT NULL COMMENT '状态:有效1/无效0/已删除2/待审批3',
  `is_confirmed` bit(1) DEFAULT NULL COMMENT '是否已确认 1、已确认 0、未确认',
  `sourcetype` int(10) DEFAULT NULL COMMENT '楼宇数据来源 1：网格系统录入，2：大数据，3：地市收集，4：省公司收集，5：CRM，6：互联网',
  `process_result` varchar(50) DEFAULT NULL COMMENT '处理结果:0疑似建档 1对手集团客户2我网集团3未建档集团4已关闭5无此企业',
  `enterprise_code` varchar(50) DEFAULT NULL COMMENT '集团编码',
  `enterprise_name` varchar(200) DEFAULT NULL COMMENT '集团名称',
  `extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_unique_to_minor_enterprise` (`minor_enterprise_code`) USING BTREE,
  SPATIAL KEY `spatIdx` (`bundary_coordinates`),
  KEY `index_minor_enterprise_grid_code` (`grid_code`) USING BTREE,
  KEY `index_minor_enterprise_minor_city_code` (`city_code`) USING BTREE,
  KEY `index_minor_enterprise_minor_cnty_code` (`district_code`) USING BTREE,
  FULLTEXT KEY `ftindex_to_minor_enterprise_name` (`minor_enterprise_name`) /*!50100 WITH PARSER `ngram` */ 
) ENGINE=InnoDB AUTO_INCREMENT=54333 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='中小企业表';

-- ----------------------------
-- Table structure for to_minor_enterprise_chargesinfo_e
-- ----------------------------
DROP TABLE IF EXISTS `to_minor_enterprise_chargesinfo_e`;
CREATE TABLE `to_minor_enterprise_chargesinfo_e` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `minor_enterprise_code` varchar(50) NOT NULL COMMENT '中小企业ID',
  `business_type` varchar(50) DEFAULT NULL COMMENT '业务类型',
  `operator` varchar(50) DEFAULT NULL COMMENT '运营商',
  `price` varchar(500) DEFAULT NULL COMMENT '资费价格',
  `quantity` int(10) DEFAULT NULL COMMENT '数量',
  `due_time` date DEFAULT NULL COMMENT '到期时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_chargesinfo_unique_enterprise_code__type_operator_price` (`minor_enterprise_code`,`business_type`,`operator`,`price`) USING BTREE COMMENT '企业编码，业务类型，运营商，资费价格',
  KEY `index_chargesinfo_unique_minor_enterprise_code` (`minor_enterprise_code`) USING BTREE COMMENT '企业编码，业务类型，运营商，资费价格'
) ENGINE=InnoDB AUTO_INCREMENT=185 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='中小企业资费信息表';

-- ----------------------------
-- Table structure for to_minor_enterprise_linkman_e
-- ----------------------------
DROP TABLE IF EXISTS `to_minor_enterprise_linkman_e`;
CREATE TABLE `to_minor_enterprise_linkman_e` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `minor_enterprise_code` varchar(50) NOT NULL COMMENT '中小企业编码',
  `linkman` varchar(50) DEFAULT NULL COMMENT '联系人',
  `position` varchar(50) DEFAULT NULL COMMENT '职位',
  `linkman_tel` varchar(100) DEFAULT NULL COMMENT '联系电话',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_linkman_unique_enterprise_code_linkman_position` (`minor_enterprise_code`,`linkman`,`position`) USING BTREE COMMENT '唯一索引中小企业编码_联系人_职位',
  KEY `index_linkman_minor_enterprise_code` (`minor_enterprise_code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=264 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='中小企业联系人信息表';

-- ----------------------------
-- Table structure for to_minor_enterprise_register_e
-- ----------------------------
DROP TABLE IF EXISTS `to_minor_enterprise_register_e`;
CREATE TABLE `to_minor_enterprise_register_e` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `province_code` varchar(50) DEFAULT NULL COMMENT '省份编码',
  `province_name` varchar(100) DEFAULT NULL COMMENT '省份名称',
  `city_code` varchar(50) DEFAULT NULL COMMENT '地市编码',
  `city_name` varchar(100) DEFAULT NULL COMMENT '地市名称',
  `district_code` varchar(50) DEFAULT NULL COMMENT '区县编码',
  `district_name` varchar(100) DEFAULT NULL COMMENT '企业名称',
  `minor_enterprise_code` varchar(50) DEFAULT NULL COMMENT '区县编码',
  `minor_enterprise_name` varchar(200) DEFAULT NULL COMMENT '企业名称',
  `minor_enterprise_name_once` varchar(200) DEFAULT NULL COMMENT '企业曾用名',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '注册地点经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '注册地点纬度',
  `uniform_social_creditcode` varchar(100) DEFAULT NULL COMMENT '统一社会信用代码',
  `registrationno` varchar(100) DEFAULT NULL COMMENT '注册号',
  `responname` varchar(100) DEFAULT NULL COMMENT '法定代表人',
  `establishment_date` date DEFAULT NULL COMMENT '成立日期',
  `management_status` varchar(50) DEFAULT NULL COMMENT '经营状态',
  `registered_amount` decimal(10,0) DEFAULT NULL COMMENT '注册资本(单位：万)',
  `registered_currency` varchar(50) DEFAULT NULL COMMENT '注册资本币种',
  `registered_address` varchar(500) DEFAULT NULL COMMENT '注册地址',
  `registered_type` varchar(200) DEFAULT NULL COMMENT '企业类型',
  `business_scope` varchar(2000) DEFAULT NULL COMMENT '经营业务范围',
  `registration_authority` varchar(50) DEFAULT NULL COMMENT '登记机关',
  `operating_date_begin` date DEFAULT NULL COMMENT '经营期限自',
  `operating_date_end` date DEFAULT NULL COMMENT '经营期限至',
  `approval_date` date DEFAULT NULL COMMENT '核准日期',
  `logout_date` date DEFAULT NULL COMMENT '注销日期',
  `revocation_date` date DEFAULT NULL COMMENT '吊销日期',
  `industry_field` varchar(500) DEFAULT NULL COMMENT '行业领域',
  `sub_industry_field` varchar(500) DEFAULT NULL COMMENT '企业类型',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段列',
  `create_user` varchar(50) DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_index` (`minor_enterprise_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='中小企业注册扩展表';

-- ----------------------------
-- Table structure for to_qrcodesite
-- ----------------------------
DROP TABLE IF EXISTS `to_qrcodesite`;
CREATE TABLE `to_qrcodesite` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `qrcodesite_code` varchar(50) NOT NULL COMMENT '码店ID',
  `qrcodesite_name` varchar(200) DEFAULT NULL COMMENT '码店名称',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '归属区域编码',
  `classify` varchar(50) DEFAULT NULL COMMENT '分类：我司码店、异业码店、王卡驿站',
  `big_classify` varchar(50) DEFAULT NULL COMMENT '大分类',
  `small_classify` varchar(50) DEFAULT NULL COMMENT '小分类',
  `qrcodesite_longitude` decimal(18,8) DEFAULT NULL COMMENT '码店经度',
  `qrcodesite_latitude` decimal(18,8) DEFAULT NULL COMMENT '码店纬度',
  `bundary_coordinates` geometry NOT NULL COMMENT '空间坐标',
  `qrcodesite_address` varchar(500) DEFAULT NULL COMMENT '码店地址',
  `create_user` varchar(50) DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_qrcodesite_unique_key_qrcodesite_code` (`qrcodesite_code`) USING BTREE,
  SPATIAL KEY `spatIdx` (`bundary_coordinates`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='码店基本信息表';

-- ----------------------------
-- Table structure for to_qrcodesite_diffnets
-- ----------------------------
DROP TABLE IF EXISTS `to_qrcodesite_diffnets`;
CREATE TABLE `to_qrcodesite_diffnets` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `qrcodesite_code` varchar(50) NOT NULL COMMENT '码店ID',
  `city` varchar(50) DEFAULT NULL COMMENT '地市编码',
  `diffnets_channel` varchar(50) DEFAULT NULL COMMENT '异网渠道',
  `collect_time` datetime DEFAULT NULL COMMENT '采集时间',
  `collector_wnbr` varchar(50) DEFAULT NULL COMMENT '采集人工号',
  `collector` varchar(50) DEFAULT NULL COMMENT '采集人名称',
  `channel_username` varchar(50) DEFAULT NULL COMMENT '对应区域我司渠道经理名称',
  `channel_useraccount` varchar(50) DEFAULT NULL COMMENT '对应区域我司渠道经理',
  `channel_typename` varchar(50) DEFAULT NULL COMMENT '渠道类型名称',
  `channel_type` varchar(50) DEFAULT NULL COMMENT '渠道类型',
  `channel_status` varchar(50) DEFAULT NULL COMMENT '渠道状态',
  `bus_area` varchar(50) DEFAULT NULL COMMENT '营业面积',
  `main_bus` varchar(50) DEFAULT NULL COMMENT '主营业务',
  `expect_mainbus_sales` varchar(50) DEFAULT NULL COMMENT '预计主营业务月销量',
  `expect_cucc_expiretime` datetime DEFAULT NULL COMMENT '预计联通合约到期时间',
  `expect_ctcc_expiretime` datetime DEFAULT NULL COMMENT '预计电信合约到期时间',
  `invalid_time` datetime DEFAULT NULL COMMENT '失效时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_qrcodesite_diffnets_unique_key_qrcodesite_code` (`qrcodesite_code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='异网码店表';

-- ----------------------------
-- Table structure for to_qrcodesite_self
-- ----------------------------
DROP TABLE IF EXISTS `to_qrcodesite_self`;
CREATE TABLE `to_qrcodesite_self` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `qrcodesite_code` varchar(50) NOT NULL COMMENT '码店ID',
  `linkman` varchar(50) DEFAULT NULL COMMENT '码店联系人',
  `linkman_tel` varchar(50) DEFAULT NULL COMMENT '联系方式',
  `qrcodesite_wnbr` varchar(50) DEFAULT NULL COMMENT '码店工号',
  `collector_wnbr` varchar(50) DEFAULT NULL COMMENT '采集人工号',
  `city` varchar(50) DEFAULT NULL COMMENT '地市编码',
  `city_name` varchar(200) DEFAULT NULL COMMENT '所属地市名称',
  `website_code` varchar(50) DEFAULT NULL COMMENT '渠道编码',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_qrcodesite_self_unique_key_qrcodesite_code` (`qrcodesite_code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='本网码店表';

-- ----------------------------
-- Table structure for to_temp_minor_enterprise
-- ----------------------------
DROP TABLE IF EXISTS `to_temp_minor_enterprise`;
CREATE TABLE `to_temp_minor_enterprise` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `city_code` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '城市编码',
  `city_name` varchar(200) DEFAULT NULL COMMENT '地市名称',
  `cnty_code` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '区县编码',
  `cnty_name` varchar(200) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '区县名称',
  `district_name` varchar(200) DEFAULT NULL COMMENT '行政区名称',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '区域编码',
  `minor_enterprise_code` varchar(50) NOT NULL COMMENT '中小企业编码',
  `minor_enterprise_name` varchar(200) NOT NULL COMMENT '中小企业名称',
  `minor_enterprise_address` varchar(500) DEFAULT NULL COMMENT '中小企业地址',
  `longitude` decimal(18,8) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(18,8) DEFAULT NULL COMMENT '纬度',
  `bundary_coordinates` geometry NOT NULL COMMENT '空间坐标',
  `building_type` varchar(50) DEFAULT NULL COMMENT '楼宇类型',
  `gadmap_type` varchar(50) DEFAULT NULL COMMENT '高德分类',
  `employee_number` int(11) DEFAULT NULL COMMENT '人员数',
  `enterprise_info` varchar(500) DEFAULT NULL COMMENT '企业信息',
  `corporation_name` varchar(50) DEFAULT NULL COMMENT '法人姓名',
  `corporation_phone` varchar(50) DEFAULT NULL COMMENT '法人联系电话',
  `building_code` varchar(50) DEFAULT NULL COMMENT '楼宇编码',
  `building_name` varchar(200) DEFAULT NULL COMMENT '楼宇名称',
  `uptown_code` varchar(50) DEFAULT NULL COMMENT '家客小区编码',
  `uptown_name` varchar(200) DEFAULT NULL COMMENT '家客小区名称',
  `floor` varchar(1000) DEFAULT NULL COMMENT '楼层',
  `room_no` varchar(1000) DEFAULT NULL COMMENT '房号',
  `enterpris_scope` varchar(50) DEFAULT NULL COMMENT '企业经营范围',
  `enterpris_needs` varchar(500) DEFAULT NULL COMMENT '企业需求',
  `enterpris_needs_other` varchar(200) DEFAULT NULL COMMENT '企业需求其他说明',
  `statement_of_needs` varchar(500) DEFAULT NULL COMMENT '需求说明',
  `phone_num_total` varchar(50) DEFAULT NULL COMMENT '手机号码总计数量',
  `proportion` decimal(10,4) DEFAULT NULL COMMENT '在网手机数量占比',
  `is_reimbursed` bit(1) DEFAULT NULL COMMENT '话费是否统一报销',
  `network_signal` varchar(50) DEFAULT NULL COMMENT '该企业网络信号测试结果',
  `know_manager` varchar(50) DEFAULT NULL COMMENT '集团知晓客户经理',
  `is_other_office` bit(1) DEFAULT NULL COMMENT '是否有分公司或总公司',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `status` varchar(50) DEFAULT NULL COMMENT '状态:有效1/无效0/已删除2/待审批3',
  `is_confirmed` bit(1) DEFAULT NULL COMMENT '是否已确认 1、已确认 0、未确认',
  `sourcetype` int(10) DEFAULT NULL COMMENT '楼宇数据来源 1：网格系统录入，2：大数据，3：地市收集，4：省公司收集，5：CRM，6：互联网',
  `process_result` varchar(50) DEFAULT NULL COMMENT '处理结果:对手集团客户、我网集团、未建档集团、已关闭、无此企业、疑似建档',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='中小企业临时表';

-- ----------------------------
-- Table structure for to_temp_minor_enterprise_chargesinfo_e
-- ----------------------------
DROP TABLE IF EXISTS `to_temp_minor_enterprise_chargesinfo_e`;
CREATE TABLE `to_temp_minor_enterprise_chargesinfo_e` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `minor_enterprise_code` varchar(50) NOT NULL COMMENT '中小企业ID',
  `business_type` varchar(50) DEFAULT NULL COMMENT '业务类型',
  `operator` varchar(50) DEFAULT NULL COMMENT '运营商',
  `price` varchar(500) DEFAULT NULL COMMENT '资费价格',
  `quantity` int(10) DEFAULT NULL COMMENT '数量',
  `due_time` date DEFAULT NULL COMMENT '到期时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='中小企业资费信息临时表';

-- ----------------------------
-- Table structure for to_temp_minor_enterprise_linkman_e
-- ----------------------------
DROP TABLE IF EXISTS `to_temp_minor_enterprise_linkman_e`;
CREATE TABLE `to_temp_minor_enterprise_linkman_e` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `minor_enterprise_code` varchar(50) NOT NULL COMMENT '中小企业编码',
  `linkman` varchar(50) DEFAULT NULL COMMENT '联系人',
  `position` varchar(50) DEFAULT NULL COMMENT '职位',
  `linkman_tel` varchar(100) DEFAULT NULL COMMENT '联系电话',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='中小企业联系人信息临时表';

-- ----------------------------
-- Table structure for to_temp_qrcodesite
-- ----------------------------
DROP TABLE IF EXISTS `to_temp_qrcodesite`;
CREATE TABLE `to_temp_qrcodesite` (
  `qrcodesite_code` varchar(50) NOT NULL COMMENT '码店ID',
  `qrcodesite_name` varchar(200) DEFAULT NULL COMMENT '码店名称',
  `grid_code` varchar(50) DEFAULT NULL COMMENT '归属区域编码',
  `classify` varchar(50) DEFAULT NULL COMMENT '分类：我司码店、异网码店',
  `big_classify` varchar(50) DEFAULT NULL COMMENT '大分类',
  `small_classify` varchar(50) DEFAULT NULL COMMENT '小分类',
  `qrcodesite_longitude` decimal(18,8) DEFAULT NULL COMMENT '码店经度',
  `qrcodesite_latitude` decimal(18,8) DEFAULT NULL COMMENT '码店纬度',
  `qrcodesite_address` varchar(500) DEFAULT NULL COMMENT '码店地址',
  PRIMARY KEY (`qrcodesite_code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='码店基本信息临时表';

-- ----------------------------
-- Table structure for to_temp_qrcodesite_diffnets
-- ----------------------------
DROP TABLE IF EXISTS `to_temp_qrcodesite_diffnets`;
CREATE TABLE `to_temp_qrcodesite_diffnets` (
  `qrcodesite_code` varchar(50) NOT NULL COMMENT '码店编码',
  `city` varchar(50) DEFAULT NULL COMMENT '地市编码',
  `diffnets_channel` varchar(50) DEFAULT NULL COMMENT '异网渠道',
  `collect_time` datetime DEFAULT NULL COMMENT '采集时间',
  `collector_wnbr` varchar(50) DEFAULT NULL COMMENT '采集人工号',
  `collector` varchar(50) DEFAULT NULL COMMENT '采集人名称',
  `channel_username` varchar(50) DEFAULT NULL COMMENT '对应区域我司渠道经理名称',
  `channel_useraccount` varchar(50) DEFAULT NULL COMMENT '对应区域我司渠道经理',
  `channel_typename` varchar(50) DEFAULT NULL COMMENT '渠道类型名称',
  `channel_type` varchar(50) DEFAULT NULL COMMENT '渠道类型',
  `channel_status` varchar(50) DEFAULT NULL COMMENT '渠道状态',
  `bus_area` varchar(50) DEFAULT NULL COMMENT '营业面积',
  `main_bus` varchar(50) DEFAULT NULL COMMENT '主营业务',
  `expect_mainbus_sales` varchar(50) DEFAULT NULL COMMENT '预计主营业务月销量',
  `expect_cucc_expiretime` datetime DEFAULT NULL COMMENT '预计联通合约到期时间',
  `expect_ctcc_expiretime` datetime DEFAULT NULL COMMENT '预计电信合约到期时间',
  `invalid_time` datetime DEFAULT NULL COMMENT '失效时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`qrcodesite_code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='异网码店临时表';

-- ----------------------------
-- Table structure for to_temp_qrcodesite_self
-- ----------------------------
DROP TABLE IF EXISTS `to_temp_qrcodesite_self`;
CREATE TABLE `to_temp_qrcodesite_self` (
  `qrcodesite_code` varchar(50) NOT NULL COMMENT '码店编码',
  `linkman` varchar(50) DEFAULT NULL COMMENT '码店联系人',
  `linkman_tel` varchar(50) DEFAULT NULL COMMENT '联系方式',
  `qrcodesite_wnbr` varchar(50) DEFAULT NULL COMMENT '码店工号',
  `collector_wnbr` varchar(50) DEFAULT NULL COMMENT '采集人工号',
  `city` varchar(50) DEFAULT NULL COMMENT '地市编码',
  `city_name` varchar(200) DEFAULT NULL COMMENT '所属地市名称',
  `website_code` varchar(50) DEFAULT NULL COMMENT '渠道编码',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`qrcodesite_code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='我司码店临时表';

-- ----------------------------
-- Table structure for to_temp_website_snapshot
-- ----------------------------
DROP TABLE IF EXISTS `to_temp_website_snapshot`;
CREATE TABLE `to_temp_website_snapshot` (
  `website_code` varchar(50) DEFAULT NULL COMMENT '渠道编码',
  `website_name` varchar(200) DEFAULT NULL COMMENT '渠道名称',
  `city` varchar(50) NOT NULL COMMENT '城市编码',
  `district` varchar(50) NOT NULL COMMENT '区域编码',
  `net_grid` varchar(50) NOT NULL COMMENT '网格编码',
  `field` varchar(50) NOT NULL COMMENT '责任田编码',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='我司渠道快照临时表';

-- ----------------------------
-- Table structure for tr_diffqrcodesite_city_sales
-- ----------------------------
DROP TABLE IF EXISTS `tr_diffqrcodesite_city_sales`;
CREATE TABLE `tr_diffqrcodesite_city_sales` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `city_name` varchar(200) NOT NULL COMMENT '城市名称',
  `data_date` date NOT NULL COMMENT '日期',
  `current_bus_tot` int(10) DEFAULT NULL COMMENT '当月业务总量',
  `current_active_tot` int(10) DEFAULT NULL COMMENT '当月活跃总量',
  `create_user` varchar(50) NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_diffqrcodesite_city_sales_unique_key_city_name` (`city_name`,`data_date`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='异码店城市销售情况表';

-- ----------------------------
-- Table structure for tr_temp_grid_stat_snapshot
-- ----------------------------
DROP TABLE IF EXISTS `tr_temp_grid_stat_snapshot`;
CREATE TABLE `tr_temp_grid_stat_snapshot` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `city` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '城市编码',
  `district` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '区域编码',
  `net_grid` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '网格编码',
  `field` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '责任田编码',
  `website_cnt` int(10) DEFAULT NULL COMMENT '我司渠道数量',
  `create_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '修改人',
  `modify_date` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_grid_stat_snapshot_unique_key_city_distr_grid_field` (`city`,`district`,`net_grid`,`field`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='区域统计快照临时表';

-- ----------------------------
-- Table structure for tt_f_biz_address
-- ----------------------------
DROP TABLE IF EXISTS `tt_f_biz_address`;
CREATE TABLE `tt_f_biz_address` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `code` varchar(50) NOT NULL COMMENT '地址编码',
  `parent_code` varchar(50) DEFAULT NULL COMMENT '父级地址编码',
  `name` varchar(50) DEFAULT NULL COMMENT '地址名称',
  `level` int(11) DEFAULT NULL COMMENT '层级',
  `create_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='地址基础信息';

-- ----------------------------
-- Table structure for tt_f_biz_category
-- ----------------------------
DROP TABLE IF EXISTS `tt_f_biz_category`;
CREATE TABLE `tt_f_biz_category` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `code` varchar(50) NOT NULL COMMENT '地址编码',
  `parent_code` varchar(50) DEFAULT NULL COMMENT '父级地址编码',
  `name` varchar(50) DEFAULT NULL COMMENT '地址名称',
  `level` int(11) DEFAULT NULL COMMENT '层级',
  `create_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='类别基础信息';

-- ----------------------------
-- Table structure for tt_spatial_computation_for_enterprise
-- ----------------------------
DROP TABLE IF EXISTS `tt_spatial_computation_for_enterprise`;
CREATE TABLE `tt_spatial_computation_for_enterprise` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bundary_coordinates` geometry NOT NULL,
  `grid_code` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  SPATIAL KEY `spatIdx` (`bundary_coordinates`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Table structure for vapptest
-- ----------------------------
DROP TABLE IF EXISTS `vapptest`;
CREATE TABLE `vapptest` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `extend_column` json DEFAULT NULL COMMENT '扩展字段列',
  `create_user` varchar(50) DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_user` varchar(50) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='vapptest';

-- ----------------------------
-- Table structure for xzy_0929
-- ----------------------------
DROP TABLE IF EXISTS `xzy_0929`;
CREATE TABLE `xzy_0929` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `企业名称` varchar(200) DEFAULT NULL,
  `注册地址` varchar(100) DEFAULT NULL,
  `企业类型` varchar(50) DEFAULT NULL,
  `经度` decimal(18,8) DEFAULT NULL,
  `纬度` decimal(18,8) DEFAULT NULL,
  `法定代表人` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10207 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='集团表';

-- ----------------------------
-- Table structure for zld_a
-- ----------------------------
DROP TABLE IF EXISTS `zld_a`;
CREATE TABLE `zld_a` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `mobile` varchar(45) DEFAULT NULL,
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mobile` (`mobile`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for zld_b
-- ----------------------------
DROP TABLE IF EXISTS `zld_b`;
CREATE TABLE `zld_b` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `mobile` varchar(45) DEFAULT NULL,
  `register_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_mobile` (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for zld_c
-- ----------------------------
DROP TABLE IF EXISTS `zld_c`;
CREATE TABLE `zld_c` (
  `Date` datetime DEFAULT NULL,
  `User` varchar(200) DEFAULT NULL,
  `Query_time` decimal(12,6) DEFAULT NULL,
  `Lock_time` decimal(12,6) DEFAULT NULL,
  `Rows_sent` int(11) DEFAULT NULL,
  `Rows_examined` bigint(16) DEFAULT NULL,
  `SQL` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Procedure structure for grid_merge
-- ----------------------------
DROP PROCEDURE IF EXISTS `grid_merge`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `grid_merge`(
IN old_grids  varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
IN coperate_user varchar(50),
IN target_grid varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
IN new_grid varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
IN new_bundary mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
IN new_center_longitude decimal(18,8),
IN new_center_latitude decimal(18,8), 
out new_grid_name varchar(500) ,
out new_grid_all_parent_code varchar(200),
out new_grid_level int(11))
BEGIN
-- declare var_sql varchar(1000);

-- 修改归档操作
update t_grid_resource_record_m set status='0' where FIND_IN_SET(grid_code,old_grids) and status='1';

INSERT INTO `t_grid_resource_record_m`(`resource_type`, `resource_code`, `grid_code`, `status`, `approver`, `create_user`, `create_date`, `modify_user`, `modify_date`) 
SELECT 'grid',code,parent_code,'1', NULL, coperate_user, now(), coperate_user, now() from t_grid_m where  level='5' and FIND_IN_SET(code,old_grids)
union all
SELECT 'building',code,grid_code,'1', NULL, coperate_user, now(), coperate_user, now() from t_biz_building_m where  status<>'2' and FIND_IN_SET(grid_code,old_grids)
union all
SELECT 'uptown',code,grid_code,'1', NULL, coperate_user, now(), coperate_user, now() from t_uptown_m where  status<>'2' and FIND_IN_SET(grid_code,old_grids)
union all
SELECT 'website',code,grid_code,'1', NULL, coperate_user, now(), coperate_user, now() from t_website_m where  status<>'2' and FIND_IN_SET(grid_code,old_grids)
union all
SELECT 'minor_enterprise',minor_enterprise_code,grid_code,'1', NULL, coperate_user, now(), coperate_user, now() from to_minor_enterprise where  status<>'2' and FIND_IN_SET(grid_code,old_grids)
union all
SELECT 'sector',station_code,grid_code,'1', NULL, coperate_user, now(), coperate_user, now() from t_biz_sector where  status<>'2' and FIND_IN_SET(grid_code,old_grids) union all
SELECT 'enterprise',code,grid_code,'1', NULL, coperate_user, now(), coperate_user, now() from t_biz_enterprise_m where  status<>'2' and FIND_IN_SET(grid_code,old_grids);

-- 失效旧网格
update t_grid_m set grid_status='2' where FIND_IN_SET(code,old_grids);
-- insert t_grid_m
INSERT INTO `t_grid_m`(`code`, `parent_code`, `all_parent_code`, `old_grid_code`, `name`, `full_name`, `type`, `bundary`, `bundary_coordinate`, `level`, `headperson`, `headperson_code`, `headperson_tel`, `center_longitude`, `center_latitude`, `area`, `grid_status`, `email`, `relate_org_code`, `relate_org`, `priority`, `short_name`, `is_town`, `remark`, `extend_column`, `create_user`, `create_date`, `modify_user`, `modify_date`) 
SELECT new_grid, `parent_code`, `all_parent_code`, `old_grid_code`, `name`, `full_name`, `type`, new_bundary, ST_GeomFromText(new_bundary，4326), `level`, `headperson`, `headperson_code`, `headperson_tel`, new_center_longitude, new_center_latitude, `area`, `grid_status`, `email`, `relate_org_code`, `relate_org`, `priority`, `short_name`, `is_town`, `remark`, `extend_column`, coperate_user, now(), coperate_user, now() FROM t_grid_m where code=target_grid;
-- 更新资源区域编码
update t_biz_building_m set grid_code=new_grid where FIND_IN_SET(grid_code,old_grids);
update t_uptown_m set grid_code=new_grid where FIND_IN_SET(grid_code,old_grids);
update t_website_m set grid_code=new_grid where FIND_IN_SET(grid_code,old_grids);
update to_minor_enterprise set grid_code=new_grid where FIND_IN_SET(grid_code,old_grids);
update t_biz_sector set grid_code=new_grid where FIND_IN_SET(grid_code,old_grids);
update t_biz_enterprise_m set grid_code=new_grid where FIND_IN_SET(grid_code,old_grids);

select name into new_grid_name from t_grid_m where code =new_grid;
select level into new_grid_level from t_grid_m where code =new_grid;
select all_parent_code into new_grid_all_parent_code from t_grid_m where code =new_grid;

END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for grid_merge_end
-- ----------------------------
DROP PROCEDURE IF EXISTS `grid_merge_end`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `grid_merge_end`(
IN old_grids  varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
IN new_grid varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
IN coperate_user varchar(50), 
IN batchno varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci)
BEGIN

-- 修改归档操作
update t_grid_resource_record_m set status='0',modify_user=coperate_user,modify_date=now()
where FIND_IN_SET(grid_code,old_grids) and status='1';

INSERT INTO `t_grid_resource_record_m`(`resource_type`, `resource_code`, `grid_code`, `status`, `approver`, `create_user`, `create_date`, `modify_user`, `modify_date`) 
SELECT `resource_type`, `resource_code`, `grid_code`, `status`, `approver`, `create_user`, `create_date`, `modify_user`, `modify_date` from t_grid_merge_record_m where batch_no=batchno;

delete from t_grid_merge_record_m where batch_no=batchno;

-- 更新资源区域编码
 update t_biz_building_m set grid_code=new_grid where FIND_IN_SET(grid_code,old_grids);
update t_uptown_m set grid_code=new_grid,modify_user=coperate_user,modify_date=now() where FIND_IN_SET(grid_code,old_grids);
update t_website_m set grid_code=new_grid,modify_user=coperate_user,modify_date=now() where FIND_IN_SET(grid_code,old_grids);
update to_minor_enterprise set grid_code=new_grid,modify_user=coperate_user,modify_date=now() where FIND_IN_SET(grid_code,old_grids);
update t_biz_sector set grid_code=new_grid,modify_user=coperate_user,modify_date=now() where FIND_IN_SET(grid_code,old_grids);
update t_biz_enterprise_m set grid_code=new_grid,modify_user=coperate_user,modify_date=now() where FIND_IN_SET(grid_code,old_grids);

END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for grid_merge_reset
-- ----------------------------
DROP PROCEDURE IF EXISTS `grid_merge_reset`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `grid_merge_reset`(
IN old_grids  varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
IN new_grid varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
IN batchno varchar(50)
)
BEGIN
-- 删除合并网格
DELETE from t_grid_m where code=new_grid;
-- 还原旧网格
update t_grid_m set grid_status='1' where FIND_IN_SET(code,old_grids);
-- 删除合并日志
DELETE from t_grid_merge_record_m where batch_no=batchno;
END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for grid_merge_start
-- ----------------------------
DROP PROCEDURE IF EXISTS `grid_merge_start`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `grid_merge_start`(
IN old_grids  varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
IN coperate_user varchar(50),
IN target_grid varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
IN new_grid varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
IN new_bundary mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
IN new_center_longitude decimal(18,8),
IN new_center_latitude decimal(18,8), 
IN batch_no varchar(50),
out rule_code varchar(50),
out new_grid_name varchar(500) ,
out new_grid_all_parent_code varchar(200),
out new_grid_level int(11),
out new_grid_status varchar(50))
BEGIN
-- declare var_sql varchar(1000);

--  增加归档日志
INSERT INTO `t_grid_merge_record_m`(`batch_no`,`resource_type`, `resource_code`, `grid_code`, `status`, `approver`, `create_user`, `create_date`, `modify_user`, `modify_date`) 
SELECT batch_no,'grid',code,parent_code,'1', NULL, coperate_user, now(), coperate_user, now() from t_grid_m where FIND_IN_SET(code,old_grids)
union all
SELECT batch_no,'building',code,grid_code,'1', NULL, coperate_user, now(), coperate_user, now() from t_biz_building_m where  status<>'2' and FIND_IN_SET(grid_code,old_grids)
union all
SELECT batch_no,'uptown',code,grid_code,'1', NULL, coperate_user, now(), coperate_user, now() from t_uptown_m where  status<>'2' and FIND_IN_SET(grid_code,old_grids)
union all
SELECT batch_no,'website',code,grid_code,'1', NULL, coperate_user, now(), coperate_user, now() from t_website_m where  status<>'2' and FIND_IN_SET(grid_code,old_grids)
union all
SELECT batch_no,'minor_enterprise',minor_enterprise_code,grid_code,'1', NULL, coperate_user, now(), coperate_user, now() from to_minor_enterprise where  status<>'2' and FIND_IN_SET(grid_code,old_grids)
union all
SELECT batch_no,'sector',station_code,grid_code,'1', NULL, coperate_user, now(), coperate_user, now() from t_biz_sector where  status<>'2' and FIND_IN_SET(grid_code,old_grids) union all
SELECT batch_no,'enterprise',code,grid_code,'1', NULL, coperate_user, now(), coperate_user, now() from t_biz_enterprise_m where  status<>'2' and FIND_IN_SET(grid_code,old_grids);

-- insert t_grid_m
INSERT INTO `t_grid_m`(`code`, `parent_code`, `all_parent_code`, `old_grid_code`, `name`, `full_name`, `type`, `bundary`, `bundary_coordinate`, `level`, `headperson`, `headperson_code`, `headperson_tel`, `center_longitude`, `center_latitude`, `area`, `grid_status`, `email`, `relate_org_code`, `relate_org`, `priority`, `short_name`, `is_town`, `remark`, `extend_column`, `create_user`, `create_date`, `modify_user`, `modify_date`)
SELECT new_grid, `parent_code`, REPLACE(all_parent_code,code,new_grid), code, `name`, `full_name`, `type`, new_bundary, ST_GeomFromText(new_bundary,4326), `level`, `headperson`, `headperson_code`, `headperson_tel`, new_center_longitude, new_center_latitude, `area`,`grid_status`, `email`, `relate_org_code`, `relate_org`, `priority`, `short_name`, `is_town`, `remark`, `extend_column`,coperate_user, now(), coperate_user, now() FROM t_grid_m where code=target_grid;


-- 失效旧网格
update t_grid_m set grid_status='0' where FIND_IN_SET(code,old_grids);

-- 更新资源区域编码 放到合并结束执行
-- update t_biz_building_m set grid_code=new_grid where FIND_IN_SET(grid_code,old_grids);
-- update t_uptown_m set grid_code=new_grid where FIND_IN_SET(grid_code,old_grids);
-- update t_website_m set grid_code=new_grid where FIND_IN_SET(grid_code,old_grids);
-- update to_minor_enterprise set grid_code=new_grid where FIND_IN_SET(grid_code,old_grids);
-- update t_biz_station_m set grid_code=new_grid where FIND_IN_SET(grid_code,old_grids);
-- update t_biz_enterprise_m set grid_code=new_grid where FIND_IN_SET(grid_code,old_grids);

select 'SD' into rule_code from dual;
select name into new_grid_name from t_grid_m where code =new_grid;
select level into new_grid_level from t_grid_m where code =new_grid;
select all_parent_code into new_grid_all_parent_code from t_grid_m where code =new_grid;
select grid_status into new_grid_status from t_grid_m where code =new_grid;

END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_create_table
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_create_table`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_create_table`()
BEGIN
	declare v_table_name varchar(50);
	-- 遍历数据结束标志
  declare done int default false;
  -- 定义游标
  declare c_table cursor for 
	
  select distinct t.table
	from t_excel t 
	where t.table like 't_%' or t.table like 'to_%';
	-- 将结束标志绑定到游标
  declare continue handler for not found set done = true;
	 -- 打开游标
  open c_table;
	truncate t_create_table;
  -- 开始循环
  read_loop: loop
    fetch c_table into v_table_name;
    -- 声明结束的时候
    if done then
      leave read_loop;
    end if;
		call p_table_structure(v_table_name);
	end loop;
END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_get_gis_info
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_get_gis_info`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_get_gis_info`(IN type_code varchar(200) character set utf8mb4,IN resource_id varchar(200) character set utf8mb4)
BEGIN 
-- 解决app资源新增修改同步到gis 获取对应推送信息
IF type_code = 'uptown' THEN 
  select 'uptown' as objectname,
SUBSTRING_INDEX(SUBSTRING_INDEX(g.all_parent_code,',',2),',',-1) as city_code,
SUBSTRING_INDEX(SUBSTRING_INDEX(g.all_parent_code,',',3),',',-1) as district_code,
SUBSTRING_INDEX(SUBSTRING_INDEX(g.all_parent_code,',',4),',',-1) as grid_code,
r.grid_code as field_code,AsText(r.bundary_coordinates) as coordinates ,
r.name,r.code,r.status,r.type from t_uptown_m  r 
left join t_grid_m g on g.code= r.grid_code where  r.id=resource_id;
ELSEIF type_code = 'station' THEN

select 'station' as objectname,
SUBSTRING_INDEX(SUBSTRING_INDEX(g.all_parent_code,',',2),',',-1) as city_code,
SUBSTRING_INDEX(SUBSTRING_INDEX(g.all_parent_code,',',3),',',-1) as district_code,
SUBSTRING_INDEX(SUBSTRING_INDEX(g.all_parent_code,',',4),',',-1) as grid_code,
r.grid_code as field_code,AsText(r.bundary_coordinates) as coordinates ,
r.name,r.code,r.status,r.type from t_biz_station_m  r 
left join t_grid_m g on g.code= r.grid_code
where r.id=resource_id;
ELSEIF type_code = 'website' THEN

select 'website' as objectname,
SUBSTRING_INDEX(SUBSTRING_INDEX(g.all_parent_code,',',2),',',-1) as city_code,
SUBSTRING_INDEX(SUBSTRING_INDEX(g.all_parent_code,',',3),',',-1) as district_code,
SUBSTRING_INDEX(SUBSTRING_INDEX(g.all_parent_code,',',4),',',-1) as grid_code,
r.grid_code as field_code,AsText(r.coordinates) as coordinates, r.sub_type,
r.name,r.code,r.status,r.type from t_website_m  r 
left join t_grid_m g on g.code= r.grid_code
where r.id=resource_id;
ELSEIF type_code = 'enterprise' THEN

select 'enterprise' as objectname,
SUBSTRING_INDEX(SUBSTRING_INDEX(g.all_parent_code,',',2),',',-1) as city_code,
SUBSTRING_INDEX(SUBSTRING_INDEX(g.all_parent_code,',',3),',',-1) as district_code,
SUBSTRING_INDEX(SUBSTRING_INDEX(g.all_parent_code,',',4),',',-1) as grid_code,
r.grid_code as field_code,AsText(r.bundary_coordinates) as coordinates,r.level,
r.name,r.code,r.status,r.type from t_biz_enterprise_m  r 
left join t_grid_m g on g.code= r.grid_code
where r.id=resource_id;
ELSEIF type_code = 'minor_enterprise' THEN

select 'minor_enterprise' as objectname,
SUBSTRING_INDEX(SUBSTRING_INDEX(g.all_parent_code,',',2),',',-1) as city_code,
SUBSTRING_INDEX(SUBSTRING_INDEX(g.all_parent_code,',',3),',',-1) as district_code,
SUBSTRING_INDEX(SUBSTRING_INDEX(g.all_parent_code,',',4),',',-1) as grid_code,
r.grid_code as field_code,AsText(r.bundary_coordinates) as coordinates,
r.minor_enterprise_name as name,r.minor_enterprise_code as code,r.status,r.type from to_minor_enterprise  r 
left join t_grid_m g on g.code= r.grid_code
where r.id=resource_id;
ELSEIF type_code = 'alongstreet_shop' THEN

select 'alongstreet_shop' as objectname,
SUBSTRING_INDEX(SUBSTRING_INDEX(g.all_parent_code,',',2),',',-1) as city_code,
SUBSTRING_INDEX(SUBSTRING_INDEX(g.all_parent_code,',',3),',',-1) as district_code,
SUBSTRING_INDEX(SUBSTRING_INDEX(g.all_parent_code,',',4),',',-1) as grid_code,
r.grid_code as field_code,AsText(r.bundary_coordinates) as coordinates,r.level,
r.name,r.code,r.status,r.type from t_alongstreet_shop_m  r 
left join t_grid_m g on g.code= r.grid_code
where r.id=resource_id;

ELSE

select 'NAN' as objectname from dual;
END IF;

end
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_biz_bigfamily_portrait_m
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_biz_bigfamily_portrait_m`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_biz_bigfamily_portrait_m`(OUT `p_status` int(10))
BEGIN 	
-- 大家庭画像表--
insert into t_biz_bigfamily_portrait_m(code,family_network_status,lovefamily_package_status,rearview_mirror_status,vehicleowner_service_status,family_num,self_net_num,diffnet_net_num,main_phone,family_members_remark,remark,create_user,create_date,modify_user,modify_date)
select code,family_network_status,lovefamily_package_status,rearview_mirror_status,vehicleowner_service_status,family_num,self_net_num,diffnet_net_num,main_phone,family_members_remark,remark,'system',sysdate(),'system',sysdate()
from t_temp_biz_bigfamily_portrait_m
on duplicate key update
family_network_status = values(family_network_status),
lovefamily_package_status = values(lovefamily_package_status),
rearview_mirror_status = values(rearview_mirror_status),
vehicleowner_service_status = values(vehicleowner_service_status),
family_num = values(family_num),
self_net_num = values(self_net_num),
diffnet_net_num = values(diffnet_net_num),
main_phone = values(main_phone),
family_members_remark = values(family_members_remark),
remark = values(remark),
modify_date = sysdate();

set p_status = 0; 
END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_biz_building_index_m
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_biz_building_index_m`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_biz_building_index_m`(OUT `p_status` int(10))
BEGIN  insert into t_biz_building_index_m(building_code,self_user_num,other_user_num,statistics_time,create_user,create_date,modify_user,modify_date) select building_code,self_user_num,other_user_num,statistics_time,'system',sysdate(),'system',sysdate() from t_temp_biz_building_index_m on duplicate key update self_user_num = values(self_user_num), other_user_num = values(other_user_num), statistics_time = values(statistics_time), modify_date = sysdate(); insert into t_biz_building_index_m(building_code,statistics_time,create_user,create_date,modify_user,modify_date) select t.`code`,t.modify_date,t.create_user,t.create_date,t.modify_user,t.modify_date from t_biz_building_m t  where not exists(select `code` from t_biz_building_index_m tu where tu.building_code = t.`code`); set p_status = 0;  END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_biz_building_m
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_biz_building_m`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_biz_building_m`(OUT `p_status` int(10))
BEGIN  insert into t_biz_building_m(grid_code,longitude,latitude,bundary_coordinates,code,name,floornum,cusyomer_name,cusyomer_phone,cover_total,cover_way,open_account_num,production_date,broadband_type,building_value,route_type,cusyomer_total,sign_cusyomer_total,is_agree_insert,dedic_line_num,dedic_line_mon_income,remarks,lytype,addr,xqid,street,housenumber,area,inblock,ratecoverage,regionname,xqname,esoptype,livefirerate,rescontentment,actualinvestment,sourcetype,covermode,update_date,order_source,build_way,build_type,first_finish_date,last_finish_date,first_open_way,last_open_way,first_open_date,last_open_date,isfinish,real_ratecoverage,serviceorderno,productname,openingtype,isconstruction,businessopen_sync_date,specialcheck,belongtype,building,subscode,is_cover_ims,is_cover_mobile,is_cover_mobilecell,mobile_num,broadband_share,manager,manager_phone,lt_num,telecommunication_num,bundary,enterprise_num,cover_scene,addr_type,device_type,free_port_count,dw_portion,property_name,property_tel,property_keyperson,property_keyperson_tel,city_name,status,is_confirmed,create_user,create_date,modify_user,modify_date) select grid_code,longitude,latitude,bundary_coordinates,code,name,floornum,cusyomer_name,cusyomer_phone,cover_total,cover_way,open_account_num,production_date,broadband_type,building_value,route_type,cusyomer_total,sign_cusyomer_total,is_agree_insert,dedic_line_num,dedic_line_mon_income,remarks,lytype,addr,xqid,street,housenumber,area,inblock,ratecoverage,regionname,xqname,esoptype,livefirerate,rescontentment,actualinvestment,sourcetype,covermode,update_date,order_source,build_way,build_type,first_finish_date,last_finish_date,first_open_way,last_open_way,first_open_date,last_open_date,isfinish,real_ratecoverage,serviceorderno,productname,openingtype,isconstruction,businessopen_sync_date,specialcheck,belongtype,building,subscode,is_cover_ims,is_cover_mobile,is_cover_mobilecell,mobile_num,broadband_share,manager,manager_phone,lt_num,telecommunication_num,bundary,enterprise_num,cover_scene,addr_type,device_type,free_port_count,dw_portion,property_name,property_tel,property_keyperson,property_keyperson_tel,city_name,status,is_confirmed,'system',sysdate(),'system',sysdate() from t_temp_biz_building_m on duplicate key update grid_code = values(grid_code), longitude = values(longitude), latitude = values(latitude), bundary_coordinates = values(bundary_coordinates), name = values(name), floornum = values(floornum), cusyomer_name = values(cusyomer_name), cusyomer_phone = values(cusyomer_phone), cover_total = values(cover_total), cover_way = values(cover_way), open_account_num = values(open_account_num), production_date = values(production_date), broadband_type = values(broadband_type), building_value = values(building_value), route_type = values(route_type), cusyomer_total = values(cusyomer_total), sign_cusyomer_total = values(sign_cusyomer_total), is_agree_insert = values(is_agree_insert), dedic_line_num = values(dedic_line_num), dedic_line_mon_income = values(dedic_line_mon_income), remarks = values(remarks), lytype = values(lytype), addr = values(addr), xqid = values(xqid), street = values(street), housenumber = values(housenumber), area = values(area), inblock = values(inblock), ratecoverage = values(ratecoverage), regionname = values(regionname), xqname = values(xqname), esoptype = values(esoptype), livefirerate = values(livefirerate), rescontentment = values(rescontentment), actualinvestment = values(actualinvestment), sourcetype = values(sourcetype), covermode = values(covermode), update_date = values(update_date), order_source = values(order_source), build_way = values(build_way), build_type = values(build_type), first_finish_date = values(first_finish_date), last_finish_date = values(last_finish_date), first_open_way = values(first_open_way), last_open_way = values(last_open_way), first_open_date = values(first_open_date), last_open_date = values(last_open_date), isfinish = values(isfinish), real_ratecoverage = values(real_ratecoverage), serviceorderno = values(serviceorderno), productname = values(productname), openingtype = values(openingtype), isconstruction = values(isconstruction), businessopen_sync_date = values(businessopen_sync_date), specialcheck = values(specialcheck), belongtype = values(belongtype), building = values(building), subscode = values(subscode), is_cover_ims = values(is_cover_ims), is_cover_mobile = values(is_cover_mobile), is_cover_mobilecell = values(is_cover_mobilecell), mobile_num = values(mobile_num), broadband_share = values(broadband_share), manager = values(manager), manager_phone = values(manager_phone), lt_num = values(lt_num), telecommunication_num = values(telecommunication_num), bundary = values(bundary), enterprise_num = values(enterprise_num), cover_scene = values(cover_scene), addr_type = values(addr_type), device_type = values(device_type), free_port_count = values(free_port_count), dw_portion = values(dw_portion), property_name = values(property_name), property_tel = values(property_tel), property_keyperson = values(property_keyperson), property_keyperson_tel = values(property_keyperson_tel), city_name = values(city_name), status = values(status), is_confirmed = values(is_confirmed), modify_date = sysdate(); END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_biz_building_marketing
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_biz_building_marketing`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_biz_building_marketing`(OUT `p_status` int(10))
BEGIN  insert into t_biz_building_marketing(building_code,marketing_code,create_user,create_date,modify_user,modify_date) select building_code,marketing_code,'system',sysdate(),'system',sysdate() from t_temp_biz_building_marketing on duplicate key update modify_date = sysdate();  set p_status = 0;  END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_biz_enterprise_m
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_biz_enterprise_m`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_biz_enterprise_m`(OUT `p_status` int(10))
BEGIN  insert into t_biz_enterprise_m(grid_code,code,name,type,longitude,latitude,bundary_coordinates,level,customer_manager,address,firstlevel_address,twolevel_address,threelevel_address,fourlevel_address,fivelevel_address,sixlevel_address,sevenlevel_address,sourcetype,status,is_confirmed,create_user,create_date,modify_user,modify_date) select grid_code,code,name,type,longitude,latitude,bundary_coordinates,level,customer_manager,address,firstlevel_address,twolevel_address,threelevel_address,fourlevel_address,fivelevel_address,sixlevel_address,sevenlevel_address,sourcetype,status,is_confirmed,'system',sysdate(),'system',sysdate() from t_temp_biz_enterprise_m on duplicate key update grid_code = values(grid_code), name = values(name), type = values(type), longitude = values(longitude), latitude = values(latitude), bundary_coordinates = values(bundary_coordinates), level = values(level), customer_manager = values(customer_manager), address = values(address), firstlevel_address = values(firstlevel_address), twolevel_address = values(twolevel_address), threelevel_address = values(threelevel_address), fourlevel_address = values(fourlevel_address), fivelevel_address = values(fivelevel_address), sixlevel_address = values(sixlevel_address), sevenlevel_address = values(sevenlevel_address), sourcetype = values(sourcetype), status = values(status), is_confirmed = values(is_confirmed), modify_date = sysdate(); set p_status = 0; END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_biz_marketing_m
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_biz_marketing_m`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_biz_marketing_m`(OUT `p_status` int(10))
BEGIN  insert into t_biz_marketing_m(code,name,begin_time,end_time,create_user,create_date,modify_user,modify_date) select code,name,begin_time,end_time,'system',sysdate(),'system',sysdate() from t_temp_biz_marketing_m on duplicate key update name = values(name), begin_time = values(begin_time), end_time = values(end_time), modify_date = sysdate();  set p_status = 0;  END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_biz_mobile_effectiveuser_statistics
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_biz_mobile_effectiveuser_statistics`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_biz_mobile_effectiveuser_statistics`(OUT `p_status` int(10))
BEGIN  insert into t_biz_mobile_effectiveuser_statistics(field,effectiveuser_statistics,create_user,create_date,modify_user,modify_date) select field,effectiveuser_statistics,'system',sysdate(),'system',sysdate()  from t_temp_biz_mobile_effectiveuser_statistics   where field is not null  on duplicate key update  effectiveuser_statistics = values(effectiveuser_statistics);  set p_status = 0;  END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_biz_phone_building
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_biz_phone_building`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_biz_phone_building`(OUT `p_status` int(10))
BEGIN  insert into t_biz_phone_building(phone,building_code,create_user,create_date,modify_user,modify_date) select phone,building_code,'system',sysdate(),'system',sysdate() from t_temp_biz_phone_building on duplicate key update modify_date = sysdate(); set p_status = 0; END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_biz_phone_index_info
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_biz_phone_index_info`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_biz_phone_index_info`(OUT `p_status` int(10))
BEGIN 	
	insert into t_biz_phone_index_info(phone,bw_busi_num,value_added_num,family_busi_num,create_user,create_date,modify_user,modify_date)
select phone,bw_busi_num,value_added_num,family_busi_num,'system',sysdate(),'system',sysdate()
from t_temp_biz_phone_index_info
on duplicate key update
bw_busi_num = values(bw_busi_num),
value_added_num = values(value_added_num),
family_busi_num = values(family_busi_num),
modify_date = sysdate();

set p_status = 0;
END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_biz_phone_m
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_biz_phone_m`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_biz_phone_m`(OUT `p_status` int(10))
BEGIN  insert into t_biz_phone_m(phone,bw_account,user_name,age,sex,role,grid_code,uptown_code,bw,phone_price,imsi,collect_date,avg_arpu,brand,city_code,create_user,create_date,modify_user,modify_date) select phone,bw_account,user_name,age,sex,role,grid_code,uptown_code,bw,phone_price,imsi,collect_date,avg_arpu,brand,city_code,'system',sysdate(),'system',sysdate() from t_temp_biz_phone_m on duplicate key update bw_account = values(bw_account), user_name = values(user_name), age = values(age), sex = values(sex), role = values(role), grid_code = values(grid_code), uptown_code = values(uptown_code), bw = values(bw), phone_price = values(phone_price), imsi = values(imsi), collect_date = values(collect_date), avg_arpu = values(avg_arpu), brand = values(brand), city_code = values(city_code), modify_date = sysdate(); set p_status = 0; END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_biz_phone_marketing
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_biz_phone_marketing`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_biz_phone_marketing`(OUT `p_status` int(10))
BEGIN  insert into t_biz_phone_marketing(phone,marketing_code,create_user,create_date,modify_user,modify_date) select phone,marketing_code,'system',sysdate(),'system',sysdate() from t_temp_biz_phone_marketing on duplicate key update phone = values(phone), marketing_code = values(marketing_code), modify_date = sysdate(); set p_status = 0; END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_biz_sector
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_biz_sector`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_biz_sector`(OUT `p_status` int(10))
BEGIN  insert into t_biz_sector(grid_code,station_code,station_name,cgi,bs_code,bs_name,bs_full_name,city_name,county_name,latitude,longitude,bundary_coordinates,cover_type,net_type,loc_code,cell_code,cell_name,cell_ci,status,is_confirmed,sourcetype,create_user,create_date,modify_user,modify_date) select grid_code,station_code,station_name,cgi,bs_code,bs_name,bs_full_name,city_name,county_name,latitude,longitude,bundary_coordinates,cover_type,net_type,loc_code,cell_code,cell_name,cell_ci,status,is_confirmed,sourcetype,'system',sysdate(),'system',sysdate() from t_temp_biz_sector on duplicate key update grid_code = values(grid_code), station_code = values(station_code), station_name = values(station_name), bs_code = values(bs_code), bs_name = values(bs_name), bs_full_name = values(bs_full_name), city_name = values(city_name), county_name = values(county_name), latitude = values(latitude), longitude = values(longitude), bundary_coordinates = values(bundary_coordinates), cover_type = values(cover_type), net_type = values(net_type), loc_code = values(loc_code), cell_code = values(cell_code), cell_name = values(cell_name), cell_ci = values(cell_ci), status = values(status), is_confirmed = values(is_confirmed), sourcetype = values(sourcetype), modify_date = sysdate();  set p_status = 0;  END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_biz_sector_resource
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_biz_sector_resource`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_biz_sector_resource`(OUT `p_status` int(10))
BEGIN  insert into t_biz_sector_resource(cgi,resource_type,resource_code,create_user,create_date,modify_user,modify_date) select cgi,resource_type,resource_code,'system',sysdate(),'system',sysdate() from t_temp_biz_sector_resource on duplicate key update modify_date = sysdate(); set p_status = 0; END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_biz_sector_test
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_biz_sector_test`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_biz_sector_test`(OUT `p_status` int(10))
BEGIN  declare v_i int(10) default 1;  declare v_bj int(10) default 1; declare v_j int(10); declare v_sum bigint(20); declare v_n int(10); declare v_strSql varchar(3000); select sum(1) into v_sum from t_temp_biz_sector t; set v_j = 20000; select round(v_sum/v_j) into v_n; while v_i <= v_n do set v_strSql = concat("insert into t_biz_sector_test(grid_code,station_code,station_name,cgi,bs_code,bs_name,bs_full_name,city_name,county_name,latitude,longitude,bundary_coordinates,cover_type,net_type,loc_code,cell_code,cell_name,cell_ci,status,is_confirmed,sourcetype,create_user,create_date,modify_user,modify_date) select grid_code,station_code,station_name,cgi,bs_code,bs_name,bs_full_name,city_name,county_name,latitude,longitude,bundary_coordinates,cover_type,net_type,loc_code,cell_code,cell_name,cell_ci,status,is_confirmed,sourcetype,'system',sysdate(),'system',sysdate() from t_temp_biz_sector limit ",v_bj,",",v_j," on duplicate key update grid_code = values(grid_code), station_code = values(station_code), station_name = values(station_name), bs_code = values(bs_code), bs_name = values(bs_name), bs_full_name = values(bs_full_name), city_name = values(city_name), county_name = values(county_name), latitude = values(latitude), longitude = values(longitude), bundary_coordinates = values(bundary_coordinates), cover_type = values(cover_type), net_type = values(net_type), loc_code = values(loc_code), cell_code = values(cell_code), cell_name = values(cell_name), cell_ci = values(cell_ci), status = values(status), is_confirmed = values(is_confirmed), sourcetype = values(sourcetype), modify_date = sysdate();"); set v_i = v_i + 1;  set v_bj = (v_i - 1) * v_j; set @vSql= v_strSql; PREPARE stmt FROM @vSql; EXECUTE stmt ; commit; DEALLOCATE PREPARE  stmt; end while; END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_biz_sector_users
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_biz_sector_users`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_biz_sector_users`(OUT `p_status` int(10))
BEGIN  insert into t_biz_sector_users(grid_code,cgi,bts_type,user_nums,create_user,create_date,modify_user,modify_date) select grid_code,cgi,bts_type,user_nums,'system',sysdate(),'system',sysdate() from t_temp_biz_sector_users on duplicate key update grid_code = values(grid_code), user_nums = values(user_nums), modify_date = sysdate(); set p_status = 0; END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_biz_smallfamily_phone_detail_m
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_biz_smallfamily_phone_detail_m`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_biz_smallfamily_phone_detail_m`(OUT `p_status` int(10))
BEGIN 	
	-- 家庭商机小家庭手机明细表--
	insert into t_biz_smallfamily_phone_detail_m(phone,smallfamily_code,avg_dou,avg_arpu,remark,create_user,create_date,modify_user,modify_date)
select phone,smallfamily_code,avg_dou,avg_arpu,remark,'system',sysdate(),'system',sysdate()
from t_temp_biz_smallfamily_phone_detail_m
on duplicate key update
avg_dou = values(avg_dou),
avg_arpu = values(avg_arpu),
remark = values(remark),
modify_date = sysdate();

set p_status = 0;
END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_biz_smallfamily_phone_m
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_biz_smallfamily_phone_m`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_biz_smallfamily_phone_m`(OUT `p_status` int(10))
BEGIN 	
	-- 家庭商机小家庭主号手机表--
	insert into t_biz_smallfamily_phone_m(grid_code,phone,uptown_code,uptown_name,uptown_level,phone_coordinates,bigfamily_code,smallfamily_code,bw_busi_num,value_added_num,family_busi_num,is_bw,is_diffnet_bw,is_potential_bw,is_magicbai,is_voice_rc,is_family_network,is_lovefamily_package,is_family_fixedline,is_rearview_mirror,is_vehicleowner_service,is_hemu,create_user,create_date,modify_user,modify_date)
select grid_code,phone,uptown_code,uptown_name,uptown_level,phone_coordinates,bigfamily_code,smallfamily_code,bw_busi_num,value_added_num,family_busi_num,is_bw,is_diffnet_bw,is_potential_bw,is_magicbai,is_voice_rc,is_family_network,is_lovefamily_package,is_family_fixedline,is_rearview_mirror,is_vehicleowner_service,is_hemu,'system',sysdate(),'system',sysdate()
from t_temp_biz_smallfamily_phone_m
on duplicate key update
grid_code = values(grid_code),
uptown_code = values(uptown_code),
uptown_name = values(uptown_name),
uptown_level = values(uptown_level),
phone_coordinates = values(phone_coordinates),
bigfamily_code = values(bigfamily_code),
smallfamily_code = values(smallfamily_code),
bw_busi_num = values(bw_busi_num),
value_added_num = values(value_added_num),
family_busi_num = values(family_busi_num),
is_bw = values(is_bw),
is_diffnet_bw = values(is_diffnet_bw),
is_potential_bw = values(is_potential_bw),
is_magicbai = values(is_magicbai),
is_voice_rc = values(is_voice_rc),
is_family_network = values(is_family_network),
is_lovefamily_package = values(is_lovefamily_package),
is_family_fixedline = values(is_family_fixedline),
is_rearview_mirror = values(is_rearview_mirror),
is_vehicleowner_service = values(is_vehicleowner_service),
is_hemu = values(is_hemu),
modify_date = sysdate();

set p_status = 0;
END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_biz_smallfamily_portrait_m
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_biz_smallfamily_portrait_m`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_biz_smallfamily_portrait_m`(OUT `p_status` int(10))
BEGIN 	
-- 小家庭画像表--
insert into t_biz_smallfamily_portrait_m(code,wifi_status,htv_status,ykq_status,hemu_status,create_user,create_date,modify_user,modify_date)
select code,wifi_status,htv_status,ykq_status,hemu_status,'system',sysdate(),'system',sysdate()
from t_temp_biz_smallfamily_portrait_m
on duplicate key update
wifi_status = values(wifi_status),
htv_status = values(htv_status),
ykq_status = values(ykq_status),
hemu_status = values(hemu_status),
modify_date = sysdate();

set p_status = 0; 
END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_biz_station_m
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_biz_station_m`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_biz_station_m`(OUT `p_status` int(10))
BEGIN 	delete from t_biz_station_m 	where `code` not in (select temp.`code` from t_temp_biz_station_m temp ); 	insert into t_biz_station_m(grid_code,code,name,local_cd,longitude,latitude,net_type,cover_type,town_name,town_cd,create_user,create_date,modify_user,modify_date) 	select grid_code,code,name,local_cd,longitude,latitude,net_type,cover_type,town_name,town_cd,'system',sysdate(),'system',sysdate() 	from t_temp_biz_station_m 	where `code` is not null 	on duplicate key update 	grid_code = values(grid_code), 	name = values(name), 	local_cd = values(local_cd), 	longitude = values(longitude), 	latitude = values(latitude), 	net_type = values(net_type), 	cover_type = values(cover_type), 	town_name = values(town_name), 	town_cd = values(town_cd), 	modify_date = sysdate(); 	set p_status = 0; END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_biz_template_m
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_biz_template_m`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_biz_template_m`(OUT `p_status` int(10))
BEGIN  insert into t_biz_template_m(code,name,content,remark,create_user,create_date,modify_user,modify_date) select code,name,content,remark,'system',sysdate(),'system',sysdate() from t_temp_biz_template_m on duplicate key update name = values(name), content = values(content), remark = values(remark), modify_date = sysdate();  set p_status = 0;  END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_grid_busi_uptwon_index_m
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_grid_busi_uptwon_index_m`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_grid_busi_uptwon_index_m`(OUT `p_status` int(10))
BEGIN
	-- 从临时表到正式区域小区商机指标表--
	insert into t_grid_busi_uptwon_index_m(grid_code,bw_self_num,potential_bw_num,diffnet_bw_num,magicbai_num,voice_rc_num,he_busi_num,family_network_num,share_flow_num,lovefamily_package_num,family_fixedline_num,rearview_mirror_num,vehicleowner_service_num,statistics_time,create_user,create_date,modify_user,modify_date)
select grid_code,bw_self_num,potential_bw_num,diffnet_bw_num,magicbai_num,voice_rc_num,he_busi_num,family_network_num,share_flow_num,lovefamily_package_num,family_fixedline_num,rearview_mirror_num,vehicleowner_service_num,statistics_time,'system',sysdate(),'system',sysdate()
from t_temp_grid_busi_uptwon_index_m
on duplicate key update
bw_self_num = values(bw_self_num),
potential_bw_num = values(potential_bw_num),
diffnet_bw_num = values(diffnet_bw_num),
magicbai_num = values(magicbai_num),
voice_rc_num = values(voice_rc_num),
he_busi_num = values(he_busi_num),
family_network_num = values(family_network_num),
share_flow_num = values(share_flow_num),
lovefamily_package_num = values(lovefamily_package_num),
family_fixedline_num = values(family_fixedline_num),
rearview_mirror_num = values(rearview_mirror_num),
vehicleowner_service_num = values(vehicleowner_service_num),
modify_date = sysdate();
	
	set p_status = 0; 
END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_grid_busi_uptwon_index_stat
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_grid_busi_uptwon_index_stat`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_grid_busi_uptwon_index_stat`(OUT `p_status` int(10))
BEGIN
	-- 从接口表到正式区域小区商机指标表--
	insert into t_temp_grid_busi_uptwon_index_m(grid_code,bw_self_num, -- 我网宽带
																				 potential_bw_num, -- 潜在宽带
																				 diffnet_bw_num,  -- 异网宽带
																				 share_flow_num, -- 流量共享
																			   family_fixedline_num, -- 家庭固话 
																				 magicbai_num, -- 魔百和
																				 voice_rc_num, -- 语音遥控器
																				 he_busi_num, -- 和目业务
																				 family_network_num, -- 亲情网
																				 lovefamily_package_num, -- 爱家套餐
																         rearview_mirror_num, -- 后视镜
																				 vehicleowner_service_num, -- 车主服务
																				 statistics_time)
	select t.grid_id,count(case when t.wifi_type = 1 then 1 else 0 end) bw_self_num,
				 count(case when t.wifi_type = 6 then 1 else 0 end) potential_bw_num,
				 count(case when t.wifi_type = 3 then 1 else 0 end) diffnet_bw_num,
				 count(case when t.is_liuliang = 0 then 1 else 0 end) share_flow_num,
				 count(case when t.is_guhua = 0 then 1 else 0 end) family_fixedline_num,
				 count(case when b.htv_status='推荐' then 1 else 0 end) magicbai_num,
				 count(case when b.ykq_status='推荐' then 1 else 0 end) voice_rc_num,
				 count(case when b.hemu_status='推荐' then 1 else 0 end) he_busi_num,
				 count(case when c.qqw_status='推荐' then 1 else 0 end) family_network_num,
				 count(case when c.aj_status='推荐' then 1 else 0 end) lovefamily_package_num,
				 count(case when c.mirror_status='推荐' then 1 else 0 end) rearview_mirror_num,
				 count(case when c.car_status='推荐' then 1 else 0 end) vehicleowner_service_num,
				 curdate()
	from dw_family_photo_product_ms t,dw_family_allview_user_ds b,dw_family_allview_class_ds c
	where t.product_no = b.product_no
	  and b.class = c.class
	group by t.grid_id;
	
	set p_status = 0; 
END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_grid_m
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_grid_m`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_grid_m`(OUT `p_status` int(10))
BEGIN  insert into t_grid_m(code,parent_code,all_parent_code,name,type,bundary,bundary_coordinate,level,headperson,headperson_code,headperson_tel,center_longitude,center_latitude,area,grid_status,email,relate_org,priority,short_name,is_town,remark,create_user,create_date,modify_user,modify_date) select code,parent_code,all_parent_code,name,type,bundary,bundary_coordinate,level,headperson,headperson_code,headperson_tel,center_longitude,center_latitude,area,grid_status,email,relate_org,priority,short_name,is_town,remark,'system',sysdate(),'system',sysdate() from t_temp_grid_m on duplicate key update parent_code = values(parent_code), all_parent_code = values(all_parent_code), name = values(name), type = values(type), bundary = values(bundary), bundary_coordinate = values(bundary_coordinate), level = values(level), headperson = values(headperson), headperson_code = values(headperson_code), headperson_tel = values(headperson_tel), center_longitude = values(center_longitude), center_latitude = values(center_latitude), area = values(area), grid_status = values(grid_status), email = values(email), relate_org = values(relate_org), priority = values(priority), short_name = values(short_name), is_town = values(is_town), remark = values(remark), modify_date = sysdate(); set p_status = 0;  END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_grid_resource_index_m
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_grid_resource_index_m`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_grid_resource_index_m`(OUT `p_status` int(10))
BEGIN   insert into t_grid_resource_index_m(grid_code,resource_type,statistics_time,port_avail_rate, dw_permeability,fuse_dw_rate, create_user,create_date,modify_user,modify_date) select b.grid_code,'uptown',curdate(),round(sum(ifnull(c.port_avail_rate,0))/count(b.grid_code),4) port_avail_rate, round(sum(ifnull(c.dw_permeability,0))/count(b.grid_code),4) dw_permeability,0 fuse_dw_rate, 'system',sysdate(),'system',sysdate() from t_grid_m a,t_uptown_m b left join t_uptown_resource_index_m c on b.`code` = c.uptown_code where a.`code` = b.grid_code and a.`level` = 5 group by b.grid_code union  select a.parent_code grid_code,'uptown',curdate(),round(sum(ifnull(c.port_avail_rate,0))/count(b.grid_code),4) port_avail_rate, round(sum(ifnull(c.dw_permeability,0))/count(b.grid_code),4) dw_permeability,0 fuse_dw_rate, 'system',sysdate(),'system',sysdate() from t_grid_m a,t_uptown_m b left join t_uptown_resource_index_m c on b.`code` = c.uptown_code where a.`code` = b.grid_code group by a.parent_code on duplicate key update port_avail_rate = values(port_avail_rate), dw_permeability = values(dw_permeability), fuse_dw_rate = values(fuse_dw_rate), building_num = values(building_num), enterprise_num = values(enterprise_num), marketing_self_num = values(marketing_self_num), marketing_other_num = values(marketing_other_num), modify_date = sysdate(); set p_status = 0; END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_minor_enterprise
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_minor_enterprise`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_minor_enterprise`(OUT `p_status` int(10))
BEGIN  insert into to_minor_enterprise(city_name,district_name,grid_code,minor_enterprise_code,minor_enterprise_name,minor_enterprise_address,longitude,latitude,bundary_coordinates,building_type,gadmap_type,employee_number,enterprise_info,corporation_name,corporation_phone,building_code,building_name,uptown_code,uptown_name,floor,room_no,enterpris_scope,enterpris_needs,enterpris_needs_other,statement_of_needs,phone_num_total,proportion,is_reimbursed,network_signal,know_manager,is_other_office,remark,status,is_confirmed,sourcetype,process_result,create_user,create_date,modify_user,modify_date) select city_name,district_name,grid_code,minor_enterprise_code,minor_enterprise_name,minor_enterprise_address,longitude,latitude,bundary_coordinates,building_type,gadmap_type,employee_number,enterprise_info,corporation_name,corporation_phone,building_code,building_name,uptown_code,uptown_name,floor,room_no,enterpris_scope,enterpris_needs,enterpris_needs_other,statement_of_needs,phone_num_total,proportion,is_reimbursed,network_signal,know_manager,is_other_office,remark,status,is_confirmed,sourcetype,process_result,'system',sysdate(),'system',sysdate() from to_temp_minor_enterprise on duplicate key update city_name = values(city_name), district_name = values(district_name), grid_code = values(grid_code), minor_enterprise_name = values(minor_enterprise_name), minor_enterprise_address = values(minor_enterprise_address), longitude = values(longitude), latitude = values(latitude), bundary_coordinates = values(bundary_coordinates), building_type = values(building_type), gadmap_type = values(gadmap_type), employee_number = values(employee_number), enterprise_info = values(enterprise_info), corporation_name = values(corporation_name), corporation_phone = values(corporation_phone), building_code = values(building_code), building_name = values(building_name), uptown_code = values(uptown_code), uptown_name = values(uptown_name), floor = values(floor), room_no = values(room_no), enterpris_scope = values(enterpris_scope), enterpris_needs = values(enterpris_needs), enterpris_needs_other = values(enterpris_needs_other), statement_of_needs = values(statement_of_needs), phone_num_total = values(phone_num_total), proportion = values(proportion), is_reimbursed = values(is_reimbursed), network_signal = values(network_signal), know_manager = values(know_manager), is_other_office = values(is_other_office), remark = values(remark), status = values(status), is_confirmed = values(is_confirmed), sourcetype = values(sourcetype), process_result = values(process_result), modify_date = sysdate(); update to_minor_enterprise set extend_column='{}' where extend_column is null;  set p_status = 0;  END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_minor_enterprise_chargesinfo_e
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_minor_enterprise_chargesinfo_e`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_minor_enterprise_chargesinfo_e`(OUT `p_status` int(10))
BEGIN  insert into to_minor_enterprise_chargesinfo_e(minor_enterprise_code,business_type,operator,price,quantity,due_time,create_user,create_date,modify_user,modify_date) select minor_enterprise_code,business_type,operator,price,quantity,due_time,'system',sysdate(),'system',sysdate() from to_temp_minor_enterprise_chargesinfo_e on duplicate key update quantity = values(quantity), due_time = values(due_time), modify_date = sysdate(); set p_status = 0;  END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_minor_enterprise_linkman_e
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_minor_enterprise_linkman_e`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_minor_enterprise_linkman_e`(OUT `p_status` int(10))
BEGIN  insert into to_minor_enterprise_linkman_e(minor_enterprise_code,linkman,position,linkman_tel,create_user,create_date,modify_user,modify_date) select minor_enterprise_code,linkman,position,linkman_tel,'system',sysdate(),'system',sysdate() from to_temp_minor_enterprise_linkman_e on duplicate key update linkman_tel = values(linkman_tel), modify_date = sysdate(); set p_status = 0;  END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_qrcodesite
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_qrcodesite`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_qrcodesite`(OUT `p_status` int(10))
BEGIN 	insert into to_qrcodesite(qrcodesite_code,qrcodesite_name,grid_code,classify,big_classify,small_classify,qrcodesite_longitude,qrcodesite_latitude,bundary_coordinates,qrcodesite_address,create_user,create_date,modify_user,modify_date) 	select qrcodesite_code,qrcodesite_name,grid_code,classify,big_classify,small_classify,qrcodesite_longitude,qrcodesite_latitude,GeomFromText(CONCAT('POINT(',qrcodesite_longitude,' ',qrcodesite_longitude,')')),qrcodesite_address,'system',sysdate(),'system',sysdate() 	from to_temp_qrcodesite 	on duplicate key update 	qrcodesite_name = values(qrcodesite_name), 	grid_code = values(grid_code), 	classify = values(classify), 	big_classify = values(big_classify), 	small_classify = values(small_classify), 	qrcodesite_longitude = values(qrcodesite_longitude), 	qrcodesite_latitude = values(qrcodesite_latitude), 	bundary_coordinates = values(bundary_coordinates), 	qrcodesite_address = values(qrcodesite_address); 	set p_status = 0; END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_qrcodesite_diffnets
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_qrcodesite_diffnets`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_qrcodesite_diffnets`(OUT `p_status` int(10))
BEGIN 	insert into to_qrcodesite_diffnets(qrcodesite_code,city,diffnets_channel,collect_time,collector_wnbr,collector,channel_username,channel_useraccount,channel_typename,channel_type,channel_status,bus_area,main_bus,expect_mainbus_sales,expect_cucc_expiretime,expect_ctcc_expiretime,invalid_time,remark,create_user,create_date,modify_user,modify_date) 	select qrcodesite_code,city,diffnets_channel,collect_time,collector_wnbr,collector,channel_username,channel_useraccount,channel_typename,channel_type,channel_status,bus_area,main_bus,expect_mainbus_sales,expect_cucc_expiretime,expect_ctcc_expiretime,invalid_time,remark,'system',sysdate(),'system',sysdate() 	from to_temp_qrcodesite_diffnets 	on duplicate key update 	city = values(city), 	diffnets_channel = values(diffnets_channel), 	collect_time = values(collect_time), 	collector_wnbr = values(collector_wnbr), 	collector = values(collector), 	channel_username = values(channel_username), 	channel_useraccount = values(channel_useraccount), 	channel_typename = values(channel_typename), 	channel_type = values(channel_type), 	channel_status = values(channel_status), 	bus_area = values(bus_area), 	main_bus = values(main_bus), 	expect_mainbus_sales = values(expect_mainbus_sales), 	expect_cucc_expiretime = values(expect_cucc_expiretime), 	expect_ctcc_expiretime = values(expect_ctcc_expiretime), 	invalid_time = values(invalid_time), 	remark = values(remark); 	set p_status = 0; END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_qrcodesite_self
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_qrcodesite_self`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_qrcodesite_self`(OUT `p_status` int(10))
BEGIN 	insert into to_qrcodesite_self(qrcodesite_code,linkman,linkman_tel,qrcodesite_wnbr,collector_wnbr,city,city_name,website_code,remark,create_user,create_date,modify_user,modify_date) 	select qrcodesite_code,linkman,linkman_tel,qrcodesite_wnbr,collector_wnbr,city,city_name,website_code,remark,'system',sysdate(),'system',sysdate() 	from to_temp_qrcodesite_self 	on duplicate key update 	linkman = values(linkman), 	linkman_tel = values(linkman_tel), 	qrcodesite_wnbr = values(qrcodesite_wnbr), 	collector_wnbr = values(collector_wnbr), 	city = values(city), 	city_name = values(city_name), 	website_code = values(website_code), 	remark = values(remark); 	set p_status = 0; END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_uptown_building
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_uptown_building`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `p_insert_uptown_building`(
IN in_uptown_code  varchar(50) ,
IN in_building_name varchar(50),
IN in_unit_num int(11),
IN in_floor_num int(11),
IN in_floor_household_num int(11),
IN in_opeater_user varchar(50))
BEGIN

 DECLARE uptown_building_code varchar(50) DEFAULT uuid();
 DECLARE i INT DEFAULT 1;
 DECLARE j INT DEFAULT 1;
 DECLARE z INT DEFAULT 1;
 DECLARE housecode varchar(50);
 DECLARE uptown_building_unit_code varchar(50);
 DECLARE rs INT DEFAULT 0;
 
 select count(1) into rs from t_uptown_buildings_m where uptown_code= in_uptown_code and name = CONCAT(in_building_name,'栋');
 IF rs = '0' THEN
	
	INSERT INTO `t_uptown_buildings_m`(`uptown_code`, `code`, `address`, `name`, `floor_num`, `unit_num`, `floor_household_num`, `house_num`, `sourcetype`, `status`, `extend_column`, `create_user`, `create_date`, `modify_user`, `modify_date`) VALUES (in_uptown_code, uptown_building_code, NULL, CONCAT(in_building_name,'栋'), in_floor_num, in_unit_num, in_floor_household_num, NULL, 1, '1', '{}', in_opeater_user, now(), in_opeater_user, now());


	WHILE i<=in_unit_num DO
		 set uptown_building_unit_code = uuid();
		 INSERT INTO `t_uptown_buildings_unit_m`( `uptown_code`, `uptown_buildings_code`, `code`, `name`, `address`, `floor_num`, `status`, `sourcetype`, `extend_column`, `create_user`, `create_date`, `modify_user`, `modify_date`) VALUES (in_uptown_code, uptown_building_code, uptown_building_unit_code, CONCAT(i,'单元'), NULL, 1, '1', 1, '{}',  in_opeater_user, now(), in_opeater_user, now());
		 SET j=1;
			 WHILE j<=in_floor_num DO
					 SET z=1;
						 WHILE z<=in_floor_household_num DO
							
							SET housecode = CONCAT((j*100+z),'');
							INSERT INTO `t_uptown_household_m`(`uptown_code`, `uptown_buildings_code`, `uptown_buildings_unit_code`, `in_floor_num`, `code`, `name`, `address`, `family_num`, `tel_number`, `remark`, `status`, `extend_column`, `create_user`, `create_date`, `modify_user`, `modify_date`) VALUES (in_uptown_code, uptown_building_code, uptown_building_unit_code, j,housecode,housecode,NULL, NULL, NULL, NULL, '1', '{}',  in_opeater_user, now(), in_opeater_user, now());	
						 SET z = z+1;
						 END WHILE;	 
					SET j = j+1;		 
			 END WHILE;
		 SET i = i+1;

	END WHILE;
	
	select 1 as result_code,rs from dual;
ELSE
	 select 0 as result_code,rs from dual;
END IF;


  
END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_uptown_building_unit
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_uptown_building_unit`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_uptown_building_unit`(
    IN in_uptown_code varchar(50),
    IN in_building_code varchar(50),
    IN in_unit_name varchar(50),
    IN in_opeater_user varchar(50))
BEGIN
    /*
        TODO 楼栋: 新增楼栋单元; param: uptown_code,uptown_buildings_code, name;  test: '1601956932', '45d4de84-60e4-11ea-9720-0242ac110002'
        1) Check parameter, can not be null
        2) Get floor_num and household_num by building_code
        3) Create Unit and HouseHold
        4) Update unit=unit+1 of Building 
     */
    DECLARE m_floor_num int(11);
    DECLARE m_floor_household_num int(11);
    DECLARE uptown_building_unit_code varchar(50) DEFAULT uuid();
    DECLARE house_code varchar(50);
        
    DECLARE unitCount INT DEFAULT 0;
    DECLARE buildingCount INT DEFAULT 0;
    DECLARE i INT DEFAULT 1;
    DECLARE j INT DEFAULT 1;
    
    select count(1) into unitCount from t_uptown_buildings_unit_m where uptown_code = in_uptown_code and uptown_buildings_code=in_building_code and name=in_unit_name;
    select count(1) into buildingCount from t_uptown_buildings_m where uptown_code=in_uptown_code and code=in_building_code;
    
    IF unitCount > 0 or buildingCount < 1 THEN
        select 0 as result_code from dual;
    ELSE
        select floor_num into m_floor_num FROM t_uptown_buildings_m where uptown_code=in_uptown_code and code=in_building_code;
		select floor_household_num into m_floor_household_num FROM t_uptown_buildings_m where uptown_code=in_uptown_code and code=in_building_code;    
        -- 1) Add Unit
        INSERT INTO t_uptown_buildings_unit_m( uptown_code, uptown_buildings_code, `code`, `name`, `floor_num`, `status`, `sourcetype`, `extend_column`, `create_user`, `create_date`, `modify_user`, `modify_date`) 
            VALUES (in_uptown_code, in_building_code, uptown_building_unit_code, in_unit_name, m_floor_num, '1', 1, '{}',  in_opeater_user, now(), in_opeater_user, now() );
        -- 2) Add HouseHold
        WHILE i<=m_floor_num DO
            SET j=1;
            WHILE j<=m_floor_household_num DO
                SET house_code = CONCAT((i*100+j), '');
                INSERT INTO t_uptown_household_m(uptown_code, uptown_buildings_code, uptown_buildings_unit_code, in_floor_num, `code`, `name`, `status`, `extend_column`, `create_user`, `create_date`, `modify_user`, `modify_date`) 
                    VALUES (in_uptown_code, in_building_code, uptown_building_unit_code, i,house_code,house_code, '1', '{}',  in_opeater_user, now(), in_opeater_user, now());
                SET j = j+1;
            END WHILE;
            SET i = i+1;
        END WHILE;
				
        -- 3) Increase Building unit number
        update t_uptown_buildings_m set `unit_num`=(unit_num+1) where `uptown_code`=in_uptown_code and `code`=in_building_code;            
        select 1 as result_code from dual;
    END IF;
END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_uptown_buildings_index_m
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_uptown_buildings_index_m`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_uptown_buildings_index_m`(OUT `p_status` int(10))
BEGIN  insert into t_uptown_buildings_index_m(uptown_code,uptown_buildings_code,building_prot_rate,building_diffnet_rate,statistics_time,create_user,create_date,modify_user,modify_date) select uptown_code,uptown_buildings_code,building_prot_rate,building_diffnet_rate,statistics_time,'system',sysdate(),'system',sysdate() from t_temp_uptown_buildings_index_m on duplicate key update building_prot_rate = values(building_prot_rate), building_diffnet_rate = values(building_diffnet_rate), modify_date = sysdate(); insert into t_uptown_buildings_index_m(uptown_code,uptown_buildings_code,statistics_time,  create_user,create_date,modify_user,modify_date) select t.`uptown_code`,t.`code`,t.modify_date,t.create_user,t.create_date,t.modify_user,t.modify_date from t_uptown_buildings_m t  where not exists(select `code` from t_uptown_buildings_index_m tu where tu.uptown_code = t.uptown_code and tu.uptown_buildings_code = t.`code`); set p_status = 0; END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_uptown_buildings_m
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_uptown_buildings_m`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_uptown_buildings_m`(OUT `p_status` int(10))
BEGIN  insert into t_uptown_buildings_m(uptown_code,code,name,address,floor_num,unit_num,floor_household_num,house_num,sourcetype,status,create_user,create_date,modify_user,modify_date) select uptown_code,code,name,address,floor_num,unit_num,floor_household_num,house_num,sourcetype,status,'system',sysdate(),'system',sysdate() from t_temp_uptown_buildings_m on duplicate key update name = values(name), address = values(address), floor_num = values(floor_num), unit_num = values(unit_num), floor_household_num = values(floor_household_num), house_num = values(house_num), sourcetype = values(sourcetype), status = values(status), modify_date = sysdate(); set p_status = 0; END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_uptown_buildings_unit_index_m
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_uptown_buildings_unit_index_m`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_uptown_buildings_unit_index_m`(OUT `p_status` int(10))
BEGIN  insert into t_uptown_buildings_unit_index_m(uptown_code,uptown_buildings_code,uptown_buildings_unit_code,unit_diffnet_rate,unit_port_rate,statistics_time,create_user,create_date,modify_user,modify_date) select uptown_code,uptown_buildings_code,uptown_buildings_unit_code,unit_diffnet_rate,unit_port_rate,statistics_time,'system',sysdate(),'system',sysdate() from t_temp_uptown_buildings_unit_index_m on duplicate key update unit_diffnet_rate = values(unit_diffnet_rate), unit_port_rate = values(unit_port_rate), modify_date = sysdate(); insert into t_uptown_buildings_unit_index_m(uptown_code,uptown_buildings_code,uptown_buildings_unit_code,statistics_time, create_user,create_date,modify_user,modify_date) select t.`uptown_code`,t.uptown_buildings_code,t.`code`,t.modify_date,t.create_user,t.create_date,t.modify_user,t.modify_date from t_uptown_buildings_unit_m t  where not exists(select tu.uptown_buildings_unit_code from t_uptown_buildings_unit_index_m tu  where tu.uptown_code = t.uptown_code  and tu.uptown_buildings_code = t.uptown_buildings_code and tu.uptown_buildings_unit_code = t.`code`); set p_status = 0; END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_uptown_buildings_unit_m
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_uptown_buildings_unit_m`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_uptown_buildings_unit_m`(OUT `p_status` int(10))
BEGIN  insert into t_uptown_buildings_unit_m(uptown_code,uptown_buildings_code,code,name,address,floor_num,status,create_user,create_date,modify_user,modify_date) select uptown_code,uptown_buildings_code,code,name,address,floor_num,status,'system',sysdate(),'system',sysdate() from t_temp_uptown_buildings_unit_m on duplicate key update name = values(name), address = values(address), floor_num = values(floor_num), status = values(status), modify_date = sysdate(); set p_status = 0; END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_uptown_household_m
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_uptown_household_m`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_uptown_household_m`(OUT `p_status` int(10))
BEGIN  insert into t_uptown_household_m(uptown_code,uptown_buildings_code,uptown_buildings_unit_code,in_floor_num,code,name,address,family_num,tel_number,remark,status,create_user,create_date,modify_user,modify_date) select uptown_code,uptown_buildings_code,uptown_buildings_unit_code,in_floor_num,code,name,address,family_num,tel_number,remark,status,'system',sysdate(),'system',sysdate() from t_temp_uptown_household_m on duplicate key update in_floor_num = values(in_floor_num), name = values(name), address = values(address), family_num = values(family_num), tel_number = values(tel_number), remark = values(remark), status = values(status), modify_date = sysdate(); set p_status = 0; END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_uptown_m
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_uptown_m`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_uptown_m`(OUT `p_status` int(10))
BEGIN  insert into t_uptown_m(code,name,type,grid_code,business_department,longitude,latitude,bundary_coordinates,city_name,district_name,houseprice,actual_householdcount,address,building_date,flatlevel_buildingcount,manylevel_buildingcount,hightlevel_buildingcount,building_householdcount,total_buildingcount,property_name,property_tel,fullresources_id,fullresources_name,total_port_count,free_port_count,user_count,marketing_center,one_level_address,two_level_address,three_level_address,four_level_address,five_level_address,cover_type,region_atr,address_source,net_source,is_homecustomer,relation_cmtyname,building_number,covered_building_num,uncovered_building_num,broadband_share,manager,manager_phone,is_cover,unit_num,property_linkman,sourcetype,is_cmty_store,cmty_store_name,cmty_store_type,cmty_store_position,status,is_confirmed,level,create_user,create_date,modify_user,modify_date) select code,name,type,grid_code,business_department,longitude,latitude,bundary_coordinates,city_name,district_name,houseprice,actual_householdcount,address,building_date,flatlevel_buildingcount,manylevel_buildingcount,hightlevel_buildingcount,building_householdcount,total_buildingcount,property_name,property_tel,fullresources_id,fullresources_name,total_port_count,free_port_count,user_count,marketing_center,one_level_address,two_level_address,three_level_address,four_level_address,five_level_address,cover_type,region_atr,address_source,net_source,is_homecustomer,relation_cmtyname,building_number,covered_building_num,uncovered_building_num,broadband_share,manager,manager_phone,is_cover,unit_num,property_linkman,sourcetype,is_cmty_store,cmty_store_name,cmty_store_type,cmty_store_position,status,is_confirmed,level,'system',sysdate(),'system',sysdate() from t_temp_uptown_m on duplicate key update name = values(name), type = values(type), grid_code = values(grid_code), business_department = values(business_department), longitude = values(longitude), latitude = values(latitude), bundary_coordinates = values(bundary_coordinates), city_name = values(city_name), district_name = values(district_name), houseprice = values(houseprice), actual_householdcount = values(actual_householdcount), address = values(address), building_date = values(building_date), flatlevel_buildingcount = values(flatlevel_buildingcount), manylevel_buildingcount = values(manylevel_buildingcount), hightlevel_buildingcount = values(hightlevel_buildingcount), building_householdcount = values(building_householdcount), total_buildingcount = values(total_buildingcount), property_name = values(property_name), property_tel = values(property_tel), fullresources_id = values(fullresources_id), fullresources_name = values(fullresources_name), total_port_count = values(total_port_count), free_port_count = values(free_port_count), user_count = values(user_count), marketing_center = values(marketing_center), one_level_address = values(one_level_address), two_level_address = values(two_level_address), three_level_address = values(three_level_address), four_level_address = values(four_level_address), five_level_address = values(five_level_address), cover_type = values(cover_type), region_atr = values(region_atr), address_source = values(address_source), net_source = values(net_source), is_homecustomer = values(is_homecustomer), relation_cmtyname = values(relation_cmtyname), building_number = values(building_number), covered_building_num = values(covered_building_num), uncovered_building_num = values(uncovered_building_num), broadband_share = values(broadband_share), manager = values(manager), manager_phone = values(manager_phone), is_cover = values(is_cover), unit_num = values(unit_num), property_linkman = values(property_linkman), sourcetype = values(sourcetype), is_cmty_store = values(is_cmty_store), cmty_store_name = values(cmty_store_name), cmty_store_type = values(cmty_store_type), cmty_store_position = values(cmty_store_position), status = values(status), is_confirmed = values(is_confirmed), level = values(level), modify_date = sysdate(); update t_uptown_m set extend_column='{}' where extend_column is null; set p_status = 0; END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_uptown_resource_index_m
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_uptown_resource_index_m`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_uptown_resource_index_m`(OUT `p_status` int(10))
BEGIN  insert into t_uptown_resource_index_m(uptown_code,port_avail_rate,dw_permeability,month_avg_arpu,month_avg_dou,marketing_business,mobile_bwuser_arrival,magicbai_user_arrival,magicbai_permeability,mobile_user_rate,mobile_bwnum,unicom_bwnum,telecom_bwnum,month_dw_add,month_netadd,magicbai_add,magicbai_netadd,mobile_top1_name,mobile_top1_rate,inmonth_due_usernum,bw_self_usernum,potential_bw_usernum,diffnet_bw_usernum,statistics_time,create_user,create_date,modify_user,modify_date) select uptown_code,port_avail_rate,dw_permeability,month_avg_arpu,month_avg_dou,marketing_business,mobile_bwuser_arrival,magicbai_user_arrival,magicbai_permeability,mobile_user_rate,mobile_bwnum,unicom_bwnum,telecom_bwnum,month_dw_add,month_netadd,magicbai_add,magicbai_netadd,mobile_top1_name,mobile_top1_rate,inmonth_due_usernum,bw_self_usernum,potential_bw_usernum,diffnet_bw_usernum,statistics_time,'system',sysdate(),'system',sysdate() from t_temp_uptown_resource_index_m on duplicate key update port_avail_rate = values(port_avail_rate), dw_permeability = values(dw_permeability), month_avg_arpu = values(month_avg_arpu), month_avg_dou = values(month_avg_dou), marketing_business = values(marketing_business), mobile_bwuser_arrival = values(mobile_bwuser_arrival), magicbai_user_arrival = values(magicbai_user_arrival), magicbai_permeability = values(magicbai_permeability), mobile_user_rate = values(mobile_user_rate), mobile_bwnum = values(mobile_bwnum), unicom_bwnum = values(unicom_bwnum), telecom_bwnum = values(telecom_bwnum), month_dw_add = values(month_dw_add), month_netadd = values(month_netadd), magicbai_add = values(magicbai_add), magicbai_netadd = values(magicbai_netadd), mobile_top1_name = values(mobile_top1_name), mobile_top1_rate = values(mobile_top1_rate), inmonth_due_usernum = values(inmonth_due_usernum), bw_self_usernum = values(bw_self_usernum), potential_bw_usernum = values(potential_bw_usernum), diffnet_bw_usernum = values(diffnet_bw_usernum), modify_date = sysdate(); insert into t_uptown_resource_index_m(uptown_code,statistics_time,create_user,`create_date` ,`modify_user`,`modify_date`) select t.`code`,t.modify_date,t.create_user,t.create_date,t.modify_user,t.modify_date from t_uptown_m t  where not exists(select `code` from t_uptown_resource_index_m tu where tu.uptown_code = t.`code`); set p_status = 0;  END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_uptown_resource_index_stat
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_uptown_resource_index_stat`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_uptown_resource_index_stat`(OUT `p_status` int(10))
BEGIN   insert into t_uptown_resource_index_m(uptown_code,inmonth_due_usernum,bw_self_usernum,potential_bw_usernum,diffnet_bw_usernum, statistics_time,create_user,create_date,modify_user,modify_date) select uptown_code,0,0,0,0,curdate(),'system',sysdate(),'system',sysdate() from t_uptown_household_chargesinfo_e on duplicate key update inmonth_due_usernum = 0, bw_self_usernum = 0, potential_bw_usernum = 0, diffnet_bw_usernum = 0, modify_date = sysdate(); update t_uptown_resource_index_m t  inner join (select t.uptown_code,count(1) inmonth_due_usernum,curdate() curdate from t_uptown_household_chargesinfo_e t where t.business_type = '1' and t.operator = '3' and TimeStampDiff(day,now(),t.expire_time) > 0 and TimeStampDiff(day,now(),t.expire_time) <= 30 group by t.uptown_code) a on t.uptown_code = a.uptown_code  and t.statistics_time = curdate() set t.inmonth_due_usernum = a.inmonth_due_usernum; update t_uptown_resource_index_m t  inner join (select t.uptown_code,count(1) bw_self_usernum,curdate() curdate  from t_uptown_household_chargesinfo_e t where t.business_type = '1' and t.operator = '3' group by t.uptown_code) b on t.uptown_code = b.uptown_code  and t.statistics_time = curdate() set t.bw_self_usernum = b.bw_self_usernum; update t_uptown_resource_index_m t  inner join(select t.uptown_code,count(1) diffnet_bw_usernum,curdate() curdate  from t_uptown_household_chargesinfo_e t where t.business_type = '1' and t.operator <> '3'  and t.operator is not null group by t.uptown_code) c on t.uptown_code = c.uptown_code  and t.statistics_time = curdate() set t.diffnet_bw_usernum = c.diffnet_bw_usernum; set p_status = 0; END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_uptown_user_portrait_m
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_uptown_user_portrait_m`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_uptown_user_portrait_m`(OUT `p_status` int(10))
BEGIN 	
	-- 区用户画像表
	insert into t_uptown_user_portrait_m(uptown_code,uptown_buildings_code,uptown_buildings_unit_code,uptown_household_code,main_phone,vice_phone,family_num,cy_num,ww_num,yw_num,is_yye,is_xx,is_zx,is_old,is_car,class_small,wifi_type,yudaoqi,wifi_end_date,full_address,longitude,latitude,hs_htv,mbh_reason,hs_ykq,ykq_reason,hs_guhua,guhua_reason,hs_hemu,hemu_reason,hs_duanhao,duanhao_reason,hs_liuliang,fuka_reason,call_all_num,call_class_num,call_enterprise_num,arpu,mou,zhu_mou,dou,tytc_monthfee_ld,dou_zhu,mou_zhu,fee_wifi,comm_price,rel_price,bhd_avg,mo_call_duration,video_visit_flow,statistics_time,create_user,create_date,modify_user,modify_date)
select uptown_code,uptown_buildings_code,uptown_buildings_unit_code,uptown_household_code,main_phone,vice_phone,family_num,cy_num,ww_num,yw_num,is_yye,is_xx,is_zx,is_old,is_car,class_small,wifi_type,yudaoqi,wifi_end_date,full_address,longitude,latitude,hs_htv,mbh_reason,hs_ykq,ykq_reason,hs_guhua,guhua_reason,hs_hemu,hemu_reason,hs_duanhao,duanhao_reason,hs_liuliang,fuka_reason,call_all_num,call_class_num,call_enterprise_num,arpu,mou,zhu_mou,dou,tytc_monthfee_ld,dou_zhu,mou_zhu,fee_wifi,comm_price,rel_price,bhd_avg,mo_call_duration,video_visit_flow,statistics_time,'system',sysdate(),'system',sysdate()
from t_temp_uptown_user_portrait_m
on duplicate key update
uptown_buildings_code = values(uptown_buildings_code),
uptown_buildings_unit_code = values(uptown_buildings_unit_code),
uptown_household_code = values(uptown_household_code),
main_phone = values(main_phone),
family_num = values(family_num),
cy_num = values(cy_num),
ww_num = values(ww_num),
yw_num = values(yw_num),
is_yye = values(is_yye),
is_xx = values(is_xx),
is_zx = values(is_zx),
is_old = values(is_old),
is_car = values(is_car),
class_small = values(class_small),
wifi_type = values(wifi_type),
yudaoqi = values(yudaoqi),
wifi_end_date = values(wifi_end_date),
full_address = values(full_address),
longitude = values(longitude),
latitude = values(latitude),
hs_htv = values(hs_htv),
mbh_reason = values(mbh_reason),
hs_ykq = values(hs_ykq),
ykq_reason = values(ykq_reason),
hs_guhua = values(hs_guhua),
guhua_reason = values(guhua_reason),
hs_hemu = values(hs_hemu),
hemu_reason = values(hemu_reason),
hs_duanhao = values(hs_duanhao),
duanhao_reason = values(duanhao_reason),
hs_liuliang = values(hs_liuliang),
fuka_reason = values(fuka_reason),
call_all_num = values(call_all_num),
call_class_num = values(call_class_num),
call_enterprise_num = values(call_enterprise_num),
arpu = values(arpu),
mou = values(mou),
zhu_mou = values(zhu_mou),
dou = values(dou),
tytc_monthfee_ld = values(tytc_monthfee_ld),
dou_zhu = values(dou_zhu),
mou_zhu = values(mou_zhu),
fee_wifi = values(fee_wifi),
comm_price = values(comm_price),
rel_price = values(rel_price),
bhd_avg = values(bhd_avg),
mo_call_duration = values(mo_call_duration),
video_visit_flow = values(video_visit_flow),
modify_date = sysdate();
END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_website_competition_m
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_website_competition_m`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_website_competition_m`(OUT `p_status` int(10))
BEGIN 	delete from t_temp_website_competition_m 	where website_code not in (select temp.website_code from t_temp_website_competition_m temp); 	insert into t_temp_website_competition_m(website_code,website_name,city,district,operator,address,longitude,latitude,create_user,create_date,modify_user,modify_date) 	select website_code,website_name,city,district,operator,address,longitude,latitude,'system',sysdate(),'system',sysdate() 	from t_temp_website_competition_m 	where website_code is not null 	on duplicate key update 	website_name = values(website_name), 	city = values(city), 	district = values(district), 	operator = values(operator), 	address = values(address), 	longitude = values(longitude), 	latitude = values(latitude), 	modify_date = sysdate(); 	set p_status = 0; END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_website_m
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_website_m`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_website_m`(OUT `p_status` int(10))
BEGIN  insert into t_website_m(grid_code,code,name,longitude,latitude,coordinates,type,sub_type,address,scale,headperson,headperson_tel,headperson2,headperson2_tel,channel_useraccount,channel_username,channel_usertel,channel_status_time,gent_code,operator,office_hours,agent_time,creator_name,picture_url,sourcetype,status,is_confirmed,create_user,create_date,modify_user,modify_date) select grid_code,code,name,longitude,latitude,coordinates,type,sub_type,address,scale,headperson,headperson_tel,headperson2,headperson2_tel,channel_useraccount,channel_username,channel_usertel,channel_status_time,gent_code,operator,office_hours,agent_time,creator_name,picture_url,sourcetype,status,is_confirmed,'system',sysdate(),'system',sysdate() from t_temp_website_m on duplicate key update grid_code = values(grid_code), name = values(name), longitude = values(longitude), latitude = values(latitude), coordinates = values(coordinates), type = values(type), sub_type = values(sub_type), address = values(address), scale = values(scale), headperson = values(headperson), headperson_tel = values(headperson_tel), headperson2 = values(headperson2), headperson2_tel = values(headperson2_tel), channel_useraccount = values(channel_useraccount), channel_username = values(channel_username), channel_usertel = values(channel_usertel), channel_status_time = values(channel_status_time), gent_code = values(gent_code), operator = values(operator), office_hours = values(office_hours), agent_time = values(agent_time), creator_name = values(creator_name), picture_url = values(picture_url), sourcetype = values(sourcetype), status = values(status), is_confirmed = values(is_confirmed), modify_date = sysdate(); set p_status = 0; END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_website_selfhall_e
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_website_selfhall_e`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_website_selfhall_e`(OUT `p_status` int(10))
BEGIN 	delete from t_website_selfhall_e 	where website_code not in (select temp.website_code from t_temp_website_selfhall_e temp); 	insert into t_website_selfhall_e(website_code,website_name,city,business_type,regional_type,office_hours,address,longitude,latitude,status,is_queue_machine,vip_seats_number,vip_room_number,is_self_service,seats_number,self_service_number,is_smart_home,is_covered_100bw,is_download_app,download_app_type,vi_version,signboard_height,store_width,latest_renovation_time,latest_renovation_amount,latest_renovation_capitalsource,latest_renovation_projectno,property_nature,lease_begin_time,lease_end_time,avg_rent,floor_area,practical_area,office_area,back_actual_area,leadinto_cooper,leadinto_website_code,cooper_business_type,cooper_counter_number,cooper_person_number,promise_business,promise_business_number,arrival_time,create_user,create_date,modify_user,modify_date) 	select website_code,website_name,city,business_type,regional_type,office_hours,address,longitude,latitude,status,is_queue_machine,vip_seats_number,vip_room_number,is_self_service,seats_number,self_service_number,is_smart_home,is_covered_100bw,is_download_app,download_app_type,vi_version,signboard_height,store_width,latest_renovation_time,latest_renovation_amount,latest_renovation_capitalsource,latest_renovation_projectno,property_nature,lease_begin_time,lease_end_time,avg_rent,floor_area,practical_area,office_area,back_actual_area,leadinto_cooper,leadinto_website_code,cooper_business_type,cooper_counter_number,cooper_person_number,promise_business,promise_business_number,arrival_time,'system',sysdate(),'system',sysdate() 	from t_temp_website_selfhall_e 	where website_code is not null 	on duplicate key update 	website_name = values(website_name), 	city = values(city), 	business_type = values(business_type), 	regional_type = values(regional_type), 	office_hours = values(office_hours), 	address = values(address), 	longitude = values(longitude), 	latitude = values(latitude), 	status = values(status), 	is_queue_machine = values(is_queue_machine), 	vip_seats_number = values(vip_seats_number), 	vip_room_number = values(vip_room_number), 	is_self_service = values(is_self_service), 	seats_number = values(seats_number), 	self_service_number = values(self_service_number), 	is_smart_home = values(is_smart_home), 	is_covered_100bw = values(is_covered_100bw), 	is_download_app = values(is_download_app), 	download_app_type = values(download_app_type), 	vi_version = values(vi_version), 	signboard_height = values(signboard_height), 	store_width = values(store_width), 	latest_renovation_time = values(latest_renovation_time), 	latest_renovation_amount = values(latest_renovation_amount), 	latest_renovation_capitalsource = values(latest_renovation_capitalsource), 	latest_renovation_projectno = values(latest_renovation_projectno), 	property_nature = values(property_nature), 	lease_begin_time = values(lease_begin_time), 	lease_end_time = values(lease_end_time), 	avg_rent = values(avg_rent), 	floor_area = values(floor_area), 	practical_area = values(practical_area), 	office_area = values(office_area), 	back_actual_area = values(back_actual_area), 	leadinto_cooper = values(leadinto_cooper), 	leadinto_website_code = values(leadinto_website_code), 	cooper_business_type = values(cooper_business_type), 	cooper_counter_number = values(cooper_counter_number), 	cooper_person_number = values(cooper_person_number), 	promise_business = values(promise_business), 	promise_business_number = values(promise_business_number), 	arrival_time = values(arrival_time), 	modify_date = sysdate(); 	set p_status = 0; END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_insert_website_society_e
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_insert_website_society_e`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_insert_website_society_e`(OUT `p_status` int(10))
BEGIN 	delete from t_website_society_e 	where website_code not in (select temp.website_code from t_temp_website_society_e temp); 	insert into t_website_society_e(website_code,website_name,owned_company,grid_name,channel_username,channel_usertel,longitude,latitude,address,cooper_start_time,star_level,status,chain_nature,chain_name,exclusiveness,create_user,create_date,modify_user,modify_date) 	select website_code,website_name,owned_company,grid_name,channel_username,channel_usertel,longitude,latitude,address,cooper_start_time,star_level,status,chain_nature,chain_name,exclusiveness,'system',sysdate(),'system',sysdate() 	from t_temp_website_society_e 	where website_code is not null 	on duplicate key update 	website_name = values(website_name), 	owned_company = values(owned_company), 	grid_name = values(grid_name), 	channel_username = values(channel_username), 	channel_usertel = values(channel_usertel), 	longitude = values(longitude), 	latitude = values(latitude), 	address = values(address), 	cooper_start_time = values(cooper_start_time), 	star_level = values(star_level), 	status = values(status), 	chain_nature = values(chain_nature), 	chain_name = values(chain_name), 	exclusiveness = values(exclusiveness), 	modify_date = sysdate(); 	set p_status = 0; END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_retrieve_grid_busi_uptwon_index_crumb_stat
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_retrieve_grid_busi_uptwon_index_crumb_stat`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_retrieve_grid_busi_uptwon_index_crumb_stat`(IN `p_grid_code` varchar(50))
BEGIN
	-- 按入参的区域编码统计区域小区商机指标数据--
	select b.`code` as grid_code,
			   sum(bw_self_num) bw_self_num, -- 我网宽带
				 sum(potential_bw_num) potential_bw_num, -- 潜在宽带
				 sum(diffnet_bw_num) diffnet_bw_num,  -- 异网宽带
				 sum(share_flow_num) share_flow_num, -- 流量共享
				 sum(family_fixedline_num) family_fixedline_num, -- 家庭固话 
				 sum(magicbai_num) magicbai_num, -- 魔百和
				 sum(voice_rc_num) voice_rc_num, -- 语音遥控器
				 sum(he_busi_num) he_busi_num, -- 和目业务
				 sum(family_network_num) family_network_num, -- 亲情网
				 sum(lovefamily_package_num) lovefamily_package_num, -- 爱家套餐
				 sum(rearview_mirror_num) rearview_mirror_num, -- 后视镜
				 sum(vehicleowner_service_num) vehicleowner_service_num -- 车主服务
	from t_grid_busi_uptwon_index_m t,t_grid_m b
	where b.`code` = p_grid_code 
		and find_in_set(t.grid_code,b.all_parent_code) > 0
	group by b.`code`;
	
END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_select_sector
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_select_sector`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_select_sector`(
in `p_code` VARCHAR(200),
in `p_key` VARCHAR(200)
)
BEGIN
drop temporary table if exists t_grid_temp;
create temporary table t_grid_temp as 
select t.code,t.`name`,t.all_parent_code from t_grid_m t where FIND_IN_SET(p_code,t.all_parent_code) and t.level =5;
ALTER TABLE `t_grid_temp` ADD INDEX `index_grid_temp_code` (`code`) USING BTREE ;
SELECT
b.id,
b.longitude,
b.latitude,
b.cgi,
b.station_name,
AsText(b.bundary_coordinates) bundary, 
g.all_parent_code as all_parent_code,
case b.`status` WHEN 0 THEN '无效' WHEN 1 THEN '生效' WHEN 2 THEN '已删除' WHEN 3 THEN '待审批' WHEN 4 THEN '离网' WHEN 5 THEN '潜在' WHEN 6 THEN '集团预销户' else b.`status` END as `status`,
b.grid_code,
g.`name` as grid_name,
b.cell_code,
b.cell_name,
b.is_confirmed
FROM
t_biz_sector b,
t_grid_temp g 
WHERE b.grid_code = g.`code`
and b.`status` in('0','1','3') 
and ( b.station_name like CONCAT('%',p_key,'%') or b.cgi like CONCAT('%',p_key,'%'))
order by b.is_confirmed asc;
END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_statistics_blind_weakness_uptown_shandong
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_statistics_blind_weakness_uptown_shandong`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_statistics_blind_weakness_uptown_shandong`()
BEGIN
   DECLARE level_t INT(11) DEFAULT 4;

DELETE from t_grid_statistics where `key` in ('blind_uptown','weakness_uptown','all_blind_uptown','all_weakness_uptown') and `type` in ('all_blind_weakness_uptown','blind_weakness_uptown') ;

-- 盲点小区
DELETE from `t_grid_statistics` where `key` = 'blind_uptown' or `key` = 'weakness_uptown';
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'blind_weakness_uptown',
		'blind_uptown',
		IFNULL(count(1),0),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g inner JOIN t_uptown_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
  AND e.`status` = 1 
	AND e.grid_code is NOT NULL
	and e.extend_type = 0
	GROUP BY e.grid_code
);
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'blind_weakness_uptown',
		'weakness_uptown',
		IFNULL(count(1),0),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g inner JOIN t_uptown_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
  AND e.`status` = 1 
	AND e.grid_code is NOT NULL
	and e.extend_type = 1
	GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'blind_weakness_uptown',
		'blind_uptown',
	 sum(e.`value`),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'blind_uptown' and g.grid_status = '1'
	GROUP BY g.parent_code
);

INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'blind_weakness_uptown',
		'weakness_uptown',
	 sum(e.`value`),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'weakness_uptown' and g.grid_status = '1'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;
-- all
DELETE from `t_grid_statistics` where `key` = 'all_blind_uptown' or `key` = 'all_weakness_uptown';
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'all_blind_weakness_uptown',
		'all_blind_uptown',
		IFNULL(count(1),0),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g inner JOIN t_uptown_blind_weakness_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	AND e.grid_code is NOT NULL
	and e.type = 0
	GROUP BY e.grid_code
);
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'all_blind_weakness_uptown',
		'all_weakness_uptown',
		IFNULL(count(1),0),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g inner JOIN t_uptown_blind_weakness_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	AND e.grid_code is NOT NULL
	and e.type = 1
	GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'all_blind_weakness_uptown',
		'all_blind_uptown',
	 sum(e.`value`),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'all_blind_uptown' and g.grid_status = '1'
	GROUP BY g.parent_code
);

INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'all_blind_weakness_uptown',
		'all_weakness_uptown',
	 sum(e.`value`),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'all_weakness_uptown' and g.grid_status = '1'
	GROUP BY g.parent_code
);
SET level_t = level_t - 1;
end while;

-- 插入配置表
DELETE FROM `t_grid_statistics_displayconfig` WHERE `group` in ('all_blind_weakness_uptown','blind_weakness_uptown')  
and `grid_statistics_key` in ('blind_uptown','weakness_uptown','all_blind_uptown','all_weakness_uptown');

INSERT INTO `t_grid_statistics_displayconfig` ( `grid_statistics_key`, `type`, `name`, `seq`, `group`, `create_user`, `create_date`, `modify_user`, `modify_date`) 
values
('blind_uptown','blind_weakness_uptown','盲点小区',1,'blind_weakness_uptown','system',NOW(),'system',NOW()),
('weakness_uptown','blind_weakness_uptown','弱点小区',2,'blind_weakness_uptown','system',NOW(),'system',NOW()),
('all_blind_uptown','all_blind_weakness_uptown','总盲点小区',1,'blind_weakness_uptown','system',NOW(),'system',NOW()),
('all_weakness_uptown','all_blind_weakness_uptown','总弱点小区',2,'blind_weakness_uptown','system',NOW(),'system',NOW());


END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_statistics_grid_shandong
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_statistics_grid_shandong`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_statistics_grid_shandong`()
BEGIN
   DECLARE level_t INT(11) DEFAULT 4;

DELETE from `t_grid_statistics` where `key` in ('website_count','entity_website_count','direct_shop_website_count','franchised_store_website_count',
'mobile_store_website_count','authorized_store_website_count','direct_selling_website_count','self_marketing_website_count',
'social_direct_selling_website_count','othernet_website_count','unicom_website_count','telecom_website_count','uptown_homecustomer_count',
'building_count','minor_enterprise_hotel','biz_enterprise','biz_enterprise_formal_count','biz_enterprise_potential_count','biz_enterprise_level_A',
'biz_enterprise_level_B','biz_enterprise_level_C','biz_enterprise_level_D') and `type` = 'pointcount';

-- '渠道'
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'website_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	-- and e.type in ('1','2','5') AND e.sub_type in ('1','2','3','4','5','6','7','8') AND e.`status` = '1' 
	and ( (e.type='1' AND e.sub_type in ('1','2','3','4')) OR (e.type='2' AND e.sub_type in ('5','6')) OR (e.type='5' AND e.sub_type in ('7','8')))
  AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'website_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'website_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;
   

-- '实体渠道'
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'entity_website_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '1' AND e.sub_type in ('1','2','3','4') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'entity_website_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'entity_website_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;
   


-- '直营店'
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'direct_shop_website_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '1' AND e.sub_type in ('1') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'direct_shop_website_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'direct_shop_website_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;


-- '加盟店'
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'franchised_store_website_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '1' AND e.sub_type in ('2') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'franchised_store_website_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'franchised_store_website_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;



-- '手机卖场'
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'mobile_store_website_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '1' AND e.sub_type in ('3') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'mobile_store_website_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'mobile_store_website_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;



-- '授权店'
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'authorized_store_website_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '1' AND e.sub_type in ('4') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'authorized_store_website_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'authorized_store_website_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;


-- '直销渠道数量'
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'direct_selling_website_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '2' AND e.sub_type in ('5','6') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'direct_selling_website_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'direct_selling_website_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;


-- '自营直销渠道'
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'self_marketing_website_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '2' AND e.sub_type in ('5') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'self_marketing_website_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'self_marketing_website_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;


-- 社会直销渠道
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'social_direct_selling_website_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '2' AND e.sub_type in ('6') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'social_direct_selling_website_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'social_direct_selling_website_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;


-- 友商渠道
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'othernet_website_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '5' AND e.sub_type in ('7','8') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'othernet_website_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'othernet_website_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;

-- 联通
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'unicom_website_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '5' AND e.sub_type in ('7') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'unicom_website_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'unicom_website_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;

-- 电信
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'telecom_website_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '5' AND e.sub_type in ('8') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'telecom_website_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'telecom_website_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;


-- 家宽小区
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'uptown_homecustomer_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_uptown_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'uptown_homecustomer_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'uptown_homecustomer_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;


-- 楼宇数量
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'building_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_biz_building_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'building_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'building_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;



-- 中小企业（潜在集团客户）
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'minor_enterprise_hotel',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN to_minor_enterprise e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and (e.is_confirmed = '0' or (e.process_result = '0' or e.is_confirmed = '1' or e.is_confirmed = '2' or e.is_confirmed = '5')) AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'minor_enterprise_hotel',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'minor_enterprise_hotel' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;



-- 集团客户
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'biz_enterprise',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_biz_enterprise_m e ON g.`code` = e.grid_code and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	WHERE g.`level` = 5 and g.grid_status = 1
  AND e.`status` in ('1','5') 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'biz_enterprise',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	WHERE e.`level` = (level_t+1) and e.`key` = 'biz_enterprise' and g.grid_status = '1'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;


-- 集团客户(正式)
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'biz_enterprise_formal_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_biz_enterprise_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
  AND e.`status` = '1'
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'biz_enterprise_formal_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'biz_enterprise_formal_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;


-- 集团客户(潜在)
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'biz_enterprise_potential_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_biz_enterprise_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
  AND e.`status` = '5'
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'biz_enterprise_potential_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'biz_enterprise_potential_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;



-- 集团客户(按级别A类)
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'biz_enterprise_level_A',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_biz_enterprise_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
  AND e.`status` = '1' and e.`level` LIKE 'A%'
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'biz_enterprise_level_A',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'biz_enterprise_level_A' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;

-- 集团客户(按级别B类)
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'biz_enterprise_level_B',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_biz_enterprise_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
  AND e.`status` = '1' and e.`level` LIKE 'B%'
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'biz_enterprise_level_B',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'biz_enterprise_level_B' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;


-- 集团客户(按级别C类)
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'biz_enterprise_level_C',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_biz_enterprise_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
  AND e.`status` = '1' and e.`level` LIKE 'C%'
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'biz_enterprise_level_C',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'biz_enterprise_level_C' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;

-- 集团客户(按级别D类)
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'biz_enterprise_level_D',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_biz_enterprise_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
  AND e.`status` = '1' and e.`level` LIKE 'D%'
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'biz_enterprise_level_D',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'biz_enterprise_level_D' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;


-- 插入配置表
DELETE FROM `t_grid_statistics_displayconfig` WHERE `group` = 'first_tab' and `grid_statistics_key` in 
('website_count',
'entity_website_count',
'direct_shop_website_count',
'franchised_store_website_count',
'mobile_store_website_count',
'authorized_store_website_count',
'direct_selling_website_count',
'self_marketing_website_count',
'social_direct_selling_website_count',
'othernet_website_count',
'unicom_website_count',
'telecom_website_count',
'uptown_homecustomer_count',
'building_count',
'minor_enterprise_hotel',
'authorized_store_website_count',
'biz_enterprise',
'biz_enterprise_formal_count',
'biz_enterprise_level_A',
'biz_enterprise_level_B',
'biz_enterprise_level_C',
'biz_enterprise_level_D',
'biz_enterprise_potential_count');

INSERT INTO `t_grid_statistics_displayconfig` ( `grid_statistics_key`, `type`, `name`, `seq`, `group`, `create_user`, `create_date`, `modify_user`, `modify_date`) 
(SELECT `key`,`type`,'渠道',1,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'实体渠道',2,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'entity_website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'直营店',3,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'direct_shop_website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'加盟店',4,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'franchised_store_website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'手机卖场',5,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'mobile_store_website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'授权店',6,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'authorized_store_website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'直销渠道',7,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'direct_selling_website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'自营直销渠道',8,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'self_marketing_website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'社会直销渠道',9,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'social_direct_selling_website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'友商渠道',10,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'othernet_website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'联通',11,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'unicom_website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'电信',12,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'telecom_website_count' GROUP BY `key`,`type` ) UNION ALL

(SELECT `key`,`type`,'家宽小区',13,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'uptown_homecustomer_count' GROUP BY `key`,`type` ) UNION ALL

(SELECT `key`,`type`,'楼宇',14,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'building_count' GROUP BY `key`,`type` ) UNION ALL

(SELECT `key`,`type`,'潜在集团客户',15,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'minor_enterprise_hotel' GROUP BY `key`,`type` ) UNION ALL

(SELECT `key`,`type`,'集团客户',16,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'biz_enterprise' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'集团客户(正式)',17,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'biz_enterprise_formal_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'集团客户(A类)',18,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'biz_enterprise_level_A' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'集团客户(B类)',19,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'biz_enterprise_level_B' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'集团客户(C类)',20,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'biz_enterprise_level_C' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'集团客户(D类)',21,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'biz_enterprise_level_D' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'集团客户(潜在)',22,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'biz_enterprise_potential_count' GROUP BY `key`,`type`); 


END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_statistics_grid_shandong_copy
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_statistics_grid_shandong_copy`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_statistics_grid_shandong_copy`()
BEGIN
   DECLARE level_t INT(11) DEFAULT 4;


-- '渠道'
DELETE from `t_grid_statistics` where `key` = 'website_count';
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'website_count',
		IFNULL(count(1),0),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type in ('1','2','3') AND e.sub_type in ('1','2','3','4','5','6') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 1 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'website_count',
	 sum(e.`value`),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'website_count' and g.grid_status = '1'
	GROUP BY g.parent_code
);
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		level_t,
		'website_count',
	 0,
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g
	WHERE g.level=level_t and g.grid_status = '1' and g.`code` not in (SELECT grid_code FROM t_grid_statistics e where e.`level` = level_t and e.`key` = 'website_count' )
);
				SET level_t = level_t - 1;
end while;
   

-- '实体渠道'
DELETE from `t_grid_statistics` where `key` = 'entity_website_count';
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'entity_website_count',
		IFNULL(count(1),0),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '1' AND e.sub_type in ('1','2','3','4') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 1 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'entity_website_count',
	 sum(e.`value`),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'entity_website_count' and g.grid_status = '1'
	GROUP BY g.parent_code
);
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		level_t,
		'entity_website_count',
	 0,
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g
	WHERE g.level=level_t and g.grid_status = '1' and g.`code` not in (SELECT grid_code FROM t_grid_statistics e where e.`level` = level_t and e.`key` = 'entity_website_count' )
);
				SET level_t = level_t - 1;
end while;
   


-- '直营店'
DELETE from `t_grid_statistics` where `key` = 'direct_shop_website_count';
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'direct_shop_website_count',
		IFNULL(count(1),0),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '1' AND e.sub_type in ('1') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 1 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'direct_shop_website_count',
	 sum(e.`value`),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'direct_shop_website_count' and g.grid_status = '1'
	GROUP BY g.parent_code
);
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		level_t,
		'direct_shop_website_count',
	 0,
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g
	WHERE g.level=level_t and g.grid_status = '1' and g.`code` not in (SELECT grid_code FROM t_grid_statistics e where e.`level` = level_t and e.`key` = 'direct_shop_website_count' )
);
				SET level_t = level_t - 1;
end while;


-- '加盟店'
DELETE from `t_grid_statistics` where `key` = 'franchised_store_website_count';
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'franchised_store_website_count',
		IFNULL(count(1),0),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '1' AND e.sub_type in ('2') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 1 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'franchised_store_website_count',
	 sum(e.`value`),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'franchised_store_website_count' and g.grid_status = '1'
	GROUP BY g.parent_code
);
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		level_t,
		'franchised_store_website_count',
	 0,
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g
	WHERE g.level=level_t and g.grid_status = '1' and g.`code` not in (SELECT grid_code FROM t_grid_statistics e where e.`level` = level_t and e.`key` = 'franchised_store_website_count' )
);
				SET level_t = level_t - 1;
end while;



-- '手机卖场'
DELETE from `t_grid_statistics` where `key` = 'mobile_store_website_count';
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'mobile_store_website_count',
		IFNULL(count(1),0),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '1' AND e.sub_type in ('3') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 1 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'mobile_store_website_count',
	 sum(e.`value`),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'mobile_store_website_count' and g.grid_status = '1'
	GROUP BY g.parent_code
);
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		level_t,
		'mobile_store_website_count',
	 0,
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g
	WHERE g.level=level_t and g.grid_status = '1' and g.`code` not in (SELECT grid_code FROM t_grid_statistics e where e.`level` = level_t and e.`key` = 'mobile_store_website_count' )
);
				SET level_t = level_t - 1;
end while;



-- '授权店'
DELETE from `t_grid_statistics` where `key` = 'authorized_store_website_count';
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'authorized_store_website_count',
		IFNULL(count(1),0),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '1' AND e.sub_type in ('4') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 1 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'authorized_store_website_count',
	 sum(e.`value`),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'authorized_store_website_count' and g.grid_status = '1'
	GROUP BY g.parent_code
);
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		level_t,
		'authorized_store_website_count',
	 0,
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g
	WHERE g.level=level_t and g.grid_status = '1' and g.`code` not in (SELECT grid_code FROM t_grid_statistics e where e.`level` = level_t and e.`key` = 'authorized_store_website_count' )
);
				SET level_t = level_t - 1;
end while;


-- '直销渠道数量'
DELETE from `t_grid_statistics` where `key` = 'direct_selling_website_count';
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'direct_selling_website_count',
		IFNULL(count(1),0),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '2' AND e.sub_type in ('5','6') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 1 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'direct_selling_website_count',
	 sum(e.`value`),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'direct_selling_website_count' and g.grid_status = '1'
	GROUP BY g.parent_code
);
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		level_t,
		'direct_selling_website_count',
	 0,
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g
	WHERE g.level=level_t and g.grid_status = '1' and g.`code` not in (SELECT grid_code FROM t_grid_statistics e where e.`level` = level_t and e.`key` = 'direct_selling_website_count' )
);
				SET level_t = level_t - 1;
end while;


-- '自营直销渠道'
DELETE from `t_grid_statistics` where `key` = 'self_marketing_website_count';
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'self_marketing_website_count',
		IFNULL(count(1),0),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '1' AND e.sub_type in ('5') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 1 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'self_marketing_website_count',
	 sum(e.`value`),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'self_marketing_website_count' and g.grid_status = '1'
	GROUP BY g.parent_code
);
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		level_t,
		'self_marketing_website_count',
	 0,
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g
	WHERE g.level=level_t and g.grid_status = '1' and g.`code` not in (SELECT grid_code FROM t_grid_statistics e where e.`level` = level_t and e.`key` = 'self_marketing_website_count' )
);
				SET level_t = level_t - 1;
end while;


-- 社会直销渠道
DELETE from `t_grid_statistics` where `key` = 'social_direct_selling_website_count';
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'social_direct_selling_website_count',
		IFNULL(count(1),0),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '1' AND e.sub_type in ('6') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 1 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'social_direct_selling_website_count',
	 sum(e.`value`),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'social_direct_selling_website_count' and g.grid_status = '1'
	GROUP BY g.parent_code
);
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		level_t,
		'social_direct_selling_website_count',
	 0,
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g
	WHERE g.level=level_t and g.grid_status = '1' and g.`code` not in (SELECT grid_code FROM t_grid_statistics e where e.`level` = level_t and e.`key` = 'social_direct_selling_website_count' )
);
				SET level_t = level_t - 1;
end while;


-- 友商渠道
 DELETE from `t_grid_statistics` where `key` = 'othernet_website_count';
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'othernet_website_count',
		IFNULL(count(1),0),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '5' AND e.sub_type in ('7','8') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 1 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'othernet_website_count',
	 sum(e.`value`),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'othernet_website_count' and g.grid_status = '1'
	GROUP BY g.parent_code
);
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		level_t,
		'othernet_website_count',
	 0,
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g
	WHERE g.level=level_t and g.grid_status = '1' and g.`code` not in (SELECT grid_code FROM t_grid_statistics e where e.`level` = level_t and e.`key` = 'othernet_website_count' )
);
				SET level_t = level_t - 1;
end while;

-- 联通
DELETE from `t_grid_statistics` where `key` = 'unicom_website_count';
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'unicom_website_count',
		IFNULL(count(1),0),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '5' AND e.sub_type in ('7') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 1 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'unicom_website_count',
	 sum(e.`value`),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'unicom_website_count' and g.grid_status = '1'
	GROUP BY g.parent_code
);
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		level_t,
		'unicom_website_count',
	 0,
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g
	WHERE g.level=level_t and g.grid_status = '1' and g.`code` not in (SELECT grid_code FROM t_grid_statistics e where e.`level` = level_t and e.`key` = 'unicom_website_count' )
);
				SET level_t = level_t - 1;
end while;

-- 电信
DELETE from `t_grid_statistics` where `key` = 'telecom_website_count';
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'telecom_website_count',
		IFNULL(count(1),0),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '5' AND e.sub_type in ('8') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 1 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'telecom_website_count',
	 sum(e.`value`),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'telecom_website_count' and g.grid_status = '1'
	GROUP BY g.parent_code
);
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		level_t,
		'telecom_website_count',
	 0,
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g
	WHERE g.level=level_t and g.grid_status = '1' and g.`code` not in (SELECT grid_code FROM t_grid_statistics e where e.`level` = level_t and e.`key` = 'telecom_website_count' )
);
				SET level_t = level_t - 1;
end while;


-- 家宽小区
DELETE from `t_grid_statistics` where `key` = 'uptown_homecustomer_count';
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'uptown_homecustomer_count',
		IFNULL(count(1),0),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_uptown_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 1 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'uptown_homecustomer_count',
	 sum(e.`value`),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'uptown_homecustomer_count' and g.grid_status = '1'
	GROUP BY g.parent_code
);
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		level_t,
		'uptown_homecustomer_count',
	 0,
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g
	WHERE g.level=level_t and g.grid_status = '1' and g.`code` not in (SELECT grid_code FROM t_grid_statistics e where e.`level` = level_t and e.`key` = 'uptown_homecustomer_count' )
);
				SET level_t = level_t - 1;
end while;


-- 楼宇数量
DELETE from `t_grid_statistics` where `key` = 'building_count';
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'building_count',
		IFNULL(count(1),0),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_biz_building_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 1 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'building_count',
	 sum(e.`value`),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'building_count' and g.grid_status = '1'
	GROUP BY g.parent_code
);
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		level_t,
		'building_count',
	 0,
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g
	WHERE g.level=level_t and g.grid_status = '1' and g.`code` not in (SELECT grid_code FROM t_grid_statistics e where e.`level` = level_t and e.`key` = 'building_count' )
);
				SET level_t = level_t - 1;
end while;



-- 中小企业（潜在集团客户）
DELETE from `t_grid_statistics` where `key` = 'minor_enterprise_hotel';
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'minor_enterprise_hotel',
		IFNULL(count(1),0),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN to_minor_enterprise e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and (e.is_confirmed = 0 or (e.process_result = 0 or e.is_confirmed = 1 or e.is_confirmed = 2 or e.is_confirmed = 5)) AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 1 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'minor_enterprise_hotel',
	 sum(e.`value`),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'minor_enterprise_hotel' and g.grid_status = '1'
	GROUP BY g.parent_code
);
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		level_t,
		'minor_enterprise_hotel',
	 0,
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g
	WHERE g.level=level_t and g.grid_status = '1' and g.`code` not in (SELECT grid_code FROM t_grid_statistics e where e.`level` = level_t and e.`key` = 'minor_enterprise_hotel' )
);
				SET level_t = level_t - 1;
end while;



-- 集团客户
DELETE from `t_grid_statistics` where `key` = 'biz_enterprise';
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'biz_enterprise',
		IFNULL(count(1),0),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_biz_enterprise_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
  AND e.`status` in ('1','1','5') 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'biz_enterprise',
	 sum(e.`value`),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'biz_enterprise' and g.grid_status = '1'
	GROUP BY g.parent_code
);
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		level_t,
		'biz_enterprise',
	 0,
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g
	WHERE g.level=level_t and g.grid_status = '1' and g.`code` not in (SELECT grid_code FROM t_grid_statistics e where e.`level` = level_t and e.`key` = 'biz_enterprise' )
);
				SET level_t = level_t - 1;
end while;


-- 集团客户(正式)
DELETE from `t_grid_statistics` where `key` = 'biz_enterprise_formal_count';
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'biz_enterprise_formal_count',
		IFNULL(count(1),0),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_biz_enterprise_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
  AND e.`status` = '1'
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 1 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'biz_enterprise_formal_count',
	 sum(e.`value`),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'biz_enterprise_formal_count' and g.grid_status = '1'
	GROUP BY g.parent_code
);
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		level_t,
		'biz_enterprise_formal_count',
	 0,
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g
	WHERE g.level=level_t and g.grid_status = '1' and g.`code` not in (SELECT grid_code FROM t_grid_statistics e where e.`level` = level_t and e.`key` = 'biz_enterprise_formal_count' )
);
				SET level_t = level_t - 1;
end while;


-- 集团客户(潜在)
DELETE from `t_grid_statistics` where `key` = 'biz_enterprise_potential_count';
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'biz_enterprise_potential_count',
		IFNULL(count(1),0),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_biz_enterprise_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
  AND e.`status` = '1'
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 1 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'biz_enterprise_potential_count',
	 sum(e.`value`),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'biz_enterprise_potential_count' and g.grid_status = '1'
	GROUP BY g.parent_code
);
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		level_t,
		'biz_enterprise_potential_count',
	 0,
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g
	WHERE g.level=level_t and g.grid_status = '1' and g.`code` not in (SELECT grid_code FROM t_grid_statistics e where e.`level` = level_t and e.`key` = 'biz_enterprise_potential_count' )
);
				SET level_t = level_t - 1;
end while;



-- 集团客户(按级别A类)
DELETE from `t_grid_statistics` where `key` = 'biz_enterprise_level_A';
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'biz_enterprise_level_A',
		IFNULL(count(1),0),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_biz_enterprise_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
  AND e.`status` = '1' and e.`level` LIKE 'A%'
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 1 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'biz_enterprise_level_A',
	 sum(e.`value`),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'biz_enterprise_level_A' and g.grid_status = '1'
	GROUP BY g.parent_code
);
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		level_t,
		'biz_enterprise_level_A',
	 0,
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g
	WHERE g.level=level_t and g.grid_status = '1' and g.`code` not in (SELECT grid_code FROM t_grid_statistics e where e.`level` = level_t and e.`key` = 'biz_enterprise_level_A' )
);
				SET level_t = level_t - 1;
end while;

-- 集团客户(按级别B类)
DELETE from `t_grid_statistics` where `key` = 'biz_enterprise_level_B';
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'biz_enterprise_level_B',
		IFNULL(count(1),0),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_biz_enterprise_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
  AND e.`status` = '1' and e.`level` LIKE 'B%'
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 1 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'biz_enterprise_level_B',
	 sum(e.`value`),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'biz_enterprise_level_B' and g.grid_status = '1'
	GROUP BY g.parent_code
);
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		level_t,
		'biz_enterprise_level_B',
	 0,
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g
	WHERE g.level=level_t and g.grid_status = '1' and g.`code` not in (SELECT grid_code FROM t_grid_statistics e where e.`level` = level_t and e.`key` = 'biz_enterprise_level_B' )
);
				SET level_t = level_t - 1;
end while;


-- 集团客户(按级别C类)
DELETE from `t_grid_statistics` where `key` = 'biz_enterprise_level_C';
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'biz_enterprise_level_C',
		IFNULL(count(1),0),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_biz_enterprise_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
  AND e.`status` = '1' and e.`level` LIKE 'C%'
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 1 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'biz_enterprise_level_C',
	 sum(e.`value`),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'biz_enterprise_level_C' and g.grid_status = '1'
	GROUP BY g.parent_code
);
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		level_t,
		'biz_enterprise_level_C',
	 0,
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g
	WHERE g.level=level_t and g.grid_status = '1' and g.`code` not in (SELECT grid_code FROM t_grid_statistics e where e.`level` = level_t and e.`key` = 'biz_enterprise_level_C' )
);
				SET level_t = level_t - 1;
end while;

-- 集团客户(按级别D类)
DELETE from `t_grid_statistics` where `key` = 'biz_enterprise_level_D';
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'biz_enterprise_level_D',
		IFNULL(count(1),0),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_biz_enterprise_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
  AND e.`status` = '1' and e.`level` LIKE 'D%'
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 1 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'biz_enterprise_level_D',
	 sum(e.`value`),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'biz_enterprise_level_D' and g.grid_status = '1'
	GROUP BY g.parent_code
);
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		level_t,
		'biz_enterprise_level_D',
	 0,
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g
	WHERE g.level=level_t and g.grid_status = '1' and g.`code` not in (SELECT grid_code FROM t_grid_statistics e where e.`level` = level_t and e.`key` = 'biz_enterprise_level_D' )
);
				SET level_t = level_t - 1;
end while;



-- 插入配置表
DELETE FROM `t_grid_statistics_displayconfig` WHERE `group` = 'first_tab' and `grid_statistics_key` in 
('website_count',
'entity_website_count',
'direct_shop_website_count',
'franchised_store_website_count',
'mobile_store_website_count',
'authorized_store_website_count',
'direct_selling_website_count',
'self_marketing_website_count',
'social_direct_selling_website_count',
'othernet_website_count',
'unicom_website_count',
'telecom_website_count',
'uptown_homecustomer_count',
'building_count',
'minor_enterprise_hotel',
'authorized_store_website_count',
'biz_enterprise',
'biz_enterprise_formal_count',
'biz_enterprise_level_A',
'biz_enterprise_level_B',
'biz_enterprise_level_C',
'biz_enterprise_level_D',
'biz_enterprise_potential_count');

INSERT INTO `t_grid_statistics_displayconfig` ( `grid_code`, `grid_statistics_key`, `type`, `name`, `seq`, `group`, `create_user`, `create_date`, `modify_user`, `modify_date`) 
(SELECT grid_code,`key`,`key`,'渠道',1,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'website_count' GROUP BY grid_code,`key` ) UNION ALL
(SELECT grid_code,`key`,`key`,'实体渠道',2,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'entity_website_count' GROUP BY grid_code,`key` ) UNION ALL
(SELECT grid_code,`key`,`key`,'直营店',3,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'direct_shop_website_count' GROUP BY grid_code,`key` ) UNION ALL
(SELECT grid_code,`key`,`key`,'加盟店',4,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'franchised_store_website_count' GROUP BY grid_code,`key` ) UNION ALL
(SELECT grid_code,`key`,`key`,'手机卖场',5,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'mobile_store_website_count' GROUP BY grid_code,`key` ) UNION ALL
(SELECT grid_code,`key`,`key`,'授权店',6,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'authorized_store_website_count' GROUP BY grid_code,`key` ) UNION ALL
(SELECT grid_code,`key`,`key`,'直销渠道',7,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'direct_selling_website_count' GROUP BY grid_code,`key` ) UNION ALL
(SELECT grid_code,`key`,`key`,'自营直销渠道',8,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'self_marketing_website_count' GROUP BY grid_code,`key` ) UNION ALL
(SELECT grid_code,`key`,`key`,'社会直销渠道',9,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'social_direct_selling_website_count' GROUP BY grid_code,`key` ) UNION ALL
(SELECT grid_code,`key`,`key`,'友商渠道',10,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'othernet_website_count' GROUP BY grid_code,`key` ) UNION ALL
(SELECT grid_code,`key`,`key`,'联通',11,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'unicom_website_count' GROUP BY grid_code,`key` ) UNION ALL
(SELECT grid_code,`key`,`key`,'电信',12,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'telecom_website_count' GROUP BY grid_code,`key` ) UNION ALL

(SELECT grid_code,`key`,`key`,'家宽小区',13,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'uptown_homecustomer_count' GROUP BY grid_code,`key` ) UNION ALL

(SELECT grid_code,`key`,`key`,'楼宇',14,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'building_count' GROUP BY grid_code,`key` ) UNION ALL

(SELECT grid_code,`key`,`key`,'潜在集团客户',15,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'minor_enterprise_hotel' GROUP BY grid_code,`key` ) UNION ALL

(SELECT grid_code,`key`,`key`,'集团客户',16,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'biz_enterprise' GROUP BY grid_code,`key` ) UNION ALL
(SELECT grid_code,`key`,`key`,'集团客户(正式)',17,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'biz_enterprise_formal_count' GROUP BY grid_code,`key` ) UNION ALL
(SELECT grid_code,`key`,`key`,'集团客户(A类)',18,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'biz_enterprise_level_A' GROUP BY grid_code,`key` ) UNION ALL
(SELECT grid_code,`key`,`key`,'集团客户(B类)',19,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'biz_enterprise_level_B' GROUP BY grid_code,`key` ) UNION ALL
(SELECT grid_code,`key`,`key`,'集团客户(C类)',20,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'biz_enterprise_level_C' GROUP BY grid_code,`key` ) UNION ALL
(SELECT grid_code,`key`,`key`,'集团客户(D类)',21,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'biz_enterprise_level_D' GROUP BY grid_code,`key` ) UNION ALL
(SELECT grid_code,`key`,`key`,'集团客户(潜在)',22,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'biz_enterprise_potential_count' GROUP BY grid_code,`key`); 



END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_statistics_grid_shandong_copy()
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_statistics_grid_shandong_copy()`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_statistics_grid_shandong_copy()`()
BEGIN
   DECLARE level_t INT(11) DEFAULT 4;

DELETE from `t_grid_statistics` where `key` in ('website_count','entity_website_count','direct_shop_website_count','franchised_store_website_count',
'mobile_store_website_count','authorized_store_website_count','direct_selling_website_count','self_marketing_website_count',
'social_direct_selling_website_count','othernet_website_count','unicom_website_count','telecom_website_count','uptown_homecustomer_count',
'building_count','minor_enterprise_hotel','biz_enterprise','biz_enterprise_formal_count','biz_enterprise_potential_count','biz_enterprise_level_A',
'biz_enterprise_level_B','biz_enterprise_level_C','biz_enterprise_level_D') and `type` = 'pointcount';

-- '渠道'
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'website_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	-- and e.type in ('1','2','5') AND e.sub_type in ('1','2','3','4','5','6','7','8') AND e.`status` = '1' 
	and ( (e.type='1' AND e.sub_type in ('1','2','3','4')) OR (e.type='2' AND e.sub_type in ('5','6')) OR (e.type='5' AND e.sub_type in ('7','8')))
  AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'website_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'website_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;
   

-- '实体渠道'
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'entity_website_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '1' AND e.sub_type in ('1','2','3','4') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'entity_website_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'entity_website_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;
   


-- '直营店'
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'direct_shop_website_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '1' AND e.sub_type in ('1') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'direct_shop_website_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'direct_shop_website_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;


-- '加盟店'
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'franchised_store_website_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '1' AND e.sub_type in ('2') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'franchised_store_website_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'franchised_store_website_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;



-- '手机卖场'
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'mobile_store_website_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '1' AND e.sub_type in ('3') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'mobile_store_website_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'mobile_store_website_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;



-- '授权店'
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'authorized_store_website_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '1' AND e.sub_type in ('4') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'authorized_store_website_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'authorized_store_website_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;


-- '直销渠道数量'
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'direct_selling_website_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '2' AND e.sub_type in ('5','6') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'direct_selling_website_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'direct_selling_website_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;


-- '自营直销渠道'
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'self_marketing_website_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '2' AND e.sub_type in ('5') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'self_marketing_website_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'self_marketing_website_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;


-- 社会直销渠道
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'social_direct_selling_website_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '2' AND e.sub_type in ('6') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'social_direct_selling_website_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'social_direct_selling_website_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;


-- 友商渠道
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'othernet_website_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '5' AND e.sub_type in ('7','8') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'othernet_website_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'othernet_website_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;

-- 联通
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'unicom_website_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '5' AND e.sub_type in ('7') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'unicom_website_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'unicom_website_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;

-- 电信
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'telecom_website_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_website_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and e.type = '5' AND e.sub_type in ('8') AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'telecom_website_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'telecom_website_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;


-- 家宽小区
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'uptown_homecustomer_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_uptown_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'uptown_homecustomer_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'uptown_homecustomer_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;


-- 楼宇数量
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'building_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_biz_building_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'building_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'building_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;



-- 中小企业（潜在集团客户）
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'minor_enterprise_hotel',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN to_minor_enterprise e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	and (e.is_confirmed = '0' or (e.process_result = '0' or e.is_confirmed = '1' or e.is_confirmed = '2' or e.is_confirmed = '5')) AND e.`status` = '1' 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'minor_enterprise_hotel',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'minor_enterprise_hotel' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;



-- 集团客户
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'biz_enterprise',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_biz_enterprise_m e ON g.`code` = e.grid_code and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	WHERE g.`level` = 5 and g.grid_status = 1
  AND e.`status` in ('1','5') 
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'biz_enterprise',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	WHERE e.`level` = (level_t+1) and e.`key` = 'biz_enterprise' and g.grid_status = '1'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;


-- 集团客户(正式)
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'biz_enterprise_formal_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_biz_enterprise_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
  AND e.`status` = '1'
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'biz_enterprise_formal_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'biz_enterprise_formal_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;


-- 集团客户(潜在)
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'biz_enterprise_potential_count',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_biz_enterprise_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
  AND e.`status` = '5'
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'biz_enterprise_potential_count',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'biz_enterprise_potential_count' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;



-- 集团客户(按级别A类)
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'biz_enterprise_level_A',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_biz_enterprise_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
  AND e.`status` = '1' and e.`level` LIKE 'A%'
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'biz_enterprise_level_A',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'biz_enterprise_level_A' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;

-- 集团客户(按级别B类)
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'biz_enterprise_level_B',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_biz_enterprise_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
  AND e.`status` = '1' and e.`level` LIKE 'B%'
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'biz_enterprise_level_B',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'biz_enterprise_level_B' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;


-- 集团客户(按级别C类)
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'biz_enterprise_level_C',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_biz_enterprise_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
  AND e.`status` = '1' and e.`level` LIKE 'C%'
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'biz_enterprise_level_C',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'biz_enterprise_level_C' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;

-- 集团客户(按级别D类)
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'pointcount',
		'biz_enterprise_level_D',
		IFNULL(count(1),0),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g LEFT JOIN t_biz_enterprise_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
  AND e.`status` = '1' and e.`level` LIKE 'D%'
	AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
		GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'pointcount',
		'biz_enterprise_level_D',
	 sum(e.`value`),
	NULL,
	'2019-01-01',
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'biz_enterprise_level_D' and g.grid_status = '1' and g.bundary is not NULL and UPPER(g.bundary) != 'POINT(0 0)'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;


-- 插入配置表
DELETE FROM `t_grid_statistics_displayconfig` WHERE `group` = 'first_tab' and `grid_statistics_key` in 
('website_count',
'entity_website_count',
'direct_shop_website_count',
'franchised_store_website_count',
'mobile_store_website_count',
'authorized_store_website_count',
'direct_selling_website_count',
'self_marketing_website_count',
'social_direct_selling_website_count',
'othernet_website_count',
'unicom_website_count',
'telecom_website_count',
'uptown_homecustomer_count',
'building_count',
'minor_enterprise_hotel',
'authorized_store_website_count',
'biz_enterprise',
'biz_enterprise_formal_count',
'biz_enterprise_level_A',
'biz_enterprise_level_B',
'biz_enterprise_level_C',
'biz_enterprise_level_D',
'biz_enterprise_potential_count');

INSERT INTO `t_grid_statistics_displayconfig` ( `grid_statistics_key`, `type`, `name`, `seq`, `group`, `create_user`, `create_date`, `modify_user`, `modify_date`) 
(SELECT `key`,`type`,'渠道',1,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'实体渠道',2,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'entity_website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'直营店',3,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'direct_shop_website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'加盟店',4,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'franchised_store_website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'手机卖场',5,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'mobile_store_website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'授权店',6,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'authorized_store_website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'直销渠道',7,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'direct_selling_website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'自营直销渠道',8,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'self_marketing_website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'社会直销渠道',9,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'social_direct_selling_website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'友商渠道',10,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'othernet_website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'联通',11,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'unicom_website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'电信',12,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'telecom_website_count' GROUP BY `key`,`type` ) UNION ALL

(SELECT `key`,`type`,'家宽小区',13,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'uptown_homecustomer_count' GROUP BY `key`,`type` ) UNION ALL

(SELECT `key`,`type`,'楼宇',14,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'building_count' GROUP BY `key`,`type` ) UNION ALL

(SELECT `key`,`type`,'潜在集团客户',15,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'minor_enterprise_hotel' GROUP BY `key`,`type` ) UNION ALL

(SELECT `key`,`type`,'集团客户',16,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'biz_enterprise' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'集团客户(正式)',17,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'biz_enterprise_formal_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'集团客户(A类)',18,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'biz_enterprise_level_A' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'集团客户(B类)',19,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'biz_enterprise_level_B' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'集团客户(C类)',20,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'biz_enterprise_level_C' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'集团客户(D类)',21,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'biz_enterprise_level_D' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'集团客户(潜在)',22,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'biz_enterprise_potential_count' GROUP BY `key`,`type`); 


END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_statistics_grid_shandong_copy1
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_statistics_grid_shandong_copy1`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_statistics_grid_shandong_copy1`()
BEGIN
   DECLARE level_t INT(11) DEFAULT 4;

DELETE from t_grid_statistics_copy1 where `key` in ('blind_uptown','weakness_uptown','all_blind_uptown','all_weakness_uptown') and `type` in ('all_blind_weakness_uptown','blind_weakness_uptown') ;

-- 盲点小区
DELETE from `t_grid_statistics_copy1` where `key` = 'blind_uptown' or `key` = 'weakness_uptown';
INSERT INTO `t_grid_statistics_copy1` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'blind_weakness_uptown',
		'blind_uptown',
		IFNULL(count(1),0),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g inner JOIN t_uptown_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
  AND e.`status` = 1 
	AND e.grid_code is NOT NULL
	and e.extend_type = 0
	GROUP BY e.grid_code
);
INSERT INTO `t_grid_statistics_copy1` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'blind_weakness_uptown',
		'weakness_uptown',
		IFNULL(count(1),0),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g inner JOIN t_uptown_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
  AND e.`status` = 1 
	AND e.grid_code is NOT NULL
	and e.extend_type = 1
	GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics_copy1` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'blind_weakness_uptown',
		'blind_uptown',
	 sum(e.`value`),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics_copy1 e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'blind_uptown' and g.grid_status = '1'
	GROUP BY g.parent_code
);

INSERT INTO `t_grid_statistics_copy1` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'blind_weakness_uptown',
		'weakness_uptown',
	 sum(e.`value`),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics_copy1 e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'weakness_uptown' and g.grid_status = '1'
	GROUP BY g.parent_code
);
				SET level_t = level_t - 1;
end while;
-- all
DELETE from `t_grid_statistics_copy1` where `key` = 'all_blind_uptown' or `key` = 'all_weakness_uptown';
INSERT INTO `t_grid_statistics_copy1` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'all_blind_weakness_uptown',
		'all_blind_uptown',
		IFNULL(count(1),0),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g inner JOIN t_uptown_blind_weakness_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	AND e.grid_code is NOT NULL
	and e.type = 0
	GROUP BY e.grid_code
);
INSERT INTO `t_grid_statistics_copy1` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.`code`,
		g.`level`,
		'all_blind_weakness_uptown',
		'all_weakness_uptown',
		IFNULL(count(1),0),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g inner JOIN t_uptown_blind_weakness_m e ON g.`code` = e.grid_code
	WHERE g.`level` = 5 and g.grid_status = 1
	AND e.grid_code is NOT NULL
	and e.type = 1
	GROUP BY e.grid_code
);

SET level_t=4;
while level_t > 0 DO
INSERT INTO `t_grid_statistics_copy1` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'all_blind_weakness_uptown',
		'all_blind_uptown',
	 sum(e.`value`),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics_copy1 e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'all_blind_uptown' and g.grid_status = '1'
	GROUP BY g.parent_code
);

INSERT INTO `t_grid_statistics_copy1` (`grid_code`,`level`,`type`,`key`,`value`,`remark`,`statistics_time`,`create_user`,`create_date`,`modify_user`,`modify_date`)
(
	SELECT
		g.parent_code,
		level_t,
		'all_blind_weakness_uptown',
		'all_weakness_uptown',
	 sum(e.`value`),
	NULL,
	NOW(),
	'system',
	NOW(),
	'system',
	NOW()
FROM
	t_grid_m g  LEFT JOIN t_grid_statistics_copy1 e ON g.`code` = e.grid_code
	WHERE e.`level` = (level_t+1) and e.`key` = 'all_weakness_uptown' and g.grid_status = '1'
	GROUP BY g.parent_code
);
SET level_t = level_t - 1;
end while;

-- 插入配置表
DELETE FROM `t_grid_statistics_displayconfig_copy1` WHERE `group` = 'first_tab' and `grid_statistics_key` in 
('website_count',
'entity_website_count',
'direct_shop_website_count',
'franchised_store_website_count',
'mobile_store_website_count',
'authorized_store_website_count',
'direct_selling_website_count',
'self_marketing_website_count',
'social_direct_selling_website_count',
'othernet_website_count',
'unicom_website_count',
'telecom_website_count',
'uptown_homecustomer_count',
'building_count',
'minor_enterprise_hotel',
'authorized_store_website_count',
'biz_enterprise',
'biz_enterprise_formal_count',
'biz_enterprise_level_A',
'biz_enterprise_level_B',
'biz_enterprise_level_C',
'biz_enterprise_level_D',
'biz_enterprise_potential_count');

INSERT INTO `t_grid_statistics_displayconfig_copy1` ( `grid_statistics_key`, `type`, `name`, `seq`, `group`, `create_user`, `create_date`, `modify_user`, `modify_date`) 
(SELECT `key`,`type`,'渠道',1,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'实体渠道',2,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'entity_website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'直营店',3,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'direct_shop_website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'加盟店',4,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'franchised_store_website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'手机卖场',5,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'mobile_store_website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'授权店',6,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'authorized_store_website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'直销渠道',7,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'direct_selling_website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'自营直销渠道',8,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'self_marketing_website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'社会直销渠道',9,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'social_direct_selling_website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'友商渠道',10,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'othernet_website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'联通',11,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'unicom_website_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'电信',12,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'telecom_website_count' GROUP BY `key`,`type` ) UNION ALL

(SELECT `key`,`type`,'家宽小区',13,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'uptown_homecustomer_count' GROUP BY `key`,`type` ) UNION ALL

(SELECT `key`,`type`,'楼宇',14,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'building_count' GROUP BY `key`,`type` ) UNION ALL

(SELECT `key`,`type`,'潜在集团客户',15,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'minor_enterprise_hotel' GROUP BY `key`,`type` ) UNION ALL

(SELECT `key`,`type`,'集团客户',16,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'biz_enterprise' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'集团客户(正式)',17,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'biz_enterprise_formal_count' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'集团客户(A类)',18,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'biz_enterprise_level_A' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'集团客户(B类)',19,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'biz_enterprise_level_B' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'集团客户(C类)',20,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'biz_enterprise_level_C' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'集团客户(D类)',21,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'biz_enterprise_level_D' GROUP BY `key`,`type` ) UNION ALL
(SELECT `key`,`type`,'集团客户(潜在)',22,'first_tab','system',NOW(),'system',NOW() from t_grid_statistics where `key`  = 'biz_enterprise_potential_count' GROUP BY `key`,`type`); 


END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_statistics_impl
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_statistics_impl`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_statistics_impl`(IN tenant VARCHAR(50),OUT `p_status` int)
BEGIN
	set p_status = 1;		

  -- 按照不同的租户类型运行不同的存储过程
	case 
     when tenant = 'shandong' then
        CALL p_statistics_grid_shandong();
		 else
				set p_status = -1;	
	end case;
		
 END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_table_structure
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_table_structure`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_table_structure`(IN `p_table` varchar(50))
BEGIN
	declare v_code varchar(50);
	declare v_name varchar(300);
	declare v_type varchar(50);
	declare v_is_required varchar(50);
	declare v_is_business_key varchar(50);
	declare v_table_comment varchar(300);
	declare v_column varchar(300);
	declare v_text text default '';
	declare v_system_column varchar(300);
	-- 遍历数据结束标志
  declare done int default false;
  -- 定义游标
  declare c_table cursor for 
	
  select t.`code`,t.`name`,t.type,t.is_required,t.is_business_key,t.remark
	from t_excel t 
	where t.table = p_table;
	-- 将结束标志绑定到游标
  declare continue handler for not found set done = true;
	 -- 打开游标
  open c_table;
  -- 开始循环
	set v_text = concat('CREATE TABLE `',p_table,'` (',CHAR(13));
  read_loop: loop
    fetch c_table into v_code,v_name,v_type,v_is_required,v_is_business_key,v_table_comment;
    -- 声明结束的时候
    if done then
      leave read_loop;
    end if;
		if v_code = 'id' then 
			set v_column = concat("`id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',",CHAR(13));
		else 
			set v_column = concat('`',v_code,'` ',v_type,' ',case when v_is_required = 'YES' then ' NOT NULL COMMENT' else ' DEFAULT NULL COMMENT ' end,"'",v_name,"',",CHAR(13));
		end if;
		set v_text = concat(v_text,v_column);
	end loop;
	set v_system_column = concat("`extend_column` json DEFAULT NULL COMMENT '扩展属性JSON串',",CHAR(13),"`create_user` varchar(50) NOT NULL COMMENT '创建人',",CHAR(13),"`create_date` datetime NOT NULL COMMENT '创建时间',",CHAR(13),"`modify_user` varchar(50) NOT NULL COMMENT '修改人',",CHAR(13),"`modify_date` datetime NOT NULL COMMENT '修改时间',",CHAR(13),"PRIMARY KEY (`id`) USING BTREE",CHAR(13));
  set v_text = concat(v_text,v_system_column,") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='",v_table_comment,"';");
	insert into t_create_table(table_script) values(v_text);
END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_update_grid_parent_code
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_update_grid_parent_code`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `p_update_grid_parent_code`()
BEGIN
	declare v_id int(11);
	declare v_parent_code varchar(50);
	declare v_level int(11);
	declare v_bundary geometry;
	declare v_count int(11) default 0;
	declare v_i int(11) default 0;
	-- 遍历数据结束标志
  declare done int default false;
  -- 定义游标 
  declare c_table cursor for 
	select  t.id,t.`level`,t.bundary_coordinate
	 from t_grid_m t
	where t.`level` <> 0
		-- and t.parent_code_test is null
		;
	declare continue handler for not found set done = true;
	
	 -- 打开游标
  open c_table;
  -- 开始循环
	select  sum(1)
	into v_count
	 from t_grid_m t
	where t.`level` <> 0;
	
	
  read_loop: loop
    fetch c_table into v_id,v_level,v_bundary;
		set v_i = v_i + 1;
		
		if v_i > v_count then
			leave read_loop;
		end if;
    -- 声明结束的时候
    /*if done then
      leave read_loop;
    end if;
	  */
		select t.`code` -- ,ST_Intersects(t.bundary_coordinate, v_bundary),t.`level`,t.id -- ,t.bundary_coordinate, v_bundary,t.`level` aa,v_level,ST_Intersects(t.bundary_coordinate, v_bundary)
	  into v_parent_code
		from t_grid_m t
		-- where ST_Intersects(t.bundary_coordinate, v_bundary)
		where st_contains(t.bundary_coordinate, st_centroid(v_bundary))
			and t.`level` = v_level - 1
		order by t.`level` desc 
		limit 1;
		-- select v_parent_code;
    
		update t_grid_m t
		set t.parent_code = v_parent_code
	  where t.id = v_id;
		
		set v_parent_code = null;
/*
		update t_grid_m t,(	select t1.`code` -- ,ST_Intersects(t.bundary_coordinate, v_bundary),t.`level`,t.id -- ,t.bundary_coordinate, v_bundary,t.`level` aa,v_level,ST_Intersects(t.bundary_coordinate, v_bundary)
	  -- into v_parent_code
		from t_grid_m t1 
		where ST_Intersects(t1.bundary_coordinate, v_bundary)
			and t1.`level` = v_level - 1
		-- order by t1.`level` desc 
		limit 1) a 
		set t.parent_code_test = a.`code`
	
	  where t.id = v_id;
*/
	end loop;
END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for updateAreaParents
-- ----------------------------
DROP PROCEDURE IF EXISTS `updateAreaParents`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `updateAreaParents`()
BEGIN DECLARE tmp_pcode VARCHAR(100) DEFAULT ""; DECLARE done INT DEFAULT 0; DECLARE index_pcode CURSOR FOR SELECT code FROM t_grid_m ; DECLARE CONTINUE HANDLER for not found set done = 1; OPEN index_pcode; FETCH index_pcode INTO tmp_pcode; WHILE (done <> 1) DO 		UPDATE t_grid_m  SET all_parent_code = ( 			SELECT       pcodes 			FROM 				( 					select * from ( 						SELECT 						@p AS parentCode, 						@pcodes := CONCAT( ( SELECT @p := parent_code FROM t_grid_m WHERE code = parentCode  ), ',',  @pcodes) AS pcodes, 						@le := @le + 1 AS LEVEL  					FROM 						( SELECT @p := tmp_pcode, @le := 0, @pcodes :=tmp_pcode ) vars, 						t_grid_m h  					WHERE 						@p != ""   and @pcodes is not null) t  						where pcodes is not null 					ORDER BY 					t.LEVEL desc 						LIMIT 1  					) t 		)  WHERE  code = tmp_pcode  and all_parent_code is null; FETCH index_pcode INTO tmp_pcode; END WHILE; CLOSE index_pcode; END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for updateAreaRelation
-- ----------------------------
DROP PROCEDURE IF EXISTS `updateAreaRelation`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `updateAreaRelation`()
BEGIN update t_grid_m t set t.center_longitude=X(ST_Centroid(t.bundary_coordinate)),t.center_latitude=Y(ST_Centroid(t.bundary_coordinate));  END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for updateResourceRelation
-- ----------------------------
DROP PROCEDURE IF EXISTS `updateResourceRelation`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `updateResourceRelation`()
BEGIN update t_biz_building_m set bundary_coordinates=GeomFromText( CONCAT("Point(",longitude," ",latitude,")")) where bundary_coordinates is null; update t_biz_building_m t,(select code,bundary_coordinate from t_grid_m where level=5) a set t.grid_code = a.code  where t.grid_code is null and ST_Contains(a.bundary_coordinate,t.bundary_coordinates);  update t_website_m set coordinates=GeomFromText( CONCAT("Point(",longitude," ",latitude,")")) where coordinates is null; update t_website_m t,(select code,bundary_coordinate from t_grid_m where level=5) a set t.grid_code = a.code  where  t.type="5" and t.grid_code is null  and ST_Contains(a.bundary_coordinate,t.coordinates);  END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for updateStatisticsGridIndicators
-- ----------------------------
DROP PROCEDURE IF EXISTS `updateStatisticsGridIndicators`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `updateStatisticsGridIndicators`()
BEGIN

		-- 不需要向上汇总的key（第三步使用）
drop table if exists not_contain_of_key_list;
create temporary table not_contain_of_key_list(key_name VARCHAR(100));
INSERT INTO not_contain_of_key_list(key_name) VALUES('area');-- 面积
INSERT INTO not_contain_of_key_list(key_name) VALUES('net_grid_directorname');-- 网格总监名称
INSERT INTO not_contain_of_key_list(key_name) VALUES('sales_manager');-- 销售经理姓名

-- 清空表t_grid_statistics的数据
DELETE FROM t_grid_statistics;

	-- 一、插入微网格数据开始 

		-- 临时表，保存责任田数据，然后再批量插入 
		drop table if exists field_data;
		create TEMPORARY table field_data(
		field VARCHAR(50),`value` VARCHAR(200),`key` VARCHAR(100)
		);
		
		-- 我司渠道 
		INSERT INTO field_data(field, `value`, `key`)
		select  grid_code,count(1), 'owner_website_count' 
		from t_website_m b 
		WHERE  b.type in ('1','2','3') AND b.sub_type in ('1','2','3','4','5','6') AND b.`status` = '1' 
		AND b.longitude is NOT NULL AND b.latitude is NOT NULL AND b.grid_code is NOT NULL
		GROUP BY grid_code;
		
		
		-- 异网渠道 
		INSERT INTO field_data(field, `value`, `key`)
		select  grid_code,count(1),'othernet_website_count' 
		from t_website_m b 
		WHERE  b.type in ('5') AND b.sub_type in ('7','8') AND b.`status` = '1' 
		AND b.longitude is NOT NULL AND b.latitude is NOT NULL AND b.grid_code is NOT NULL
		GROUP BY grid_code;

		-- 渠道数量
		INSERT INTO field_data(field, `value`, `key`)
		select  grid_code,count(1), 'website_count' 
		from t_website_m b 
		WHERE  b.type in ('1','2','3','5') AND b.sub_type in ('1','2','3','4','5','6','7','8') AND b.`status` = '1'
		AND b.longitude is NOT NULL AND b.latitude is NOT NULL AND b.grid_code is NOT NULL
		GROUP BY grid_code;

		-- 实体渠道数量
		INSERT INTO field_data(field, `value`, `key`)
		select  grid_code,count(1), 'entity_website_count' 
		from t_website_m b 
		WHERE  b.type = '1' AND b.sub_type in ('1','2','3','4') AND b.`status` = '1' 
		AND b.longitude is NOT NULL AND b.latitude is NOT NULL AND b.grid_code is NOT NULL
		GROUP BY grid_code;

		-- 直销渠道数量
		INSERT INTO field_data(field, `value`, `key`)
		select  grid_code,count(1), 'direct_selling_website_count' 
		from t_website_m b 
		WHERE  b.type = '2' AND b.sub_type in ('5','6') AND b.`status` = '1' 
		AND b.longitude is NOT NULL AND b.latitude is NOT NULL AND b.grid_code is NOT NULL
		GROUP BY grid_code;

		-- 直营店
		INSERT INTO field_data(field, `value`, `key`)
		select  grid_code,count(1), 'direct_shop_website_count' 
		from t_website_m b 
		WHERE  b.type = '1' AND b.sub_type = '1' AND b.`status` = '1' 
		AND b.longitude is NOT NULL AND b.latitude is NOT NULL AND b.grid_code is NOT NULL
		GROUP BY grid_code;

		-- 加盟店
		INSERT INTO field_data(field, `value`, `key`)
		select  grid_code,count(1), 'franchised_store_website_count' 
		from t_website_m b 
		WHERE  b.type = '1' AND b.sub_type = '2' AND b.`status` = '1' GROUP BY grid_code;

		-- 手机卖场
		INSERT INTO field_data(field, `value`, `key`)
		select  grid_code,count(1), 'mobile_store_website_count' 
		from t_website_m b 
		WHERE  b.type = '1' AND b.sub_type = '3' AND b.`status` = '1' 
		AND b.longitude is NOT NULL AND b.latitude is NOT NULL AND b.grid_code is NOT NULL
		GROUP BY grid_code;

		-- 授权店
		INSERT INTO field_data(field, `value`, `key`)
		select  grid_code,count(1), 'authorized_store_website_count' 
		from t_website_m b 
		WHERE  b.type = '1' AND b.sub_type = '4' AND b.`status` = '1' 
		AND b.longitude is NOT NULL AND b.latitude is NOT NULL AND b.grid_code is NOT NULL
		GROUP BY grid_code;

		-- 自营直销渠道
		INSERT INTO field_data(field, `value`, `key`)
		select  grid_code,count(1), 'self_marketing_website_count' 
		from t_website_m b 
		WHERE  b.type = '2' AND b.sub_type = '5' AND b.`status` = '1' 
		AND b.longitude is NOT NULL AND b.latitude is NOT NULL AND b.grid_code is NOT NULL
		GROUP BY grid_code;

		-- 社会直销渠道
		INSERT INTO field_data(field, `value`, `key`)
		select  grid_code,count(1), 'social_direct_selling_website_count' 
		from t_website_m b 
		WHERE  b.type = '2' AND b.sub_type = '6' AND b.`status` = '1' 
		AND b.longitude is NOT NULL AND b.latitude is NOT NULL AND b.grid_code is NOT NULL
		GROUP BY grid_code;

		-- 联通
		INSERT INTO field_data(field, `value`, `key`)
		select  grid_code,count(1), 'unicom_website_count' 
		from t_website_m b 
		WHERE  b.type = '5' AND b.sub_type = '7' AND b.`status` = '1' 
		AND b.longitude is NOT NULL AND b.latitude is NOT NULL AND b.grid_code is NOT NULL
		GROUP BY grid_code;

		-- 电信
		INSERT INTO field_data(field, `value`, `key`)
		select  grid_code,count(1), 'telecom_website_count' 
		from t_website_m b 
		WHERE  b.type = '5' AND b.sub_type = '8' AND b.`status` = '1' 
		AND b.longitude is NOT NULL AND b.latitude is NOT NULL AND b.grid_code is NOT NULL
		GROUP BY grid_code;

		-- 家宽小区
		INSERT INTO field_data(field, `value`, `key`)
		select  e.grid_code,count(1),'uptown_homecustomer_count' 
		from t_uptown_m e
	  WHERE e.`status` = '1' AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL	
		GROUP BY e.grid_code;

		-- 中小企业
		INSERT INTO field_data(field, `value`, `key`)
		select  e.grid_code,count(1),'minor_enterprise_hotel'
		from to_minor_enterprise e
	  WHERE e.`status` = '1' AND e.longitude is NOT NULL AND e.latitude is NOT NULL AND e.grid_code is NOT NULL
		GROUP BY e.grid_code;
		
		
		-- 有效用户数 
		INSERT INTO field_data(field, `value`, `key`)
		select field, effectiveuser_statistics as count,'mobile_effectivecustomer_count' 
		from  t_biz_mobile_effectiveuser_statistics;
		
		
		-- 楼宇数量
		INSERT INTO field_data(field, `value`, `key`)
		select  grid_code,count(1),'building_count'  
		from t_biz_building_m a  
		WHERE a.`status` = '1' AND a.longitude is NOT NULL AND a.latitude is NOT NULL AND a.grid_code is NOT NULL
		GROUP BY grid_code;
		
		-- 集团客户
		INSERT INTO field_data(field, `value`, `key`)
		select  grid_code,count(1),'biz_enterprise'  
		from t_biz_enterprise_m a  
		WHERE a.`status` in ('1','5') AND a.longitude is NOT NULL AND a.latitude is NOT NULL AND a.grid_code is NOT NULL
		GROUP BY grid_code;
		
		-- 集团客户(正式)
		INSERT INTO field_data(field, `value`, `key`)
		select  grid_code,count(1),'biz_enterprise_formal_count'  
		from t_biz_enterprise_m a  
		WHERE a.`status` = '1' AND a.longitude is NOT NULL AND a.latitude is NOT NULL AND a.grid_code is NOT NULL
		GROUP BY grid_code;
		
		-- 集团客户(潜在)
		INSERT INTO field_data(field, `value`, `key`)
		select  grid_code,count(1),'biz_enterprise_potential_count'  
		from t_biz_enterprise_m a  
		WHERE a.`status` = '5' AND a.longitude is NOT NULL AND a.latitude is NOT NULL AND a.grid_code is NOT NULL
		GROUP BY grid_code;
		
		-- 集团客户(按级别A类)
		INSERT INTO field_data(field, `value`, `key`)
		select  grid_code,count(1),'biz_enterprise_level_A'  
		from t_biz_enterprise_m a
		Where a.`level` in ('A','A1','A2') and a.`status` = '1' AND a.longitude is NOT NULL AND a.latitude is NOT NULL AND a.grid_code is NOT NULL
		GROUP BY grid_code;
		
				-- 集团客户(按级别B类)
		INSERT INTO field_data(field, `value`, `key`)
		select  grid_code,count(1),'biz_enterprise_level_B'  
		from t_biz_enterprise_m a
		Where a.`level` in ('B','B1','B2') and a.`status` = '1' AND a.longitude is NOT NULL AND a.latitude is NOT NULL AND a.grid_code is NOT NULL
		GROUP BY grid_code;
		
				-- 集团客户(按级别C类)
		INSERT INTO field_data(field, `value`, `key`)
		select  grid_code,count(1),'biz_enterprise_level_C'  
		from t_biz_enterprise_m a
		Where a.`level` in ('C') and a.`status` = '1' AND a.longitude is NOT NULL AND a.latitude is NOT NULL AND a.grid_code is NOT NULL
		GROUP BY grid_code;
		
				-- 集团客户(按级别A类)
		INSERT INTO field_data(field, `value`, `key`)
		select  grid_code,count(1),'biz_enterprise_level_D'  
		from t_biz_enterprise_m a
		Where a.`level` in ('D','D1','D2') and a.`status` = '1' AND a.longitude is NOT NULL AND a.latitude is NOT NULL AND a.grid_code is NOT NULL
		GROUP BY grid_code;
		
		
		
					-- 销售经理列表
		INSERT INTO field_data(field, `value`, `key`)
		select c.grid_code, group_concat(distinct c.resonse_person) v,'sales_manager'
					from (select b.grid_code , b.name as resonse_person 
									from t_grid_m  a 
									inner join t_biz_grid_staff_e b on a.code=b.grid_code where a.level=5) c
					group by c.grid_code HAVING v is not null and v != ''  ;

		
-- 上级网格总监名称
		INSERT INTO field_data(field, `value`, `key`)
		select a.field_code as grid_code, b.headperson as str,'net_grid_directorname'
						from t_grid_m b,
						(select  parent_code , code as field_code  
							from t_grid_m where level =5) a
				where b.code = a.parent_code HAVING str is not null and str != '';

		


		
		-- 插入微网格数据 
		
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-4),',',1),
					SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-3),',',1),
					SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-2),',',1),
					a.field,a.`key`,a.`value`,'system',NOW(),'system',NOW() 
		FROM
					field_data a,
				t_grid_m m WHERE m.`code` = a.field and a.field IS NOT NULL and m.`level` = 5
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;
		
		-- 插入微网格数据结束 
		
		-- 获取网格下的微网格数量，插入网格层级中 
		    --  获取网格下的微网格数量，插入网格层级中 
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-3),',',1),
					SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-2),',',1),
					m.`code` as code,
					'','field_count',
					count(m1.`code`) as child_count,
					'system',NOW(),'system',NOW() 
		FROM t_grid_m m
		LEFT JOIN t_grid_m m1
		ON m.code= m1.parent_code where m.level = 4 GROUP BY m.code
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;

	-- 获取区县下的网格数量，插入区县层级  
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT 
		SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-2),',',1),
		m.`code` as code,
		'' as net_grid,'' as field,
		'grid_count' as `key`,
		count(m1.`code`) as child_count,
		'system',NOW(),'system',NOW() 
		FROM t_grid_m m
		LEFT JOIN t_grid_m m1
		ON m.code= m1.parent_code where m.level = 3 GROUP BY m.code
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;

	-- 二、

-- 插入有效用户数责任田基本数据
INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-4),',',1),
			SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-3),',',1),
			SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-2),',',1),
			s.field,'mobile_effectivecustomer_count',s.effectiveuser_statistics,'system',NOW(),'system',NOW() 
FROM
		t_biz_mobile_effectiveuser_statistics s,
		t_grid_m m WHERE m.`code` = s.field and s.field IS NOT NULL and m.`level` = 5
ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date);


-- 插入有效用户数网格级别基本数据（有效用户数不需要把微网格数据汇总到网格）
INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-3),',',1),
			SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-2),',',1),
			s.field,
			'','mobile_effectivecustomer_count',s.effectiveuser_statistics,'system',NOW(),'system',NOW() 
FROM
		t_biz_mobile_effectiveuser_statistics s,
		t_grid_m m WHERE m.`code` = s.field and s.field IS NOT NULL and m.`level` = 4
ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date);


-- 在责任田层已插入父级网格的网格总监名称，直接插入网格层级中
INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
SELECT city, district, net_grid, "", s.`key`, max(`value`) , 'system', now(), 'system', now() 
FROM t_grid_statistics s 
WHERE field != "" and field IS NOT NULL and s.`key` = 'net_grid_directorname'
GROUP BY s.city, s.district, net_grid, s.`key` 
ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
;


			-- 三、把微网格的数据向上汇总，从微网格汇总到网格，从网格汇总到区县，从区县汇总到城市，从城市汇总到省开始-->
		
		
		-- 1.汇总微网格数据到网格 (有效用户数不需要把微网格数据汇总到网格)(暂时不汇总网格经理个数和微网格经理个数)
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT city, district, net_grid, "", s.`key`, sum(if(IFNULL(`value`, '') = '', 0, `value`)) , 'system', now(), 'system', now() 
		FROM t_grid_statistics s 
		WHERE field != ""  and field IS NOT NULL AND `key` not in ('mobile_effectivecustomer_count') and s.`key` NOT IN (SELECT k.key_name from not_contain_of_key_list k)
		GROUP BY s.city, s.district, net_grid, s.`key`
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;

	-- 2.汇总网格数据到分公司 
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT s.city, s.district, "", "", s.`key`, sum(if(IFNULL(`value`, '') = '', 0, `value`)) , 'system', now(), 'system', now() 
		FROM t_grid_statistics s 
		WHERE net_grid !="" and field ="" and s.`key` NOT IN (SELECT k.key_name from not_contain_of_key_list k)
		GROUP BY s.city, s.district, s.`key`
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;
	
		-- 3.汇总分公司数据到城市 
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT city, "", "", "", s.`key`, sum(if(IFNULL(`value`, '') = '', 0, `value`)) , 'system', now(), 'system', now() 
		FROM t_grid_statistics s 
		WHERE district !="" and net_grid ="" and field ="" and s.`key` NOT IN (SELECT k.key_name from not_contain_of_key_list k) 
		GROUP BY s.city, s.`key`
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;
				
		-- 4.汇数据城市到省 
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT "", "", "", "", s.`key`, sum(if(IFNULL(`value`, '') = '', 0, `value`)) , 'system', now(), 'system', now() 
		FROM t_grid_statistics s 
		WHERE city != "" and district ="" and net_grid ="" and field ="" 
		and s.`key` NOT IN (SELECT k.key_name from not_contain_of_key_list k)
		GROUP BY s.`key`
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;
		
		-- 把责任田的数据向上汇总，从责任田汇总到网格，从网格汇总到分公司，从分公司汇总到城市，从城市汇总到省结束 -->

END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for updateStatisticsGridIndicators_bizEnterprise
-- ----------------------------
DROP PROCEDURE IF EXISTS `updateStatisticsGridIndicators_bizEnterprise`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `updateStatisticsGridIndicators_bizEnterprise`()
BEGIN

		-- 不需要向上汇总的key（第三步使用）
drop table if exists not_contain_of_key_list;
create temporary table not_contain_of_key_list(key_name VARCHAR(100));
INSERT INTO not_contain_of_key_list(key_name) VALUES('area');-- 面积
INSERT INTO not_contain_of_key_list(key_name) VALUES('net_grid_directorname');-- 网格总监名称
INSERT INTO not_contain_of_key_list(key_name) VALUES('sales_manager');-- 销售经理姓名

-- 清空表t_grid_statistics的数据
DELETE FROM t_grid_statistics where `key` in ('biz_enterprise','biz_enterprise_formal_count','biz_enterprise_potential_count','biz_enterprise_level_A','biz_enterprise_level_B','biz_enterprise_level_C','biz_enterprise_level_D');

	-- 一、插入微网格数据开始 

		-- 临时表，保存责任田数据，然后再批量插入 
		drop table if exists field_data;
		create TEMPORARY table field_data(
		field VARCHAR(50),`value` VARCHAR(200),`key` VARCHAR(100)
		);
		
		-- 集团客户
		INSERT INTO field_data(field, `value`, `key`)
		select  grid_code,count(1),'biz_enterprise'  
		from t_biz_enterprise_m a  
		WHERE a.`status` in ('1','5') AND a.longitude is NOT NULL AND a.latitude is NOT NULL
		AND a.grid_code is NOT NULL
		GROUP BY grid_code;
		
		-- 集团客户(正式)
		INSERT INTO field_data(field, `value`, `key`)
		select  grid_code,count(1),'biz_enterprise_formal_count'  
		from t_biz_enterprise_m a  
		WHERE a.`status` = '1' AND a.longitude is NOT NULL AND a.latitude is NOT NULL
		AND a.grid_code is NOT NULL
		GROUP BY grid_code;
		
		-- 集团客户(潜在)
		INSERT INTO field_data(field, `value`, `key`)
		select  grid_code,count(1),'biz_enterprise_potential_count'  
		from t_biz_enterprise_m a  
		WHERE a.`status` = '5' AND a.longitude is NOT NULL AND a.latitude is NOT NULL
		AND a.grid_code is NOT NULL
		GROUP BY grid_code;
		
		-- 集团客户(按级别A类)
		INSERT INTO field_data(field, `value`, `key`)
		select  grid_code,count(1),'biz_enterprise_level_A'  
		from t_biz_enterprise_m a
		Where a.`level` in ('A','A1','A2') and a.`status` = '1' AND a.longitude is NOT NULL AND a.latitude is NOT NULL
		AND a.grid_code is NOT NULL
		GROUP BY grid_code;
		
				-- 集团客户(按级别B类)
		INSERT INTO field_data(field, `value`, `key`)
		select  grid_code,count(1),'biz_enterprise_level_B'  
		from t_biz_enterprise_m a
		Where a.`level` in ('B','B1','B2') and a.`status` = '1' AND a.longitude is NOT NULL AND a.latitude is NOT NULL
		AND a.grid_code is NOT NULL
		GROUP BY grid_code;
		
				-- 集团客户(按级别C类)
		INSERT INTO field_data(field, `value`, `key`)
		select  grid_code,count(1),'biz_enterprise_level_C'  
		from t_biz_enterprise_m a
		Where a.`level` in ('C') and a.`status` = '1' AND a.longitude is NOT NULL AND a.latitude is NOT NULL
		AND a.grid_code is NOT NULL
		GROUP BY grid_code;
		
				-- 集团客户(按级别D类)
		INSERT INTO field_data(field, `value`, `key`)
		select  grid_code,count(1),'biz_enterprise_level_D'  
		from t_biz_enterprise_m a
		Where a.`level` in ('D','D1','D2') and a.`status` = '1' AND a.longitude is NOT NULL AND a.latitude is NOT NULL
		AND a.grid_code is NOT NULL
		GROUP BY grid_code;

		-- 插入微网格数据 
		
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-4),',',1),
					SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-3),',',1),
					SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-2),',',1),
					a.field,a.`key`,a.`value`,'system',NOW(),'system',NOW() 
		FROM
					field_data a,
				t_grid_m m WHERE m.`code` = a.field and a.field IS NOT NULL and m.`level` = 5
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;
		
		-- 插入微网格数据结束 
		
		-- 获取网格下的微网格数量，插入网格层级中 
		    --  获取网格下的微网格数量，插入网格层级中 
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-3),',',1),
					SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-2),',',1),
					m.`code` as code,
					'','field_count',
					count(m1.`code`) as child_count,
					'system',NOW(),'system',NOW() 
		FROM t_grid_m m
		LEFT JOIN t_grid_m m1
		ON m.code= m1.parent_code where m.level = 4 GROUP BY m.code
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;

	-- 获取区县下的网格数量，插入区县层级  
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-2),',',1),
					m.`code` as code,
					'','','grid_count',
					(SELECT COUNT(1) FROM t_grid_m m1 WHERE m1.parent_code = m.`code`) as child_count,
					'system',NOW(),'system',NOW() 
		FROM t_grid_m m WHERE m.`level` = 3
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;

			-- 三、把微网格的数据向上汇总，从微网格汇总到网格，从网格汇总到区县，从区县汇总到城市，从城市汇总到省开始-->
		
		
		-- 1.汇总微网格数据到网格 (有效用户数不需要把微网格数据汇总到网格)(暂时不汇总网格经理个数和微网格经理个数)
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT city, district, net_grid, "", s.`key`, sum(if(IFNULL(`value`, '') = '', 0, `value`)) , 'system', now(), 'system', now() 
		FROM t_grid_statistics s 
		WHERE field != ""  and field IS NOT NULL AND `key` not in ('mobile_effectivecustomer_count') and s.`key` NOT IN (SELECT k.key_name from not_contain_of_key_list k)
		GROUP BY s.city, s.district, net_grid, s.`key`
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;

	-- 2.汇总网格数据到分公司 
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT s.city, s.district, "", "", s.`key`, sum(if(IFNULL(`value`, '') = '', 0, `value`)) , 'system', now(), 'system', now() 
		FROM t_grid_statistics s 
		WHERE net_grid !="" and field ="" and s.`key` NOT IN (SELECT k.key_name from not_contain_of_key_list k)
		GROUP BY s.city, s.district, s.`key`
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;
	
		-- 3.汇总分公司数据到城市 
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT city, "", "", "", s.`key`, sum(if(IFNULL(`value`, '') = '', 0, `value`)) , 'system', now(), 'system', now() 
		FROM t_grid_statistics s 
		WHERE district !="" and net_grid ="" and field ="" and s.`key` NOT IN (SELECT k.key_name from not_contain_of_key_list k) 
		GROUP BY s.city, s.`key`
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;
				
		-- 4.汇数据城市到省 
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT "", "", "", "", s.`key`, sum(if(IFNULL(`value`, '') = '', 0, `value`)) , 'system', now(), 'system', now() 
		FROM t_grid_statistics s 
		WHERE city != "" and district ="" and net_grid ="" and field ="" 
		and s.`key` NOT IN (SELECT k.key_name from not_contain_of_key_list k)
		GROUP BY s.`key`
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;
		
		-- 把责任田的数据向上汇总，从责任田汇总到网格，从网格汇总到分公司，从分公司汇总到城市，从城市汇总到省结束 -->
		
		
END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for updateStatisticsGridIndicators_building
-- ----------------------------
DROP PROCEDURE IF EXISTS `updateStatisticsGridIndicators_building`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `updateStatisticsGridIndicators_building`()
BEGIN

		-- 不需要向上汇总的key（第三步使用）
drop table if exists not_contain_of_key_list;
create temporary table not_contain_of_key_list(key_name VARCHAR(100));
INSERT INTO not_contain_of_key_list(key_name) VALUES('area');-- 面积
INSERT INTO not_contain_of_key_list(key_name) VALUES('net_grid_directorname');-- 网格总监名称
INSERT INTO not_contain_of_key_list(key_name) VALUES('sales_manager');-- 销售经理姓名

-- 清空表t_grid_statistics的数据
DELETE FROM t_grid_statistics where `key` in ('building_count');

	-- 一、插入微网格数据开始 

		-- 临时表，保存责任田数据，然后再批量插入 
		drop table if exists field_data;
		create TEMPORARY table field_data(
		field VARCHAR(50),`value` VARCHAR(200),`key` VARCHAR(100)
		);
		
		-- 楼宇数量
		INSERT INTO field_data(field, `value`, `key`)
		select  grid_code,count(1),'building_count'  
		from t_biz_building_m a  
		WHERE a.`status` = '1' AND a.longitude is NOT NULL AND a.latitude is NOT NULL
		AND a.grid_code is NOT NULL
		GROUP BY grid_code;

		-- 插入微网格数据 
		
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-4),',',1),
					SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-3),',',1),
					SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-2),',',1),
					a.field,a.`key`,a.`value`,'system',NOW(),'system',NOW() 
		FROM
					field_data a,
				t_grid_m m WHERE m.`code` = a.field and a.field IS NOT NULL and m.`level` = 5
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;
		
		-- 插入微网格数据结束 
		
		-- 获取网格下的微网格数量，插入网格层级中 
		    --  获取网格下的微网格数量，插入网格层级中 
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-3),',',1),
					SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-2),',',1),
					m.`code` as code,
					'','field_count',
					count(m1.`code`) as child_count,
					'system',NOW(),'system',NOW() 
		FROM t_grid_m m
		LEFT JOIN t_grid_m m1
		ON m.code= m1.parent_code where m.level = 4 GROUP BY m.code
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;

	-- 获取区县下的网格数量，插入区县层级  
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-2),',',1),
					m.`code` as code,
					'','','grid_count',
					(SELECT COUNT(1) FROM t_grid_m m1 WHERE m1.parent_code = m.`code`) as child_count,
					'system',NOW(),'system',NOW() 
		FROM t_grid_m m WHERE m.`level` = 3
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;

			-- 三、把微网格的数据向上汇总，从微网格汇总到网格，从网格汇总到区县，从区县汇总到城市，从城市汇总到省开始-->
		
		
		-- 1.汇总微网格数据到网格 (有效用户数不需要把微网格数据汇总到网格)(暂时不汇总网格经理个数和微网格经理个数)
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT city, district, net_grid, "", s.`key`, sum(if(IFNULL(`value`, '') = '', 0, `value`)) , 'system', now(), 'system', now() 
		FROM t_grid_statistics s 
		WHERE field != ""  and field IS NOT NULL AND `key` not in ('mobile_effectivecustomer_count') and s.`key` NOT IN (SELECT k.key_name from not_contain_of_key_list k)
		GROUP BY s.city, s.district, net_grid, s.`key`
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;

	-- 2.汇总网格数据到分公司 
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT s.city, s.district, "", "", s.`key`, sum(if(IFNULL(`value`, '') = '', 0, `value`)) , 'system', now(), 'system', now() 
		FROM t_grid_statistics s 
		WHERE net_grid !="" and field ="" and s.`key` NOT IN (SELECT k.key_name from not_contain_of_key_list k)
		GROUP BY s.city, s.district, s.`key`
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;
	
		-- 3.汇总分公司数据到城市 
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT city, "", "", "", s.`key`, sum(if(IFNULL(`value`, '') = '', 0, `value`)) , 'system', now(), 'system', now() 
		FROM t_grid_statistics s 
		WHERE district !="" and net_grid ="" and field ="" and s.`key` NOT IN (SELECT k.key_name from not_contain_of_key_list k) 
		GROUP BY s.city, s.`key`
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;
				
		-- 4.汇数据城市到省 
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT "", "", "", "", s.`key`, sum(if(IFNULL(`value`, '') = '', 0, `value`)) , 'system', now(), 'system', now() 
		FROM t_grid_statistics s 
		WHERE city != "" and district ="" and net_grid ="" and field ="" 
		and s.`key` NOT IN (SELECT k.key_name from not_contain_of_key_list k)
		GROUP BY s.`key`
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;
		
		-- 把责任田的数据向上汇总，从责任田汇总到网格，从网格汇总到分公司，从分公司汇总到城市，从城市汇总到省结束 -->
		


END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for updateStatisticsGridIndicators_enterprise
-- ----------------------------
DROP PROCEDURE IF EXISTS `updateStatisticsGridIndicators_enterprise`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `updateStatisticsGridIndicators_enterprise`()
BEGIN

		-- 不需要向上汇总的key（第三步使用）
drop table if exists not_contain_of_key_list;
create temporary table not_contain_of_key_list(key_name VARCHAR(100));
INSERT INTO not_contain_of_key_list(key_name) VALUES('area');-- 面积
INSERT INTO not_contain_of_key_list(key_name) VALUES('net_grid_directorname');-- 网格总监名称
INSERT INTO not_contain_of_key_list(key_name) VALUES('sales_manager');-- 销售经理姓名

-- 清空表t_grid_statistics的数据
-- 清空表t_grid_statistics的数据
DELETE FROM t_grid_statistics where `key` in ('minor_enterprise_hotel');

	-- 一、插入微网格数据开始 

		-- 临时表，保存责任田数据，然后再批量插入 
		drop table if exists field_data;
		create TEMPORARY table field_data(
		field VARCHAR(50),`value` VARCHAR(200),`key` VARCHAR(100)
		);
		
		-- 中小企业
		INSERT INTO field_data(field, `value`, `key`)
		select  e.grid_code,count(1),'minor_enterprise_hotel'
		from to_minor_enterprise e
	  WHERE e.`status` = '1' AND e.longitude is NOT NULL AND e.latitude is NOT NULL
		AND e.grid_code is NOT NULL
		GROUP BY e.grid_code;

		-- 插入微网格数据 
		
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-4),',',1),
					SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-3),',',1),
					SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-2),',',1),
					a.field,a.`key`,a.`value`,'system',NOW(),'system',NOW() 
		FROM
					field_data a,
				t_grid_m m WHERE m.`code` = a.field and a.field IS NOT NULL and m.`level` = 5
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;
		
		-- 插入微网格数据结束 
		
		-- 获取网格下的微网格数量，插入网格层级中 
		    --  获取网格下的微网格数量，插入网格层级中 
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-3),',',1),
					SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-2),',',1),
					m.`code` as code,
					'','field_count',
					count(m1.`code`) as child_count,
					'system',NOW(),'system',NOW() 
		FROM t_grid_m m
		LEFT JOIN t_grid_m m1
		ON m.code= m1.parent_code where m.level = 4 GROUP BY m.code
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;

	-- 获取区县下的网格数量，插入区县层级  
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-2),',',1),
					m.`code` as code,
					'','','grid_count',
					(SELECT COUNT(1) FROM t_grid_m m1 WHERE m1.parent_code = m.`code`) as child_count,
					'system',NOW(),'system',NOW() 
		FROM t_grid_m m WHERE m.`level` = 3
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;

			-- 三、把微网格的数据向上汇总，从微网格汇总到网格，从网格汇总到区县，从区县汇总到城市，从城市汇总到省开始-->
		
		
		-- 1.汇总微网格数据到网格 (有效用户数不需要把微网格数据汇总到网格)(暂时不汇总网格经理个数和微网格经理个数)
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT city, district, net_grid, "", s.`key`, sum(if(IFNULL(`value`, '') = '', 0, `value`)) , 'system', now(), 'system', now() 
		FROM t_grid_statistics s 
		WHERE field != ""  and field IS NOT NULL AND `key` not in ('mobile_effectivecustomer_count') and s.`key` NOT IN (SELECT k.key_name from not_contain_of_key_list k)
		GROUP BY s.city, s.district, net_grid, s.`key`
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;

	-- 2.汇总网格数据到分公司 
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT s.city, s.district, "", "", s.`key`, sum(if(IFNULL(`value`, '') = '', 0, `value`)) , 'system', now(), 'system', now() 
		FROM t_grid_statistics s 
		WHERE net_grid !="" and field ="" and s.`key` NOT IN (SELECT k.key_name from not_contain_of_key_list k)
		GROUP BY s.city, s.district, s.`key`
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;
	
		-- 3.汇总分公司数据到城市 
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT city, "", "", "", s.`key`, sum(if(IFNULL(`value`, '') = '', 0, `value`)) , 'system', now(), 'system', now() 
		FROM t_grid_statistics s 
		WHERE district !="" and net_grid ="" and field ="" and s.`key` NOT IN (SELECT k.key_name from not_contain_of_key_list k) 
		GROUP BY s.city, s.`key`
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;
				
		-- 4.汇数据城市到省 
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT "", "", "", "", s.`key`, sum(if(IFNULL(`value`, '') = '', 0, `value`)) , 'system', now(), 'system', now() 
		FROM t_grid_statistics s 
		WHERE city != "" and district ="" and net_grid ="" and field ="" 
		and s.`key` NOT IN (SELECT k.key_name from not_contain_of_key_list k)
		GROUP BY s.`key`
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;
		
		-- 把责任田的数据向上汇总，从责任田汇总到网格，从网格汇总到分公司，从分公司汇总到城市，从城市汇总到省结束 -->
		


END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for updateStatisticsGridIndicators_other
-- ----------------------------
DROP PROCEDURE IF EXISTS `updateStatisticsGridIndicators_other`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `updateStatisticsGridIndicators_other`()
BEGIN

		-- 不需要向上汇总的key（第三步使用）
drop table if exists not_contain_of_key_list;
create temporary table not_contain_of_key_list(key_name VARCHAR(100));
INSERT INTO not_contain_of_key_list(key_name) VALUES('area');-- 面积
INSERT INTO not_contain_of_key_list(key_name) VALUES('net_grid_directorname');-- 网格总监名称
INSERT INTO not_contain_of_key_list(key_name) VALUES('sales_manager');-- 销售经理姓名

-- 清空表t_grid_statistics的数据
DELETE FROM t_grid_statistics where `key` in ('sales_manager','net_grid_directorname','mobile_effectivecustomer_count');

	-- 一、插入微网格数据开始 

		-- 临时表，保存责任田数据，然后再批量插入 
		drop table if exists field_data;
		create TEMPORARY table field_data(
		field VARCHAR(50),`value` VARCHAR(200),`key` VARCHAR(100)
		);
		
		-- 有效用户数 
		INSERT INTO field_data(field, `value`, `key`)
		select field, effectiveuser_statistics as count,'mobile_effectivecustomer_count' 
		from  t_biz_mobile_effectiveuser_statistics;
				
					-- 销售经理列表
		INSERT INTO field_data(field, `value`, `key`)
		select c.grid_code, group_concat(distinct c.resonse_person) v,'sales_manager'
					from (select b.grid_code , b.name as resonse_person 
									from t_grid_m  a 
									inner join t_biz_grid_staff_e b on a.code=b.grid_code where a.level=5) c
					group by c.grid_code HAVING v is not null and v != ''  ;

		
-- 上级网格总监名称
		INSERT INTO field_data(field, `value`, `key`)
		select a.field_code as grid_code, b.headperson as str,'net_grid_directorname'
						from t_grid_m b,
						(select  parent_code , code as field_code  
							from t_grid_m where level =5) a
				where b.code = a.parent_code HAVING str is not null and str != '';
				
				
		-- 插入微网格数据 
		
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-4),',',1),
					SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-3),',',1),
					SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-2),',',1),
					a.field,a.`key`,a.`value`,'system',NOW(),'system',NOW() 
		FROM
					field_data a,
				t_grid_m m WHERE m.`code` = a.field and a.field IS NOT NULL and m.`level` = 5
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;
		
		-- 插入微网格数据结束 
		
		-- 获取网格下的微网格数量，插入网格层级中 
		    --  获取网格下的微网格数量，插入网格层级中 
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-3),',',1),
					SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-2),',',1),
					m.`code` as code,
					'','field_count',
					count(m1.`code`) as child_count,
					'system',NOW(),'system',NOW() 
		FROM t_grid_m m
		LEFT JOIN t_grid_m m1
		ON m.code= m1.parent_code where m.level = 4 GROUP BY m.code
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;

	-- 获取区县下的网格数量，插入区县层级  
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-2),',',1),
					m.`code` as code,
					'','','grid_count',
					(SELECT COUNT(1) FROM t_grid_m m1 WHERE m1.parent_code = m.`code`) as child_count,
					'system',NOW(),'system',NOW() 
		FROM t_grid_m m WHERE m.`level` = 3
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;

	-- 二、

-- 插入有效用户数责任田基本数据
INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-4),',',1),
			SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-3),',',1),
			SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-2),',',1),
			s.field,'mobile_effectivecustomer_count',s.effectiveuser_statistics,'system',NOW(),'system',NOW() 
FROM
		t_biz_mobile_effectiveuser_statistics s,
		t_grid_m m WHERE m.`code` = s.field and s.field IS NOT NULL and m.`level` = 5
ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date);


-- 插入有效用户数网格级别基本数据（有效用户数不需要把微网格数据汇总到网格）
INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-3),',',1),
			SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-2),',',1),
			s.field,
			'','mobile_effectivecustomer_count',s.effectiveuser_statistics,'system',NOW(),'system',NOW() 
FROM
		t_biz_mobile_effectiveuser_statistics s,
		t_grid_m m WHERE m.`code` = s.field and s.field IS NOT NULL and m.`level` = 4
ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date);


-- 在责任田层已插入父级网格的网格总监名称，直接插入网格层级中
INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
SELECT city, district, net_grid, "", s.`key`, max(`value`) , 'system', now(), 'system', now() 
FROM t_grid_statistics s 
WHERE field != "" and field IS NOT NULL and s.`key` = 'net_grid_directorname'
GROUP BY s.city, s.district, net_grid, s.`key` 
ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
;


			-- 三、把微网格的数据向上汇总，从微网格汇总到网格，从网格汇总到区县，从区县汇总到城市，从城市汇总到省开始-->
		
		
		-- 1.汇总微网格数据到网格 (有效用户数不需要把微网格数据汇总到网格)(暂时不汇总网格经理个数和微网格经理个数)
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT city, district, net_grid, "", s.`key`, sum(if(IFNULL(`value`, '') = '', 0, `value`)) , 'system', now(), 'system', now() 
		FROM t_grid_statistics s 
		WHERE field != ""  and field IS NOT NULL AND `key` not in ('mobile_effectivecustomer_count') and s.`key` NOT IN (SELECT k.key_name from not_contain_of_key_list k)
		GROUP BY s.city, s.district, net_grid, s.`key`
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;

	-- 2.汇总网格数据到分公司 
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT s.city, s.district, "", "", s.`key`, sum(if(IFNULL(`value`, '') = '', 0, `value`)) , 'system', now(), 'system', now() 
		FROM t_grid_statistics s 
		WHERE net_grid !="" and field ="" and s.`key` NOT IN (SELECT k.key_name from not_contain_of_key_list k)
		GROUP BY s.city, s.district, s.`key`
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;
	
		-- 3.汇总分公司数据到城市 
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT city, "", "", "", s.`key`, sum(if(IFNULL(`value`, '') = '', 0, `value`)) , 'system', now(), 'system', now() 
		FROM t_grid_statistics s 
		WHERE district !="" and net_grid ="" and field ="" and s.`key` NOT IN (SELECT k.key_name from not_contain_of_key_list k) 
		GROUP BY s.city, s.`key`
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;
				
		-- 4.汇数据城市到省 
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT "", "", "", "", s.`key`, sum(if(IFNULL(`value`, '') = '', 0, `value`)) , 'system', now(), 'system', now() 
		FROM t_grid_statistics s 
		WHERE city != "" and district ="" and net_grid ="" and field ="" 
		and s.`key` NOT IN (SELECT k.key_name from not_contain_of_key_list k)
		GROUP BY s.`key`
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;
		
		-- 把责任田的数据向上汇总，从责任田汇总到网格，从网格汇总到分公司，从分公司汇总到城市，从城市汇总到省结束 -->
		


END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for updateStatisticsGridIndicators_uptown
-- ----------------------------
DROP PROCEDURE IF EXISTS `updateStatisticsGridIndicators_uptown`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `updateStatisticsGridIndicators_uptown`()
BEGIN

-- 不需要向上汇总的key（第三步使用）
drop table if exists not_contain_of_key_list;
create temporary table not_contain_of_key_list(key_name VARCHAR(100));
INSERT INTO not_contain_of_key_list(key_name) VALUES('area');-- 面积
INSERT INTO not_contain_of_key_list(key_name) VALUES('net_grid_directorname');-- 网格总监名称
INSERT INTO not_contain_of_key_list(key_name) VALUES('sales_manager');-- 销售经理姓名

-- 清空表t_grid_statistics的数据
DELETE FROM t_grid_statistics where `key` in ('uptown_homecustomer_count');

	  -- 一、插入微网格数据开始 

		-- 临时表，保存责任田数据，然后再批量插入 
		drop table if exists field_data_uptown;
		create TEMPORARY table field_data_uptown(
		field VARCHAR(50),`value` VARCHAR(200),`key` VARCHAR(100)
		);
		
    -- 家宽小区
		INSERT INTO field_data_uptown(field, `value`, `key`)
		select  e.grid_code,count(1),'uptown_homecustomer_count' 
		from t_uptown_m e
	  WHERE e.`status` = '1' AND e.longitude is NOT NULL AND e.latitude is NOT NULL	
		AND e.grid_code is NOT NULL
		GROUP BY e.grid_code;
		
		-- 插入微网格数据 
		
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-4),',',1),
					SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-3),',',1),
					SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-2),',',1),
					a.field,a.`key`,a.`value`,'system',NOW(),'system',NOW() 
		FROM
					field_data_uptown a,
				t_grid_m m WHERE m.`code` = a.field and a.field IS NOT NULL and m.`level` = 5
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;
		
		-- 插入微网格数据结束 
		
		-- 获取网格下的微网格数量，插入网格层级中 
		    --  获取网格下的微网格数量，插入网格层级中 
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-3),',',1),
					SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-2),',',1),
					m.`code` as code,
					'','field_count',
					count(m1.`code`) as child_count,
					'system',NOW(),'system',NOW() 
		FROM t_grid_m m
		LEFT JOIN t_grid_m m1
		ON m.code= m1.parent_code where m.level = 4 GROUP BY m.code
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;

	-- 获取区县下的网格数量，插入区县层级  
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT 
		SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-2),',',1),
		m.`code` as code,
		'' as net_grid,'' as field,
		'grid_count' as `key`,
		count(m1.`code`) as child_count,
		'system',NOW(),'system',NOW() 
		FROM t_grid_m m
		LEFT JOIN t_grid_m m1
		ON m.code= m1.parent_code where m.level = 3 GROUP BY m.code
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;
		
			-- 三、把微网格的数据向上汇总，从微网格汇总到网格，从网格汇总到区县，从区县汇总到城市，从城市汇总到省开始-->
		
		
		-- 1.汇总微网格数据到网格 (有效用户数不需要把微网格数据汇总到网格)(暂时不汇总网格经理个数和微网格经理个数)
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT city, district, net_grid, "", s.`key`, sum(if(IFNULL(`value`, '') = '', 0, `value`)) , 'system', now(), 'system', now() 
		FROM t_grid_statistics s 
		WHERE field != ""  and field IS NOT NULL AND `key` not in ('mobile_effectivecustomer_count') and s.`key` NOT IN (SELECT k.key_name from not_contain_of_key_list k)
		GROUP BY s.city, s.district, net_grid, s.`key`
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;

	-- 2.汇总网格数据到分公司 
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT s.city, s.district, "", "", s.`key`, sum(if(IFNULL(`value`, '') = '', 0, `value`)) , 'system', now(), 'system', now() 
		FROM t_grid_statistics s 
		WHERE net_grid !="" and field ="" and s.`key` NOT IN (SELECT k.key_name from not_contain_of_key_list k)
		GROUP BY s.city, s.district, s.`key`
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;
	
		-- 3.汇总分公司数据到城市 
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT city, "", "", "", s.`key`, sum(if(IFNULL(`value`, '') = '', 0, `value`)) , 'system', now(), 'system', now() 
		FROM t_grid_statistics s 
		WHERE district !="" and net_grid ="" and field ="" and s.`key` NOT IN (SELECT k.key_name from not_contain_of_key_list k) 
		GROUP BY s.city, s.`key`
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;
				
		-- 4.汇数据城市到省 
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT "", "", "", "", s.`key`, sum(if(IFNULL(`value`, '') = '', 0, `value`)) , 'system', now(), 'system', now() 
		FROM t_grid_statistics s 
		WHERE city != "" and district ="" and net_grid ="" and field ="" 
		and s.`key` NOT IN (SELECT k.key_name from not_contain_of_key_list k)
		GROUP BY s.`key`
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;
		
		-- 把责任田的数据向上汇总，从责任田汇总到网格，从网格汇总到分公司，从分公司汇总到城市，从城市汇总到省结束 -->

END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for updateStatisticsGridIndicators_website
-- ----------------------------
DROP PROCEDURE IF EXISTS `updateStatisticsGridIndicators_website`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` PROCEDURE `updateStatisticsGridIndicators_website`()
BEGIN

-- 不需要向上汇总的key（第三步使用）
drop table if exists not_contain_of_key_list;
create temporary table not_contain_of_key_list(key_name VARCHAR(100));
INSERT INTO not_contain_of_key_list(key_name) VALUES('area');-- 面积
INSERT INTO not_contain_of_key_list(key_name) VALUES('net_grid_directorname');-- 网格总监名称
INSERT INTO not_contain_of_key_list(key_name) VALUES('sales_manager');-- 销售经理姓名

-- 清空表t_grid_statistics的数据
DELETE FROM t_grid_statistics where `key` in ('owner_website_count','othernet_website_count','website_count','entity_website_count','direct_selling_website_count','direct_shop_website_count','franchised_store_website_count','mobile_store_website_count','authorized_store_website_count','self_marketing_website_count','social_direct_selling_website_count','unicom_website_count','telecom_website_count');

	-- 一、插入微网格数据开始 

		-- 临时表，保存责任田数据，然后再批量插入 
		drop table if exists field_data_website;
		create TEMPORARY table field_data_website(
		field VARCHAR(50),`value` VARCHAR(200),`key` VARCHAR(100)
		);
		
		-- 我司渠道 
		INSERT INTO field_data_website(field, `value`, `key`)
		select  grid_code,count(1), 'owner_website_count' 
		from t_website_m b 
		WHERE  b.type in ('1','2','3') AND b.sub_type in ('1','2','3','4','5','6') AND b.`status` = '1' AND b.longitude is NOT NULL AND b.latitude is NOT NULL
		AND b.grid_code is NOT NULL
		GROUP BY grid_code;
		
		
		-- 异网渠道 
		INSERT INTO field_data_website(field, `value`, `key`)
		select  grid_code,count(1),'othernet_website_count' 
		from t_website_m b 
		WHERE  b.type in ('5') AND b.sub_type in ('7','8') AND b.`status` = '1' AND b.longitude is NOT NULL AND b.latitude is NOT NULL
		AND b.grid_code is NOT NULL
		GROUP BY grid_code;

		-- 渠道数量
		INSERT INTO field_data_website(field, `value`, `key`)
		select  grid_code,count(1), 'website_count' 
		from t_website_m b 
		WHERE  b.type in ('1','2','3','5') AND b.sub_type in ('1','2','3','4','5','6','7','8') AND b.`status` = '1' AND b.longitude is NOT NULL AND b.latitude is NOT NULL
		AND b.grid_code is NOT NULL
		GROUP BY grid_code;

		-- 实体渠道数量
		INSERT INTO field_data_website(field, `value`, `key`)
		select  grid_code,count(1), 'entity_website_count' 
		from t_website_m b 
		WHERE  b.type = '1' AND b.sub_type in ('1','2','3','4') AND b.`status` = '1' AND b.longitude is NOT NULL AND b.latitude is NOT NULL
		AND b.grid_code is NOT NULL
		GROUP BY grid_code;

		-- 直销渠道数量
		INSERT INTO field_data_website(field, `value`, `key`)
		select  grid_code,count(1), 'direct_selling_website_count' 
		from t_website_m b 
		WHERE  b.type = '2' AND b.sub_type in ('5','6') AND b.`status` = '1' AND b.longitude is NOT NULL AND b.latitude is NOT NULL 
		AND b.grid_code is NOT NULL
		GROUP BY grid_code;

		-- 直营店
		INSERT INTO field_data_website(field, `value`, `key`)
		select  grid_code,count(1), 'direct_shop_website_count' 
		from t_website_m b 
		WHERE  b.type = '1' AND b.sub_type = '1' AND b.`status` = '1' AND b.longitude is NOT NULL AND b.latitude is NOT NULL
		AND b.grid_code is NOT NULL
		GROUP BY grid_code;

		-- 加盟店
		INSERT INTO field_data_website(field, `value`, `key`)
		select  grid_code,count(1), 'franchised_store_website_count' 
		from t_website_m b 
		WHERE  b.type = '1' AND b.sub_type = '2' AND b.`status` = '1' AND b.longitude is NOT NULL AND b.latitude is NOT NULL
		AND b.grid_code is NOT NULL
		GROUP BY grid_code;

		-- 手机卖场
		INSERT INTO field_data_website(field, `value`, `key`)
		select  grid_code,count(1), 'mobile_store_website_count' 
		from t_website_m b 
		WHERE  b.type = '1' AND b.sub_type = '3' AND b.`status` = '1' AND b.longitude is NOT NULL AND b.latitude is NOT NULL 
		AND b.grid_code is NOT NULL
		GROUP BY grid_code;

		-- 授权店
		INSERT INTO field_data_website(field, `value`, `key`)
		select  grid_code,count(1), 'authorized_store_website_count' 
		from t_website_m b 
		WHERE  b.type = '1' AND b.sub_type = '4' AND b.`status` = '1' AND b.longitude is NOT NULL AND b.latitude is NOT NULL
		AND b.grid_code is NOT NULL
		GROUP BY grid_code;

		-- 自营直销渠道
		INSERT INTO field_data_website(field, `value`, `key`)
		select  grid_code,count(1), 'self_marketing_website_count' 
		from t_website_m b 
		WHERE  b.type = '2' AND b.sub_type = '5' AND b.`status` = '1' AND b.longitude is NOT NULL AND b.latitude is NOT NULL
		AND b.grid_code is NOT NULL
		GROUP BY grid_code;

		-- 社会直销渠道
		INSERT INTO field_data_website(field, `value`, `key`)
		select  grid_code,count(1), 'social_direct_selling_website_count' 
		from t_website_m b 
		WHERE  b.type = '2' AND b.sub_type = '6' AND b.`status` = '1' AND b.longitude is NOT NULL AND b.latitude is NOT NULL
		AND b.grid_code is NOT NULL
		GROUP BY grid_code;
		
		-- 联通
		INSERT INTO field_data_website(field, `value`, `key`)
		select  grid_code,count(1), 'unicom_website_count' 
		from t_website_m b 
		WHERE  b.type = '5' AND b.sub_type = '7' AND b.`status` = '1' AND b.longitude is NOT NULL AND b.latitude is NOT NULL
		AND b.grid_code is NOT NULL
		GROUP BY grid_code;

		-- 电信
		INSERT INTO field_data_website(field, `value`, `key`)
		select  grid_code,count(1), 'telecom_website_count' 
		from t_website_m b 
		WHERE  b.type = '5' AND b.sub_type = '8' AND b.`status` = '1' AND b.longitude is NOT NULL AND b.latitude is NOT NULL
		AND b.grid_code is NOT NULL
		GROUP BY grid_code;
		
		-- 插入微网格数据 
		
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-4),',',1),
					SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-3),',',1),
					SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-2),',',1),
					a.field,a.`key`,a.`value`,'system',NOW(),'system',NOW() 
		FROM
					field_data_website a,
				t_grid_m m WHERE m.`code` = a.field and a.field IS NOT NULL and m.`level` = 5
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;
		
		-- 插入微网格数据结束 
		
		-- 获取网格下的微网格数量，插入网格层级中 
		    --  获取网格下的微网格数量，插入网格层级中 
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-3),',',1),
					SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-2),',',1),
					m.`code` as code,
					'','field_count',
					count(m1.`code`) as child_count,
					'system',NOW(),'system',NOW() 
		FROM t_grid_m m
		LEFT JOIN t_grid_m m1
		ON m.code= m1.parent_code where m.level = 4 GROUP BY m.code
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;


		-- 获取区县下的网格数量，插入区县层级  
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT 
		SUBSTRING_INDEX(SUBSTRING_INDEX(m.all_parent_code,',',-2),',',1),
		m.`code` as code,
		'' as net_grid,'' as field,
		'grid_count' as `key`,
		count(m1.`code`) as child_count,
		'system',NOW(),'system',NOW() 
		FROM t_grid_m m
		LEFT JOIN t_grid_m m1
		ON m.code= m1.parent_code where m.level = 3 GROUP BY m.code
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;
		

		-- 三、把微网格的数据向上汇总，从微网格汇总到网格，从网格汇总到区县，从区县汇总到城市，从城市汇总到省开始-->
		
		
		-- 1.汇总微网格数据到网格 (有效用户数不需要把微网格数据汇总到网格)(暂时不汇总网格经理个数和微网格经理个数)
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT city, district, net_grid, "", s.`key`, sum(if(IFNULL(`value`, '') = '', 0, `value`)) , 'system', now(), 'system', now() 
		FROM t_grid_statistics s 
		WHERE field != ""  and field IS NOT NULL AND `key` not in ('mobile_effectivecustomer_count') and s.`key` NOT IN (SELECT k.key_name from not_contain_of_key_list k)
		GROUP BY s.city, s.district, net_grid, s.`key`
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;

	-- 2.汇总网格数据到分公司 
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT s.city, s.district, "", "", s.`key`, sum(if(IFNULL(`value`, '') = '', 0, `value`)) , 'system', now(), 'system', now() 
		FROM t_grid_statistics s 
		WHERE net_grid !="" and field ="" and s.`key` NOT IN (SELECT k.key_name from not_contain_of_key_list k)
		GROUP BY s.city, s.district, s.`key`
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;
	
		-- 3.汇总分公司数据到城市 
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT city, "", "", "", s.`key`, sum(if(IFNULL(`value`, '') = '', 0, `value`)) , 'system', now(), 'system', now() 
		FROM t_grid_statistics s 
		WHERE district !="" and net_grid ="" and field ="" and s.`key` NOT IN (SELECT k.key_name from not_contain_of_key_list k) 
		GROUP BY s.city, s.`key`
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;
				
		-- 4.汇数据城市到省 
		INSERT INTO t_grid_statistics ( city, district, net_grid, field,`key`,`value`,create_user,create_date,modify_user,modify_date)
		SELECT "", "", "", "", s.`key`, sum(if(IFNULL(`value`, '') = '', 0, `value`)) , 'system', now(), 'system', now() 
		FROM t_grid_statistics s 
		WHERE city != "" and district ="" and net_grid ="" and field ="" 
		and s.`key` NOT IN (SELECT k.key_name from not_contain_of_key_list k)
		GROUP BY s.`key`
		ON DUPLICATE KEY UPDATE `value`=values(`value`), modify_user=values(modify_user), modify_date=values(modify_date)
		;
		
		-- 把责任田的数据向上汇总，从责任田汇总到网格，从网格汇总到分公司，从分公司汇总到城市，从城市汇总到省结束 -->


END
;;
DELIMITER ;

-- ----------------------------
-- Function structure for f_get_type
-- ----------------------------
DROP FUNCTION IF EXISTS `f_get_type`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` FUNCTION `f_get_type`(`as_type` varchar(50)) RETURNS varchar(50) CHARSET utf8mb4
BEGIN
	if as_type = '城市小区' then 
		return 1;
	elseif as_type = '开放小区' then 
	 return 2;
	elseif as_type = '封闭小区' then 
		return 3;
	elseif as_type = '企业宿舍' then 
		return 4;
	elseif as_type = '机关宿舍' then 
		return 5;
	elseif as_type = '自然村' then 
		return 6;
	elseif as_type = '农村社区' then 
		return 7;
	elseif as_type = '封闭' then 
		return 8;
	elseif as_type = '高校校园' then 
		return 9;
	elseif as_type = '普通校园' then 
		return 10;
  elseif as_type = '开发小区' then 
	  return 11;
	end if;

	RETURN '';
END
;;
DELIMITER ;

-- ----------------------------
-- Function structure for f_get_uptown_type
-- ----------------------------
DROP FUNCTION IF EXISTS `f_get_uptown_type`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` FUNCTION `f_get_uptown_type`(`as_type` varchar(50)) RETURNS varchar(50) CHARSET utf8mb4
BEGIN
	if as_type = '城市小区' then 
		return 1;
	elseif as_type = '开放小区' then 
	 return 2;
	elseif as_type = '封闭小区' then 
		return 3;
	elseif as_type = '企业宿舍' then 
		return 4;
	elseif as_type = '机关宿舍' then 
		return 5;
	elseif as_type = '自然村' then 
		return 6;
	elseif as_type = '农村社区' then 
		return 7;
	elseif as_type = '封闭' then 
		return 8;
	elseif as_type = '高校校园' then 
		return 9;
	elseif as_type = '普通校园' then 
		return 10;
	elseif as_type = '开发小区' then 
	  return 11;
	end if;

	RETURN '';
END
;;
DELIMITER ;

-- ----------------------------
-- Function structure for GetNum
-- ----------------------------
DROP FUNCTION IF EXISTS `GetNum`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` FUNCTION `GetNum`(Varstring varchar(50)) RETURNS varchar(30) CHARSET utf8mb4
BEGIN
DECLARE v_length INT DEFAULT 0;
DECLARE v_Tmp varchar(50) default '';
set v_length=CHAR_LENGTH(Varstring);
WHILE v_length > 0 DO
IF (ASCII(mid(Varstring,v_length,1))>47 and ASCII(mid(Varstring,v_length,1))<58 )   THEN
set v_Tmp=concat(v_Tmp,mid(Varstring,v_length,1));
END IF;
SET v_length = v_length - 1;
END WHILE;
RETURN REVERSE(v_Tmp);
END
;;
DELIMITER ;

-- ----------------------------
-- Function structure for SPLIT_STR
-- ----------------------------
DROP FUNCTION IF EXISTS `SPLIT_STR`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` FUNCTION `SPLIT_STR`(x VARCHAR(255),   delim VARCHAR(12),   pos INT) RETURNS varchar(255) CHARSET utf8
RETURN REPLACE(SUBSTRING(SUBSTRING_INDEX(x, delim, pos),        LENGTH(SUBSTRING_INDEX(x, delim, pos -1)) + 1),        delim, '')
;;
DELIMITER ;

-- ----------------------------
-- Event structure for updateStatistics_event
-- ----------------------------
DROP EVENT IF EXISTS `updateStatistics_event`;
DELIMITER ;;
CREATE DEFINER=`dcp_admin`@`%` EVENT `updateStatistics_event` ON SCHEDULE EVERY 5 MINUTE STARTS '2019-03-25 09:04:53' ON COMPLETION PRESERVE DISABLE DO call updateStatisticsGridIndicatorsSD()
;;
DELIMITER ;
